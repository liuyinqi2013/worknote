#!/bin/sh
#clean all ipcs created by middle
#change SERVERNO is the same as trpc.conf 

SERVERNO=64
COUNTER=0

KEY1=8011
KEY2=8012

ipcrm -S $KEY2
ipcrm -S $KEY1

ipcrm -M $KEY1 
ipcrm -M $KEY2

while [ $COUNTER -lt $SERVERNO ]
do
	MQKEY=`expr $COUNTER + $KEY2`
	ipcrm -Q $MQKEY
	COUNTER=`expr $COUNTER + 1`
done
