/*
    lvs ���ű�
        added by verminniu
*/


#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/time.h>
#include <sys/types.h>
#include <assert.h>

#define LVS_DEBUG

#ifndef false
#define false (0 != 0)
#endif

#ifndef true
#define true (0 == 0)
#endif


#ifdef      LVS_DEBUG
#define     LVS_TEST_LOG(...)  fprintf(stderr, __VA_ARGS__);
#define     LVS_TEST_LOG(...)  fprintf(stderr, __VA_ARGS__);
#else
#define     LVS_TEST_LOG(...)  // do nothing
#define     LVS_TEST_LOG(...)  // do nothing
#endif

#include "trpc_client.h"
#include "trpc_error.h"

static TRPC_INFO *g_pTrpcHnd = NULL;

static int
test_Login(const char * sIP,
	int iPort,
	const char * sUser,
	const char * sPass,
	int iTimeOut)
{
    int iRetVal;

    g_pTrpcHnd = trpc_info_create(sIP, iPort, sUser, sPass, iTimeOut);
    iRetVal = trpc_open(g_pTrpcHnd);
    if (iRetVal == TRPC_ERR_PASSWD){
        LVS_TEST_LOG("ret: %d info %s\n", iRetVal, trpc_error(g_pTrpcHnd));
        return 1;
    }
    
    if (iRetVal != 0) {
        LVS_TEST_LOG("ret: %d info %s\n", iRetVal, trpc_error(g_pTrpcHnd));
        return -1;
    }

    return 0;
}

static char *
strupper(char *str)
{
    char *p;
    for (p = str; *p != '\0'; ++p) {
        *p = toupper(*p);
    }
    return str;
}

static char *
get_rand_str(char *str, int len)
{
    static char *char_table =
        "1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
    size_t chars_len = strlen(char_table);
    int i;

    // ���������
    struct timeval tval;
    gettimeofday(&tval, NULL);
    srand(tval.tv_sec * tval.tv_usec * getpid());

    for (i = 0; i < len; ++i) {
        str[i] =
            char_table[(int) ((float) chars_len * rand() / (RAND_MAX + 1.0))];
    }
    str[len - 1] = '\0';
    return str;
}

static int
test_send(int iCount)
{
    char sIn[32];
    char sOut[32];
    char sStrUpper[32];
    size_t iOutSize;
    int iRetVal;
    int i;

    for (i = 0; i < iCount; ++i) {
        get_rand_str(sIn, 16);
        strcpy(sStrUpper, sIn);
        strupper(sStrUpper);

        iOutSize = sizeof(sOut);
        iRetVal = trpc_call(g_pTrpcHnd, "warning_service",
                            sIn, strlen(sIn), sOut, &iOutSize);
        
        // if not find service return 0
        if ((iRetVal == TRPC_ERR_SERVICE) || (iRetVal == TRPC_ERR_PASSWD)){
            LVS_TEST_LOG("ret: %d info %s\n", iRetVal, trpc_error(g_pTrpcHnd));
            return 1;
        }
        
        if (iRetVal != 0) {
            LVS_TEST_LOG("ret: %d info %s\n", iRetVal, trpc_error(g_pTrpcHnd));
            return -1;
        }

        if (strncmp(sStrUpper, sOut, strlen(sStrUpper)) != 0){
            LVS_TEST_LOG("ERROR: %s != %s\n", sOut, sStrUpper);
            return -1;
        }

        LVS_TEST_LOG("sIn:  [%s]\n", sIn);
        LVS_TEST_LOG("sOut: [%s]\n", sOut);
    }

    return 0;
}

int
main(int argc, char **argv)
{
    char sIP[32] = "0";
    int iPort = 28000;
    char sUser[32] = "trpc";
    char sPass[32] = "middle";
    int iTimeOut = 10;
    int iNum = 0;
    int  ch = 0;
    int ret = 0;

    while ((ch = getopt(argc, argv, "h:p:n:")) != -1)
    {
        switch (ch) {
        case 'h':  
            strncpy(sIP, optarg,sizeof(sIP));
            break;
        case 'p':  
            iPort  = atoi( optarg);
            break;
        case 'n':  
            iNum  = atoi( optarg);
            break;
        default:
            exit(1);
            break;
        }
    } 

    if ((ret = test_Login(sIP, iPort, sUser, sPass, iTimeOut)) != 0){
        if (ret >= 0){
            exit(0);
        } else {
            exit(-1);
        }
    }
	
	if ((ret = test_send(iNum)) != 0){
        if (ret >= 0){
            exit(0);
        } else {
            exit(-1);
        }
    }

    exit(0);
}
