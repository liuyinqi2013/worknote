#!/bin/sh

#stop_from_file.sh
#ֹͣ�����ļ��е�����server

SOCKETBIN="/usr/local/middle/bin/usr/bin/socket"

if [ $# -ne 1 ];then
	echo "use :stop_from_file ServerNameFile"
	exit
fi

while read ServerName
do
	echo "stop ${ServerName}" | ${SOCKETBIN} -c -q 0 28001
done < $1