#include <stdio.h>
#include <stdlib.h>

#include "trpc_queue.h"

int main(int argc,char **  argv)
{
    if ( argc != 5)
    {
		printf("Use: %s QueueIpcKey MaxServerNo MaxProcessNo MaxMqNum\n",argv[0]);
        return 0;
    }
        
    CTrpcQueue * pQueue = new CTrpcQueue(atoi(argv[1]),
                                 atoi(argv[2]),
                                 atoi(argv[3]),
                                 256,
                                 atoi(argv[4]),
                                 15, 5, 50, 5);
        
    int iRetVal = pQueue->Open();
    if (iRetVal < 0) {
        return -1;
    }

    pQueue->PrintServerMqInfo(printf);
        
    return 0;
}
