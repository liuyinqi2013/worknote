#include "arithmetic.h"

#include "des.h"

CArithmetic::CArithmetic()
{

}

CArithmetic::~CArithmetic()
{

}
/*���ñ��Ĵ������ߺ���*/
int CArithmetic::Bcd2ToAscii(const char *bcd,int len,int align,char *ascii)
{
	char *tbl="0123456789ABCDEF";
	int i,j;
	char *tmpbuf;
	tmpbuf=(char *) malloc((len+1)*sizeof(char));
	memset(tmpbuf,'0',len+1);
	if((align!=0)&&(len%2)!=0)//�Ҷ���
	{
		memcpy(tmpbuf+1,bcd,len);
	}
	else	//�����
	{
		memcpy(tmpbuf,bcd,len);
	}
	for(i=0;i<((len+1)/2);i++)
	{
		for(j=0;j<16;j++)
			if(*(tbl+j)==tmpbuf[2*i])
				break;
		if(j==16)
		{
			free(tmpbuf);
			return -1;
		}
		ascii[i]=j;
		ascii[i] = ascii[i] << 4;
		for(j=0;j<16;j++)
			if(*(tbl+j)==tmpbuf[2*i+1])
				break;
		if(j==16)
		{
			free(tmpbuf);
			return -1;
		}
		ascii[i] += j;
	}	
	free(tmpbuf);
	return (len+1)/2;
};
/*
��0x30ת��Ϊ"30"
*/
int CArithmetic::AsciiToBcd2(const char *ascii,int len,char *bcd,int mode)
{
	char *tbl2="0123456789ABCDEF";	
	char *tbl1="0123456789:;<=>?";
	char *tbl;
	
	if(mode == 0)
	    tbl = tbl2;
	else
	    tbl = tbl1;
	
	unsigned char t;
	for(int i=0;i<len;i++)
	{
		t=(ascii[i]&(0xf0));
		t=t>>4;
		bcd[2*i]=*(tbl+t);
		t=(ascii[i]&(0x0f));
		bcd[2*i+1]=*(tbl+t);		
	}	
	return (2*len);
};


void CArithmetic::Des3(const char *key, const char *indata, char *res)
{
	unsigned char data[8];
	memset(data,0,sizeof(data));
	CDes des;
	des.EnCode((pbyte) indata,(pbyte) data,(pbyte) key);
	des.DeCode((pbyte) data,(pbyte) data,(pbyte)(key+8));
	des.EnCode((pbyte) data,(pbyte)data,(pbyte) key);
	memcpy(res,data,8);	
}

void CArithmetic::GenSonKey(const char *tmk, const char *sid, char *tak)
{
	int i;
	unsigned char data[8];
	memcpy(data,sid,sizeof(data));
	Des3(tmk,(const char *)data,tak);
	
	/*xor*/
	for(i=0;i<8;i++)
	{
		data[i]^=0xFF;
	}
	
	/**/
	Des3(tmk,(const char *)data,tak+8);
}

void CArithmetic::GenMac(const byte *content, int len, const byte *key, byte *mac)
{
	int i,j,k;
	byte tmp[8];
	CDes des;
	memset(tmp,0,sizeof(tmp));
	byte tmpbuf[1024];
	memset(tmpbuf,0,sizeof(tmpbuf));
	memcpy(tmpbuf,content,len);
	memset(tmpbuf+len,0x80,1);
	j=len/8+(((len%8)==0)?0:1);
	for(i=0;i<j;i++)
	{
		for(k=0;k<8;k++)
		{
			mac[k]^=tmpbuf[i*8+k];
		}
		if(i<j-1)
			des.EnCode(mac,tmp,key);
		else
			Des3((char *)key,(char *)mac,(char *)tmp);
		memcpy(mac,tmp,8);
	}
}
void CArithmetic::GenYBSMac(const byte *content, int len, const byte *key, byte *mac)
{
	int i,j,k;
	byte tmp[8];
	CDes des;
	memset(tmp,0,sizeof(tmp));
	byte tmpbuf[1024];
	memset(tmpbuf,0,sizeof(tmpbuf));
	memcpy(tmpbuf,content,len);
	//memset(tmpbuf+len,0x80,1);
	j=len/8+(((len%8)==0)?0:1);
	for(i=0;i<j;i++)
	{
		for(k=0;k<8;k++)
		{
			mac[k]^=tmpbuf[i*8+k];
		}
		des.EnCode(mac,tmp,key);
		memcpy(mac,tmp,8);
	}
}
void CArithmetic::UnDes3(const char *key, const char *indata, char *res)
{
	unsigned char data[8];
	memset(data,0,sizeof(data));
	CDes des;
	des.DeCode((pbyte) indata,(pbyte) data,(pbyte) key);
	des.EnCode((pbyte) data,(pbyte) data,(pbyte)(key+8));
	des.DeCode((pbyte) data,(pbyte)data,(pbyte) key);
	memcpy(res,data,8);	
}

int DesEncrypt(string strOutAttach, string& strInAttach)
{
    char szbuf[1024]= {0};

    strncpy(szbuf, strInAttach.c_str(), sizeof(szbuf));

    //printf("szbuf=%s\n",szbuf);

    CArithmetic ar;
    char szKey[16] = {0};

    char *srcStr;
    char *stEnData;
    char *szBase64Data;

    char    mkey[16];
    char    elm[8];
    char    wkey[16];

    memcpy(mkey,"\x11\x11\x11\x11\x11\x11\x11\x11\x22\x22\x22\x22\x22\x22\x22\x22",16);
    memcpy(elm,"\x00\x00\x00\x00\x00\x00\x00\x00",8);

    ar.GenSonKey(mkey,elm,wkey);

    printf("after GenSonKey\n");

    for(int i=0; i<8; i++)
    {
        wkey[i] ^=wkey[8+i];
    }
    const std::string  key = wkey;
	

    int len = strlen(szbuf);
    int enLen = (len%8)==0?len:((len/8+1)*8);

    srcStr = new char[enLen+1];
    memset(srcStr, 0, enLen+1);
    strncpy(srcStr,szbuf, enLen );

    stEnData = new char[enLen+1];
    memset(stEnData, 0, enLen+1);

    int bcdlen= ((enLen+2)/3)*4;
    szBase64Data=new char[bcdlen+1];
    memset(szBase64Data, 0, bcdlen+1);
    ar.Bcd2ToAscii(key.c_str(), 32, 0, szKey);

    int times= len/8 + (((len%8)==0)?0:1);
    for(unsigned int index=0; index<times ; index++)
    {
        ar.Des3(szKey, srcStr+8*index,  stEnData+8*index);
    }

    char szTmp[4096]= {0};
    Base64_Encode((const unsigned char*)stEnData,enLen,szTmp,sizeof(szTmp),&enLen);

    strOutAttach = szTmp;

    delete stEnData;
    delete szBase64Data;
    return 0;
}

int DesDecrypt(string& stOutAttach, const string& strInAttach)
{
    int iSize;
    char szTmp[4096]= {0};
    if(Base64_Decode(strInAttach.c_str(), strInAttach.size(), (unsigned char*)szTmp, sizeof(szTmp), &iSize) != 0)
    {
        return -1;
    }

    CArithmetic ar;
    char szKey[16] = {0};
    char *stEnData, *szResult;

    char    mkey[16];
    char    elm[8];
    char    wkey[16];

    memcpy(mkey,"\x11\x11\x11\x11\x11\x11\x11\x11\x22\x22\x22\x22\x22\x22\x22\x22",16);
    memcpy(elm,"\x00\x00\x00\x00\x00\x00\x00\x00",8);

    ar.GenSonKey(mkey,elm,wkey);

    printf("after GenSonKey\n");

    for(int i=0; i<8; i++)
    {
        wkey[i] ^=wkey[8+i];
    }
    const std::string  key = wkey;
	
    int enLen= ((iSize)%8)==0?(iSize):( (iSize/8+1)*8 ) ;
    stEnData = new char[enLen];
    memset(stEnData, 0, enLen);
    memcpy(stEnData, szTmp, iSize);

    szResult = new char[enLen+1];
    memset(szResult, 0, enLen+1);

    ar.Bcd2ToAscii(key.c_str(), 32, 0, szKey);

    int times= enLen/8;

    for(unsigned int index=0; index<times ; index++)
    {
        ar.UnDes3(szKey, stEnData+8*index, szResult+8*index  );
    }

    stOutAttach = szResult;

    delete stEnData;
    delete szResult;
    return 0;
}

