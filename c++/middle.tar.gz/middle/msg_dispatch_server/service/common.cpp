#include "sstring.h"
#include <string>
#include <time.h>
#include <vector>
#include "relayProxy.h"
#include "CftRequest.h"
//#include "action_service.h"
#include "msg_dispatch_service.h"
#include "CBaseType.h"
#include "common.h"

#define RELAY_ERR_LOG_PATH		"/usr/local/middle/log/action_server/relay_action_server.log"

extern CConfig* gPtrConfig; // ȫ������ָ��

void InitCftSecRelayProxy ( RelayProxy & relay )
{
//    char szServerIp[20] = { 0 };
//    char szFailCallSavePath[256] = "/usr/local/middle/log/action_server/relay_action_server.log";
//    int tmout = 10;

//    memcpy(szServerIp, gPtrConfig->sRelayIP.c_str(), sizeof(szServerIp));
//    tmout = gPtrConfig->cftSecRelayCfg.cftrelay_timeout;
    
///    if( szServerIp[0] == '\0' )
//    {
//        throw CException(ERR_APP_PARAM, "InitCftRelayProxy::bad relay IP!");
//    }
    relay.addServer (gPtrConfig->sRelayIP, gPtrConfig->iRelayPort);
    relay.setTimeout ( gPtrConfig->iRelayTimeOut);
    relay.setFailCallSavePath ( RELAY_ERR_LOG_PATH );
    return;
}

void CftSecRelayRequest(int request_type, const char *sp_id, CStr2Map &mapReq, RequestBase &tPayResult, int bModeEncrypted)
{
    struct timeval tv1,tv2;
    
    CgiRequest tCftSecRealyReq( request_type , sp_id, "", bModeEncrypted );
    RelayProxy  relay;
    CStr2Map::iterator iter = mapReq.begin();

    InitCftSecRelayProxy ( relay ); 
    while(mapReq.end() != iter)
    {
        //tCftSecRealyReq.setValue(iter->first.c_str(),iter->second.c_str());
        tCftSecRealyReq.setValue(iter->first,iter->second);
        iter++;
    }
    //gPtrAppLog->debug("[%s:%d] tCftSecRealyReq=[%s]", __FILE__, __LINE__, ((RequestBase*)(&tCftSecRealyReq))->pack("&").c_str());
    string strPayRequest = tCftSecRealyReq.pack ( "&" );
    gettimeofday(&tv1,NULL); //����ǰʱ��
    relay.call ( strPayRequest, tPayResult );
    gettimeofday(&tv2,NULL);//���ú�ʱ��
    
    long long CallTimeBegin=0,CallTimeEnd=0,calltime=0;
    CallTimeBegin=tv1.tv_sec*1000000+tv1.tv_usec;
    CallTimeEnd=tv2.tv_sec*1000000+tv2.tv_usec;
    
    calltime=CallTimeEnd-CallTimeBegin;    //���û���ʱ��
    gPtrAppLog->error("===call cft relay[%d] with[%s] cost[%08lld]===",request_type,strPayRequest.c_str(),calltime);
    return;
}
