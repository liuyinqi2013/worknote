/*
 * CUpdateDispatch.cpp
 *
 *  Created on: 2014-7-3
 *      Author: jiejf
 */

#include "CUpdateDispatch.h"
#include "msg_dispatch_common.h"
#include "myTime.h"
#include "timeStamp.h"


using namespace std;

extern CConfig* gPtrConfig;
extern CCftLogger* gPtrAppLog;
extern CCftLogger* gPtrSysLog;
extern CMySQL* gPtrMysql;

CUpdateDispatch::CUpdateDispatch()
{

}

CUpdateDispatch::~CUpdateDispatch()
{

}

void CUpdateDispatch::ProcessMsg(TRPC_SVCINFO* pRequst)
throw (CException)
{
    gPtrAppLog->debug("CUpdateDispatch ProcessMsg begin");

    // ��������
    KeyValueMap objInMap;
    KeyValueMap objOutMap;

    //����Ĳ���������ΪMAP����
    string strInBuf = pRequst->idata;
    analyzeCgiParam(strInBuf, objInMap, ANALYZE_PARAM_NONE);

    string strMsgID = getSafeInput(objInMap["msg_id"]);
    string strState = getSafeInput(objInMap["state"]);
    string strUserType = getSafeInput(objInMap["user_type"]);
    gPtrAppLog->debug("[strMsgID=%s][strState=%s][strUserType=%s]",
                      strMsgID.c_str(),strState.c_str(),strUserType.c_str());
    if((0 == strMsgID.length()) ||(0 == strState.length()) ||(0 == strUserType.length()))
    {
        throw CException(INPUT_PARAMETER_FAIL, ERR_INPUT_PARAMETER);
    }

    try
    {
        gPtrMysql->Begin();

        _ST_MessageSndReq req;
        req.strMsgId = strMsgID;
        req.strState = strState;
        int nType = atoi(strUserType.c_str());

        {
            QueryMessageSndReq(req,nType);

            if((atoi(req.strSndNum.c_str()))>=(atoi(req.strMaxNum.c_str())-1))
            {
                DeleteMessageSndReq(req,nType);
                req.strState = strState;
                gPtrAppLog->debug("req.strSndNum=%s", req.strSndNum.c_str());
                req.strSndNum = i2s(atoi(req.strSndNum.c_str()) + 1);
                gPtrAppLog->debug("req.strSndNum=%s", req.strSndNum.c_str());
                InsertMessageSndResult(req,nType);
            }
            else
            {
                UpdateMessageSndReq(req,  nType);
            }
        }

		{
            gPtrAppLog->debug("req.strModifyTime=%s", req.strModifyTime.c_str());

            if(("4" == strState) ||((atoi(req.strSndNum.c_str()))>=(atoi(req.strMaxNum.c_str())-1)))
            {
                DeleteMessageSndReq(req,nType);
                req.strState = strState;
                gPtrAppLog->debug("req.strSndNum=%s", req.strSndNum.c_str());
                req.strSndNum = i2s(atoi(req.strSndNum.c_str()) + 1);
                gPtrAppLog->debug("req.strSndNum=%s", req.strSndNum.c_str());
                InsertMessageSndResult(req,nType);
            }
            else
            {
                UpdateMessageSndReq(req,  nType);
            }
        }

        gPtrMysql->Commit();

        packMessage(PACKMSG_TYPE_OK, "", pRequst, PACKMSG_TYPE_OK);

        gPtrAppLog->debug("uncode service End ...");
    }
    catch(CException &e)
    {
        //�ع�
        gPtrMysql->Rollback();
        throw CException(e.error(), e.what());
    }
}


