#if !defined _CODE_DES_H_

#define _CODE_DES_H_



#include <string.h>

#include <stdlib.h>

#include <stdio.h>
#include <string>
#include "base64.h"




typedef unsigned char byte;

class CDes

{

private:

    void cipher(byte *input, byte *output, byte mode);

    void rotate(byte* ptr, byte times);

    void function_rk(byte *input, byte *output, byte *key);

    void do_ip(byte *input, byte *output, byte *table);

    byte ip_table[64];

    byte inv_ip_table[64];

    byte exp_table[48];

    byte perm_table[48];

    byte perm_choice1_C[28];

    byte perm_choice1_D[28];

    byte perm_choice2[48];

    byte shifts_table[16];

    byte sel_table[512];

    byte bitmapx[64];

    byte perm_keys[16][6];

    byte key[8];

    byte card_data[9];

    byte card_data1[9];



    void gen_keys();



public:

    void EnCode( byte *dg,byte *out,const byte *key_ptr);

    void DeCode( byte *dg,byte *out,const byte *key_ptr);

    CDes();

    virtual ~CDes();



};



#endif

