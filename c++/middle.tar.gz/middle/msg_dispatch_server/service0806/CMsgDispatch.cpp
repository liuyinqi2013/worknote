/*
 * CMsgDispatch.cpp
 *
 *  Created on: 2014-7-3
 *      Author: jiejf
 */

#include "CMsgDispatch.h"
#include "msg_dispatch_common.h"
#include "urlcodec.h"


using namespace std;

extern CConfig* gPtrConfig;
extern CCftLogger* gPtrAppLog;
extern CCftLogger* gPtrSysLog;
extern CMySQL* gPtrMysql;

CMsgDispatch::CMsgDispatch()
{

}

CMsgDispatch::~CMsgDispatch()
{

}

void CMsgDispatch::ProcessMsg(TRPC_SVCINFO* pRequst)
throw (CException)
{
    gPtrAppLog->debug("CMsgDispatch ProcessMsg begin");

    // ��������
    KeyValueMap objInMap;
    KeyValueMap objOutMap;

    //����Ĳ���������ΪMAP����
    string strInBuf = pRequst->idata;
    analyzeCgiParam(strInBuf, objInMap, ANALYZE_PARAM_NONE);
    
    string strUserId = getSafeInput(objInMap["user_id"]);
    string strBusinessType = getSafeInput(objInMap["business_type"]);
    string strMsgText = objInMap["msg_text"];
	string strMessageType = getSafeInput(objInMap["msg_type"]);

    try
    {
        gPtrMysql->Begin();        

        _ST_MessageSndReq reqMessageSnd;
        reqMessageSnd.strState = "1";
        reqMessageSnd.strUserId= strUserId;
        reqMessageSnd.strBusinessType= strBusinessType;
        reqMessageSnd.strMsgText = strMsgText;
        reqMessageSnd.strErrorCode = "";
        reqMessageSnd.strErrorInfo = "";
        reqMessageSnd.strSndNum = "0";
		reqMessageSnd.strMsgType= strMessageType;
        
        InsertMessageSndReq( reqMessageSnd, 2);

        gPtrMysql->Commit();

        packMessage(PACKMSG_TYPE_OK, "", pRequst, PACKMSG_TYPE_OK);

        gPtrAppLog->debug("uncode service End ...");
    }
    catch(CException &e)
    {
        //�ع�
        gPtrMysql->Rollback();
        throw CException(e.error(), e.what());
    }
}


