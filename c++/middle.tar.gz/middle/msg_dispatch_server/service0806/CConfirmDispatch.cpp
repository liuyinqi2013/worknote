/*
 * CConfirmDispatch.cpp
 *
 *  Created on: 2014-7-3
 *      Author: jiejf
 */

#include "CConfirmDispatch.h"
#include "msg_dispatch_common.h"

using namespace std;

extern CConfig* gPtrConfig;
extern CCftLogger* gPtrAppLog;
extern CCftLogger* gPtrSysLog;
extern CMySQL* gPtrMysql;

CConfirmDispatch::CConfirmDispatch()
{

}

CConfirmDispatch::~CConfirmDispatch()
{

}

void CConfirmDispatch::ProcessMsg(TRPC_SVCINFO* pRequst)
throw (CException)
{
    gPtrAppLog->debug("CConfirmDispatch ProcessMsg begin");

    // ��������
    KeyValueMap objInMap;
    KeyValueMap objOutMap;

    //����Ĳ���������ΪMAP����
    string strInBuf = pRequst->idata;
    analyzeCgiParam(strInBuf, objInMap, ANALYZE_PARAM_NONE);

    string strMsgID = getSafeInput(objInMap["msg_id"]);

    if(0 == strMsgID.length() )
    {
        throw CException(INPUT_PARAMETER_FAIL, ERR_INPUT_PARAMETER);
    }

    try
    {
        gPtrMysql->Begin();

        _ST_MessageSndReq req;
        req.strMsgId = strMsgID;
        int nType =  0;
        int nResult = TraverseMessageSndReq(req,nType);

        if(1 == nResult)
        {
            gPtrMysql->Rollback();
            gPtrAppLog->debug("this msgid do not meet the condition, can not dispatch message");
            throw CException(GET_RECORD_FROM_TABLE_FAIL, ERR_GET_RECORD_FROM_TABLE);
        }

        gPtrMysql->Commit();

        objOutMap["user_id"] = req.strUserId;
        objOutMap["msg_text"] = req.strMsgText;
        objOutMap["msg_type"] = req.strMsgType;
        //ҵ������ɺ�����������
        string strOutData ;
        objOutMap.GenString(strOutData);
        gPtrAppLog->debug("strOutData =%s", strOutData.c_str());
        packMessage(PACKMSG_TYPE_OK, strOutData.c_str(), pRequst, PACKMSG_TYPE_OK);

        gPtrAppLog->debug("confirm msg service End ...");
    }
    catch(CException &e)
    {
        //�ع�
        gPtrMysql->Rollback();
        throw CException(e.error(), e.what());
    }
}


