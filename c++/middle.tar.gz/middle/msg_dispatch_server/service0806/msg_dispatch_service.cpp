/**
 * FileName: msg_dispatch_service.cpp
 * Author: jiejf
 * Version :1.0
 * Date: 2014-03-25
 * Description:
 */

#include "msg_dispatch_service.h"
#include "accesslog.h"
#include    <CftLogger.h>
#include      "xml-config.h"
#include      "xmlHelper.h"

//1- ȷ���·�
#include "CConfirmDispatch.h"
//2- �����·�������Ϣ
#include "CUpdateDispatch.h"
//3- �ʼ��·�
#include "CMsgDispatch.h"



using namespace std;


CConfig* gPtrConfig = NULL; // ȫ������ָ��

CCftLogger* gPtrProcessLog = NULL; // ������־���ļ�ָ��
CCftLogger* gPtrAppLog = NULL; // ��־�ļ�ָ��
CCftLogger* gPtrSysLog = NULL; // ��־�ļ�ָ��
CMySQL* gPtrMysql = NULL; // mysql����


void getLogger(TiXmlNode* pNodeRecords, CCftLogger* &gPtrLog)
{
    TiXmlNode* pName = NULL;
    string suffix;
    string prefix;
    int i_level;
    int i_shiftMode;
    int i_maxFileSize;
    int i_maxBackupIndex;


    pName = pNodeRecords->FirstChild("suffix");
    if(pName == NULL)
    {
        stringstream ssErrMsg;
        ssErrMsg << "Not Find Node: " << "suffix";

        throw CException(ERR_NULL_XML_NODE, ssErrMsg.str());
    }
    suffix = XmlNodeWrapper(pName).getValue("");

    pName = pNodeRecords->FirstChild("prefix");
    if(pName == NULL)
    {
        stringstream ssErrMsg;
        ssErrMsg << "Not Find Node: " << "prefix";

        throw CException(ERR_NULL_XML_NODE, ssErrMsg.str());
    }
    prefix = XmlNodeWrapper(pName).getValue("");

    pName = pNodeRecords->FirstChild("level");
    if(pName == NULL)
    {
        stringstream ssErrMsg;
        ssErrMsg << "Not Find Node: " << "level";

        throw CException(ERR_NULL_XML_NODE, ssErrMsg.str());
    }
    i_level = atoi(XmlNodeWrapper(pName).getValue("").c_str());


    pName = pNodeRecords->FirstChild("shiftMode");
    if(pName == NULL)
    {
        stringstream ssErrMsg;
        ssErrMsg << "Not Find Node: " << "shiftMode";

        throw CException(ERR_NULL_XML_NODE, ssErrMsg.str());
    }
    i_shiftMode = atoi(XmlNodeWrapper(pName).getValue("").c_str());


    pName = pNodeRecords->FirstChild("maxFileSize");
    if(pName == NULL)
    {
        stringstream ssErrMsg;
        ssErrMsg << "Not Find Node: " << "maxFileSize";

        throw CException(ERR_NULL_XML_NODE, ssErrMsg.str());
    }
    i_maxFileSize = atoi(XmlNodeWrapper(pName).getValue("").c_str());


    pName = pNodeRecords->FirstChild("maxBackupIndex");
    if(pName == NULL)
    {
        stringstream ssErrMsg;
        ssErrMsg << "Not Find Node: " << "maxBackupIndex";

        throw CException(ERR_NULL_XML_NODE, ssErrMsg.str());
    }
    i_maxBackupIndex = atoi(XmlNodeWrapper(pName).getValue("").c_str());



    //gPtrLog = new CCftLogger(string("/usr/local/middle/log/test_server/test").c_str(),
    gPtrLog = new CCftLogger(prefix.c_str(),
                             i_maxFileSize * 1024 * 1024, i_maxBackupIndex,
                             CCftLogger::LOG_LEVEL(i_level),
                             CCftLogger::SHIFT_MODE(i_shiftMode));

    gPtrLog->setSuffix(suffix.c_str());

}

void initialLog()
{

    // �����ļ�
    XmlConfig config(MSG_DISPATCH_LOG_CONF);
    if( !config )
    {
        stringstream ssErrMsg;
        ssErrMsg << "XmlConfig Init [" << MSG_DISPATCH_LOG_CONF<< "]: " << config.getLastError();

        throw CException(ERR_LOAD_CFG, ssErrMsg.str());
    }

    TiXmlNode* pRootNode = config.getNode("/root");
    if(NULL == pRootNode )
    {
        stringstream ssErrMsg;
        ssErrMsg << "Not Find Node: " << "/root";

        throw CException(ERR_NULL_XML_NODE, ssErrMsg.str());
    }

    XmlNodeWrapper rootNode(pRootNode);

    TiXmlNode* pNodeRecords = rootNode->FirstChild("logCategory");
    if (pNodeRecords == NULL)
    {
        stringstream ssErrMsg;
        ssErrMsg << "Not Find Node: " << "logCategory";

        throw CException(ERR_NULL_XML_NODE, ssErrMsg.str());
    }
    getLogger(pNodeRecords, gPtrAppLog);


    pNodeRecords=pNodeRecords->NextSibling("logCategory");
    if (pNodeRecords == NULL)
    {
        stringstream ssErrMsg;
        ssErrMsg << "Not Find Node: " << "logCategory";

        throw CException(ERR_NULL_XML_NODE, ssErrMsg.str());
    }
    getLogger(pNodeRecords, gPtrSysLog);



    pNodeRecords=pNodeRecords->NextSibling("logCategory");
    if (pNodeRecords == NULL)
    {
        stringstream ssErrMsg;
        ssErrMsg << "Not Find Node: " << "logCategory";

        throw CException(ERR_NULL_XML_NODE, ssErrMsg.str());
    }
    getLogger(pNodeRecords, gPtrProcessLog);

    gPtrAppLog->debug("Begin  app debug  ...");
    gPtrAppLog->info("Begin  app info  ...");
    gPtrAppLog->error("Begin  app error  ...");

    gPtrSysLog->debug("Begin  sys debug...");
    gPtrSysLog->info("Begin  sys info...");
    gPtrSysLog->error("Begin  sys error...");

    gPtrProcessLog->debug("Begin  process debug...");
    gPtrProcessLog->info("Begin  process info...");
    gPtrProcessLog->error("Begin  process error...");


}



void fini_log()
{
    delete gPtrAppLog;
    gPtrAppLog = NULL;
    delete gPtrSysLog;
    gPtrSysLog = NULL;

}


/**
 * �����־
 */
void clearLog()
{
    // �ر���־
    delete gPtrAppLog;
    delete gPtrSysLog;
    delete gPtrProcessLog;
//  CCftLogger::shutdown();
}

/**
 * ��ʼ�������ļ�
 */
void newCfg()
{
    gPtrConfig = new CConfig(MSG_DISPATCH_SERVER_CONF);
}

/**
 * ��ʼ�������ļ�
 */
void initialCfg()
{
    gPtrConfig->readConf();
}

/**
 * ��������ļ�
 */
void clearCfg()
{
    delete gPtrConfig;
}
/**
 * ��ʼ�����ݿ�����
 */
void initialDB()
{
    if (gPtrConfig == NULL)
    {
        throw CException(ERR_LOAD_CFG, "gPtrConfig is NULL");
    }

    gPtrMysql = new CMySQL(gPtrConfig->m_strDBHost.c_str(),
                           gPtrConfig->m_strDBUser.c_str(), gPtrConfig->m_strDBPass.c_str(),
                           gPtrConfig->m_strDBPort.c_str(), gPtrConfig->m_iDBOverTime);

    gPtrMysql->Connect();

}

void clearDB()
{
    delete gPtrMysql;
    //  delete gPtrMysqlCS;
}
//��ڣ������￪ʼ
DECLARE_SO_INIT()
{
    newCfg();
    initialLog();

    // ��ȡ������
    try
    {
        initialCfg();

        initialDB();

        // ��ӡ������־
        gPtrSysLog->debug("msg_dispatch_server start ...");
    }
    catch(CException& e)
    {
        gPtrSysLog->error("DECLARE_SO_INIT failed: %d, %s", e.error(), e.what());
    }
}
//�����������˽���
DECLARE_SO_FINI()
{
    gPtrSysLog->debug("msg_dispatch_server stop ...");

    clearDB();
    clearCfg();
    clearLog();
//  fini_log();
}

// ������server�ڵ�service
// ���������

DECLARE_SERVICE(confirm_dispatch)
{
    gPtrAppLog->debug("confirm_dispatch:%s", rqst->idata);

    CAccessLog ObjTime(rqst->idata, "confirm_dispatch");

    try
    {
        CConfirmDispatch verifyService;
        verifyService.ProcessMsg(rqst);
    }
    catch(CException& e)
    {
        // ��¼������־
        gPtrAppLog->error("confirm_dispatch Error info %d,%s", e.error(), e.what());
        //ObjTime.setResult(e.error());
        // ������ؽ��
        packMessage(e.error(), e.what(), rqst, PACKMSG_TYPE_ERR);
    }

    // ��ӡ������Ϣ
    gPtrAppLog->debug("confirm_dispatch:%s", rqst->odata);
    // ������Ϣ
    trpc_return(rqst, 0);
}

DECLARE_SERVICE(update_dispatch)
{
    gPtrAppLog->debug("update_dispatch_req:%s", rqst->idata);

    CAccessLog ObjTime(rqst->idata, "update_dispatch_req");

    try
    {
        CUpdateDispatch verifyService;
        verifyService.ProcessMsg(rqst);
    }
    catch(CException& e)
    {
        // ��¼������־
        gPtrAppLog->error("update_dispatch_req Error info %d,%s", e.error(), e.what());
        //ObjTime.setResult(e.error());
        // ������ؽ��
        packMessage(e.error(), e.what(), rqst, PACKMSG_TYPE_ERR);
    }

    // ��ӡ������Ϣ
    gPtrAppLog->debug("update_dispatch_req:%s", rqst->odata);
    // ������Ϣ
    trpc_return(rqst, 0);
}


DECLARE_SERVICE(msg_dispatch)
{
    gPtrAppLog->debug("msg_dispatch:%s", rqst->idata);

    CAccessLog ObjTime(rqst->idata, "msg_dispatch");

    try
    {
        CMsgDispatch verifyService;
        verifyService.ProcessMsg(rqst);
    }
    catch(CException& e)
    {
        // ��¼������־
        gPtrAppLog->error("msg_dispatch Error info %d,%s", e.error(), e.what());
        //ObjTime.setResult(e.error());
        // ������ؽ��
        packMessage(e.error(), e.what(), rqst, PACKMSG_TYPE_ERR);
    }

    // ��ӡ������Ϣ
    gPtrAppLog->debug("msg_dispatch:%s", rqst->odata);
    // ������Ϣ
    trpc_return(rqst, 0);
}