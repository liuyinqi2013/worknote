#include "msg_dispatch_common.h"

extern CConfig* gPtrConfig; // ȫ������ָ��
extern CCftLogger* gPtrAppLog; // ��־�ļ�ָ��
extern CCftLogger* gPtrSysLog; // ��־�ļ�ָ��
extern CMySQL* gPtrMysql; // mysql����


int InsertMessageSndReq(_ST_MessageSndReq &req, int nType)
{
    stringstream sSQL;

    string strTableName;
    string strNo;

    strTableName = "message_db.t_message_snd_req";
    strNo = "Fuser_id";

    sSQL << "insert into "
         << strTableName
         << " ( Fcreate_time, Fmodify_time, Fstate, Fmsg_type, "
         << strNo
         << ", Fmsg_text, Ferror_code,Ferror_info, Fbusiness_type,  Fsnd_num, Fmax_num) values( "
         << "now()"  << ","
         <<"now()" << ",'"
         <<CMySQL::EscapeStr(req.strState) << "','"
         <<CMySQL::EscapeStr(req.strMsgType) << "','"
         <<CMySQL::EscapeStr(req.strUserId) << "','"
         <<CMySQL::EscapeStr(req.strMsgText) << "','"
         <<CMySQL::EscapeStr(req.strErrorCode) << "','"
         <<CMySQL::EscapeStr(req.strErrorInfo) << "','"
         <<CMySQL::EscapeStr(req.strBusinessType) << "','"
         <<CMySQL::EscapeStr(req.strSndNum) << "','"
         <<CMySQL::EscapeStr(req.strMaxNum)
         <<"')"         ;

    try
    {
        gPtrMysql->Query(sSQL.str().c_str(), sSQL.str().length());
    }
    catch(...)
    {
        gPtrAppLog->error("InsertMessageSndReq err throw, req.strMsgId[%s]", req.strMsgId.c_str());
        throw;
    }

    return 0;
}

int TraverseMessageSndReq(_ST_MessageSndReq &req,  int nType)
{
    stringstream sqlss;
    int nResult = -1;
    ostringstream ssErr;

    string strTableName;
    string strNo;

    strTableName = "message_db.t_message_snd_req";
    strNo = "Fuser_id";

    sqlss << " SELECT  Fmsg_id, Fbusiness_type, Fmsg_type,Fcreate_time,Fmodify_time,"
          <<"  Fstate, Fuser_id, Fmsg_text, Ferror_code, Ferror_info, Fsnd_num FROM   "
          << strTableName
          << "  WHERE Fmsg_id='" << req.strMsgId << "'"
          << "  and Fstate= 1"
          <<"   and Fsnd_num <= Fmax_num"  ;

    try
    {
        gPtrMysql->Query(sqlss.str().c_str(), sqlss.str().length());
    }
    catch(...)
    {
        ssErr << "TraverseMessageSndReq error Fmsg_id[" << req.strMsgId  << "] ";
        gPtrAppLog->error("%s", ssErr.str().c_str());
        throw CException(ERR_SYSTEM_G, ssErr.str().c_str());
    }

    KeyValueMap mTrans;
    nResult = gPtrMysql->FetchResultMap(mTrans);
    gPtrAppLog->debug("nResult[%d]", nResult);

    if(ERR_DB_SQL_NOVALUE == nResult)
    {
        gPtrAppLog->debug("the result not found");

        return  1;
    }
    else
    {
        req.strMsgText= mTrans["Fmsg_text"];
        req.strUserId= mTrans["Fuser_id"];
        req.strMsgType= mTrans["Fmsg_type"];
    }

    gPtrAppLog->debug("nResult[%d]", nResult);
    return nResult;

    return 0;
}

int UpdateMessageSndReq(_ST_MessageSndReq &req,  int nType)
{
    stringstream sSQL;
    ostringstream ssErr;

    string strTableName;
    string strNo;

    strTableName = "message_db.t_message_snd_req";
    strNo = "Fuser_id";

    sSQL << "update  "
         <<strTableName
         <<"   set  Fmodify_time= now() , Fsnd_num = Fsnd_num+1,"
         <<"   Fstate = '"
         <<req.strState
         <<"'  where  Fmsg_id='"
         <<CMySQL::EscapeStr(req.strMsgId)
         <<"'";
    try
    {
        gPtrMysql->Query(sSQL.str().c_str(), sSQL.str().length());
    }
    catch(...)
    {
        throw;
    }

    return 0;
}

int DeleteMessageSndReq(_ST_MessageSndReq &req,  int nType)
{
    stringstream sSQL;
    ostringstream ssErr;

    string strTableName;
    string strNo;

    strTableName = "message_db.t_message_snd_req";
    strNo = "Fuser_id";

    sSQL << "delete from "
         <<strTableName
         <<"   where  Fmsg_id='"
         <<CMySQL::EscapeStr(req.strMsgId)
         <<"'";
    try
    {
        gPtrMysql->Query(sSQL.str().c_str(), sSQL.str().length());
    }
    catch(...)
    {
        throw;
    }

    return 0;
}

int InsertMessageSndResult(_ST_MessageSndReq &req, int nType)
{
    stringstream sSQL;

    string strTableName;
    string strNo;

    strTableName = "message_db.t_message_snd_result";
    strNo = "Fuser_id";

    sSQL << "insert into "
         << strTableName
         << " ( Fcreate_time, Fmodify_time, Fstate, "
         << strNo
         << ", Fmsg_text, Ferror_code,Ferror_info, Fbusiness_type,"
         <<" Fmsg_type, Fsnd_num) values( '"
         <<CMySQL::EscapeStr(req.strCreateTime) << "',"
         <<"now()" << ",'"
         <<CMySQL::EscapeStr(req.strState) << "','"
         <<CMySQL::EscapeStr(req.strUserId) << "','"
         <<CMySQL::EscapeStr(req.strMsgText) << "','"
         <<CMySQL::EscapeStr(req.strErrorCode) << "','"
         <<CMySQL::EscapeStr(req.strErrorInfo) << "','"
         <<CMySQL::EscapeStr(req.strBusinessType)<< "','"
         <<CMySQL::EscapeStr(req.strMsgType) << "','"
         <<CMySQL::EscapeStr(req.strSndNum)
         <<"')"         ;

    try
    {
        gPtrMysql->Query(sSQL.str().c_str(), sSQL.str().length());
    }
    catch(...)
    {
        gPtrAppLog->error("InsertMessageSndResult err throw, req.strMsgId[%s]", req.strMsgId.c_str());
        throw;
    }

    return 0;
}

int QueryMessageSndReq(_ST_MessageSndReq &req,  int nType)
{
    stringstream sqlss;
    int nResult = -1;
    ostringstream ssErr;

    string strTableName;
    string strNo;

    strTableName = "message_db.t_message_snd_req";
    strNo = "Fuser_id";

    sqlss << " SELECT  Fmsg_id, Fbusiness_type, Fmsg_type,Fcreate_time,Fmodify_time,"
          <<"  Fstate, Fuser_id, Fmsg_text, Ferror_code, Ferror_info, Fsnd_num FROM   "
          << strTableName
          << "  WHERE Fmsg_id='" << req.strMsgId << "'";

    try
    {
        gPtrMysql->Query(sqlss.str().c_str(), sqlss.str().length());
    }
    catch(...)
    {
        ssErr << "TraverseMessageSndReq error Fmsg_id[" << req.strMsgId  << "] ";
        gPtrAppLog->error("%s", ssErr.str().c_str());
        throw CException(ERR_SYSTEM_G, ssErr.str().c_str());
    }

    KeyValueMap mTrans;
    nResult = gPtrMysql->FetchResultMap(mTrans);
    gPtrAppLog->debug("nResult[%d]", nResult);

    if(ERR_DB_SQL_NOVALUE == nResult)
    {
        gPtrAppLog->debug("the result not found");

        return  1;
    }
    else
    {
        req.strMsgText= mTrans["Fmsg_text"];
        req.strUserId= mTrans["Fuser_id"];
        req.strBusinessType= mTrans["Fbusiness_type"];
        req.strCreateTime= mTrans["Fcreate_time"];
        req.strErrorCode= mTrans["Ferror_code"];
        req.strErrorInfo= mTrans["Ferror_info"];
        req.strModifyTime= mTrans["Fmodify_time"];
        req.strMsgId= mTrans["Fmsg_id"];
        req.strSndNum= mTrans["Fsnd_num"];
        req.strState= mTrans["Fstate"];
        req.strMsgType = mTrans["Fmsg_type"];
    }

    gPtrAppLog->debug("nResult[%d]", nResult);
    return nResult;

    return 0;
}
