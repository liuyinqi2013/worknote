#ifndef   __VERIFY_COMMON_H_
#define   __VERIFY_COMMON_H_

#include "sstring.h"
#include <string>
#include "AirPlaneComm.h"
#include "exception.h"
#include "Config.h"
#include "Error.h"
#include "crypter.h"


//�����붨��
//�����Ȩ�ӿڵĴ�����
#define SUCCESS_RESULT                                                                              "SUCCESS_RESULT"
#define ERR_INPUT_PARAMETER                                                              "ERR_INPUT_PARAMETER_LENGTH"
#define ERR_GET_RECORD_FROM_TABLE                                             "ERR_GET_RECORD_FROM_TABLE"


#define SUCCESS_RESULTCODE                                                                               0
#define INPUT_PARAMETER_FAIL                                                              240101
#define GET_RECORD_FROM_TABLE_FAIL                                                        240116



/**
 * �����·���������
 */
struct _ST_MessageSndReq
{
    string strMsgId;
    string strCreateTime;
    string strModifyTime;
    string strState;
    string strUserId;//ͳһ���ڴ��ֶ���
    string strMsgText;
    string strErrorCode;
    string strErrorInfo;
    string strSndNum;
    string strBusinessType;
    string strMsgType;
    string strMaxNum;
};

enum OperType
{
    MOBILE = 1,
    EMAIL = 2,
};

struct _ST_SignKey
{
    string strUId;
    string strSpId;
    string strCreateTime;
    string strModifyTime;
    string strSignType;
    string strSignKey;
};

int InsertMessageSndReq(_ST_MessageSndReq &req,  int nType);

int TraverseMessageSndReq(_ST_MessageSndReq &req, int nType);

int UpdateMessageSndReq(_ST_MessageSndReq &req, int nType);

int DeleteMessageSndReq(_ST_MessageSndReq &req,  int nType);

int InsertMessageSndResult(_ST_MessageSndReq &req, int nType);

int QueryMessageSndReq(_ST_MessageSndReq &req,  int nType);

#endif
