//vi: set tabstop=4 shiftwidth=4 expandtab:
#ifndef _GHNTNKIT_H__
#define _GHNTNKIT_H__

#include "tinyxml.h"
#include <string>
#include <unistd.h>
using std::string;

//------------------------------------------------------------------------------
class GhNtnKit 
{
public:
    //@return 0 ok; else error
    static int IvkSoap(const string &stURL, const string &stData, string &stRet, string &stErr);

    //@return value or ""
    static const char *GetXMLValue(const TiXmlElement *pElem, const char *szName);

	static string DateTransform(string &date);
	static int ComAndEncode(string &stSrc, string &stDest);
	static int Conv(const char *fromCode, const char *toCode, string &fromStr, string &toStr);
	static string Utf82GBK(const string &stSRC);
	static string GBK2Utf8(const string &stSRC);
	static int CheckReturnCode(string &xmlStr);
	static string CentToYuan(string &stPrice);
	static string ToDateTime(const string &stDate, const string &stTime);
	static string ToTime(const string &stDateTime);
	static string Int2String(int integer);
	static void Upper(string &str);	
	static int Compress(const string &stSrc, string &stDest);
	
	static int CallGhNtnAPI(const string &stURL, string &stReq, string &stRet, 
	                        string &stErrMsg, const string &stServiceName);

private:
    GhNtnKit();
    ~GhNtnKit();
    GhNtnKit(const GhNtnKit &right);
    GhNtnKit & operator= (const GhNtnKit &right);
    
    static int Curl_Writer(char *data, size_t size, size_t nmemb, string *writerData);
};
//------------------------------------------------------------------------------
#endif

