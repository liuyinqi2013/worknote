#ifndef __C_SERVER_SHM_CMD_H
#define __C_SERVER_SHM_CMD_H

/*
����: 
       1.  ���ضԸ���Server�Ŀ�������ͨѶ�����ڴ���

Created by Song, 2003-01
Change list:

*/


#include <time.h>
#include <vector>
#include <string>

using namespace std;

#include "trpc.h"
#include "sv_semaphore.h"
#include "sv_shared_memory.h"


struct ServerCommand_T{
    time_t tInsertedTime;
    int iSeqNo;
    char sCommand[256];
    char sReserve[128];
};

class CServerShmCmd
{
public:
    CServerShmCmd(unsigned uMaxServerNo,
                unsigned uCmdsPerServer,
                char * pShmPtr,
                size_t uShmSize,
                SVSemaphore * pObjSem,
                int iSemNum);

    virtual ~CServerShmCmd();

    static void InitStatic(time_t tLastGetCmdTime,
            int iLastGetSeqNo,
            int iInsertSeqNo);
    
    const char * get_error_text() const {return _error_text;}

public:
    // ����һ������
    int Insert(unsigned uServerNo, const char * sCmd);

    // ȡ��Ч������
    int Get(unsigned uServerNo, vector<ServerCommand_T>& vCmd);

    int Reset(unsigned uServerNo);

    // �����Insert�ĵ�Ԫ����
    inline int _Insert(unsigned uServerNo,
            const char * sCmd,
            time_t tInsertTime,
            int iInsertSeqNo);

    const ServerCommand_T *GetRecord(unsigned uServerNo,
            unsigned uRecordNo);

    const void * GetShmPtr() const {return _pShmPtr;}
    
    static size_t GetShmSize(unsigned uMaxServerNo,
                unsigned uCmdsPerServer)
    {return sizeof(ServerCommand_T) * uMaxServerNo * uCmdsPerServer;}

    unsigned GetCmdsPerServer() const {return _uCmdsPerServer;}

public:
    inline int Lock();
    inline int UnLock();

private:
    inline ServerCommand_T *_GetServerCommandPtr(unsigned uServerNo);
    
public:
    // �⼸��������ҪΪ�˷��㵥Ԫ����
    static time_t GetLastGetCmdTime(){return _tLastGetCmdTime;}
    
    static int GetLastGetSeqNo(){return _iLastGetSeqNo;}
    
    static int GetInsertSeqNo(){return _iInsertSeqNo;}


    static void SetLastGetCmdTime(time_t tLastGetCmdTime)
        {_tLastGetCmdTime = tLastGetCmdTime;}
    
    static void SetLastGetSeqNo(int iLastGetSeqNo)
        {_iLastGetSeqNo = iLastGetSeqNo;}
    
    static void SetInsertSeqNo(int iInsertSeqNo)
        {_iInsertSeqNo = iInsertSeqNo;}

public:
    void PrintServerCommand_T(const ServerCommand_T * p,
        int (*fnPrintf)(const char * fmt, ...));

    int Print(unsigned uServerNo, int (*fnPrintf)(const char * fmt, ...));
    
private:
    static int CmpServerCommand_T(const void * a, const void * b);

    static int CmpServerCommand_T_2(time_t tInsertedTime,
                int iSeqNo,
                const ServerCommand_T * p);
    
private:
    static time_t _tLastGetCmdTime;  // �ϴ�get�����ʱ��
    static int _iLastGetSeqNo;  // �ϴ�get�����SeqNo

    static int _iInsertSeqNo;  // �ϴ�insert��SeqNo

    const unsigned _uMaxServerNo;
    const unsigned _uCmdsPerServer;
    
    char * _pShmPtr;
    size_t _uShmSize;
    char * _pShmEnd;

    SVSemaphore * _pObjSem;
    const int _iSemNum;

    ServerCommand_T * _Data;
    
    char _error_text[256];
};


inline int
CServerShmCmd::Lock()
{
    if (_pObjSem->lock(_iSemNum) != 0){
        sprintf(_error_text, "lock: %s", _pObjSem->get_error_text());
        return -1;
    }
    return 0;
}

inline int
CServerShmCmd::UnLock()
{
    if (_pObjSem->unlock(_iSemNum) != 0){
        sprintf(_error_text, "unlock: %s", _pObjSem->get_error_text());
        return -1;
    }
    return 0;
}

#endif
