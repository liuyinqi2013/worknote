#ifndef __C_SHM_NAME_VALUE_CONF_H
#define __C_SHM_NAME_VALUE_CONF_H

/*
����: 
       1.  NameValue�����࣬�����ڹ����ڴ�ͱ����ڴ�

Created by Song, 2003-02
Change list:

*/


#include <vector>
#include <string>

#include "shm_config.h"
#include "name_value_conf.h"

class CShmNameValueConf: public CShmConfig
{
public:
    CShmNameValueConf(const char * sConfigPath,
            unsigned uMaxRows,
            char * pShmPtr,
            size_t uShmSize,
            SVSemaphore * pObjSem,
            int iSemNum,
            const char * sSectionName);

    virtual ~CShmNameValueConf();

public:
    // �������ļ��ж�ȡ���õ�˽���ڴ棬�������
    virtual int ReadFromFile();

    // ��˽���ڴ�ļ�¼д�빲���ڴ棬�������
    virtual int WriteToShm();

public:
    // uMaxRows����¼��Ҫ���ڴ��С
    static size_t GetShmSize(unsigned uMaxRows)
    {return sizeof(ShmConfigHead_T) + sizeof(NameValue_T) * uMaxRows;}

public:
    // ȡ������sName��Value
    // ����ֵ-- 
    // 0: �ɹ���> 0 �Ҳ�����< 0: ʧ��
    inline int GetNameValue(const char * sName,
            char * sValue,
            size_t nValueSize,
            const char * sDefaultValue = NULL);
    inline int GetNameValue(const char * sName,
            int& iValue,
            int iDefaultValue = 0);
    inline int GetNameValue(const char * sName,
            long& lValue,
            long lDefaultValue = 0);
    inline int GetNameValue(const char * sName,
            double& dValue,
            double dDefaultValue = 0.0);
    inline int GetNameValue(const char * sName,
            unsigned& dValue,
            unsigned dDefaultValue = 0);

    // ȡuRow��¼�ŵļ�¼
    // ����ֵ-- 
    // !=NULL: �ɹ���NULL �Ҳ�����ʧ��
    const NameValue_T *GetRecord(unsigned uRow);

public:
    // �ӱ����ڴ���������sName��Value
    //  ����ͬGetNameValue
    // ȡ������sName��Value
    // ����ֵ-- 
    // 0: �ɹ���> 0 �Ҳ�����< 0: ʧ��
    inline int GetLocalNameValue(const char * sName,
            char * sValue,
            size_t nValueSize,
            const char * sDefaultValue = NULL);
    inline int GetLocalNameValue(const char * sName,
            int& iValue,
            int iDefaultValue = 0);
    inline int GetLocalNameValue(const char * sName,
            long& lValue,
            long lDefaultValue = 0);
    inline int GetLocalNameValue(const char * sName,
            double& dValue,
            double dDefaultValue = 0.0);
       inline int GetLocalNameValue(const char * sName,
            unsigned& dValue,
            unsigned dDefaultValue = 0.0);

public:
    // ��ӡһ��NameValue_T��¼����
    static void PrintNameValue_T(const NameValue_T * p,
        int (*fnPrintf)(const char * fmt, ...));
    
    // ��ӡ�����ڴ��е�����
    void PrintShm(int (*fnPrintf)(const char * fmt, ...)) const;
    
    // ��ӡ�����ڴ��е�����
    void Print(int (*fnPrintf)(const char * fmt, ...)) const;
    
private:
    CNameValueConf _objConf;
};


inline int
CShmNameValueConf::GetNameValue(const char * sName,
            char * sValue,
            size_t nValueSize,
            const char * sDefaultValue /*= NULL*/)
{
    int iRetVal = _objConf._GetNameValue(_pData, _pHead->uRows, sName,
            sValue, CNameValueConf::CT_TYPE_STR, nValueSize);
    if (iRetVal > 0){
        strncpy(sValue, sDefaultValue != NULL ? sDefaultValue:"", nValueSize);
        sValue[nValueSize - 1] = '\0';
    }
    return iRetVal;
}

inline int
CShmNameValueConf::GetNameValue(const char * sName,
            int& iValue,
            int iDefaultValue /*= 0*/)
{
    int iRetVal = _objConf._GetNameValue(_pData, _pHead->uRows, sName,
            &iValue, CNameValueConf::CT_TYPE_INT);
    if (iRetVal > 0){
        iValue = iDefaultValue;
    }
    return iRetVal;
}

inline int
CShmNameValueConf::GetNameValue(const char * sName,
            unsigned& iValue,
            unsigned iDefaultValue /*= 0*/)
{
    int iRetVal = _objConf._GetNameValue(_pData, _pHead->uRows, sName,
            &iValue, CNameValueConf::CT_TYPE_UNSIGNED);
    if (iRetVal > 0){
        iValue = iDefaultValue;
    }
    return iRetVal;
}

    
inline int
CShmNameValueConf::GetNameValue(const char * sName,
            long& lValue,
            long lDefaultValue /*= 0*/)
{
    int iRetVal = _objConf._GetNameValue(_pData, _pHead->uRows, sName,
            &lValue, CNameValueConf::CT_TYPE_LONG);
    if (iRetVal > 0){
        lValue = lDefaultValue;
    }
    return iRetVal;
}

inline int
CShmNameValueConf::GetNameValue(const char * sName,
            double& dValue,
            double dDefaultValue /*= 0*/)
{
    int iRetVal = _objConf._GetNameValue(_pData, _pHead->uRows, sName,
            &dValue, CNameValueConf::CT_TYPE_DOUBLE);
    if (iRetVal > 0){
        dValue = dDefaultValue;
    }
    return iRetVal;
}

// ȡ�����ڴ�
inline int
CShmNameValueConf::GetLocalNameValue(const char * sName,
            char * sValue,
            size_t nValueSize,
            const char * sDefaultValue /*= NULL*/)
{
    return _objConf.GetNameValue(sName, sValue, nValueSize, sDefaultValue);
}

inline int
CShmNameValueConf::GetLocalNameValue(const char * sName,
            int& iValue,
            int iDefaultValue /*= 0*/)
{
    return _objConf.GetNameValue(sName, iValue, iDefaultValue);
}
    
inline int
CShmNameValueConf::GetLocalNameValue(const char * sName,
            long& lValue,
            long lDefaultValue /*= 0*/)
{
    return _objConf.GetNameValue(sName, lValue, lDefaultValue);
}

inline int
CShmNameValueConf::GetLocalNameValue(const char * sName,
            double& dValue,
            double dDefaultValue /*= 0*/)
{
    return _objConf.GetNameValue(sName, dValue, dDefaultValue);
}

inline int
CShmNameValueConf::GetLocalNameValue(const char * sName,
            unsigned& dValue,
            unsigned dDefaultValue /*= 0*/)
{
    return _objConf.GetNameValue(sName, dValue, dDefaultValue);
}


#endif
