#ifndef __C_SHM_ACCESS_CONTROL_CONF_H
#define __C_SHM_ACCESS_CONTROL_CONF_H

/*
����: 
       1.  ��¼����
       2.  Service����Ȩ�޿���

Created by Song, 2003-02
Change list:

*/

#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include <vector>
using namespace std;

#include "shm_config.h"


/*
struct AccessControl_T{
    char sIP[32];
    char sUserName[32];
    char sPasswd[32];
    char bIsByServer; // false: service true: server
    char sReserve[128];
    unsigned uArrayNum;
    char sServiceArray[MAX_ACCESS_CONTROL_SERVICE][MAX_SERVICE_NAME];
};
*/

// ���ִ�С��AccessMaskControl_T, ���¼���
struct AccessMaskControl_T{
    char sIP[24];
    unsigned int uBaseIp;
    unsigned int uSubNetMask;
    char sUserName[32];
    char sPasswd[32];
    char bIsByServer; // false: service true: server
    char sReserve[128];
    unsigned uArrayNum;
    char sServiceArray[MAX_ACCESS_CONTROL_SERVICE][MAX_SERVICE_NAME];
};

class CShmAccessControl: public CShmConfig
{
public:
    CShmAccessControl(const char * sConfigPath,
            unsigned uMaxRows,
            char * pShmPtr,
            size_t uShmSize,
            SVSemaphore * pObjSem,
            int iSemNum);

    virtual ~CShmAccessControl();
    
public:
    // �������ļ��ж�ȡ���õ�˽���ڴ�
    virtual int ReadFromFile();

    // ��˽���ڴ�ļ�¼д�빲���ڴ�
    virtual int WriteToShm();

    static size_t GetShmSize(unsigned uMaxRows)
    {return sizeof(ShmConfigHead_T) + sizeof(AccessMaskControl_T) * uMaxRows;}

public:
    enum{
        NOT_ALLOW = 0,
        ALLOW = 1,
        ALLOW_ALL = 2
    };
    // Client����Service��Ȩ��
    int GetPrivilege(const char * sIP,
            const char * sUserName,
            const char * sServerName,
            const char * sServiceName);

    bool PasswdIsOK(const char * sIP,
                const char * sUserName,
                const char * sPasswd);

    const AccessMaskControl_T * GetRecord(unsigned uRow);
public:
    inline const AccessMaskControl_T * GetAccessMaskControlPtr(const std::string& sIP, 
                const char *sUserName);
    
    int ParseIp(AccessMaskControl_T *p);
    int CheckIp(const std::string& ip, const AccessMaskControl_T* p);

public:
    void PrintAccessControl_T(const AccessMaskControl_T * p,
        int (*fnPrintf)(const char * fmt, ...));

    void PrintShm(int (*fnPrintf)(const char * fmt, ...));
    
    void Print(int (*fnPrintf)(const char * fmt, ...));
    
private:
    static int ReadRecordEntrance(char * str, void * arg);

    int ReadRecord(char * str);

    static int CmpAccessControl_T(const void * a, const void * b);

private:
    struct AccessControl_Serach_T
    {
        const char * psIP;
        const char * psUserName;
    };
private:
    //vector<AccessControl_T> _vData;
    vector<AccessMaskControl_T> _vMaskData;
};


#endif
