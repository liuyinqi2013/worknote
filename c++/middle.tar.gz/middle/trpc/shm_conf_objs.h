#ifndef __C_SHM_CONF_OBJS_H
#define __C_SHM_CONF_OBJS_H

/*
����: 
       1.  ���������ڴ�������ļ���

Created by Song, 2003-02
Change list:

*/


#include "shm_config.h"

#include "shm_access_control.h"
#include "shm_name_value_conf.h"
#include "shm_server_conf.h"
#include "shm_service_conf.h"

#include "server_shm_cmd.h"


struct ShmConfObjsHead_T
{
    char sReserve[1024 * 1024 * 2];
};

class CShmConfObjs
{
public:
    CShmConfObjs(const char * sConfigPath,
            int iIpcKey,
            unsigned uMaxServerNo,
            unsigned uCushionSize);
    
    virtual ~CShmConfObjs();

    int Create();
    int Open();
    int Close();
    int Remove();
    int ReadFromFile();
    int WriteToShm();

    const char * get_error_text() const { return _error_text; }

public:
    CShmNameValueConf * GetConstConf(){return _pConstConf;}
    CShmNameValueConf * GetMainConf(){return _pMainConf;}
    CShmAccessControl * GetAccessControl(){return _pAccessControl;}
    CShmServerConf * GetServerConf(){return _pServerConf;}
    CShmServiceConf * GetServiceConf(){return _pServiceConf;}
    CServerShmCmd * GetServerCmd(){return _pServerCmd;}
    
    const void * GetShmPtr() const;
    
private:
    static const int IPC_MODE = 0664;
    static const int MAX_SEM_NUM = 16;

    // 0 ����
    static const int _iConstConf_No = 1;
    static const int _iMainConf_No = 2;
    static const int _iAccessControl_No = 3;
    static const int _iServerConf_No = 4;
    static const int _iServiceConf_No = 5;
    static const int _iServerCmd_No = 6;
    
    string _strConfigPath;
    int _iIpcKey;
    unsigned _uMaxServerNo;
    unsigned _uCushionSize;
    
    CShmNameValueConf * _pConstConf;
    CShmNameValueConf * _pMainConf;
    CShmAccessControl * _pAccessControl;
    CShmServerConf * _pServerConf;
    CShmServiceConf * _pServiceConf;
    CServerShmCmd * _pServerCmd;

    size_t _nConstConf_ShmSize;
    size_t _nMainConf_ShmSize;
    size_t _nAccessControl_ShmSize;
    size_t _nServerConf_ShmSize;
    size_t _nServiceConf_ShmSize;
    size_t _nServerCmd_ShmSize;

    size_t _nShmSize;
    
    SVSharedMemory * _pObjShm;
    SVSemaphore * _pObjSem;
    char * _pShmPtrArray[MAX_SEM_NUM];

    char _error_text[256];
};

#endif
