/*
����: 
       1.  �����ڴ����õĻ���

Created by Song, 2003-02
Change list:

*/

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <assert.h>

#include "shm_config.h"

CShmConfig::CShmConfig(const char *sConfigPath,
                       unsigned uMaxRows,
                       char *pShmPtr,
                       size_t uShmSize, SVSemaphore * pObjSem, int iSemNum)
:  CConfig(sConfigPath, uMaxRows),
_pShmPtr(pShmPtr), _uShmSize(uShmSize), _pObjSem(pObjSem), _iSemNum(iSemNum)
{
    _pHead = (ShmConfigHead_T *) _pShmPtr;
    _pData = pShmPtr + sizeof(ShmConfigHead_T);
    _pShmEnd = _pShmPtr + uShmSize;
}

CShmConfig::~CShmConfig()
{

}

void
CShmConfig::ResetShm()
{
    memset(_pShmPtr, 0, _uShmSize);
}
