/*
����: 
       1.  �����ڴ�Service������
       2.  Server�ĸ������̵�״̬
       3.  Serverʹ�õ������ļ�����־����̬���

Created by Song, 2003-02
Change list:

*/

#include <stdio.h>
#include <assert.h>

#include "shm_server_conf.h"

CShmServerConf::CShmServerConf(const char *sConfigPath,
                               unsigned uMaxRows,
                               char *pShmPtr,
                               size_t uShmSize,
                               SVSemaphore * pObjSem, int iSemNum)
    :
CShmConfig(sConfigPath, uMaxRows, pShmPtr, uShmSize, pObjSem, iSemNum),
_vData(uMaxRows)
{
    assert(_uShmSize == GetShmSize(uMaxRows));
}

CShmServerConf::~CShmServerConf()
{
}

int
CShmServerConf::ReadFromFile()
{
    //_uRows = 1;                 // middledռ����һ��
    _uRows = NORMAL_SERVER_NO_BEGIN;         // middled, ���, �첽,һ��3������

    memset(&_vData[0], 0, _uMaxRows * sizeof(ServerConf_T));

    int iRetVal = ReadConfig(_strConfigPath.c_str(),
                             SECTION_NAME_SERVER_CONF,
                             ReadRecordEntrance,
                             (void *) this);

    if (iRetVal != 0) {
        return iRetVal;
    }

    return 0;
}

int
CShmServerConf::WriteToShm()
{
    // дServer���õ������ڴ棬ProcessInfo���ֲ�д
    int Size = GetServerInfoSize();

    // ֻд��ͨ������Ϣ
    ServerConf_T *p = (ServerConf_T *) ((char* )_pData + Size * NORMAL_SERVER_NO_BEGIN);

    // �пռ�¼
    // ��copy iLogLevel
    size_t uMcpSize = (char *) &p->iLogLevel - (char *) p;
    _pHead->uRows = _uRows;
    for (unsigned i = NORMAL_SERVER_NO_BEGIN; i < _vData.size(); ++i) {
        memcpy(p, &_vData[i], uMcpSize);
        p = (ServerConf_T *) ((char* )p + Size);
    }

    return 0;
}

int
CShmServerConf::CmpServerConf_T(const void *a, const void *b)
{
    const ServerConf_T *p1 = (const ServerConf_T *) a;
    const ServerConf_T *p2 = (const ServerConf_T *) b;

    if (p1->uServerNo > p2->uServerNo) {
        return 1;
    }
    else if (p1->uServerNo < p2->uServerNo) {
        return -1;
    }

    return 0;
}

int
CShmServerConf::ReadRecordEntrance(char *str, void *arg)
{
    CShmServerConf *pThis = (CShmServerConf *) arg;
    return pThis->ReadRecord(str);
}

int
CShmServerConf::ReadRecord(char *str)
{
    ServerConf_T stRecord;
    ServerConf_T *p = &stRecord;

    char sTmp[2048];
    memset(&stRecord, 0, sizeof(ServerConf_T));

    char *pe = str;
    pe = GetToken(sTmp, sizeof(sTmp), pe, DELIMITER_STR);
    strncpy(p->sServerName, sTmp, sizeof(p->sServerName) - 1);

    pe = GetToken(sTmp, sizeof(sTmp), pe, DELIMITER_STR);
    p->uServerNo = atoi(sTmp);

    pe = GetToken(sTmp, sizeof(sTmp), pe, DELIMITER_STR);
    p->uProcessNum = atoi(sTmp);

	// added by verminniu
	pe = GetToken(sTmp, sizeof(sTmp), pe, DELIMITER_STR);
    p->uSoNum = 0;
	char * pTmp = sTmp;
	trpc_debug_log("SoFileArrayTmp = %s \n", sTmp);
    for (unsigned i = 0; i < MAX_TRPC_SO_NUM; ++i) {
        pTmp = GetToken(p->sSoFileArray[i],
                      sizeof(p->sSoFileArray[i]), pTmp, ",");
		trpc_debug_log("SoFileArrayTmp[%d] = %s \n", i, p->sSoFileArray[i]);
        if (strcmp(p->sSoFileArray[i], "") == 0) {
            break;
        }
        ++p->uSoNum;
    }

	// Begin Added by verminniu 2007-11-13
	pe = GetToken(sTmp, sizeof(sTmp), pe, DELIMITER_STR);
	if(pe == NULL) {
		// ��Ϊ0����admin����ʱ���������0����ȡȫ�ֵ�
		p->uTimeOut = 0;
	} else {
		p->uTimeOut = atoi(sTmp);
	}
    
    // �Ƿ���Ա�ɱ��
	if(pe != NULL)
	{
		pe = GetToken(sTmp, sizeof(sTmp), pe, DELIMITER_STR);

        trpc_debug_log("after GetToken kill pe : %p, str: %s\n", pe, pe);

		if(*pe == '\0') {
			// Ĭ�Ͽ��Ա�ɱ��
			p->uCanKill = 1;
		} else {
			p->uCanKill = (unsigned char)atoi(sTmp);
		}
	} else {
		// Ĭ�Ͽ��Ա�ɱ��
		p->uCanKill = 1;
	}

    trpc_debug_log("Before Get Stat, pe : %p, str: %s\n", pe, pe);

    // �Ƿ���ͳ����Ϣ
	if(pe != NULL)
	{
		pe = GetToken(sTmp, sizeof(sTmp), pe, DELIMITER_STR);
		if(*pe == '\0') {
			// ��Ϊ0����admin����ʱ���������0����ȡȫ�ֵ�
			p->uStat = 1;
		} else {
			p->uStat = (unsigned char)atoi(sTmp);
		}
	} else {
		p->uStat = 1;
	}
    
    trpc_debug_log("Before Get Warning, pe : %p, str: %s\n", pe, pe);

    // �Ƿ��ͱ�����Ϣ
	if(pe != NULL)
	{
		pe = GetToken(sTmp, sizeof(sTmp), pe, DELIMITER_STR);
		if(*pe == '\0') {
			// ��Ϊ0����admin����ʱ���������0����ȡȫ�ֵ�
			p->uWarning = 1;
		} else {
			p->uWarning = (unsigned char)atoi(sTmp);
		}
	} else {
		p->uWarning = 1;
	}
	// End Added by verminniu 2007-11-13

    if (p->uServerNo >= _uMaxRows) {
        // �������ֵ
        sprintf(_error_text, "too many rows: MaxRow==%u", _uMaxRows);
        return -1;
    }

    if (p->uProcessNum > MAX_TRPC_PROCESS_NO) {
        // �������ֵ
        sprintf(_error_text, "too many Processes: MaxProcessNum==%u", MAX_TRPC_PROCESS_NO);
        return -1;
    }
    // ����Ƿ����ظ���¼
    for (size_t i = 0; i < _vData.size(); ++i) {
        if (p->uServerNo <= 0) {
            // �Ѿ�������ͬ��¼
            sprintf(_error_text, "ServerNo must > 0");
            return -1;
        }

        if (p->uServerNo == _vData[i].uServerNo) {
            // �Ѿ�������ͬ��¼
            sprintf(_error_text, "duplicated ServerNo: %u", p->uServerNo);
            return -1;
        }

        if (strcmp(p->sServerName, _vData[i].sServerName) == 0) {
            // �Ѿ�������ͬ��¼
            sprintf(_error_text, "duplicated ServerName: [%s]",
                    p->sServerName);
            return -1;
        }
    }

    memcpy(&_vData[p->uServerNo], p, sizeof(ServerConf_T));

    return 0;
}

ServerConf_T *
CShmServerConf::GetServerInfoPtr(unsigned uServerNo)
{
    if (_pHead == NULL || _pData == NULL) {
        sprintf(_error_text, "_pHead == %p, _pData == %p\n", _pHead, _pData);
        return NULL;
    }

    if (uServerNo > 0 && uServerNo >= _pHead->uRows) {
        sprintf(_error_text, "uServerNo >= _pHead->uRows: %d >= %d\n",
                uServerNo, _pHead->uRows);
        return NULL;
    }

    // �ж��Ƿ�Խ��
    assert(((char *)_pData+ GetServerInfoSize() *uServerNo) <
           (char *) _pShmEnd);

    return  (ServerConf_T *)((char *)_pData+ GetServerInfoSize() *uServerNo);
}

/*
// ȡerrorsvr��Ϣ
ServerConf_T *
CShmServerConf::GetErrServerInfoPtr()
{
    unsigned uServerNo = _uMaxRows;
        
    if (_pHead == NULL || _pData == NULL) {
        sprintf(_error_text, "_pHead == %p, _pData == %p\n", _pHead, _pData);
        return NULL;
    }

    // �ж��Ƿ�Խ��
    assert(((char *)_pData+ GetServerInfoSize() *uServerNo) <
           (char *) _pShmEnd);

    return  (ServerConf_T *)((char *)_pData+ GetServerInfoSize() *uServerNo);

}

// ȡasynsvr ��Ϣ
ServerConf_T *
CShmServerConf::GetAsynServerInfoPtr()
{
    unsigned uServerNo = _uMaxRows + 1;

    if (_pHead == NULL || _pData == NULL) {
        sprintf(_error_text, "_pHead == %p, _pData == %p\n", _pHead, _pData);
        return NULL;
    }

    // �ж��Ƿ�Խ��
    assert(((char *)_pData+ GetServerInfoSize() * uServerNo) <
           (char *) _pShmEnd);

    return  (ServerConf_T *)((char *)_pData+ GetServerInfoSize() *uServerNo);
}
*/

unsigned char *
CShmServerConf::GetWarningPtr(unsigned uServerNo)
{
    ServerConf_T *p = GetServerInfoPtr(uServerNo);
    if (p == NULL) {
        return NULL;
    }
    return &p->uWarning;
}

unsigned char *
CShmServerConf::GetStatPtr(unsigned uServerNo)
{
    ServerConf_T *p = GetServerInfoPtr(uServerNo);
    if (p == NULL) {
        return NULL;
    }
    return &p->uStat;
}

int *
CShmServerConf::GetLogLevelPtr(unsigned uServerNo)
{
    ServerConf_T *p = GetServerInfoPtr(uServerNo);
    if (p == NULL) {
        return NULL;
    }
    return &p->iLogLevel;
}

int
CShmServerConf::GetLogLevel(unsigned uServerNo)
{
    ServerConf_T *p = GetServerInfoPtr(uServerNo);
    if (p == NULL) {
        return CLog::NORMAL_LOG;
    }
    return p->iLogLevel;
}

int
CShmServerConf::SetLogLevel(unsigned uServerNo, int iLogLevel)
{
    ServerConf_T *p = GetServerInfoPtr(uServerNo);
    if (p == NULL) {
        UnLock();
        return 1;
    }
    p->iLogLevel = iLogLevel;
    return 0;
}

ProcessInfo_T *
CShmServerConf::GetProcessInfoPtr(unsigned uServerNo, unsigned uProcessNo)
{
    ServerConf_T *p = GetServerInfoPtr(uServerNo);
    if (p == NULL) {
        return NULL;
    }

    if (uProcessNo >= p->uProcessNum) {
        sprintf(_error_text, "uProcessNo >= p->uProcessNum: %d >= %d",
                uProcessNo, p->uProcessNum);
        return NULL;
    }

    // �ж��Ƿ�Խ��
    assert((char *) (p->stProcInfoArray + uProcessNo) < (char *) _pShmEnd);

    return p->stProcInfoArray + uProcessNo;
}

/*
// ȡerr svr�Ľ�����Ϣ
ProcessInfo_T *
CShmServerConf::GetErrProcessInfoPtr(unsigned uProcessNo)
{
    ServerConf_T *p = GetErrServerInfoPtr();
    if (p == NULL) {
        return NULL;
    }

    if (uProcessNo >= p->uProcessNum) {
        sprintf(_error_text, "uProcessNo >= p->uProcessNum: %d >= %d",
                uProcessNo, p->uProcessNum);
        return NULL;
    }

    // �ж��Ƿ�Խ��
    assert((char *) (p->stProcInfoArray + uProcessNo) < (char *) _pShmEnd);

    return p->stProcInfoArray + uProcessNo;
}

// ȡasyn svr�Ľ�����Ϣ
ProcessInfo_T *
CShmServerConf::GetAsynProcessInfoPtr(unsigned uProcessNo)
{
    ServerConf_T *p = GetAsynServerInfoPtr();
    if (p == NULL) {
        return NULL;
    }

    if (uProcessNo >= p->uProcessNum) {
        sprintf(_error_text, "uProcessNo >= p->uProcessNum: %d >= %d",
                uProcessNo, p->uProcessNum);
        return NULL;
    }

    // �ж��Ƿ�Խ��
    assert((char *) (p->stProcInfoArray + uProcessNo) < (char *) _pShmEnd);

    return p->stProcInfoArray + uProcessNo;
}
*/

void
CShmServerConf::PrintServerConf_T(const ServerConf_T * p,
                                  int (*fnPrintf) (const char *fmt, ...))
{
    char sTmp[8192];
    int iLen = 0;
    int iLeftLen = sizeof(sTmp);

    sTmp[0] = '\0';
    for (unsigned i = 0; i < p->uSoNum; ++i) {
        if (i == 0) {
            iLen += snprintf(sTmp + iLen, iLeftLen, "%s", p->sSoFileArray[i]);
        }
        else {
            iLen += snprintf(sTmp + iLen, iLeftLen, ",%s",
                             p->sSoFileArray[i]);
        }
        iLeftLen -= iLen;
    }

    fnPrintf("\nsServerName: [%s]\n", p->sServerName);
    fnPrintf("uServerNo: %u\n", p->uServerNo);
    fnPrintf("uProcessNum: %d\n", p->uProcessNum);
    fnPrintf("iLogLevel: %d\n", p->iLogLevel);
    fnPrintf("iStatus: 	%d\n", p->iStatus);
    fnPrintf("uSoNum: %d\n", p->uSoNum);
    fnPrintf("sSoFileArray: [%s]\n", sTmp);

    fnPrintf("ProcessInfo:\n");
    const ProcessInfo_T *pProc = (const ProcessInfo_T *) p->stProcInfoArray;
    for (unsigned i = 0; i < p->uProcessNum; ++i, ++pProc) {
        fnPrintf("  pid: 		%d\n", pProc->pid);
        fnPrintf("  tStartTime: 	%ld\n", pProc->tStartTime);
        fnPrintf("  tHeartbeatTime: %ld\n\n", pProc->tHeartbeatTime);
    }
}

void
CShmServerConf::PrintShm(int (*fnPrintf) (const char *fmt, ...)) const
{
    if (_pHead == NULL || _pData == NULL) {
        fnPrintf("_pHead == %p, _pData == %p\n", _pHead, _pData);
        return;
    }

    int uRows = _pHead->uRows;
    const ServerConf_T *p = (const ServerConf_T *) _pData;

    fnPrintf("rows: %d\n", uRows);
    for (int i = 0; i < uRows; ++i, ++p) {
        PrintServerConf_T(p, fnPrintf);
    }
}

void
CShmServerConf::Print(int (*fnPrintf) (const char *fmt, ...)) const
{
    fnPrintf("rows: %d\n", _vData.size());
    const ServerConf_T *p = &_vData[0];
    for (size_t i = 0; i < _vData.size(); ++i, ++p) {
        PrintServerConf_T(p, fnPrintf);
    }
}
