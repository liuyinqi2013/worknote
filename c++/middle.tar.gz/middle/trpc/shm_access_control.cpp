/*
����: 
       1.  ��¼����
       2.  Service����Ȩ�޿���

Created by Song, 2003-02
Change list:

*/

#include <stdio.h>
#include <assert.h>

#include "shm_access_control.h"

CShmAccessControl::CShmAccessControl(const char *sConfigPath,
                                     unsigned uMaxRows,
                                     char *pShmPtr,
                                     size_t uShmSize,
                                     SVSemaphore * pObjSem, int iSemNum)
:  CShmConfig(sConfigPath, uMaxRows, pShmPtr, uShmSize, pObjSem, iSemNum)
{
    assert(_uShmSize == GetShmSize(uMaxRows));
}

CShmAccessControl::~CShmAccessControl()
{

}

int
CShmAccessControl::ReadFromFile()
{
    _uRows = 0;
    _vMaskData.clear();

    int iRetVal = ReadConfig(_strConfigPath.c_str(),
                             SECTION_NAME_ACCESS_CONTROL,
                             ReadRecordEntrance,
                             (void *) this);

    if (iRetVal != 0) {
        return iRetVal;
    }

    // ����
    qsort(&_vMaskData[0], _vMaskData.size(), sizeof(_vMaskData[0]), CmpAccessControl_T);

    return 0;
}

int
CShmAccessControl::WriteToShm()
{
    _pHead->uRows = _uRows;
    memcpy(_pData, &_vMaskData[0], _vMaskData.size() * sizeof(_vMaskData[0]));

    return 0;
}

/**
 * Funciton:  AccessControl_T�ṹ�ıȽϺ��������������
  ����:
  a:  ��¼1ָ��
  b: ��¼2ָ��
  
 return value 0: a == b
                 > 0:  a > b
                 < 0:  a < b
**/
int
CShmAccessControl::CmpAccessControl_T(const void *a, const void *b)
{
    const AccessMaskControl_T *p1 = (const AccessMaskControl_T *) a;
    const AccessMaskControl_T *p2 = (const AccessMaskControl_T *) b;

    // ��֤�����ڹ���ǰ��ƥ��,���в���/�Ķ����ڴ�/��
    char * pstr1 = strstr(p1->sIP, "/");
    char * pstr2 = strstr(p2->sIP, "/");

    if (pstr1 != NULL && pstr2 == NULL) {
        return 1;
    }
    
    if (pstr1 == NULL && pstr2 != NULL) {
        return -1;
    }

    // �������
    int iRet;

    iRet = strcmp(p1->sIP, p2->sIP);
    if (iRet != 0) {
        return iRet;
    }

    return strcmp(p1->sUserName, p2->sUserName);
}

int
CShmAccessControl::ReadRecordEntrance(char *str, void *arg)
{
    CShmAccessControl *pThis = (CShmAccessControl *) arg;
    return pThis->ReadRecord(str);
}

int
CShmAccessControl::ParseIp(AccessMaskControl_T *p)  
{
    std::string ip = p->sIP;
    size_t spint_pos = ip.find('/');

    if (spint_pos == std::string::npos) {
        // ���ҵ�ip
        p->uBaseIp = inet_network(ip.c_str());
        // ��������, 32λȫ����Ч
        p->uSubNetMask  = 0xFFFFFFFF;
    } else {
        // ���ҵ�ip
        p->uBaseIp = inet_network(ip.substr(0, spint_pos).c_str());

        // 32λint
        int t = 32 - atoi(ip.substr(spint_pos + 1).c_str());
        
        p->uSubNetMask = 0xFFFFFFFF << t;

        // baseip���ܺ�λ���ô���,��Ϊ0, �Լ���0
        p->uBaseIp &= p->uSubNetMask;
    }

    return 0;
}

/**
 * Funciton:  У��ip
  ����:
  ip: ���õĴ��Ͳ���
  
 return value 0: check ok
           else: check error
**/
int 
CShmAccessControl::CheckIp(const std::string& ip, const AccessMaskControl_T* p)
{
    unsigned int t = inet_network(ip.c_str());
    
    unsigned int result = t & p->uSubNetMask;
    
    if (result == p->uBaseIp)
    {
        return 0;
    }
    else
    {
        return -1;
    }

    // never go here
    return -1;
}
/**
 * Funciton:  ����һ�����ü�¼
  ����:
  str:  ��������ü�¼�ı�
  
 return value 0: successful
                 > 0:  ��¼��Ч
                 < 0:  have error(s)
**/
int
CShmAccessControl::ReadRecord(char *str)
{
    AccessMaskControl_T stRecord;
    AccessMaskControl_T *p = &stRecord;

    memset(&stRecord, 0, sizeof(stRecord));

    char sTmp[128];

    char *pe = str;
    pe = GetToken(p->sIP, sizeof(p->sIP), pe, DELIMITER_STR);
    pe = GetToken(p->sUserName, sizeof(p->sUserName), pe, DELIMITER_STR);
    pe = GetToken(p->sPasswd, sizeof(p->sPasswd), pe, DELIMITER_STR);

    pe = GetToken(sTmp, sizeof(sTmp), pe, DELIMITER_STR);
    if (strcasecmp(sTmp, "false") == 0) {
        p->bIsByServer = false;
    }
    else {
        p->bIsByServer = true;
    }

    p->uArrayNum = 0;
    for (unsigned i = 0; i < MAX_ACCESS_CONTROL_SERVICE; ++i) {
        pe = GetToken(p->sServiceArray[i],
                      sizeof(p->sServiceArray[i]), pe, ",");
        if (strcmp(p->sServiceArray[i], "") == 0) {
            break;
        }
        ++p->uArrayNum;
    }

    // ����Ƿ����ظ���¼
    for (size_t i = 0; i < _vMaskData.size(); ++i) {
        if (CmpAccessControl_T(&_vMaskData[i], p) == 0) {
            // �Ѿ�������ͬ��¼
            // ����
            sprintf(_error_text, "duplicated record: %s -- %s",
                    p->sIP, p->sUserName);
            return -1;
        }
    }

    ParseIp(p);

    _vMaskData.push_back(*p);
        
    return 0;
}

inline const AccessMaskControl_T *
CShmAccessControl::GetAccessMaskControlPtr(const std::string& sIP, const char *sUserName)
{
    // ��������, ��Ϊ�����˰�������Ȩ��,���������кܶ�������, �����������
    for (unsigned int i = 0; i < _pHead->uRows; ++i) {
        AccessMaskControl_T * tp = (AccessMaskControl_T *)_pData + i;
        trpc_debug_log("CheckIp %s, 0x%08x, %s, %s\n", sIP.c_str(), tp->uBaseIp, tp->sUserName, sUserName);
        if (CheckIp(sIP, tp) == 0
                && strcmp(tp->sUserName, sUserName) == 0) {
            return tp;
        }
    }

    return NULL;
}

/**
 * Funciton: �Ƿ��з���Service/Server��Ȩ��
  ����:
  sIP:  Client��IP
  sUserName:  ��¼���û���
  sServerName:  Ҫ���ʵ�Service���ڵ�Server����
  sServiceName:  Ҫ���ʵ�Service����
  
 return value NOT_ALLOW: �ܾ�����
                 ALLOW: ��������
                 ALLOW_ALL: ������������Service
**/
int
CShmAccessControl::GetPrivilege(const char *sIP,
                                const char *sUserName,
                                const char *sServerName,
                                const char *sServiceName)
{
    const AccessMaskControl_T *p = GetAccessMaskControlPtr(sIP, sUserName);
    if (p == NULL) {
        return NOT_ALLOW;
    }

    trpc_debug_log("GetPrivilege: [%s] -- [%s] -- [%s] -- [%s] -- [%s]\n", 
		sIP, sUserName, sServerName, sServiceName, p->sServiceArray[0]);

    assert((char *) p < (char *) _pShmEnd);     // �ж��Ƿ�Խ��

    assert(p->uArrayNum < MAX_ACCESS_CONTROL_SERVICE);

    if (p->uArrayNum >= MAX_ACCESS_CONTROL_SERVICE) {
        return NOT_ALLOW;
    }

    if (strcmp(p->sServiceArray[0], "*") == 0) {
        return ALLOW_ALL;
    }

    const char *pCondition;
    if (p->bIsByServer) {
        pCondition = sServerName;
    }
    else {
        pCondition = sServiceName;
    }

    for (unsigned i = 0; i < p->uArrayNum; ++i) {
        assert((char *) p < (char *) &p->sServiceArray[i]);     // �ж��Ƿ�Խ��

        if (strcmp(p->sServiceArray[i], pCondition) == 0) {
            return ALLOW;
        }
    }

    return NOT_ALLOW;
}

/**
 * Funciton: �����Ƿ���ȷ
  ����:
  sIP:  Client��IP
  sUserName:  ��¼���û���
  sPasswd:  ����
  
 return value true: ��������
                 false: �ܾ�����
**/
bool CShmAccessControl::PasswdIsOK(const char *sIP,
                                   const char *sUserName, const char *sPasswd)
{
    const AccessMaskControl_T *
        p =
        GetAccessMaskControlPtr(sIP, sUserName);
    trpc_debug_log("GetAccessMaskControlPtr is 0x%08x\n", p);

    if (p == NULL) {
        return -1;
    }
    
    assert((char *) p < (char *) _pShmEnd);     // �ж��Ƿ�Խ��

    return (strcmp(sPasswd, p->sPasswd) == 0);
}

const AccessMaskControl_T *
CShmAccessControl::GetRecord(unsigned uRow)
{
    if (_pHead == NULL || _pData == NULL) {
        sprintf(_error_text, "_pHead == %p, _pData == %p\n", _pHead, _pData);
        return NULL;
    }

    if (uRow >= _pHead->uRows) {
        sprintf(_error_text, "uRow >= _pHead->uRows: %d >= %d\n",
                uRow, _pHead->uRows);
        return NULL;
    }

    // �ж��Ƿ�Խ��
    assert((char *) ((const AccessMaskControl_T *) _pData + uRow) <
           (char *) _pShmEnd);

    return (const AccessMaskControl_T *) _pData + uRow;
}

void
CShmAccessControl::PrintAccessControl_T(const AccessMaskControl_T * p,
                                        int (*fnPrintf) (const char *fmt,
                                                         ...))
{
    char sTmp[8192];
    int iLen = 0;
    int iLeftLen = sizeof(sTmp);

    sTmp[0] = '\0';
    for (unsigned i = 0; i < p->uArrayNum; ++i) {
        if (i == 0) {
            iLen += snprintf(sTmp + iLen, iLeftLen, "%s",
                             p->sServiceArray[i]);
        }
        else {
            iLen += snprintf(sTmp + iLen, iLeftLen, ",%s",
                             p->sServiceArray[i]);
        }
        iLeftLen -= iLen;
    }

    fnPrintf("[%s]; [%s]; [%s]; %s; %d;  [%s]\n",
             p->sIP,
             p->sUserName,
             p->sPasswd,
             p->bIsByServer ? "true" : "false", p->uArrayNum, sTmp);
}

void
CShmAccessControl::PrintShm(int (*fnPrintf) (const char *fmt, ...))
{
    if (_pHead == NULL || _pData == NULL) {
        fnPrintf("_pHead == %p, _pData == %p\n", _pHead, _pData);
        return;
    }

    int uRows = _pHead->uRows;
    const AccessMaskControl_T *p = (const AccessMaskControl_T *) _pData;

    fnPrintf("rows: %d\n", uRows);
    for (int i = 0; i < uRows; ++i, ++p) {
        PrintAccessControl_T(p, fnPrintf);
    }
}

void
CShmAccessControl::Print(int (*fnPrintf) (const char *fmt, ...))
{
    fnPrintf("rows: %d\n", _vMaskData.size());
    const AccessMaskControl_T *p = &_vMaskData[0];
    for (size_t i = 0; i < _vMaskData.size(); ++i, ++p) {
        PrintAccessControl_T(p, fnPrintf);
    }
}
