/*
����: 
       1.  ���������ڴ�������ļ���

Created by Song, 2003-02
Change list:

*/

#include <stdio.h>
#include <assert.h>

#include "shm_conf_objs.h"

// uCushionSize �ǻ�������С��
// �ڸ��������ڴ���֮����һ������ش�
// ������һ����Խ�����������Ӱ��
CShmConfObjs::CShmConfObjs(const char *sConfigPath,
                           int iIpcKey,
                           unsigned uMaxServerNo, unsigned uCushionSize)
    :
_strConfigPath(sConfigPath),
_iIpcKey(iIpcKey),
_uMaxServerNo(uMaxServerNo),
_uCushionSize(uCushionSize),
_pConstConf(NULL),
_pMainConf(NULL),
_pAccessControl(NULL),
_pServerConf(NULL),
_pServiceConf(NULL),
_pServerCmd(NULL),
_pObjShm(NULL),
_pObjSem(NULL)
{
    _nConstConf_ShmSize = CShmNameValueConf::GetShmSize(MAX_CONST_CONF_ROWS);
    _nMainConf_ShmSize = CShmNameValueConf::GetShmSize(MAX_MAIN_CONF_ROWS);
    _nAccessControl_ShmSize =
        CShmAccessControl::GetShmSize(MAX_ACCESS_CONTROL_ROWS);
    _nServerConf_ShmSize = CShmServerConf::GetShmSize(MAX_SERVER_CONF_ROWS);
    _nServiceConf_ShmSize =
        CShmServiceConf::GetShmSize(MAX_SERVICE_CONF_ROWS);

    _nServerCmd_ShmSize = CServerShmCmd::GetShmSize
        (MAX_TRPC_SERVER_NO, MAX_SERVER_CMD_ROWS);

    for (int i = 0; i < MAX_SEM_NUM; ++i) {
        _pShmPtrArray[i] = NULL;
    }

    _nShmSize = sizeof(ShmConfObjsHead_T) + _uCushionSize;
    _nShmSize += _nConstConf_ShmSize + _uCushionSize;
    _nShmSize += _nMainConf_ShmSize + _uCushionSize;
    _nShmSize += _nAccessControl_ShmSize + _uCushionSize;
    _nShmSize += _nServerConf_ShmSize + _uCushionSize;
    _nShmSize += _nServiceConf_ShmSize + _uCushionSize;
    _nShmSize += _nServerCmd_ShmSize + _uCushionSize;

    _pObjShm = new SVSharedMemory(_iIpcKey, IPC_MODE, _nShmSize);
    _pObjSem = new SVSemaphore(_iIpcKey, IPC_MODE, MAX_SEM_NUM);

    _error_text[0] = '\0';
}

CShmConfObjs::~CShmConfObjs()
{
    Close();

    delete _pConstConf;
    delete _pAccessControl;
    delete _pMainConf;
    delete _pServerConf;
    delete _pServiceConf;
    delete _pServerCmd;

    delete _pObjShm;
    delete _pObjSem;
}

int
CShmConfObjs::Create()
{
    int iRetVal;
    int iExistedCount = 0;

    iRetVal = _pObjShm->create();
    if (iRetVal < 0) {
        sprintf(_error_text, "SVSharedMemory::create: %s",
                _pObjShm->get_error_text());
        return -1;
    }
    else if (iRetVal > 0) {
        ++iExistedCount;
    }

    iRetVal = _pObjSem->create();
    if (iRetVal < 0) {
        sprintf(_error_text, "SVSemaphore::create: %s",
                _pObjSem->get_error_text());
        return -1;
    }
    else if (iRetVal > 0) {
        ++iExistedCount;
    }

    return iExistedCount;
}

int
CShmConfObjs::Open()
{
    int iRetVal;

    iRetVal = _pObjShm->open_and_attach();
    if (iRetVal < 0) {
        sprintf(_error_text, "SVSharedMemory::open_and_attach: %s",
                _pObjShm->get_error_text());
        return -1;
    }

    iRetVal = _pObjSem->open();
    if (iRetVal < 0) {
        sprintf(_error_text, "SVSemaphore::open: %s",
                _pObjSem->get_error_text());
        return -1;
    }

    // ��������ڴ�����ָ��λ��
    char *pShmPtr = (char *) _pObjShm->get_shm_ptr();
    pShmPtr += sizeof(ShmConfObjsHead_T) + _uCushionSize;

    _pShmPtrArray[_iConstConf_No] = pShmPtr;
    pShmPtr += _nConstConf_ShmSize + _uCushionSize;

    _pShmPtrArray[_iMainConf_No] = pShmPtr;
    pShmPtr += _nMainConf_ShmSize + _uCushionSize;

    _pShmPtrArray[_iAccessControl_No] = pShmPtr;
    pShmPtr += _nAccessControl_ShmSize + _uCushionSize;

    _pShmPtrArray[_iServerConf_No] = pShmPtr;
    pShmPtr += _nServerConf_ShmSize + _uCushionSize;

    _pShmPtrArray[_iServiceConf_No] = pShmPtr;

    pShmPtr += _nServiceConf_ShmSize + _uCushionSize;
    _pShmPtrArray[_iServerCmd_No] = pShmPtr;


    // �����������ö���
    _pConstConf = new CShmNameValueConf(_strConfigPath.c_str(),
                                        MAX_CONST_CONF_ROWS,
                                        _pShmPtrArray[_iConstConf_No],
                                        _nConstConf_ShmSize,
                                        _pObjSem,
                                        _iConstConf_No,
                                        SECTION_NAME_CONST_CONF);

    _pMainConf = new CShmNameValueConf(_strConfigPath.c_str(),
                                       MAX_MAIN_CONF_ROWS,
                                       _pShmPtrArray[_iMainConf_No],
                                       _nMainConf_ShmSize,
                                       _pObjSem,
                                       _iMainConf_No, SECTION_NAME_MAIN_CONF);

    _pAccessControl = new CShmAccessControl(_strConfigPath.c_str(),
                                            MAX_ACCESS_CONTROL_ROWS,
                                            _pShmPtrArray[_iAccessControl_No],
                                            _nAccessControl_ShmSize,
                                            _pObjSem, _iAccessControl_No);

    _pServerConf = new CShmServerConf(_strConfigPath.c_str(),
                                      MAX_SERVER_CONF_ROWS,
                                      _pShmPtrArray[_iServerConf_No],
                                      _nServerConf_ShmSize,
                                      _pObjSem, _iServerConf_No);

    _pServiceConf = new CShmServiceConf(_strConfigPath.c_str(),
                                        MAX_SERVICE_CONF_ROWS,
                                        _pShmPtrArray[_iServiceConf_No],
                                        _nServiceConf_ShmSize,
                                        _pObjSem, _iServiceConf_No);

    _pServerCmd = new CServerShmCmd(MAX_TRPC_SERVER_NO,
                                    MAX_SERVER_CMD_ROWS,
                                    _pShmPtrArray[_iServerCmd_No],
                                    _nServerCmd_ShmSize,
                                    _pObjSem, _iServerCmd_No);

    // ����Ƿ�Խ��
    char *pShmEnd = (char *) _pObjShm->get_shm_ptr() + _nShmSize;
    assert(_pShmPtrArray[_iConstConf_No] < pShmEnd);
    assert(_pShmPtrArray[_iMainConf_No] < pShmEnd);
    assert(_pShmPtrArray[_iAccessControl_No] < pShmEnd);
    assert(_pShmPtrArray[_iServerConf_No] < pShmEnd);
    assert(_pShmPtrArray[_iServiceConf_No] < pShmEnd);
    assert(_pShmPtrArray[_iServerCmd_No] < pShmEnd);
    pShmEnd = NULL;
    return 0;
}

int
CShmConfObjs::Close()
{
    int iRetVal;

    iRetVal = _pObjShm->dettach();
    if (iRetVal < 0) {
        sprintf(_error_text, "SVSharedMemory::dettach: %s",
                _pObjShm->get_error_text());
        return -1;
    }

    iRetVal = _pObjSem->close();
    if (iRetVal < 0) {
        sprintf(_error_text, "SVSemaphore::open: %s",
                _pObjSem->get_error_text());
        return -1;
    }

    return 0;
}

int
CShmConfObjs::Remove()
{
    int iRetVal;

    iRetVal = _pObjShm->remove();
    if (iRetVal < 0) {
        sprintf(_error_text, "SVSharedMemory::remove: %s",
                _pObjShm->get_error_text());
        return -1;
    }

    iRetVal = _pObjSem->remove();
    if (iRetVal < 0) {
        sprintf(_error_text, "SVSemaphore::remove: %s",
                _pObjSem->get_error_text());
        return -1;
    }

    return 0;
}

int
CShmConfObjs::ReadFromFile()
{
    trpc_debug_log("Into CShmConfObjs::ReadFromFile\n");

    if (_pConstConf->ReadFromFile() != 0) {
        sprintf(_error_text, "_pConstConf->ReadFromFile: %s",
                _pConstConf->get_error_text());
        return -1;
    }

    if (_pMainConf->ReadFromFile() != 0) {
        sprintf(_error_text, "_pMainConf->ReadFromFile: %s",
                _pMainConf->get_error_text());
        return -1;
    }

    if (_pAccessControl->ReadFromFile() != 0) {
        sprintf(_error_text, "_pAccessControl->ReadFromFile: %s",
                _pAccessControl->get_error_text());
        return -1;
    }

    if (_pServerConf->ReadFromFile() != 0) {
        sprintf(_error_text, "_pServerConf->ReadFromFile: %s",
                _pServerConf->get_error_text());
        return -1;
    }


    return 0;
}

int
CShmConfObjs::WriteToShm()
{
    trpc_debug_log("Into CShmConfObjs::WriteToShm\n");

    if (_pConstConf->WriteToShm() != 0) {
        sprintf(_error_text, "_pConstConf->WriteToShm: %s",
                _pConstConf->get_error_text());
        return -1;
    }

    if (_pMainConf->WriteToShm() != 0) {
        sprintf(_error_text, "_pMainConf->WriteToShm: %s",
                _pMainConf->get_error_text());
        return -1;
    }

    if (_pAccessControl->WriteToShm() != 0) {
        sprintf(_error_text, "_pAccessControl->WriteToShm: %s",
                _pAccessControl->get_error_text());
        return -1;
    }

    if (_pServerConf->WriteToShm() != 0) {
        sprintf(_error_text, "_pServerConf->WriteToShm: %s",
                _pServerConf->get_error_text());
        return -1;
    }


    return 0;
}

const void *
CShmConfObjs::GetShmPtr() const
{
    if (_pObjShm == NULL) {
        return NULL;
    }
    return _pObjShm->get_shm_ptr();
}
