/*
����: 
       1.  NameValue�����࣬�����ڹ����ڴ�ͱ����ڴ�

Created by Song, 2003-02
Change list:

*/

#include <stdio.h>
#include <assert.h>

#include "shm_name_value_conf.h"

CShmNameValueConf::CShmNameValueConf(const char *sConfigPath,
                                     unsigned uMaxRows,
                                     char *pShmPtr,
                                     size_t uShmSize,
                                     SVSemaphore * pObjSem,
                                     int iSemNum, const char *sSectionName)
    :
CShmConfig(sConfigPath, uMaxRows, pShmPtr, uShmSize, pObjSem, iSemNum),
_objConf(sConfigPath, uMaxRows, sSectionName)
{
    assert(_uShmSize == GetShmSize(uMaxRows));
}

CShmNameValueConf::~CShmNameValueConf()
{

}

int
CShmNameValueConf::ReadFromFile()
{
    return _objConf.ReadFromFile();
}

int
CShmNameValueConf::WriteToShm()
{
    _pHead->uRows = _objConf.GetRows();

    const NameValue_T *pLocalData = _objConf.GetRecord(0);
    memcpy(_pData, pLocalData, _objConf.GetRows() * sizeof(NameValue_T));

    return 0;
}

const NameValue_T *
CShmNameValueConf::GetRecord(unsigned uRow)
{
    if (_pHead == NULL || _pData == NULL) {
        sprintf(_error_text, "_pHead == %p, _pData == %p\n", _pHead, _pData);
        return NULL;
    }

    if (uRow >= _pHead->uRows) {
        sprintf(_error_text, "uRow >= _pHead->uRows: %d >= %d\n",
                uRow, _pHead->uRows);
        return NULL;
    }

    // �ж��Ƿ�Խ��
    assert((char *) ((const NameValue_T *) _pData + uRow) <
           (char *) _pShmEnd);

    return (const NameValue_T *) _pData + uRow;
}

void
CShmNameValueConf::PrintNameValue_T(const NameValue_T * p,
                                    int (*fnPrintf) (const char *fmt, ...))
{
    CNameValueConf::PrintNameValue_T(p, fnPrintf);
}

void
CShmNameValueConf::PrintShm(int (*fnPrintf) (const char *fmt, ...)) const
{
    if (_pHead == NULL || _pData == NULL) {
        fnPrintf("_pHead == %p, _pData == %p\n", _pHead, _pData);
        return;
    }

    int uRows = _pHead->uRows;
    const NameValue_T *p = (const NameValue_T *) _pData;

    fnPrintf("rows: %d\n", uRows);
    for (int i = 0; i < uRows; ++i, ++p) {
        PrintNameValue_T(p, fnPrintf);
    }
}

void
CShmNameValueConf::Print(int (*fnPrintf) (const char *fmt, ...)) const
{
    _objConf.Print(fnPrintf);
}
