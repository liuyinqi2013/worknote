/*
����: 
       1.  ���ضԸ���Server�Ŀ�������ͨѶ�����ڴ���

Created by Song, 2003-01
Change list:

*/

#include <stdio.h>
#include <assert.h>

#include "server_shm_cmd.h"

// ��ʼ����̬����
time_t
    CServerShmCmd::_tLastGetCmdTime =
    0;
int
    CServerShmCmd::_iLastGetSeqNo =
    0;
int
    CServerShmCmd::_iInsertSeqNo =
    0;

void
CServerShmCmd::InitStatic(time_t tLastGetCmdTime,
                          int iLastGetSeqNo, int iInsertSeqNo)
{
    _tLastGetCmdTime = tLastGetCmdTime;
    _iLastGetSeqNo = iLastGetSeqNo;
    _iInsertSeqNo = iInsertSeqNo;
}

CServerShmCmd::CServerShmCmd(unsigned uMaxServerNo,
                             unsigned uCmdsPerServer,
                             char *pShmPtr,
                             size_t uShmSize,
                             SVSemaphore * pObjSem, int iSemNum)
    :
_uMaxServerNo(uMaxServerNo),
_uCmdsPerServer(uCmdsPerServer),
_pShmPtr(pShmPtr),
_uShmSize(uShmSize),
_pShmEnd(pShmPtr + uShmSize),
_pObjSem(pObjSem),
_iSemNum(iSemNum)
{
    _Data = (ServerCommand_T *) _pShmPtr;
    assert(uShmSize == GetShmSize(uMaxServerNo, uCmdsPerServer));

    _error_text[0] = '\0';
}

CServerShmCmd::~CServerShmCmd()
{

}

int
CServerShmCmd::CmpServerCommand_T(const void *a, const void *b)
{
    const ServerCommand_T *p1 = (const ServerCommand_T *) a;
    const ServerCommand_T *p2 = (const ServerCommand_T *) b;

    if (p1->tInsertedTime > p2->tInsertedTime) {
        return 1;
    }
    else if (p1->tInsertedTime < p2->tInsertedTime) {
        return -1;
    }

    if (p1->iSeqNo > p2->iSeqNo) {
        return 1;
    }
    else if (p1->iSeqNo < p2->iSeqNo) {
        return -1;
    }

    return 0;
}

int
CServerShmCmd::CmpServerCommand_T_2(time_t tInsertedTime,
                                    int iSeqNo, const ServerCommand_T * p)
{
    if (tInsertedTime > p->tInsertedTime) {
        return 1;
    }
    else if (tInsertedTime < p->tInsertedTime) {
        return -1;
    }

    if (iSeqNo > p->iSeqNo) {
        return 1;
    }
    else if (iSeqNo < p->iSeqNo) {
        return -1;
    }

    return 0;
}

inline ServerCommand_T *
CServerShmCmd::_GetServerCommandPtr(unsigned uServerNo)
{
    if (uServerNo >= _uMaxServerNo) {
        sprintf(_error_text, "uServerNo >= _uMaxServerNo: %d >= %d",
                uServerNo, _uMaxServerNo);
        return NULL;
    }

    return _Data + _uCmdsPerServer * uServerNo;
}

inline int
CServerShmCmd::_Insert(unsigned uServerNo,
                       const char *sCmd, time_t tInsertTime, int iInsertSeqNo)
{
    // ���Զ�����tInsertedTime��iSeqNo��
    // ��Ϊ�˷�������Ԫ����(��������ָ��������ֵ)

    // �ҳ����ϵļ�¼�滻��

    ServerCommand_T *pOld = _GetServerCommandPtr(uServerNo);
    ServerCommand_T *p = pOld + 1;

    if (pOld == NULL) {
        return -1;
    }

    for (unsigned i = 1; i < _uCmdsPerServer; ++i, ++p) {
        assert((char *) p < (char *) _pShmEnd); // �ж��Ƿ�Խ��

        if (CmpServerCommand_T(p, pOld) < 0) {
            // ���ϵļ�¼
            pOld = p;
        }
    }

    assert((char *) pOld < (char *) _pShmEnd);  // �ж��Ƿ�Խ��

    pOld->iSeqNo = iInsertSeqNo;
    pOld->tInsertedTime = tInsertTime;
    strncpy(pOld->sCommand, sCmd, sizeof(pOld->sCommand));
    pOld->sCommand[sizeof(pOld->sCommand) - 1] = '\0';

    return 0;
}

int
CServerShmCmd::Insert(unsigned uServerNo, const char *sCmd)
{
    return _Insert(uServerNo, sCmd, time(NULL), _iInsertSeqNo++);
}

int
CServerShmCmd::Get(unsigned uServerNo, vector < ServerCommand_T > &vCmd)
{
    vCmd.clear();

    time_t tMaxCmdTime = _tLastGetCmdTime;
    int iMaxSeqNo = _iLastGetSeqNo;

    // �ٶ�5��֮�ڿ����������ѭ��
    time_t tNow = time(NULL) + 5;

    ServerCommand_T *p = _GetServerCommandPtr(uServerNo);
    if (p == NULL) {
        return 1;
    }

    for (unsigned i = 0; i < _uCmdsPerServer; ++i, ++p) {
        assert((char *) p < (char *) _pShmEnd); // �ж��Ƿ�Խ��

        if (p->tInsertedTime > tNow) {
            // ʱ��ֵ���ԣ�����
            p->tInsertedTime = 0;
            continue;
        }

        if (CmpServerCommand_T_2(_tLastGetCmdTime, _iLastGetSeqNo, p) < 0) {
            // �����ʱ��֮��ļ�¼
            vCmd.push_back(*p);

            if (CmpServerCommand_T_2(tMaxCmdTime, iMaxSeqNo, p) < 0) {
                tMaxCmdTime = p->tInsertedTime;
                iMaxSeqNo = p->iSeqNo;
            }
        }
    }

    if (vCmd.size() > 0) {
        _tLastGetCmdTime = tMaxCmdTime;
        _iLastGetSeqNo = iMaxSeqNo;
    }

    return 0;
}

const ServerCommand_T *
CServerShmCmd::GetRecord(unsigned uServerNo, unsigned uRecordNo)
{
    ServerCommand_T *p = _GetServerCommandPtr(uServerNo);
    if (p == NULL) {
        return NULL;
    }

    if (uRecordNo >= _uCmdsPerServer) {
        sprintf(_error_text, "uRecordNo >= _uCmdsPerServer: %d >= %d",
                uRecordNo, _uCmdsPerServer);
        return NULL;
    }

    assert((char *) (p + uRecordNo) < (char *) _pShmEnd);

    return p + uRecordNo;
}

int
CServerShmCmd::Reset(unsigned uServerNo)
{
    ServerCommand_T *p = _GetServerCommandPtr(uServerNo);
    if (p == NULL) {
        return 1;
    }

    memset(p, 0, _uCmdsPerServer * sizeof(ServerCommand_T));

    return 0;
}

void
CServerShmCmd::PrintServerCommand_T(const ServerCommand_T * p,
                                    int (*fnPrintf) (const char *fmt, ...))
{
    fnPrintf("InsertedTime:%ld, SeqNo: %d, Cmd: [%s]\n",
             p->tInsertedTime, p->iSeqNo, p->sCommand);
}

int
CServerShmCmd::Print(unsigned uServerNo,
                     int (*fnPrintf) (const char *fmt, ...))
{
    ServerCommand_T *p = _GetServerCommandPtr(uServerNo);
    if (p == NULL) {
        fnPrintf("%s", _error_text);
        return 1;
    }

    for (unsigned i = 0; i < _uCmdsPerServer; ++i, ++p) {
        PrintServerCommand_T(p, fnPrintf);
    }

    return 0;
}
