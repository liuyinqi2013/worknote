/*
����: 
       1.  ������Ķ���

Created by Song, 2003-02
Change list:

*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <setjmp.h>
#include <signal.h>
#include <errno.h>
#include <assert.h>
#include "log.h"
#include "trpc_queue.h"

#include <sys/time.h>

CTrpcQueue::CTrpcQueue(int iIpcKey,
            unsigned uMaxServerNo,
            unsigned uMaxServerProcNo,
            unsigned uRowsPerServer,
            unsigned uMaxMqNo,
            int iValidTime,
            int iRecyleTime,
            int iSendRetryTimes,
            int iSendSleepTime,
            int iSendSleepUs /*= 5*/)
    :
_iIpcKey(iIpcKey),
_uMaxServerNo(uMaxServerNo),
_uMaxServerProcNo(uMaxServerProcNo),
_uRowsPerServer(uRowsPerServer),
_uMaxMqNo(uMaxMqNo),
_iValidTime(iValidTime),
// ��ʱ���ù���ʱ��Ķ���
_iRecyleTime(iRecyleTime),
_iSendSleepUs(iSendSleepUs),
_iRequestRowsPerServer(uRowsPerServer - uMaxServerProcNo),
_iShmAreaSize(sizeof(TrpcShmMessageNode_T)),
_pObjMQArray(NULL),
_pObjShm(NULL),
_pObjSem(NULL),
_bMqIsExisted(true),
_bShmIsExisted(true),
_bSemIsExisted(true),
_iShmSize(0),
_bIsQueueError(false),
_iSemNo(0),
_pServerMQNum(NULL),
_pObjQueueHead(NULL),
_pObjMessageNode(NULL),
_iSendRetryTimes(iSendRetryTimes),
_iSendSleepTime(iSendSleepTime)
{
    assert(_iIpcKey >= 0);
    assert(_uMaxServerNo > 0);
    assert(_uMaxServerProcNo > 0);
    assert(_uRowsPerServer > 0);

    //assert(_uRowsPerServer > _uMaxServerProcNo);

    //ͷ�ڵ�
    _iShmSize += sizeof(TrpcShmMessageHead_T);

    //���serverӵ����Ϣ����������
    _iShmSize += sizeof(int)*_uMaxServerNo;

    //��Ϣ��
    _iShmSize += uMaxMqNo * _iShmAreaSize;
    assert(_iShmSize > 0);


    _pObjMQArray = new SVMessageQueue[_uMaxServerNo];
    for (unsigned i = 0; i < _uMaxServerNo; ++i) {
        _pObjMQArray[i].init(_iIpcKey + i, IPC_FLAGS);

    }
    _pObjShm = new SVSharedMemory(iIpcKey, IPC_FLAGS, _iShmSize);
    _pObjSem = new SVSemaphore(iIpcKey, IPC_FLAGS, _iSemNo + 1);

    _error_text[0] = '\0';
}

CTrpcQueue::~CTrpcQueue()
{
    Close();
    delete[]_pObjMQArray;
    delete _pObjShm;
    delete _pObjSem;
}

int
CTrpcQueue::Create()
{
    int iRetVal;

    _bMqIsExisted = false;
    _bShmIsExisted = false;
    _bSemIsExisted = false;

    iRetVal = _pObjShm->create();
    if (iRetVal < 0) {
        sprintf(_error_text, "SVSharedMemory::create: %s",
                _pObjShm->get_error_text());
        return -1;
    }
    else if (iRetVal > 0) {
        _bShmIsExisted = true;
    }

    for (unsigned i = 0; i < _uMaxServerNo; ++i) {
        SVMessageQueue *_pObjMQ = _pObjMQArray + i;

        for (int count = 0; count < 2; ++count) {
            iRetVal = _pObjMQ->create();
            if (iRetVal < 0) {
                sprintf(_error_text, "SVMessageQueue::create(%d): %s",
                        i, _pObjMQ->get_error_text());
                return -1;
            }
            else if (iRetVal > 0) {
                _bMqIsExisted = true;
                // �Ȱ���Ϣ����ɾ�����ٴ���
                (void) _pObjMQ->remove();
                continue;
            }

            break;
        }
    }

    ushort *arrSemInit = new ushort[_iSemNo + 1];
    for (int i = 0; i <= _iSemNo; ++i) {
        arrSemInit[i] = 1;
        //arrSemInit[i + _uMaxServerNo] = _iRequestRowsPerServer;
    }
    iRetVal = _pObjSem->create(arrSemInit);
    delete[]arrSemInit;
    if (iRetVal < 0) {
        sprintf(_error_text, "SVSemaphore::create: %s",
                _pObjSem->get_error_text());
        return -1;
    }
    else if (iRetVal > 0) {
        _bSemIsExisted = true;
    }

    return 0;
}

int
CTrpcQueue::Open()
{
    int iRetVal;

    if (_bSemIsExisted) {
        iRetVal = _pObjSem->open();
        if (iRetVal != 0) {
            sprintf(_error_text, "SVSemaphore::open: %s",
                    _pObjSem->get_error_text());
            return -1;
        }
    }

    for (unsigned i = 0; i < _uMaxServerNo; ++i) {
        SVMessageQueue *_pObjMQ = _pObjMQArray + i;

        iRetVal = _pObjMQ->open();
        if (iRetVal != 0) {
            sprintf(_error_text, "SVMessageQueue::open(%d): %s",
                    i, _pObjMQ->get_error_text());
            return -1;
        }
    }

    iRetVal = _pObjShm->open_and_attach();
    if (iRetVal != 0) {
        sprintf(_error_text, "SVSharedMemory::open_and_attach: %s",
                _pObjShm->get_error_text());
        return -1;
    }

    //added by verminniu 2007-8-23
    
    //��������ṹ�ڹ����ڴ��е�λ��
    
    char *pShmPtr = (char *) _pObjShm->get_shm_ptr();
    _pObjQueueHead = (TrpcShmMessageHead_T *)pShmPtr;

    pShmPtr += sizeof(TrpcShmMessageHead_T);
    _pServerMQNum = (int *)pShmPtr;

    pShmPtr += sizeof(unsigned)*_uMaxServerNo;
    _pObjMessageNode = (TrpcShmMessageNode_T *)pShmPtr;
    
    //end added by verminniu 2007-8-23
    
    return 0;
}

int
CTrpcQueue::Close()
{
    for (unsigned i = 0; i < _uMaxServerNo; ++i) {
        SVMessageQueue *_pObjMQ = _pObjMQArray + i;
        _pObjMQ->close();
    }

    _pObjShm->dettach();
    _pObjSem->close();

    return 0;
}

int
CTrpcQueue::Remove()
{
    int iRetVal;

    for (unsigned i = 0; i < _uMaxServerNo; ++i) {
        SVMessageQueue *_pObjMQ = _pObjMQArray + i;

        iRetVal = _pObjMQ->remove();
        if (iRetVal != 0) {
            sprintf(_error_text, "SVMessageQueue::remove(%d): %s",
                    i, _pObjMQ->get_error_text());
            return -1;
        }
    }

    iRetVal = _pObjShm->remove();
    if (iRetVal != 0) {
        sprintf(_error_text, "SVSharedMemory::remove: %s",
                _pObjShm->get_error_text());
        return -1;
    }

    iRetVal = _pObjSem->remove();
    if (iRetVal != 0) {
        sprintf(_error_text, "SVSemaphore::remove: %s",
                _pObjSem->get_error_text());
        return -1;
    }

    return 0;
}

/* changed by verminniu
   ��Ϣ�洢������server���ã�����Ҫ����server�������ַ
inline char *
CTrpcQueue::GetShmArea(int iQueueNo)
{
    return (char *) _pObjShm->get_shm_ptr()
        + _iShmAreaSize * iQueueNo + sizeof(TrpcShmMessageHead_T);
}

*/

inline TrpcShmMessage_T *
CTrpcQueue::GetShmNode(int iShmRecNo)
{
        return (TrpcShmMessage_T *) (_pObjMessageNode + iShmRecNo ); 
}

/*  ���нڵ���ջ�У�����Ҫ����
TrpcShmMessage_T *
CTrpcQueue::GetFreeShmNode(int iQueueNo, int &iShmRecNo)
{
    char *pArea = GetShmArea(iQueueNo);
    //TrpcShmMessageHead_T * pHead = (TrpcShmMessageHead_T *)pArea;
    TrpcShmMessage_T *pMsg =
        (TrpcShmMessage_T *) (pArea + sizeof(TrpcShmMessageHead_T));

    for (unsigned i = 0; i < _iRequestRowsPerServer; ++i, ++pMsg) {
        if (pMsg->iStatus == CT_STATUS_FREE) {
            // �ҵ��սڵ�
            iShmRecNo = i;
            return pMsg;
        }
    }

    // �Ҳ����սڵ�
    return NULL;
}
*/

TrpcShmMessage_T *
CTrpcQueue::GetFreeShmNode(unsigned uServerNo, int &iShmRecNo)
{   
    //û�п��нڵ�
    if(_pObjQueueHead->iFreeListHead < 0)
        return NULL;

    //server�ɷ���Ľڵ������ѵ�������
    if(_pServerMQNum[uServerNo] >= (int)_uRowsPerServer)
        return NULL;

    iShmRecNo = _pObjQueueHead->iFreeListHead;

    _pObjQueueHead->iFreeListHead = _pObjMessageNode[iShmRecNo].inext;

    return &_pObjMessageNode[iShmRecNo].Data;
}

void
CTrpcQueue::AlarmHandler(int signo)
{
    signal(SIGALRM, AlarmHandler);
}

/**
 * Funciton:  ������Ϣ������
  ����:
  iQueueNo:  ���б��
  uProcessNo:  Server�еĽ��̱�ţ�
  		����CallType==CT_CALL_TYPE_INNER_RESPONDʱ��Ч
  stMsg:  ��Ϣ��¼
  iTimeOut:  ȡ��¼�Ķ�ʱʱ��
  iFlags:  ����recvʱ��flags�����msgsnd�ֲ�
  
 return value:  0 successful
                 SEND_QUEUE_FULL  ������
                 SEND_TIME_OUT  ���빲���ڴ�����ʱ
                 SEND_ERROR_QUEUE  ���д���
                 
                 < 0 have error(s)
**/
int
CTrpcQueue::Send(unsigned uServerNo,
                 unsigned uProcessNo,
                 const TrpcShmMessage_T & stMsg,
                 const char *sData, int iTimeOut /*= 0*/ ,
                 int iFlags /*= 0*/ )
{
    _bIsQueueError = false;

    if (stMsg.iDestServerNo >= _uMaxServerNo) {
        sprintf(_error_text, "iDestServerNo >= _uMaxServerNo: %d >= %d",
                stMsg.iDestServerNo, _uMaxServerNo);
        return -1;
    }

    // �������ڴ�����¼
    int iShmRecNo;
    TrpcShmMessage_T *pMsg;

    if (_pObjSem->lock(_iSemNo) != 0) {
        sprintf(_error_text, "SVSemaphore::lock: %s",
                _pObjSem->get_error_text());

        _bIsQueueError = true;
        return SEND_ERROR_QUEUE;
    }

    // �Ҳ�������ֱ�ӷ���,����ѯ
    pMsg = GetFreeShmNode(uServerNo, iShmRecNo);
    if (pMsg == NULL) {
        _pObjSem->unlock(_iSemNo);
        return SEND_QUEUE_FULL;
    }
        
    //  ����mcmcpy�Ĵ���
    // (�������һ�Σ�������ϵͳ��copy��һ��sData)
    size_t nMcpSize = (char *) stMsg.sData - (char *) &stMsg;
    memcpy(pMsg, &stMsg, nMcpSize);
    
    // ��ǰ��buf ��ձ��������������
    memset(pMsg->sData, 0x00,sizeof(pMsg->sData));
    memcpy(pMsg->sData, sData, stMsg.iDataLen);

	// �޸Ľṹ��ṹ������һ��memcpy 
    // �ֶ���һ��
    // Added by Song 2004-01-12
    // ��ʶservice������Դ(IP��service)
    nMcpSize = sizeof(stMsg) - ((char *)stMsg.sSrcEntry - (char *) &stMsg);
    memcpy(pMsg->sSrcEntry, stMsg.sSrcEntry, nMcpSize);
    // End of Added by Song 2004-01-12
	
    pMsg->iStatus = CT_STATUS_REDY;
    
    //added by verminniu 2004-8-23
    //���ӹ����ڴ��м�¼server������Ϣ�ĸ���
    ++_pServerMQNum[uServerNo];

    //endadded by verminniu 2004-8-23
    
    _pObjSem->unlock(_iSemNo);


    // ����Ϣ���в����¼
    CTrpcMqMessage objMqMsg;
    objMqMsg.set_type(stMsg.lMqType);
    objMqMsg.SetServerNo(stMsg.iDestServerNo);
    objMqMsg.SetShmRecNo(iShmRecNo);
    objMqMsg.SetWaterFlow(stMsg.uWaterFlow);
    objMqMsg.SetEnqueueTime(stMsg.tEnqueueTime);

    // ����alarm����ʱ��msgsndֻ����һ���Ĵ���
    SVMessageQueue *pObjMq = _pObjMQArray + uServerNo;

    for (int i=0; i<_iSendRetryTimes; ++i)
    {
        int iRetVal = pObjMq->send(objMqMsg, objMqMsg.Size(), iFlags | IPC_NOWAIT);
        if (0 == iRetVal){
            return 0;
        }

        //����
        if (EAGAIN == errno){
            usleep(_iSendSleepTime);
            continue;
        }

        break;
    }

    sprintf(_error_text, "SVMessageQueue::send: %s",
            pObjMq->get_error_text());
    // ��ΪFree��������
  
    //added by verminniu 2007-9-6
    //�������ջ�ȡ�Ľڵ�
    PushFreeList(iShmRecNo);
    //end added by verminniu 2007-9-6
  
	// msgsnd����,Ӧ���ǳ�������,���ö���
    _bIsQueueError = true;
    return SEND_ERROR_QUEUE;
}

/**
 * Funciton:  �Ӷ�����ȡ��Ϣ
  ����:
  iQueueNo:  ���б��
  lMsgType:  System V �е�mtype
  stMsg:  ��Ϣ��¼
  iTimeOut:  ȡ��¼�Ķ�ʱʱ��
  iFlags:  ����recvʱ��flags�����msgsnd�ֲ�
  
 return value:  0 successful
                 RECV_TIME_OUT time out
                 RECV_QUEUE_REMOVED ��Ϣ���б�ɾ��
                 RECV_ERROR_QUEUE ���г���
                 RECV_ROW_TOO_OLD ��¼̫��
                 RECV_NOT_MATCH ��¼�д�
                 < 0 have error(s)
**/
int
CTrpcQueue::Recv(unsigned uServerNo,
                 long lMsgType,
                 TrpcShmMessage_T & stMsg, int iTimeOut /*= 0*/ ,
                 int iFlags /*= 0*/ )
{
    _bIsQueueError = false;

    /*
       ��Ҫע��ĵط�
       1��EqueueTime��ʱ��ļ�¼Ҫ�ӵ�
       2������ʱ���б�ɾ���Ĵ���
     */

    // ����Ϣ������ȡ��Ϣ
    if (uServerNo >= _uMaxServerNo) {
        sprintf(_error_text, "iQueueNo >= _uMaxServerNo: %d >= %d",
                uServerNo, _uMaxServerNo);
        return -1;
    }

    // ��������
    signal(SIGALRM, AlarmHandler);
    alarm(iTimeOut);

    CTrpcMqMessage objMqMsg;
    SVMessageQueue *pObjMq = _pObjMQArray + uServerNo;
    int iRetVal = pObjMq->recv(objMqMsg, objMqMsg.Size(), lMsgType, iFlags);
    if (iRetVal != 0) {
        sprintf(_error_text, "SVMessageQueue::recv: %s",
                pObjMq->get_error_text());

        alarm(0);
        if (errno == EINTR) {
            // ���ź��жϣ���Ϊ�ǳ�ʱ
            return RECV_TIME_OUT;
        }

        _bIsQueueError = true;
        if (errno == EIDRM) {
            // ���б�ɾ��
            return RECV_QUEUE_REMOVED;
        }

        return RECV_ERROR_QUEUE;
    }
    alarm(0);

    
    //changed by verminniu 2007-9-10
    //��֤��Ϣ�ڵ��ڶ�����
    if (objMqMsg.GetShmRecNo() >= _uMaxMqNo) {
        sprintf(_error_text, "ShmRecNo too large: %d >= %d",
                objMqMsg.GetShmRecNo(), _uMaxMqNo);
        return -1;
    }
     //changed by verminniu 2007-9-10


    // �ӹ����ڴ���ȡ��¼��������
    TrpcShmMessage_T *pMsg = GetShmNode(objMqMsg.GetShmRecNo());

    memcpy(&stMsg, pMsg, sizeof(stMsg));

    // �����¼�Ƿ���Ч
    if (stMsg.iStatus != CT_STATUS_REDY) {
        sprintf(_error_text, "iStatus==%d wrong, ShmNodeNo=%u", pMsg->iStatus, objMqMsg.GetShmRecNo());
        return RECV_NOT_MATCH;
    }

    if (stMsg.iDestServerNo != objMqMsg.GetServerNo()) {
        sprintf(_error_text, "ServerNo not match: %d -- %d, ShmNodeNo=%u",
                stMsg.iDestServerNo, objMqMsg.GetServerNo(), objMqMsg.GetShmRecNo());
        return RECV_NOT_MATCH;
    }

    if (stMsg.uWaterFlow != objMqMsg.GetWaterFlow()) {
        sprintf(_error_text, "uWaterFlow not match: %d -- %d, ShmNodeNo=%u",
                stMsg.uWaterFlow, objMqMsg.GetWaterFlow(), objMqMsg.GetShmRecNo());
        return RECV_NOT_MATCH;
    }

    if (stMsg.tEnqueueTime != objMqMsg.GetEnqueueTime()) {
        sprintf(_error_text, "tEnqueueTime not match: %ld -- %ld, ShmNodeNo=%u",
                stMsg.tEnqueueTime, objMqMsg.GetEnqueueTime(), objMqMsg.GetShmRecNo());

        return RECV_NOT_MATCH;
    }

    //added by verminniu 2007-8-23 

    //���нڵ����
    if(PushFreeList(objMqMsg.GetShmRecNo()) != 0)
        return -1;

    // ���ù����ڴ����ڵ�Ϊ��
    //pMsg->iStatus = CT_STATUS_FREE;
    
     //end added by verminniu

    time_t tNow = time(NULL);
    if (tNow - stMsg.tEnqueueTime > _iValidTime) {
        // ��ʱ����¼��Ч
        sprintf(_error_text, "record too old: _iValidTime==%d", _iValidTime);
        return RECV_ROW_TOO_OLD;
    }

    return 0;
}

void
Print_TrpcShmMessage_T(const TrpcShmMessage_T & stMsg)
{
    printf("iStatus: %d\n", stMsg.iStatus);
    printf("iCallType: %d\n", stMsg.iCallType);
    printf("sServiceName: [%s]\n", stMsg.sServiceName);
    printf("iSrcServerNo: %d\n", stMsg.iSrcServerNo);
    printf("iDestServerNo: %d\n", stMsg.iDestServerNo);
    printf("iSocketNo: %d\n", stMsg.iSocketNo);
    printf("iSocketNoID: %d\n", stMsg.iSocketNoID);
    printf("uWaterFlow: %d\n", stMsg.uWaterFlow);
    printf("tEnqueueTime: %ld\n", stMsg.tEnqueueTime);
    printf("lMqType: %ld\n", stMsg.lMqType);
    printf("iReplyMqNo: %d\n", stMsg.iReplyMqNo);
    printf("lReplyMqType: %ld\n", stMsg.lReplyMqType);
    printf("iDataLen: %d\n", stMsg.iDataLen);
}

void
Print_TrpcShmMessageHead_T(const TrpcShmMessageHead_T & stHead)
{
    printf("iFreeListHead: %d\n", stHead.iFreeListHead);
}

/********  added by verminniu    ****
**  ��ʼ����Ϣ��
**  ����:   0 ��ʼ���ɹ�
**          1 �Ѿ�����ʼ����
**         -1 ����
********/

int 
CTrpcQueue::InitFreeList()
{
    //��Ϣ����Ϊ0
    if (_uMaxMqNo == 0){
        sprintf(_error_text, "_uMaxMqNo == 0");
        return -1;
    }

    
    if (_bShmIsExisted)
        return 1;

    memset(_pServerMQNum, 0, sizeof(int)*_uMaxServerNo);

    _pObjQueueHead->iFreeListHead = 0;

    unsigned uEnd = _uMaxMqNo - 1;
    for (unsigned i=0;i < uEnd;++i)
        _pObjMessageNode[i].inext = i+1;

    //inext = -1��ʾ��β
    _pObjMessageNode[uEnd].inext = -1;

    return 0;
}

//�������
int
CTrpcQueue::PushFreeList(int iShmNo)
{       
    //��Ҫ���յĽڵ��ڶ�����
    if( iShmNo >= (int)_uMaxMqNo || iShmNo < 0)
    {
        sprintf(_error_text, "CTrpcQueue::PushFreeList iShmNo too large: %d > %d",
            iShmNo,_uMaxMqNo);
        return -1;
    }

    
    if( _pObjSem->lock(_iSemNo) == -1)
    {
        sprintf(_error_text, "CTrpcQueue::PushFreeList Lock Error:%s",
            _pObjSem->get_error_text());
        return -1;
    }

	//�Ѿ�Ϊ���в���Ҫ����   
    if(_pObjMessageNode[iShmNo].Data.iStatus == CT_STATUS_FREE)
    {
    	_pObjSem->unlock(_iSemNo);
        return 0;
    }
	
    //Server����ںϷ���Χ��
    if( _pObjMessageNode[iShmNo].Data.iQueueServerNo < 0 
            || _pObjMessageNode[iShmNo].Data.iQueueServerNo > _uMaxServerNo)
    {
        sprintf(_error_text, "CTrpcQueue::PushFreeList QueueServerNo Error: %d",
            _pObjMessageNode[iShmNo].Data.iQueueServerNo);
		_pObjSem->unlock(_iSemNo);
        return -1;
    }
    

    _pObjMessageNode[iShmNo].inext = _pObjQueueHead->iFreeListHead;
    _pObjQueueHead->iFreeListHead = iShmNo; 

    //����server�ڹ����ڴ��е���Ϣ����
    if( _pServerMQNum[_pObjMessageNode[iShmNo].Data.iQueueServerNo] > 0 )
    {
        --_pServerMQNum[_pObjMessageNode[iShmNo].Data.iQueueServerNo];
    }
    else
    {
        _pServerMQNum[_pObjMessageNode[iShmNo].Data.iQueueServerNo] = 0;
    }

    //��Ϣ�ڵ���Ϊfree
    _pObjMessageNode[iShmNo].Data.iStatus = CT_STATUS_FREE;

    _pObjSem->unlock(_iSemNo);

    return 0;
}


/*********
**      ���ճ�ʱ�Ľڵ�
**      ����ֵ:
**          ��ȷ    ���յĽڵ����Ŀ
**          ����    -1
**********/
int
CTrpcQueue::RecyleNodeByTime()
{
    time_t tNow = time(NULL);

    struct timeval stTimeBegin, stTimeEnd;

    unsigned iRecyledNum = 0;

    gettimeofday(&stTimeBegin, NULL);
    
    for (unsigned i=0;i<_uMaxMqNo;++i)
    {
        TrpcShmMessage_T * pShmMsgPtr = &_pObjMessageNode[i].Data;
        if( tNow - pShmMsgPtr->tEnqueueTime > _iRecyleTime && pShmMsgPtr->iStatus != CT_STATUS_FREE)
        {
            ++iRecyledNum;
            if( PushFreeList(i) == -1)             
                return -1;
            pShmMsgPtr->iStatus = CT_STATUS_FREE;
        }
    }

    gettimeofday(&stTimeEnd, NULL);

    if(iRecyledNum != 0)
    {
        trpc_debug_log("Recyled %d Nodes Use: %d.%06d\n", 
                iRecyledNum,
                stTimeEnd.tv_sec-stTimeBegin.tv_sec,
				stTimeEnd.tv_usec-stTimeBegin.tv_usec);
    }

    return iRecyledNum;
}

/***********
**      �������нڵ������
**     ����
**          �����нڵ���մ�ӡ����ʱ��
***********/
int
CTrpcQueue::RecyleAllNode() 
{
    _pObjQueueHead->iFreeListHead = -1;

    for(unsigned i=0;i<_uMaxMqNo;++i)
    {
        TrpcShmMessage_T * pShmMsgPtr = &_pObjMessageNode[i].Data;
        pShmMsgPtr->tEnqueueTime = 0;
        pShmMsgPtr->iStatus = CT_STATUS_REDY;
    }
    
     time_t tNow = time(NULL);

    struct timeval stTimeBegin, stTimeEnd;

    unsigned iRecyledNum = 0;

    gettimeofday(&stTimeBegin, NULL);
    
    for (unsigned i=0;i<_uMaxMqNo;++i,++iRecyledNum)
    {
        TrpcShmMessage_T * pShmMsgPtr = &_pObjMessageNode[i].Data;
        if( tNow - pShmMsgPtr->tEnqueueTime > _iRecyleTime && pShmMsgPtr->iStatus != CT_STATUS_FREE)
        {
            if( PushFreeList(i) == -1)             
                return -1;
           // pShmMsgPtr->iStatus = CT_STATUS_FREE;
        }
    }

    gettimeofday(&stTimeEnd, NULL);

    trpc_error_log("Recyled %d Nodes Use: %d.%06d\n", 
                iRecyledNum,
                stTimeEnd.tv_sec-stTimeBegin.tv_sec,
				stTimeEnd.tv_usec-stTimeBegin.tv_usec);

    return iRecyledNum;
}

//��ӡ��Ϣ��Ϣ
void
CTrpcQueue::PrintServerMqInfo(int (*fnPrintf) (const char *fmt, ...))
{
    fnPrintf("%10s\t%10s\n","ServerNo","UsedNodes");
    for (unsigned i =0;i < _uMaxServerNo;++i)
        {
            fnPrintf("%10d%10d\n", i, _pServerMQNum[i]);
        }
}

int 
CTrpcQueue::GetServerMq(int iServerNo)
{
	if (iServerNo >= (int)_uMaxServerNo || iServerNo < 0)
		return -1;
	
	return _pServerMQNum[iServerNo];
}


//end added by verminniu
