#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <libgen.h>
#include <errno.h>

#include "log.h"
#include "asyn_server.h"

int
main(int argc, char **argv)
{
    if (argc < 7) {
        fprintf(stderr,
                "Usage: %s server_no process_no conf_ipc_key logfile logsize lognum\n",
                argv[0]);
        return -1;
    }

    for (int fd = 3; fd < 64; ++fd) {
        close(fd);
    }

    // ȡServer������
    char sServerName[256];
    strncpy(sServerName, argv[0], sizeof(sServerName));
    sServerName[sizeof(sServerName) - 1] = '\0';
    strcpy(sServerName, basename(sServerName));

    // ȡ����
    unsigned uServerNo = atoi(argv[1]);
    unsigned uProcessNo = 0;
    if (uServerNo <= 0 || uServerNo >= NORMAL_SERVER_NO_BEGIN) {
        fprintf(stderr, "ERROR: ServerNo==%d\n", uServerNo);
        return -1;
    }

    int iConfIpcKey = atoi(argv[3]);
    const char *pLogFile = argv[4];
    int iMaxLogSize = atoi(argv[5]);
    int iMaxLogNum = atoi(argv[6]);

    // �����־Ŀ¼�����ڣ�����Ŀ¼
    char sLogDir[256];
    strcpy(sLogDir, pLogFile);
    strcpy(sLogDir, dirname(sLogDir));
    struct stat stStat;
    if (stat(sLogDir, &stStat) != 0) {
        if (mkdir(sLogDir, 0775) < 0) {
            fprintf(stderr, "mkdir %s: %s\n", sLogDir, strerror(errno));
            return -1;
        }
    }

    g_pLog = new CLog(pLogFile, iMaxLogSize, iMaxLogNum);
    if (g_pLog->open() != 0) {
        fprintf(stderr, "CLog::open: %s\n", g_pLog->get_error());
        delete g_pLog;
        return -1;
    }

	// added by verminniu
	// acclog
	char sAccLogFile[256] = {0};
	snprintf(sAccLogFile, sizeof(sAccLogFile) - 1,
		"%s_acc", pLogFile);

	g_pAccLog = new CLog(sAccLogFile, iMaxLogSize, iMaxLogNum);
    if (g_pAccLog->open() != 0) {
        fprintf(stderr, "CLog::open: AccLog %s\n", g_pAccLog->get_error());
        delete g_pAccLog;
        return -1;
    }
	// end added by verminniu

    // ȡ��������
    const char *pTrpcHome = getenv(TRPC_HOME_NAME);
    if (pTrpcHome == NULL) {
        trpc_error_log("Environment variable '%s' not found\n",
                       TRPC_HOME_NAME);
        delete g_pLog;
        return -1;
    }

    if (ReadStaticConfig(pTrpcHome) != 0){
        fprintf(stderr, "ERROR: ReadStaticConfig\n");
    }

    g_pServer = new CAsynServer(pTrpcHome, sServerName, uServerNo, uProcessNo, iConfIpcKey);

    if (g_pServer->Init() != 0) {
        fprintf(stderr, "ERROR: CAsynServer::Init: %s\n",
                g_pServer->get_error_text());
        goto _error;
    }

    if (g_pServer->Run() != 0) {
        fprintf(stderr, "ERROR: CAsynServer::Run: %s\n",
                g_pServer->get_error_text());
        goto _error;
    }

    delete g_pServer;
    delete g_pLog;

    return 0;

  _error:
    delete g_pServer;
    delete g_pLog;
    return -1;
}
