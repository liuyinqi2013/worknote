/*
����:
       1.  Middled��ʵ��

Created by Song, 2003-02,03
Change list:

*/

#include <cstdio>
#include <cstring>
#include <ctype.h>
#include <assert.h>
#include <pthread.h>
#include <sys/types.h>
#include <signal.h>
#include <errno.h>

#include "asyn_server.h"
#include "log_mutex.h"

CAsynServer *g_pServer = NULL;

// ��ʼ����̬����
unsigned
    CAsynServer::_uWaterFlow =
    0;

const char * const
    CAsynServer::TRPC_DATA_FILR_PATH = "data";

CAsynServer::CAsynServer(const char *sTrpcHome,
                            const char *sServerName, 
                            unsigned uServerNo,
                            unsigned uProcessNo, 
                            int iConfIpcKey)
    :
_iRecvTimeOut(DEFAULT_MSG_RECV_TIME_OUT),
_iSendTimeOut(DEFAULT_MSG_SEND_TIME_OUT),
_iWaitTimeOut(DEFAULT_WAIT_TIME_OUT),
_iQueueTimeOut(DEFAULT_QUEUE_TIME_OUT),
_iScanTimeOut(_iQueueTimeOut * 2),
_iScanSleepTime(DEFAULT_SCAN_SLEEP_TIME),
_strTrpcHome(sTrpcHome),
_strServerName(sServerName),
_pSendQueue(NULL),
_pRecvQueue(NULL),
_pShmConfObjs(NULL),
_pid(getpid()),
_pServerInfo(NULL),
_iConfIpcKey(iConfIpcKey),
_iQueueIpcKey((key_t) - 1),
_iMaxMqNum(0),
_iFileNodeNum(0),
_uServerNo(uServerNo),
_uProcessNo(uProcessNo),
_pLogMutex(NULL),
_pAccLogMutex(NULL),
_pWarningHandle(NULL),
_pStatHandle(NULL)
{
    char sConfigPath[256];
    
    size_t nLen = strlen(sTrpcHome);
    if (nLen == 0 || sTrpcHome[nLen - 1] != '/') {
        _strTrpcHome += "/";
    }

    // ��¼ÿ�������ļ�����־
    _strInFileLog = _strTrpcHome + "log/" + _strServerName + "/day/infile";
    
    // ��¼ÿ�����ļ�ɾ������־
    _strOutFileLog = _strTrpcHome + "log/" + _strServerName + "/day/outfile";

    // ���������ļ�·��
    snprintf(sConfigPath, sizeof(sConfigPath), "%sconf/%s.conf",
             _strTrpcHome.c_str(), sServerName);

    _strConfFile = sConfigPath;

    _pLogMutex = new CLogMutex();
	_pAccLogMutex = new CLogMutex();

    // ��ʼ��Server������ڴ���
    CServerShmCmd::InitStatic(time(NULL), 0, 0);

    _ThreadIDArray[0] = 0;
    _ThreadIDArray[1] = 0;
    _ThreadIDArray[2] = 0;

    _error_text[0] = '\0';

    if (_uServerNo == ASYN_SERVER_NO){
        _iMqType = CT_ASYN_CALL_MQ_TYPE;
        _iCallType = CT_CALL_TYPE_ASYN_REQUEST;
        _iResCallType = CT_CALL_TYPE_ASYN_RESPOND;
        _iErrorNo = TRPC_ERR_ASYN_CALL;
        _iStatItem = STAT_MIDDLE_ASYN_CALL_RECV;
        strncpy(_szFileFullErrorId, ERR_MIDDLE_ASYN_FILE_FULL, sizeof(_szFileFullErrorId) - 1);
    } else {
        _iMqType = CT_ERROR_CALL_MQ_TYPE;
        _iCallType = CT_CALL_TYPE_ERROR_REQUEST;
        _iResCallType = CT_CALL_TYPE_ERROR_RESPOND;
        _iErrorNo = TRPC_ERR_ERR_CALL;
        _iStatItem = STAT_MIDDLE_ERROR_CALL_RECV;
        strncpy(_szFileFullErrorId, ERR_MIDDLE_ERR_FILE_FULL, sizeof(_szFileFullErrorId) - 1);
    }

    // ����ɨ���߳���Ϣ
    // new�׳��쳣core������...
    _ScanThreadInfoArray = new TrpcScanThreadInfo_T[MAX_TRPC_SERVER_NO];
    memset(_ScanThreadInfoArray, 0x00, MAX_TRPC_SERVER_NO * sizeof(TrpcScanThreadInfo_T));

    signal(SIGINT, SIG_IGN);
    signal(SIGHUP, SIG_IGN);
    signal(SIGQUIT, SIG_IGN);
    signal(SIGPIPE, SIG_IGN);
    signal(SIGTTOU, SIG_IGN);
    signal(SIGTTIN, SIG_IGN);
    signal(SIGCHLD, SIG_IGN);
    signal(SIGTERM, SIG_IGN);
}

CAsynServer::~CAsynServer()
{
    for (unsigned int i = 0; i < MAX_TRPC_SERVER_NO; ++i){
        delete (_pDataFilePtrArray + i);
    }
    delete _pDataFilePtrArray;
    
    if (_pSendQueue != NULL) {
        _pSendQueue->Close();
    }
    delete _pSendQueue;

    delete _pRecvQueue;
    if (_pRecvQueue != NULL) {
        _pRecvQueue->Close();
    }

    delete _pShmConfObjs;
    if (_pShmConfObjs != NULL) {
        _pShmConfObjs->Close();
    }
    
    delete _pWarningHandle;
    delete _pStatHandle;

    delete _pMainConf;

    delete _pLogMutex;
}


int
CAsynServer::ReadConfig(const char *sConfigFile)
{
    int iRetVal;

    // ��ȡ�����ļ���Main
    _pMainConf = new CNameValueConf(sConfigFile, MAX_MAIN_CONF_ROWS, "Main");

    iRetVal = _pMainConf->ReadFromFile();
    if (iRetVal != 0) {
        sprintf(_error_text, "ReadConfig: %s", _pMainConf->get_error_text());
        return -1;
    }

    const int CONF_SIZE = 2;

    char sNameArr[CONF_SIZE][128] = {
        {"ScanSleepTime"},
        {"FileNodeNum"}
    };

    int iRetArr[CONF_SIZE];
    iRetArr[0] = _pMainConf->GetNameValue(sNameArr[0], _iScanSleepTime);
    iRetArr[1] = _pMainConf->GetNameValue(sNameArr[1], _iFileNodeNum);
    
    for (int i = 0; i < CONF_SIZE; ++i) {
        if (iRetArr[i] != 0) {
            sprintf(_error_text, "ReadConfig: MainConf not found: [%s]",
                    sNameArr[i]);

            return -1;
        }
    }

    return 0;
}

int
CAsynServer::InitShmConfig()
{
    trpc_debug_log("Into CServer::InitShmConfig\n");

    // Server���ܴ������ļ���ȡ���õ������ڴ�
    // �����ļ�����Ϊ��
    _pShmConfObjs = new CShmConfObjs("",
                                     _iConfIpcKey,
                                     MAX_TRPC_SERVER_NO,
                                     MAX_CONF_CUSHION_SIZE);

    CShmConfObjs *pObjs = _pShmConfObjs;

    int iRetVal = pObjs->Open();
    if (iRetVal < 0) {
        sprintf(_error_text, "CShmConfObjs::Open: %s",
                pObjs->get_error_text());
        return -1;
    }

    // ����ServerInfo
    CShmServerConf *pServerConf = pObjs->GetServerConf();
    assert(pServerConf != NULL);

    ServerConf_T *pServerInfo =
        pServerConf->GetServerInfoPtr(_uServerNo);
    if (pServerInfo == NULL) {
        sprintf(_error_text, "CShmServerConf::GetServerInfoPtr: %s",
                pServerConf->get_error_text());
        return -1;
    }
    strncpy(pServerInfo->sServerName, _strServerName.c_str(),
            sizeof(pServerInfo->sServerName));
    pServerInfo->sServerName[sizeof(pServerInfo->sServerName) - 1] = '\0';

    // ������־����
    int *pLogLevel = pServerConf->GetLogLevelPtr(_uServerNo);
    if (pLogLevel == NULL) {
        trpc_error_log("InitShmConfig: GetLogLevelPtr(%u): %s",
                       _uServerNo, pServerConf->get_error_text());
        // ��������
    }

    trpc_set_log_level_ptr(pLogLevel);
    trpc_set_log_mutex(_pLogMutex);

	trpc_set_acclog_level_ptr(pLogLevel);
	trpc_set_acclog_mutex(_pAccLogMutex);

    return 0;
}

int
CAsynServer::ReadConstConfig()
{
    trpc_debug_log("Into CAsynServer::ReadConstConfig\n");

    // ��ȡ�����ļ���Const
    CShmNameValueConf *pConstConf = _pShmConfObjs->GetConstConf();

    const int NAME_ARR_SIZE = 2;

    char sNameArr[NAME_ARR_SIZE][128] = {
        {"QueueIpcKey"},
        {"MaxMqNum"}
    };

    int iRetArr[NAME_ARR_SIZE];
    iRetArr[0] = pConstConf->GetNameValue(sNameArr[0], _iQueueIpcKey);
    iRetArr[1] = pConstConf->GetNameValue(sNameArr[1], _iMaxMqNum);

    for (int i = 0; i < NAME_ARR_SIZE; ++i) {
        if (iRetArr[i] != 0) {
            sprintf(_error_text, "ConstConf not found: [%s]", sNameArr[i]);
            return -1;
        }
    }

    return 0;
}

int
CAsynServer::InitTrpcQueue()
{
    trpc_debug_log("Into CAsynServer::InitTrpcQueue\n");

    int iRetVal;

    CShmNameValueConf *pConstConf = _pShmConfObjs->GetConstConf();
    assert(pConstConf != NULL);

    int iQueueValidTime;
    iRetVal = pConstConf->GetNameValue("QueueValidTime", iQueueValidTime);
    if (iRetVal != 0) {
        iQueueValidTime = DEFAULT_QUEUE_VALID_TIME;
    }
    
    int iRecyleTime;
    iRetVal = pConstConf->GetNameValue("QueueRecyleTime", iRecyleTime);
    if (iRetVal != 0) {
        iRecyleTime = DEFAULT_RECYLE_TIME;
    }

    int iSendRetryTimes;
    iRetVal = pConstConf->GetNameValue("MQSendRetryTimes", iSendRetryTimes);
    if (iRetVal != 0) {
        iSendRetryTimes = DEFAULT_SEND_RETRY_TIMES;
    }

    int iSendSleepTime;
    iRetVal = pConstConf->GetNameValue("MQSendSleepTime", iSendSleepTime);
    if (iRetVal != 0) {
        iSendSleepTime = DEFAULT_SEND_SLEEP_TIME;
    }

    unsigned uMaxRowsPerServer;
    iRetVal = pConstConf->GetNameValue("MaxRowsPerServer", uMaxRowsPerServer);
    if (iRetVal != 0) {
        uMaxRowsPerServer = DEFAULT_MAX_ROWS_PER_SERVER;
    }

    // ������
    _pSendQueue = new CTrpcQueue(_iQueueIpcKey,
                                 MAX_TRPC_SERVER_NO,
                                 MAX_TRPC_PROCESS_NO,
                                 uMaxRowsPerServer,
                                 _iMaxMqNum,
                                 iQueueValidTime,
                                 iRecyleTime,
                                 iSendRetryTimes,
                                 iSendSleepTime,
                                 5);
    iRetVal = _pSendQueue->Create();
    if (iRetVal < 0) {
        sprintf(_error_text, "CTrpcQueue::Create: %s",
                _pSendQueue->get_error_text());
        return -1;
    }

    iRetVal = _pSendQueue->Open();
    if (iRetVal < 0) {
        sprintf(_error_text, "CTrpcQueue::Open: %s",
                _pSendQueue->get_error_text());
        return -1;
    }

    // ������
    _pRecvQueue = new CTrpcQueue(_iQueueIpcKey,
                                 MAX_TRPC_SERVER_NO,
                                 MAX_TRPC_PROCESS_NO,
                                 uMaxRowsPerServer,
                                 _iMaxMqNum,
                                 iQueueValidTime,
                                 iSendRetryTimes,
                                 iSendSleepTime,
                                 5);

    iRetVal = _pRecvQueue->Open();
    if (iRetVal < 0) {
        sprintf(_error_text, "CTrpcQueue::Open: %s",
                _pRecvQueue->get_error_text());
        return -1;
    }

    return 0;
}

int
CAsynServer::InitProcInfo()
{
    trpc_debug_log("Into CAsynServer::InitProcInfo\n");

    // ȡ�ñ�Server�Ĺ����ڴ�ָ��
    CShmServerConf *pServerConf = _pShmConfObjs->GetServerConf();
    assert(pServerConf != NULL);

    _pServerInfo = pServerConf->GetServerInfoPtr(_uServerNo);
    if (_pServerInfo == NULL) {
        trpc_error_log("CShmServerConf::GetServerInfoPtr: %s\n",
                       pServerConf->get_error_text());
        return -1;
    }


    // ������־����
    if (pServerConf->Lock() != 0) {
        sprintf(_error_text, "pServerConf->Lock: %s",
                pServerConf->get_error_text());
        return -1;
    }

    ProcessInfo_T *p = pServerConf->GetProcessInfoPtr(_uServerNo,
                                                      _uProcessNo);
    if (p == NULL) {
        sprintf(_error_text, "GetProcessInfoPtr: not found(%d, %d)",
                _uServerNo, _uProcessNo);
        pServerConf->UnLock();
        return -1;
    }

    _pid = getpid();
    time_t tNow = time(NULL);
    p->pid = _pid;
    p->tStartTime = tNow;
    p->tHeartbeatTime = tNow;
    // ����״̬Ϊ����
    _pServerInfo->iStatus = CT_PROC_RUNNING;

    pServerConf->UnLock();

    return 0;
}

// ��ʼ�������ļ�
int
CAsynServer::InitDataFile()
{
    trpc_debug_log("Into CAsynServer::InitDataFile\n");

    // ��ʼ������
    _pDataFilePtrArray = new CTrpcData *[MAX_TRPC_SERVER_NO];

    if (_pDataFilePtrArray == NULL){
        sprintf(_error_text, "InitDataFile Error: _pDataFilePtrArray new error");
    
        return -1; 
    }

    // ��ʱ�����ļ���
    char szFileName[MAX_DATA_FILE_NAME_LENGTH] = {0};

    // ��ʼ��ÿ����
    // ����ͨ����ʼ
    for (unsigned int i = NORMAL_SERVER_NO_BEGIN; i < MAX_TRPC_SERVER_NO; ++i){
        memset(szFileName, 0x00, sizeof(szFileName));
        
        // ƴ���ļ���,��׺Ϊserver��� -- �п��ܷ��񲻴���,��û������
        snprintf(szFileName, sizeof(szFileName) - 1,
            "%s/%s/%s/%u.dat", _strTrpcHome.c_str(), TRPC_DATA_FILR_PATH, _strServerName.c_str(), i);

        _pDataFilePtrArray[i] = new CTrpcData(_iFileNodeNum, szFileName, _iScanTimeOut);

        if (_pDataFilePtrArray[i] == NULL){
            sprintf(_error_text, "InitDataFile Error: _pDataFilePtrArray[%d] new error", i);
    
            return -1; 
        }
    }

    return 0;
}

int
CAsynServer::InitClient()
{
    CShmNameValueConf *pConstConf = _pShmConfObjs->GetConstConf();
    
    const int NAME_ARRAY_SIZE = 4;
    
    char sNameArr[NAME_ARRAY_SIZE][128]= {
        {"WarningHost"},
        {"WarningPort"},
        {"StatHost"},
        {"StatPort"}
    };

    int iRetArr[NAME_ARRAY_SIZE];
    // warning
    iRetArr[0] = pConstConf->GetNameValue(sNameArr[0], _sWarningIp, sizeof(_sWarningIp));
    iRetArr[1] = pConstConf->GetNameValue(sNameArr[1], _iWarningPort);

    // stat
    iRetArr[2] = pConstConf->GetNameValue(sNameArr[2], _sStatIp, sizeof(_sStatIp));
    iRetArr[3] = pConstConf->GetNameValue(sNameArr[3], _iStatPort);

    // �������Ƿ���ͳ����Ϣ,�������ж�����
    if (_sStatIp[0] != 0 && _iWarningPort != 0)
    {
        _pWarningHandle = new CTrpcWarning(_sWarningIp, _iWarningPort);
    }
    else
    {
        _pWarningHandle = NULL;
    }

    if (_sStatIp[0] != 0 && _iStatPort != 0)
    {
        _pStatHandle = new CTrpcStat(_sStatIp, _iStatPort);
    }
    else
    {
        _pStatHandle = NULL;
    }


    return 0;
}


/**
 * Funciton: ��ʼ����Դ
  ����:

 return value true: 0 �ɹ�
                 != 0: ʧ��
**/
int
CAsynServer::Init()
{
    trpc_debug_log("Into CAsynServer::Init\n");

    int iRetVal;

    iRetVal = ReadConfig(_strConfFile.c_str());
    if (iRetVal != 0) {
        trpc_error_log("ReadConfig %s: %s\n",
                       _strConfFile.c_str(), _error_text);
        return -1;
    }

    iRetVal = InitShmConfig();
    if (iRetVal != 0) {
        trpc_error_log("InitShmConfig %s: %s\n",
                       "", _error_text);
        return -1;
    }

    iRetVal = ReadConstConfig();
    if (iRetVal != 0) {
        trpc_error_log("ReadConstConfig : %s\n",
                       _error_text);
        return -1;
    }

    iRetVal = InitTrpcQueue();
    if (iRetVal != 0) {
        trpc_error_log("InitTrpcQueue: %s\n", _error_text);
        return -1;
    }

    iRetVal = InitDataFile();
    if (iRetVal != 0) {
        trpc_error_log("InitDataFile: %s\n", _error_text);
        return -1;
    }
    
    // ��ʼ��ͳ�ƺͱ���
    if (InitClient() != 0) {
        trpc_error_log("Init: %s\n", _error_text);
        return -1;
    }

    trpc_write_log("CAsynServer::Init Finnished\n\n");

    return 0;
}

int
CAsynServer::Run()
{
    trpc_debug_log("Into CAsynServer::Run\n");

    _HeartBeatArray[0] = _HeartBeatArray[1] = _HeartBeatArray[2] = time(NULL);

    pthread_t thread_recv;
    
    if (pthread_create(&thread_recv, NULL, RequestThreadEntrance, (void *) this) != 0) {
        trpc_error_log("pthread_create:RequestThreadEntrance %s\n", strerror(errno));
        Exit(-1);
    }

    // ����ÿ��server����ɨ���߳�
    for (unsigned int i = NORMAL_SERVER_NO_BEGIN; i < MAX_TRPC_SERVER_NO; ++i){
    //for (unsigned int i = NORMAL_SERVER_NO_BEGIN; i < NORMAL_SERVER_NO_BEGIN+1; ++i){
    
        _ScanThreadInfoArray[i].handle = this;
        _ScanThreadInfoArray[i].server_no = i;
        
        if (pthread_create(&_ScanThreadInfoArray[i].pid, NULL, ScanThreadEntrance, (void *) &_ScanThreadInfoArray[i]) != 0) {
            trpc_error_log("pthread_create:RespondThreadEntrance %s\n", strerror(errno));
            Exit(-1);
        }
    }

    pthread_detach(pthread_self());

    SendQueueThread();

    return 0;
}

// ����server���������߳�
int
CAsynServer::SendQueueThread()
{
    _ThreadIDArray[0] = getpid();

    for (;;) {
        try {
            RunOnce();
        }
        catch(SocketException & e) {
            trpc_error_log("SocketException: %s\n", e.what());
        }

        ThreadHeartBeat(0);
    }
    return 0;
}

int
CAsynServer::RequestRecvThread()
{
    trpc_debug_log("Into CAsynServer::RequestRecvThread\n");

    // ����������Ϣ
    if (InitProcInfo() != 0) {
        trpc_error_log("InitProcInfo: %s\n", _error_text);
        return -1;
    }

    _ThreadIDArray[1] = getpid();

    int iRetVal = 0;
    int iCount = 0;

    for (;;) {
        iRetVal = Enqueue();
        // ���г�������Ѿ�����

        ++iCount;
        if (iRetVal == 2 || iCount > 3) {
            // ��ʱ�����ߴ���3�����ú��������ڴ�����
            ThreadHeartBeat(1);

            DealShmCmd();
            iCount = 0;
        }
    }

    return 0;
}

int 
CAsynServer::ScanThread(unsigned server_no)
{
    for(;;){
        ScanAllNode(server_no);

        sleep(_iScanSleepTime);
    }

    return 0;
}

int
CAsynServer::ScanAllNode(unsigned server_no)
{
    // ɨ��һ��server�������ļ�,���Ƿ��г�ʱ����
    CTrpcData * server_data = _pDataFilePtrArray[server_no];
    time_t      now = time(NULL);

    int ret = 0;

    ret = server_data->file_ok();
    
    // ����ļ��Ƿ�����
    if (ret < 0){
        // �ļ� ��С����,����
        trpc_error_log("server %d data file is not ok: %s\n",
            server_no, server_data->get_error_text());
        
        return -1;
    }
    else if (ret > 0){
        // �ļ������ڲ���¼��־
        return 1;
    }

    for (long int i = 0; i < server_data->max_node(); ++i){
        // �ж��Ƿ�ʱ
        int ret = server_data->check_timeout(i, now);
        if (ret == 0){
            // �˽�û�г�ʱ
            continue;
        } else if (ret < 0) {
            // ���ش���
            trpc_error_log("check time out error server[%u], offset [%ld] info: %s\n",
                server_no, i, server_data->get_error_text());

            continue;
        } else {
            trpc_debug_log("ScanAllNode queue_push serverno: %d, i: %d, now: %d\n", 
                server_no, i, now);

            // �ڵ㳬ʱ,�������
            queue_push(server_no, i, now);
        }
    }

    return 0;
}


void *
CAsynServer::RequestThreadEntrance(void *arg)
{
    trpc_debug_log("Into CAsynServer::ThreadEntrance\n");

    pthread_detach(pthread_self());

    CAsynServer *pThis = (CAsynServer *) arg;
    pThis->RequestRecvThread();
    return NULL;
}

void * 
CAsynServer::ScanThreadEntrance(void * arg)
{
    pthread_detach(pthread_self());

    TrpcScanThreadInfo_T * param = (TrpcScanThreadInfo_T *) arg;
    
    trpc_debug_log("Into CAsynServer::ScanThreadEntrance %u\n",
            param->server_no);

    // ��ʱ��sleep server_no��, ����ÿ�������ļ���ɨ��ʱ��
    // �������߳�ͬʱ��һ����ȥɨ�������ļ����ϵͳ���ع���
    sleep(param->server_no);
        
    param->handle->ScanThread(param->server_no);
    return NULL;
}

// д�ļ�
int
CAsynServer::WriteFile(TrpcShmMessage_T& stMsg)
{
    trpc_debug_log("CAsynServer::WriteFile: ServiceName==%s, From==%s\n",
    		stMsg.sServiceName,
    		stMsg.sSrcEntry);

    long int offset = 0;

    // ��־�Ƿ��ǲ�������ٴ��׳����
    bool again = false;

    // ���ñ�������ˮ��
    // �����ļ�����ˮ��
    stMsg.uWaterFlow = ++_uWaterFlow;

    // ����Ƿ��ǲ����������
    // �ڶ��εĲ������Ͳ�ʵʱ�ط���
    if (stMsg.tInFileTime != 0) {
        // uWaterFlow, tInFileTime, iTimeOutTimes ��������ǰ��
        again = true;
    } else {
        // �����ļ�ʱ��
        stMsg.tInFileTime = time(NULL);

        // ��ʱΪ0
        stMsg.iTimeOutTimes = 0;
    }
    
	// ���ӳ���ʱ�����д�빲���ڴ�
    gettimeofday(&stMsg.tvDequeueTimeStamp, NULL);

    if (ServerNOOK(stMsg.iDestServerNo) != 0) {
        trpc_error_log("CAsynServer::WriteFile Invalid ServerNo: %d\n", stMsg.iDestServerNo);
        return -1;
    }

    // ��¼��Ϣ���ļ�
    offset = _pDataFilePtrArray[stMsg.iDestServerNo]->set(&stMsg);

    trpc_debug_log("CAsynServer::WriteFile set data serverno: %d, offset: %d, water_flow: %u, again: %d, iTimeOutTimes: %d\n", 
        stMsg.iDestServerNo, stMsg.iOffset, stMsg.uWaterFlow, again, stMsg.iTimeOutTimes);

    if (offset < 0) {
        // ���ش���
        trpc_error_log("CAsynServer::WriteFile Set [%d]: %s\n", stMsg.iDestServerNo,
            _pDataFilePtrArray[stMsg.iDestServerNo]->get_error_text());

        char Content[128] = {0};

        snprintf(Content, sizeof(Content) - 1, "%s Write ServerNo: %d", _strServerName.c_str(), _uServerNo);

        Warning(_szFileFullErrorId, Content);

        snprintf(_error_text, sizeof(_error_text) - 1,
            "CAsynServer::WriteFile error info: %s", _pDataFilePtrArray[stMsg.iDestServerNo]->get_error_text());
            

        SendReturnMsg(stMsg, _iErrorNo);
    } else {
        // ���سɹ�
        SendReturnMsg(stMsg, TRPC_RT_OK);

        // ������ǵ�һ�ε����,д�����,ʵʱ�ط�
        if (!again)
        {
            // ���Ӷ���
            queue_push(stMsg.iDestServerNo, stMsg.iOffset, stMsg.tEnqueueTime);
        }
        
        // ÿ��д���ļ�����¼��־
        // �¼Ӵ�ӡ����� -- ��߶����ı���,���ⲻ��
        trpc_day_log(_strInFileLog.c_str(),
                "|%u|%s|%u|%ld|%d|%ld|%s\n",
                stMsg.uWaterFlow,
                stMsg.sServiceName,
                stMsg.iDestServerNo,
                stMsg.iOffset,
                stMsg.tInFileTime,
                stMsg.iTimeOutTimes,
                stMsg.sData
            );
    }

    return 0;
}

// ɾ���ļ���Ϣ
int
CAsynServer::DelFile(TrpcShmMessage_T& stMsg)
{
    int iRetVal = 0;
        
    // ��鷵��ֵ,���ж�Ӧ�õķ�����
    if (stMsg.iResult != 0){
        // ֱ�ӷ���,���´��ط�
        trpc_error_log("Dequeue CTrpcQueue::Recv: iResult %d\n",
            stMsg.iResult);
        return 3;
    }

    trpc_debug_log("delete serverno: %d, offset: %d, water_flow: %u\n", 
        stMsg.iSrcServerNo, stMsg.iOffset, stMsg.uWaterFlow);
    
    if (ServerNOOK(stMsg.iSrcServerNo) != 0) {
        trpc_error_log("Dequeue Invalid ServerNo: %d\n", stMsg.iSrcServerNo);
        return -1;
    }
    
    // ����ֵΪ0,ֱ��ɾ���ļ�
    iRetVal = _pDataFilePtrArray[stMsg.iSrcServerNo]->del(stMsg.iOffset, &stMsg);

    trpc_debug_log("delete serverno: %d, offset: %d, water_flow: %u, ret: %d\n", 
        stMsg.iSrcServerNo, stMsg.iOffset, stMsg.uWaterFlow, iRetVal);

    if (iRetVal < 0){
        trpc_error_log("CAsynServer::DelFile: %s\n", _pDataFilePtrArray[stMsg.iSrcServerNo]->get_error_text());
        return -1;
    }

    // ��¼ɾ���ļ���־-- ��ǰ���һ������ʱ��
    trpc_day_log(_strOutFileLog.c_str(),
            "|%u|%s|%u|%ld|%d|%ld|%d|%d|%s|%s\n",
            stMsg.uWaterFlow,
            stMsg.sServiceName,
            stMsg.iSrcServerNo,
            stMsg.iOffset,
            stMsg.tInFileTime,
            stMsg.iTimeOutTimes,
            stMsg.iResult,
            time(NULL) - stMsg.tInFileTime,
            "normal deleted",
            stMsg.sData
        );
    
    return 0;
}

// �ж��Ƿ�Ϊ������Ϣ
bool
CAsynServer::IsRespond(TrpcShmMessage_T& stMsg)
{
    return _iResCallType == stMsg.iCallType;
}

// �����ⲿ����,д�ļ�
int
CAsynServer::RunOnce()
{
    int iRetVal = 0;
    
    TrpcShmMessage_T stMsg;

    // �Ӷ�����ȡ����
    // middled���ò�����첽����,����������
    iRetVal = _pRecvQueue->Recv(_uServerNo,
                            CT_NORMAL_MQ_TYPE, stMsg, _iRecvTimeOut);

    if (_pRecvQueue->IsQueueError()) {
        trpc_error_log("RunOnce CTrpcQueue::Recv: %s\n", _pRecvQueue->get_error_text());
        return 1;
    }
    else if (iRetVal == CTrpcQueue::RECV_TIME_OUT) { 
        return 2;
    }
    else if (iRetVal == CTrpcQueue::RECV_ROW_TOO_OLD) {
        trpc_debug_log("RunOnce CTrpcQueue::Recv: %s\n", _pRecvQueue->get_error_text());

        // ���Ͱ�̫�ϵ�ͳ����Ϣ
        SendStat(STAT_MIDDLE_PACKET_TOO_OLD, 1);

        if (IsRespond(stMsg))
        {
            // ���ͳ�ʱ����
            SendReturnMsg(stMsg, TRPC_ERR_PACKET_OLD);

            return -1;
        }
        else
        {
            // ����ǵ��÷���,��ʹ���ݳ�ʱҲ��������
        }
    }
    else if (iRetVal != 0) {
        trpc_error_log("RunOnce CTrpcQueue::Recv: %s\n", _pRecvQueue->get_error_text());
        return -1;
    }
    
    // �ж��ǵ���,���Ƿ���
    if (IsRespond(stMsg))
    {
        // ɾ������
        return DelFile(stMsg);
    }
    else
    {
        // ����ͳ����Ϣ
        SendStat(_iStatItem, 1);
    
        // д������
        return WriteFile(stMsg);
    }

    return 0;
}

// ��server�Ķ��з���
int
CAsynServer::Enqueue()
{
    unsigned server_no = 0;
    long int offset = 0;

    int ret = 0;

    ret = queue_pop(server_no, offset);

    if (ret < 0) {
        return ret;
    } else if (ret > 0){
        // ��ʱ,����0
        return 0;
    }

    // ��ȡ��Ϣ
    TrpcShmMessage_T stMsg;

    memset(&stMsg, 0x00, sizeof(stMsg));

    ret = _pDataFilePtrArray[server_no]->get(offset, &stMsg);
    if (ret < 0){      
        // ���ش���
        trpc_error_log("CAsynServer::get [%d]: %s\n", server_no,
            _pDataFilePtrArray[server_no]->get_error_text());

        
        snprintf(_error_text, sizeof(_error_text) - 1,
            "CAsynServer::Enqueue : %s", _pDataFilePtrArray[server_no]->get_error_text());

        return -1;
    }

    if (stMsg.iTimeOutTimes > 5) {
        // ��ʱɨ�赽5������,���ͱ�������
        // ��������Ϣ
        char Content[1024] = {0};

        snprintf(Content, sizeof(Content) - 1, "[%s][%ld] Has Got %ld Times Error", stMsg.sServiceName, stMsg.iOffset, stMsg.iTimeOutTimes);

        Warning(ERR_MIDDLE_ERR_TIMES, Content);
    }

    // ����server
    TrpcShmMessage_T * pstMsg = &stMsg;

    if (ServerNOOK(stMsg.iDestServerNo) != 0) {
        trpc_error_log("Enqueue Invalid ServerNo: %d\n", stMsg.iDestServerNo);
        return -1;
    }

    // ����Ƿ�����Ѿ�ֹͣ
    if (CheckServerState(stMsg.iDestServerNo) != 0) {
        trpc_error_log("Server Stoped ServerNo: %d\n", stMsg.iDestServerNo);
        return -1;
    }
    
    pstMsg->iCallType = _iCallType;
    
    pstMsg->lMqType = CT_NORMAL_MQ_TYPE;
    pstMsg->iReplyMqNo = _uServerNo;

    // �����ڴ��е�״̬,�����������ļ��е�״̬
    pstMsg->iStatus = CT_STATUS_REDY;
    
    // ����ҲΪ��ͨ��Ϣͨ�����е�calltype����
    pstMsg->lReplyMqType = CT_NORMAL_MQ_TYPE;

    // �޸ķ���ʱ��--- �ڴ��еĶ������ʱ��
    pstMsg->tEnqueueTime = time(NULL);

    // ���ڵ�ʵ�ʵ�server���
    pstMsg->iQueueServerNo = pstMsg->iDestServerNo;

    // Added by Song 2004-01-12
    // ��ʶservice������Դ(IP��service)
    snprintf(pstMsg->sSrcEntry, sizeof(pstMsg->sSrcEntry),
        "%s", _strServerName.c_str());
    // End of Added by Song 2004-01-12

    // sDataֱ�Ӵ���Send����
    int iRetVal = _pSendQueue->Send(pstMsg->iDestServerNo,
                                    0,
                                    *pstMsg,
                                    pstMsg->sData,
                                    0,
                                    0);
    if (_pSendQueue->IsQueueError()) {
        // ���г���
        sprintf(_error_text, "CTrpcQueue::Send: %s",
                _pSendQueue->get_error_text());
        trpc_error_log("Enqueue %s\n", _error_text);

        (void) _pSendQueue->Close();
        for (;;) {
            sleep(1);
            if (_pSendQueue->Open() == 0) {
                trpc_write_log("Enqueue CTrpcQueue::Open: OK\n");
                break;
            }
            else {
                trpc_error_log("Enqueue CTrpcQueue::Open: %s\n",
                   _pSendQueue->get_error_text());
            }
        }
        return -1;
    }
    else if (iRetVal < 0) {
        sprintf(_error_text, "CTrpcQueue::Send: %s",
                _pSendQueue->get_error_text());
        return -1;
    }
    else if (iRetVal > 0) {
        trpc_write_log("Enqueue CTrpcQueue::Send: iRetVal==%d\n", iRetVal);
        
        // ������,ֱ�ӷ���
        return iRetVal;
    }

    trpc_debug_log("Enqueue serverno: %d, offset: %d, water_flow: %u\n", 
        stMsg.iDestServerNo, stMsg.iOffset, stMsg.uWaterFlow);

    return 0;
}

// ���ͷ��ذ�
int 
CAsynServer::SendReturnMsg(const TrpcShmMessage_T& stMsg, int iRetNo)
{
    TrpcShmMessage_T stRetMsg;
    int iResult = 0;

    // ��ʱʹ��,����ƴ�ӷ�����Ϣ
    TRPC_SVCINFO *rqst = &_stSvcInfo;

    stRetMsg.iResult = iRetNo;
    
    rqst->olen = trpc_strerror_len(stRetMsg.iResult);
    strncpy(rqst->odata, trpc_strerror(stRetMsg.iResult), MAX_TRPC_ERRMSG_LEN);
    rqst->odata[MAX_TRPC_ERRMSG_LEN - 1] = '\0';

    if (stMsg.iCallType == CT_CALL_TYPE_INNER_REQUEST) {
        stRetMsg.iCallType = CT_CALL_TYPE_INNER_RESPOND;
    } else if (stMsg.iCallType == CT_CALL_TYPE_EXT_REQUEST){
        stRetMsg.iCallType = CT_CALL_TYPE_EXT_RESPOND;
    } else if (stMsg.iCallType == CT_CALL_TYPE_ASYN_REQUEST){
        stRetMsg.iCallType = CT_CALL_TYPE_ASYN_RESPOND;
    } else {
        stRetMsg.iCallType = CT_CALL_TYPE_ERROR_RESPOND;
    }
    
    strncpy(stRetMsg.sServiceName, stMsg.sServiceName, sizeof(stRetMsg.sServiceName));
    stRetMsg.sServiceName[sizeof(stRetMsg.sServiceName) - 1] = '\0';

    stRetMsg.iSrcServerNo = _uServerNo;
    stRetMsg.iDestServerNo = stMsg.iSrcServerNo;
    stRetMsg.iSocketNo = stMsg.iSocketNo;
    stRetMsg.iSocketNoID = stMsg.iSocketNoID;
    stRetMsg.uWaterFlow = stMsg.uWaterFlow;
    stRetMsg.iSeqNo = stMsg.iSeqNo;
    // ���õ�ǰϵͳʱ��
    stRetMsg.tEnqueueTime = time(NULL);
    stRetMsg.lMqType = stMsg.lReplyMqType;      // ע�⣬��Ҫ
    stRetMsg.iReplyMqNo = stMsg.iSrcServerNo;
    stRetMsg.lReplyMqType = 0;
    stRetMsg.iDataLen = rqst->olen;

    // ���ڵ�ֱ�����ڵ�server���
    stRetMsg.iQueueServerNo = stMsg.iReplyMqNo;

	// ����ʱ���
	stRetMsg.tvEnqueueTimeStamp = stMsg.tvEnqueueTimeStamp;
    
 	// ���ӳ���ʱ�����д�빲���ڴ�
    gettimeofday(&stRetMsg.tvDequeueTimeStamp, NULL);
    
    // ���������ǰlogkey
    memcpy(stRetMsg.sLogKey, stMsg.sData, sizeof(stRetMsg.sLogKey) - 1);

    // ���ý�����
    stRetMsg.sLogKey[sizeof(stRetMsg.sLogKey) - 1] = 0;
    
    // sDataֱ�Ӵ���Send ����
    int iRetVal = _pSendQueue->Send(stMsg.iReplyMqNo,
                            stMsg.uReplyProcessNo,
                            stRetMsg, rqst->odata, _iSendTimeOut, 0);
    if (_pSendQueue->IsQueueError()) {
        trpc_error_log("CTrpcQueue::Send: %s\n", _pSendQueue->get_error_text());
        iResult = 1;
    }
    else if (iRetVal < 0) {
        trpc_error_log("CTrpcQueue::Send: %s\n", _pSendQueue->get_error_text());
        iResult = -1;
    }
    else if (iRetVal > 0) {
        trpc_error_log("Send msg time out: SocketNo==%d, WaterFlow==%d\n",
                       stMsg.iSocketNo, stMsg.uWaterFlow);
        trpc_error_log("CTrpcQueue::Send: iRetVal==%d\n", iRetVal);
        iResult = -1;
    }

    return iResult;
}

int
CAsynServer::GetDestServiceInfo(const char *sServiceName,
                                  ServiceInfo_T & stServerInfo)
{
    CShmServiceConf *pServiceConf = _pShmConfObjs->GetServiceConf();
    assert(pServiceConf != NULL);

    if (pServiceConf->Lock() != 0) {
        sprintf(_error_text, "CShmServiceConf::Lock: %s",
                pServiceConf->get_error_text());
        return -1;
    }

    const ServiceInfo_T *pServiceInfo = pServiceConf->Get(sServiceName);
    if (pServiceInfo == NULL) {
        pServiceConf->UnLock();
        return 1;
    }
    memcpy(&stServerInfo, pServiceInfo, sizeof(stServerInfo));
    pServiceConf->UnLock();

    return 0;
}

// ��ȡserver��Ϣ
int
CAsynServer::GetServerInfo(unsigned uServerNo, ServerConf_T & stServerInfo)
{
    CShmServerConf *pServerConf = _pShmConfObjs->GetServerConf();
    if (pServerConf->Lock() != 0) {
        sprintf(_error_text, "pServerConf->Lock: %s",
                pServerConf->get_error_text());
        return -1;
    }


    ServerConf_T *pServerInfo = pServerConf->GetServerInfoPtr(uServerNo);
    if (pServerInfo != NULL) {
        memcpy(&stServerInfo, pServerInfo, sizeof(ServerConf_T));
    }
    pServerConf->UnLock();

    if (pServerInfo == NULL) {
        // �Ҳ���
        return 1;
    }

    return 0;
}

int
CAsynServer::CheckServerState(unsigned uServerNo)
{
    // �Ҹ�Server ����Ϣ
    ServerConf_T stServerInfo;
    int iRetVal = GetServerInfo(uServerNo, stServerInfo);

    if (iRetVal != 0){
        return -1;
    }

    // ���server״̬�ǲ�������
    if (stServerInfo.iStatus != CT_PROC_RUNNING){
        // �������״̬����running�Ļ�,�����������,����
        char Content[1024] = {0};

        snprintf(Content, sizeof(Content) - 1, "%s is stop", stServerInfo.sServerName);

        Warning(ERR_MIDDLE_SERVER_STOPED, Content);

        return 1;
    }

    return 0;
}

int
CAsynServer::ThreadHeartBeat(int nThreadNo)
{
    time_t tNow = time(NULL);
    _HeartBeatArray[nThreadNo] = tNow;

    int nOtherThreadNo = (nThreadNo == 0 ? 1 : 0);

    if (tNow - _HeartBeatArray[nOtherThreadNo] > _tThreadTimeOut) {
        trpc_error_log("Thread %d TimeOut(TimeOut==%ld)\n",
                       nOtherThreadNo, _tThreadTimeOut);

        pid_t iOtherPid = _ThreadIDArray[nOtherThreadNo];
        trpc_error_log("pid %d %s\n",
        		iOtherPid,
        		CheckProcess(iOtherPid) == 0 ? "found":"not found");
        Exit(-1);
    }

    if (nThreadNo == 1) {
        // ������
        ProcessInfo_T *pProcInfo =
            &_pServerInfo->stProcInfoArray[_uProcessNo];
        if (_pid != pProcInfo->pid) {
            // �б�Ľ�����������ǰ�����˳�
            trpc_error_log("pid not match: %d != %d\n", _pid, pProcInfo->pid);
            Exit(-1);
        }
        pProcInfo->tHeartbeatTime = tNow;
    }


    return 0;
}

int
CAsynServer::DealShmCmd()
{
//trpc_debug_log("Into CAsynServer::DealShmCmd\n");

    vector < ServerCommand_T > vCmd;

    // ������
    CServerShmCmd *pShmCmd = _pShmConfObjs->GetServerCmd();
    if (pShmCmd->Get(_uServerNo, vCmd) != 0) {
        trpc_error_log("CServerShmCmd::Get: %s\n", pShmCmd->get_error_text());

        return -1;
    }

    if (vCmd.size() <= 0) {
        return 0;
    }

    string strStop = TRPC_SHM_CMD_STOP;
    string strInit = TRPC_SHM_CMD_INIT;
    string strLoadconf = TRPC_SHM_CMD_LOADCONF;
    string strLoadso = TRPC_SHM_CMD_LOADSO;
    string strErrClean = TRPC_SHM_CMD_ERRCLEAN;

    // ��������
    for (vector < ServerCommand_T >::const_iterator iter = vCmd.begin();
         iter != vCmd.end(); ++iter) {
        trpc_write_log("Get ShmCmd: [%s]\n", iter->sCommand);

        if (strncasecmp(iter->sCommand,
                        strStop.c_str(), strStop.length()) == 0) {
            // ����״̬Ϊֹͣ
            _pServerInfo->iStatus = CT_PROC_TO_STOP;

            // ������ֹ
            Exit(0);
        } else if (strncasecmp(iter->sCommand, 
                        strErrClean.c_str(), strErrClean.length()) == 0) {
            DealCmdClean(iter->sCommand);
        }
        else {
            trpc_error_log("unknown cmd: %s\n", iter->sCommand);
        }

    }

    return 0;
}

// ���������ļ�����
int 
CAsynServer::DealCmdClean(const char * cmd)
{
    // ��������
    vector < string > vCmdArray;
    SplitString(cmd, " ", 8, vCmdArray);

    // �����СС��2,ֱ�ӱ���
    if (vCmdArray.size() < 2) {
        trpc_error_log("DealCmdClean error: %s\n", cmd);
        return -1;
    }
    
    unsigned server_no = (unsigned) atoi(vCmdArray[1].c_str());
    
    if (ServerNOOK(server_no) != 0) {
        trpc_error_log("Dequeue Invalid ServerNo: %d\n", server_no);
        return -1;
    }
    
    // ����߳�ֱ��ɾ���ļ�����,�����������̴߳���,�Ͼ�������ʷǳ���С 
    // ��� vCmdArray��С ȷ��������ɾ������ɾ��ĳ���ڵ�
    if (vCmdArray.size() == 2) {
        // ����ɾ��
        for (int i = 0; i < _iFileNodeNum; ++i) {
            CleanFile(server_no, i);
        }
    } else {
        // ����2�Ļ�,ֻ����һ������������, ɾ��ĳ���ڵ�
        // �����ǵڶ��������Ƿ�Ϊ����,�����ͳһ�ж�,�����ظ�У��
        unsigned offset = (unsigned) atoi(vCmdArray[2].c_str());

        CleanFile(server_no, offset);
    } 

    return 0;
}

// �ȶ�ȡ,��ɾ��,�����ȡ��ɾ���Ĳ���ͬһ������
int
CAsynServer::CleanFile(unsigned server_no, unsigned offset)
{
    TrpcShmMessage_T stMsg;
    int iRetVal = -1;
    
    memset(&stMsg, 0x00, sizeof(stMsg));

    // ��ȡ����, ����ļ��ڵ��Ƿ�ʹ�õ�
    iRetVal = _pDataFilePtrArray[server_no]->get(offset, &stMsg);

    if (iRetVal < 0) {
        trpc_error_log("CleanFile server_no [%d] offset [%d] error: %s\n", 
            server_no, offset, _pDataFilePtrArray[server_no]->get_error_text());

        return -1;
    } else if (iRetVal > 0) {
        // �ڵ�Ϊ���������
        trpc_debug_log("CleanFile server_no [%d] offset [%d] info: %s\n", 
            server_no, offset, _pDataFilePtrArray[server_no]->get_error_text());
    }

    // ��¼ɾ�����ݵ���־ -- �ȼ�¼��־,��ɾ��
    trpc_day_log(_strOutFileLog.c_str(),
            "|%u|%s|%u|%ld|%d|%ld|%d|%d|%s|%s\n",
            stMsg.uWaterFlow,
            stMsg.sServiceName,
            stMsg.iSrcServerNo,
            stMsg.iOffset,
            stMsg.tInFileTime,
            stMsg.iTimeOutTimes,
            stMsg.iResult,
            time(NULL) - stMsg.tInFileTime,
            "manaul deleted",
            stMsg.sData
        );

    // ȷ�Ϻ�ɾ������
    iRetVal = _pDataFilePtrArray[server_no]->del(offset, &stMsg);

    if (iRetVal < 0) {
        trpc_error_log("CleanFile server_no [%d] offset [%d] error: %s\n", 
            server_no, offset);

        return -1;
    }   

    // ��¼ɾ�����ݵ���־

    return 0;
}

void
CAsynServer::Exit(int iStatus)
{
    trpc_debug_log("Into CAsynServer::Exit\n");

    trpc_write_log("EXIT...\n");

    // ĳЩ����¹���exit ��������ֹ����
    kill(getpid(), SIGKILL);
    exit(iStatus);
}

int 
CAsynServer::queue_push(unsigned server_no, long int offset, time_t equeue_time)
{
    // ����
    CAutoLock lock(__mutex);

    TrpcQueueData_T tmp;

    tmp.equeue_time = equeue_time;
    tmp.server_no = server_no;
    tmp.offset = offset;

    __wait_queue.push(tmp);

    // ֪ͨ
    __mutex.signal();
    
    trpc_debug_log("CAsynServer::queue_push ok: queue_size: %d, server_no: %d, offset: %d, time: %d\n", 
        __wait_queue.size(), server_no, offset, equeue_time);
            
    return 0;
}

int 
CAsynServer::queue_pop(unsigned& server_no, long int& offset)
{
    int iRetVal = 0;
    
    // �ȴ��������Ƿ�����Ϣ
    {
        // ��������wait
        CAutoLock lock(__mutex);
        
        while(__wait_queue.size() <= 0){
            iRetVal = __mutex.wait(_iWaitTimeOut);
            
            if (iRetVal != 0) { 
                snprintf(_error_text, sizeof(_error_text),
                    "get_one_node error info: %s", __mutex.get_error_text());

                return -1;
            }

            //  ��ʱ
            return 1;
        }
    }

    // ��ȡ����
    // �Ӷ�ȡ������
    CAutoLock lock(__mutex);
    time_t tNow = time(NULL);
    
    TrpcQueueData_T tmp;

    tmp = __wait_queue.front();
    __wait_queue.pop();

    // ��������Ƿ�ʱ
    // �п��ܺ����Ѿ����ظ����ݽ���,����������
    if (tNow - tmp.equeue_time > _iQueueTimeOut) {
        trpc_error_log("CAsynServer::queue_pop : QueueTimeOut [%d] now [%d] - equeue_time [%d]\n", 
            _iQueueTimeOut, tNow, tmp.equeue_time);
        
        snprintf(_error_text, sizeof(_error_text),
            "queue_pop: data too old");
        
        return -1;
    }

    server_no = tmp.server_no;
    offset = tmp.offset;
        
    trpc_debug_log("CAsynServer::queue_pop ok: queue_size: %d, server_no: %d, offset: %d, time: %d\n", 
        __wait_queue.size(), server_no, offset, tmp.equeue_time);

    return 0;
}

int
CAsynServer::Warning(char ErrorId[], char Content[])
{
    if (_pWarningHandle == NULL)
    {
        return 0;
    }

    return _pWarningHandle->warning(ErrorId, Content);
}

int
CAsynServer::SendStat(int iStatId, int iValue)
{
    if (_pStatHandle == NULL)
    {
        return 0;
    }

    return _pStatHandle->Send(iStatId, iValue);
}

