//
// timeStamp.h
// ʱ��������,��¼����������ʱ��(��ȷ��΢��)
//
// written by bondshi
// 2007/09/17
//

#ifndef __TIME_STAMP_H__
#define __TIME_STAMP_H__

#include <sys/time.h>



// you can redefine TS_LOG macro to use another output facility 
// prototype of TS_LOG: log(fmt, ...)


class TimeStamp
{
public:
    TimeStamp()
    {
    }
    
    TimeStamp(const std::string& opName) {
	reset(opName);
    }

    ~TimeStamp() {
	if ( !__opName.empty() )
        end();
    }

    void reset(const std::string& opName) {
	if (!__opName.empty())
        end();

	__opName = opName;
	gettimeofday(&__tm, NULL);
    }

    void end() {
	struct timeval tm1;
	gettimeofday(&tm1, NULL);
	tm1.tv_sec -= __tm.tv_sec;
	if (tm1.tv_usec >= __tm.tv_usec)
    {
        tm1.tv_usec -= __tm.tv_usec;
    }
	else
    {
        tm1.tv_sec -= 1;
        tm1.tv_usec += 1000000 - __tm.tv_usec;
    }

	__opName = "";
    }

private:
    std::string __opName;
    struct timeval __tm;
};

#endif // __TIME_STAMP_H__


