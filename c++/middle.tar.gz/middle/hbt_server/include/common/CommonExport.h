
// -*- C++ -*-
// sac_export.h,v 1.3 2003/10/28 18:34:23 bala Exp
// Definition for Win32 Export directives.
// This file is generated automatically by generate_export_file.pl
// ------------------------------
#ifndef _COMMON_EXPORT_H_
#define _COMMON_EXPORT_H_

#include "ace/config-all.h"

/////////////////// COMMON //////////////////////////////////////////////

#if defined (SERVER_STATIC_LIBS)
#  if !defined (COMMON_HAS_DLL)
#    define COMMON_HAS_DLL 0
#  endif /* ! SAC_SYSTEM_AGENT_HAS_DLL */
#else
#  if !defined (COMMON_HAS_DLL)
#    define COMMON_HAS_DLL 1
#  endif /* ! SAC_SYSTEM_AGENT_HAS_DLL */
#endif

#if defined (COMMON_HAS_DLL) && (COMMON_HAS_DLL == 1)
#  if defined (COMMON_BUILD_DLL)
#    define COMMON_Export ACE_Proper_Export_Flag
#  else /* SAC_SYSTEM_AGENT_BUILD_DLL */
#    define COMMON_Export ACE_Proper_Import_Flag
#  endif /* SAC_SYSTEM_AGENT_BUILD_DLL */
#else /* SAC_SYSTEM_AGENT_HAS_DLL == 1 */
#  define COMMON_Export
#endif /* SAC_SYSTEM_AGENT_HAS_DLL == 1 */




#endif /* _COMMON_EXPORT_H_ */

// End of auto generated file.
