#ifndef _CNMS_LOG_MGR_H_
#define _CNMS_LOG_MGR_H_

#include "ace/Log_Msg.h"
#include "ace/Event_Handler.h"
#include "ace/Synch.h"
#include "ace/Reactor.h"
#include "ace/Date_Time.h"
#include "ace/Task.h"
#include <string>
#include <vector>
#include "common/CommonExport.h"

#define ERROR_TRC 0
#define WARN_TRC  1
#define DEBUG_TRC 2
#define TRACE_TRC 3


#define ERRORTRC(y) \
    do { \
	    if ( IPC_Log_Mgr::instance()->setTag(ERROR_TRC) ) \
            IPC_Log_Mgr::instance()->trace y; \
	} while(0);

#define WARNTRC(y) \
    do { \
	    if ( IPC_Log_Mgr::instance()->setTag(WARN_TRC) ) \
            IPC_Log_Mgr::instance()->trace y; \
	} while(0);

#define DEBUGTRC(y) \
    do { \
	    if ( IPC_Log_Mgr::instance()->setTag(DEBUG_TRC) ) \
            IPC_Log_Mgr::instance()->trace y; \
	} while(0);

#define TRACE(y) \
    do { \
	    if ( IPC_Log_Mgr::instance()->setTag(TRACE_TRC) ) \
            IPC_Log_Mgr::instance()->trace y; \
	} while(0);

#define FUNC_TRC(x) \
    CFuncTrace aFuncTrace( x);
class COMMON_Export CFuncTrace
{
    public:
		CFuncTrace( const std::string& strFuncName);
		~CFuncTrace( void );

	private:
		std::string _FuncName;
};
class  COMMON_Export IPC_Log_Mgr :public ACE_Task<ACE_MT_SYNCH>
{
public:
	void enableTraceLevel( const unsigned int iLevel );
	// ת��Trace����
    	unsigned short traceLevel( const std::string& strLevel );
    	std::string traceLevel( const unsigned short sLevel );
	
    	// �򿪻��߹ر� Trace
    	void enableTraceClient( bool isEnable );
	// ���� trace tag
	bool setTag( const unsigned int iLevel);
	// ��¼trace
	void trace( const char *format, ... );
	///ʹ������������� iMAP_LOG_INIT
	int initialize(const std::string& path,const char* mod_name ,const char * logflag);
	///��õ�ʵ��ָ��
	static IPC_Log_Mgr* instance(void);
	///�ͷź���, ע�����������ʹ��iMAP_LOG���߳��˳���,�����ͷ�
	static void release(void);

	int open(void *);
       int svc(void);
		
private:

	int handle_timeout();

	IPC_Log_Mgr();
    	~IPC_Log_Mgr(void);

    // ��ʱ��������
	//�����־�ļ�������������־�ļ���ʱ��Ҫ�����������
	int init_file_name(void);
	
	std::vector<std::string> log_suffix_ex;
	std::string root_path_;
	char mod_name_[250];
	char log_path[250];
	char cur_log_file_[512];
	char cur_log_file_index_;
	static IPC_Log_Mgr* instance_;
	ACE_OSTREAM_TYPE* log_file_;
	long timer_id_;

	char        _msg[8192];
	ACE_Mutex   _msgLock;

	bool _bEnable;
	bool _bClose;
	unsigned int _iMaxLevel;
 	ACE_Date_Time _dt;

	std::string  _traceTag[4];

};
#endif

