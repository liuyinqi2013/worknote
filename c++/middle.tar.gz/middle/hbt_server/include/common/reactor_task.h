#ifndef _REACTOR_TASK_H_
#define _REACTOR_TASK_H_

/****************************************************************
 * ��˾     : Xinwei Telecom Inc.
 * ��Ʒ��ʶ : 
 * ����     : ������ 01267
 * �������� : 2007-03-14
 * ˵��     : 
 *            
 *            
 *                
 *****************************************************************/

#include "ace/Task.h"
#include "ace/Reactor.h"
#include <list>
#include <map>

#include "common/CommonExport.h"


class Socket_Base;

class COMMON_Export Reactor_Task  :public ACE_Task<ACE_MT_SYNCH>
{
public:
		
    Reactor_Task( );
    virtual ~Reactor_Task();
    
    //�����¼�ѭ��
    virtual int open_thread(void* args = 0);
    
    virtual int svc(void);
    
    virtual int register_handle(Socket_Base* socket, ACE_Reactor_Mask mask);
    
    void exit_task(void);
    
    void schedule_remove(Socket_Base* socket);        
            
protected:
        
    void del_schedule_socket();
    
    void reg_schedule_socket();
            
    ACE_Reactor reactor_;
    
    //��Ҫɾ����Socketָ���б�
    typedef std::list <Socket_Base*> LIST_SOCKET;
    LIST_SOCKET socket_will_del_;	
    
    //��Ҫע���Socketָ���б�
    typedef std::map <Socket_Base*, ACE_Reactor_Mask> MAP_SOCKET_TO_MASK;
    MAP_SOCKET_TO_MASK socket_will_reg_;
            
    int reactor_full_;
	int exit_;
};

#endif /* __REACTOR_TASK_H__ */
