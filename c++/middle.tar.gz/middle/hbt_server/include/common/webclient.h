#ifndef      __CSAIR_WEB_CLIENT_H_
#define      __CSAIR_WEB_CLIENT_H_

#include      <string>

using namespace std;


const int QUERY_URLCALL_TIME_OUT=20;

#define DEFAULT_CFT_CHARACTERSET "GB18030"
#define PARAM_POST_CHUNK "POST_CHUNK"

enum emUrlCallType
{
        CALL_TYPE_POST = 1,  // post
        CALL_TYPE_GET  = 2   // get
};


class CWebClient
{
private:       
        string m_strOperateUrl;//��ѯurl
        string md5Key;
        string m_post_chunk;
      
public:
	
        CWebClient(const string& url,const string& key);
        void SetParamter(const string& name,const string& value);
        ~CWebClient();        
        void ChangeCharacterSize(string &strBuf, const char * szFrom,const char * szTo) throw(CException);
        void CallUrl(const string & strInBuf, string& strOutBuf, int iType) throw(CException);
        void CallUrlPost(const string & strInBuf, string& strOutBuf) throw(CException);
        void CallUrlGet(const string & strInBuf, string& strOutBuf) throw(CException);        
        static size_t writerext(void *ptr, size_t size, size_t nmemb, void *stream);      
        int GetMd5(const char *key, int len, char *szRes);        
        void CallQueryExt(string& inBuf,string& outBuf,long long & call_time); 
        void CallQuery(string& inBuf,string& outBuf,long long & call_time); 
        int GetQueryStrExt(string & inStr,string& outStr);
};
#endif

