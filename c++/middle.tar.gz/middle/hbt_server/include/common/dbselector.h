/******************
 *DBSelector.h
 *
 *
 *****************/


#ifndef DBSELECTOR_H
#define DBSELECTOR_H

#include <map>
#include <list>
#include <string>
#include "common/dbmgr.h"

struct Charge_Field
{
        std::string strName; //������
        std::string strValue;  //����ֵ
};

class  CDBSelector
{
public:	
	CDBSelector(CMysqlMgr* mysqlMgr);
	~CDBSelector();
		
	long GetValue(const std::string &strCol, std::string &anyValue);
	long GetRecordNum()
	{
		return _lNumRecord;
	}
	long ExecuteGetSql(const std::string & strSql);
	long ExecuteSetSql(const std::string & strSql);		
	long next();
	long NextRow(std::map<std::string,std::string>& row_data);
	long GetRow(std::list<Charge_Field> & row_data);	
private:	
	std::string _strTable;
	std::map<std::string,std::string> _columnMap;	
	MYSQL_RES *_pResult;
	long _lNumField;
	long _lNumRecord;
	MYSQL_FIELD *_pField;
	CMysqlMgr* _mysqlMgr;

};

#endif

