#ifndef  _CSOCKET_PROTECT
#define  _CSOCKET_PROTECT

class CSocketClient
{
  public:
    CSocketClient();
    ~CSocketClient();
     
    int init(int port,const char * host);
    int tcp_close();
    int read_data( char *, int,int timeout);
    int write_data( char *, int);
    
  private:   
    int  m_sock;
    int TcpConnect( int port,const char *host); 
    int isReadyToRecv(int sockfd, int timeOut);
};

#endif

