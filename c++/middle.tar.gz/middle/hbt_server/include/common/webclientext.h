#ifndef      __CSAIR_WEB_CLIENT_EXT_H_
#define      __CSAIR_WEB_CLIENT_EXT_H_

#include "ace/Addr.h"
#include "ace/SOCK_Stream.h"
#include "ace/SOCK_Acceptor.h"
#include "ace/SOCK_Connector.h"
#include "ace/INET_Addr.h"
#include <curl/curl.h>
#include <string>
#include <ctype.h>
#include <stdio.h>
#include <string.h>


using namespace std;

#define MAXNUM_SIZE 16


int Curl_raw_equal(const char *first, const char *second);
int Curl_raw_nequal(const char *first, const char *second, size_t max);

char Curl_raw_toupper(char in);

bool Curl_compareheader(const char *headerline,const char *header,const char *content);
bool Curl_isxdigit(char digit);

#define checkprefix(a,b)    Curl_raw_nequal(a,b,strlen(a))
#define ISSPACE(x)  (isspace((int)  ((unsigned char)x)))

void Curl_strntoupper(char *dest, const char *src, size_t n);

typedef enum 
{
  CHUNK_FIRST, /* never use */

  /* In this we await and buffer all hexadecimal digits until we get one
     that isn't a hexadecimal digit. When done, we go POSTHEX */
  CHUNK_HEX,

  /* We have received the hexadecimal digit and we eat all characters until
     we get a CRLF pair. When we see a CR we go to the CR state. */
  CHUNK_POSTHEX,

  /* A single CR has been found and we should get a LF right away in this
     state or we go back to POSTHEX. When LF is received, we go to DATA.
     If the size given was zero, we set state to STOP and return. */
  CHUNK_CR,

  /* We eat the amount of data specified. When done, we move on to the
     POST_CR state. */
  CHUNK_DATA,

  /* POSTCR should get a CR and nothing else, then move to POSTLF */
  CHUNK_POSTCR,

  /* POSTLF should get a LF and nothing else, then move back to HEX as the
     CRLF combination marks the end of a chunk */
  CHUNK_POSTLF,

  /* Each Chunk body should end with a CRLF.  Read a CR and nothing else,
     then move to CHUNK_STOP */
  CHUNK_STOPCR,

  /* This is mainly used to really mark that we're out of the game.
     NOTE: that there's a 'dataleft' field in the struct that will tell how
     many bytes that were not passed to the client in the end of the last
     buffer! */
  CHUNK_STOP,

  /* At this point optional trailer headers can be found, unless the next line
     is CRLF */
  CHUNK_TRAILER,

  /* A trailer CR has been found - next state is CHUNK_TRAILER_POSTCR.
     Next char must be a LF */
  CHUNK_TRAILER_CR,

  /* A trailer LF must be found now, otherwise CHUNKE_BAD_CHUNK will be
     signalled If this is an empty trailer CHUNKE_STOP will be signalled.
     Otherwise the trailer will be broadcasted via Curl_client_write() and the
     next state will be CHUNK_TRAILER */
  CHUNK_TRAILER_POSTCR,

  CHUNK_LAST /* never use */

} ChunkyState;

typedef enum 
{
  CHUNKE_STOP = -1,
  CHUNKE_OK = 0,
  CHUNKE_TOO_LONG_HEX = 1,
  CHUNKE_ILLEGAL_HEX,
  CHUNKE_BAD_CHUNK,
  CHUNKE_WRITE_ERROR,
  CHUNKE_STATE_ERROR,
  CHUNKE_BAD_ENCODING,
  CHUNKE_OUT_OF_MEMORY,
  CHUNKE_LAST
} CHUNKcode;

struct Curl_chunker 
{
  char hexbuffer[ MAXNUM_SIZE + 1];
  int hexindex;
  ChunkyState state;
  size_t datasize;
  size_t dataleft; /* untouched data amount at the end of the last buffer */
};

struct SRequest
{
	ssize_t size;
	bool header;
	int httpcode;
	int headerline;
	int httpversion;
	char *buf;
	char *p;
	char *str;	
	char *hbufp;
	size_t hbuflen;
	char *str_start;
	char *end_ptr;
	bool chunk;
	bool trailerhdrpresent;
	size_t bytecount;
	char headerbuff[128];

	SRequest()
	{
		ACE_OS::memset(this, 0, sizeof(SRequest));
	}
};
class CWebClientExt
{
private:       
        string m_strOperateUrl;//��ѯurl
        string md5Key;
        string m_post_chunk;
        string *ret_report_;
        ACE_SOCK_Stream *socket_stream_;
        char* send_data_;
        char* recv_data_;
        SRequest* request_;
        Curl_chunker* chunker_;
        char host_[24];
        unsigned short port_;
        char url_path_[256];

        CURLcode read_socket_data(char *buf,size_t sizerequested,ssize_t *n,int timeout);
        CURLcode read_http_header(SRequest *k,ssize_t *nread,bool *stop_reading);
        CHUNKcode read_http_chunk(SRequest *k,Curl_chunker*ch,char *datap,ssize_t datalen,ssize_t *wrotep);
        int init_chunker();
        int parseurl(const char *url,char *host,unsigned short *port,char *path);
      
public:

	int init();
	int send_data(string& strRequest);
	int read_data(string* strResponse);	
	
        CWebClientExt(const string& url,const string& key);
        void SetParamter(const string& name,const string& value);
        ~CWebClientExt();        
        void ChangeCharacterSize(string &strBuf, const char * szFrom,const char * szTo) throw(CException);
        int CallUrl(string & strInBuf, string* strOutBuf);
        void CallUrlPost(const string & strInBuf, string& strOutBuf) throw(CException);
        void CallUrlGet(const string & strInBuf, string& strOutBuf) throw(CException);        
        static size_t writerext(void *ptr, size_t size, size_t nmemb, void *stream);      
        int GetMd5(const char *key, int len, char *szRes);        
        void CallQueryExt(string& inBuf,string* outBuf,long long & call_time) throw(CException); 
        void CallQuery(string& inBuf,string& outBuf,long long & call_time); 
        int GetQueryStrExt(string & inStr,string& outStr);
};
#endif

