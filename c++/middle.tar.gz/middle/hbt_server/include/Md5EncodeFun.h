/**
  * FileName: Md5EncodeFun.h
  * Author: verminniu
  * Version :1.0
  * Date: 2008-01-16
  * Description: Md5���ܺ���
  * ChangeList:
  *			2008-01-16		Created by verminniu
  */

#ifndef     __AIRPLANE_MD5ENCODEFUN_H
#define     __AIRPLANE_MD5ENCODEFUN_H

#include     "Functions.h"
#include     "AirPlaneComm.h"
#include     "Error.h"
#include     "exception.h"

#include     <sstream>
using namespace std;


class CMd5Encode : public CFunction
{
public:

	virtual void EncodeFun(const char * szInBuf, int iInLength, char * szOutBuf, int & iOutLength) throw(CException); 	 
};

#endif
