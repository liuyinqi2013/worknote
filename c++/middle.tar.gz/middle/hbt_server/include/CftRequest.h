#ifndef   __CFT_REQUEST_H
#define   __CFT_REQUEST_H

#include  "Error.h"
#include "sstring.h"
#include "exception.h"
#include "urlcodec.h" 
#include "CStringMap.h"
#include     "CftLogger.h"
#include <map>
#include <vector>
#include <sstream>
#include <string>
using namespace std;

extern CCftLogger*   gPtrAppLog;  // ��־ָ��

typedef std::vector<SuperString> string_vector_t;

string decrypt(const string& spid, const string& srcStr) throw(CException);
string encrypt(const string& spid, const string& srcStr) throw(CException);
string createDigest(const string& srcStr) throw(CException);
void checkDigest(const string& srcStr) throw(CException);



//
// @class RequestBase
// @brief ����URL���󴮸�ʽ�������(���/���)
//
class RequestBase : private std::map<SuperString, SuperString>
{   
public:
    typedef std::map<SuperString, SuperString> base;
    typedef base::const_iterator const_iterator;
    
    RequestBase()
    {}
    
    RequestBase(const char* pszParams, const char* szSep = "&")
    {
        parse(pszParams, szSep);
    }
    
    virtual ~RequestBase()
    {}

    bool hasKey(const std::string& key)const {
    return (find(key) != end());
    }

    // add other Request Object Content into this
    void merge(const RequestBase& req) {
    const_iterator it = req.begin();
    for (it = req.begin(); it != req.end(); ++it)
    {
           // �����Ŀ�Ѵ��ڣ��򲻸���
        if (!hasKey(it->first))
            this->insert(*it);
    }
    }

    // replace content from other dict
    void replace(const RequestBase& req) {
    const_iterator it = req.begin();
    for (it = req.begin(); it != req.end(); ++it)
    {
        this->insert(*it);
    }
    }

    // replace content from CStringMap
    void replace(bsapi::CStringMap& req)
    {
        for (bsapi::CStringMap::iterator it = req.begin(); it != req.end(); ++it)
        {
            this->insert(*it);
        }
    }


    // replace contenet with default value
    // argTable: char** argTable = {key1, defalultVal1/NULL, key2, defaultVal2/NULL, ..., NULL, NULL}
    void replace(const RequestBase& req, const char** argTable) {
        for (int i = 0; argTable[i] != NULL; i += 2) {
            const char* pszKey = argTable[i];
        const char* pszDefVal = argTable[i+1];
            
            if (pszDefVal == NULL)
                setValue(pszKey, req[pszKey]);
            else
                setValue(pszKey, req.asString(pszKey, pszDefVal));
        }
    }

    // parse request parameters string
    virtual void parse(const char* pszParams, const char* sep = "&") throw (CException) {
    string_vector_t sv = SuperString(pszParams).split(sep);
    string_vector_t::const_iterator it;

        //set new content
    for (it = sv.begin(); it != sv.end(); ++it)
    {
            const std::string& item = *it;
            if (item.empty())
                continue;

            // �����µķ�ʽ�ֽ�key=value...��Ŀ��
            // ����valueδ��ת�������£���ʧ����'='
            std::string::size_type pos = item.find('=');
            std::string key = item.substr(0, pos);
            std::string val;
    
            if (pos != std::string::npos)
            {
            val = item.substr(pos + 1);
            val = urlDecode(val, *sep);
            }

            this->insert(value_type(key, val));                    

            /*
        string_vector_t nv = it->split("=");
        if (nv.size() > 0)
        {
        std::string key = nv[0];
        std::string val;
        if (nv.size() > 1)
        {
                    // ��Ҫ�Էָ�����н���
            val = urlDecode(nv[1], *sep);
        }

        this->insert(value_type(key, val));        
        }
        */
    }
    }

    // pack content to key=value... string
    virtual SuperString pack(const char* sep = "&")const throw (CException) {
    const_iterator it = begin();
    std::stringstream ss;

    if (it != end())
    {
            // ��Ҫ��sep����ת��
        ss << it->first << "=" << urlEncode(it->second, *sep);
        ++it;
    }
    
    for (; it != end(); ++it)
    {
            // ��Ҫ��sep����ת��
        ss << sep << it->first << "=" << urlEncode(it->second, *sep);        
    }

    return ss.str();
    }

    // member data access
    SuperString asString(const std::string& key)const {
    const_iterator it = find(key);
    if (it == end())
        throw CException(ERR_RELAY_FAIL,key);

    return it->second;
    }

    SuperString asString(const std::string& key, const std::string& defaultVal)const {
    const_iterator it = find(key);
    if (it == end())
        return defaultVal;

    return it->second;
    } 

    long asInteger(const std::string& key)const {
    std::string val = asString(key);
    return atol(val.c_str());
    }

    long asInteger(const std::string& key, int defaultVal)const {
    const_iterator it = find(key);
    if (it == end())
        return defaultVal;
    
    return atol(it->second.c_str());
    }

    SuperString operator[](const std::string& key)const {
    return asString(key);
    }

    void setValue(const std::string& key, const std::string& val) {        
        iterator it = find(key);
        if (it != end())
            it->second = val;
        else                
            insert(value_type(key, val));
    }

    void setValue(const std::string& key, long val) {
    char buff[64] = {0};
    sprintf(buff, "%ld", val);
    setValue(key, buff);
    }

    void erase(const std::string& key) {
    base::erase(key);
    }

    void clear() {
    base::clear();
    }

    // for enumerate
    const_iterator begin()const {
    return base::begin();
    }

    const_iterator end()const {
    return base::end();
    }

    size_t size()const {
    return base::size();
    }  
};


//
// @class CgiRequest
// @brief Cgi-->Relay Request String 
//
class CgiRequest : public RequestBase
{
public:
    enum {modeNotEncrypted = 0, modeEncrypted = 1};
    CgiRequest() : __requestType(-1), __version(1), __mode(0)
    {
        }
    
    CgiRequest(const char* pszParams) : RequestBase(pszParams, "&"),
    __requestType(-1), __version(1), __mode(0)
    {}

    // ���ʱʹ�õĹ��캯����
    // requestType: request_type value defined in relaysvr configuration
    // pszSpid: encrypt spid key
    // mode: encrypt mode: 0--plain text request, 1--encrypted request
    // ver: protocol version
    // pszHeadUin: head_u value in relaysvr request param
    CgiRequest(
    int requestType, const char* pszSpid, const char* pszHeadUin = NULL,
    int mode = modeNotEncrypted, int ver = 1
    ) : __requestType(requestType), __version(ver), __mode(mode),
    __spid(pszSpid), __headUin(pszHeadUin?pszHeadUin:"")
    {
    }

    virtual void parse(const char* pszParam, const char* pszSep = "&") throw (CException)
    {
        if (pszParam)
            RequestBase::parse(pszParam, pszSep);   

        std::string spid = asString("sp_id");
        std::string requestText = asString("request_text");
        std::string srcStr = decrypt(spid, requestText);            

        erase("request_text");
        merge(RequestBase(srcStr.c_str(), "$"));        

        // set version
        __version = asInteger("ver", 1);        
        if (__version == 2 || __version == 3) 
        {
            // ���goods_tag����mac������������������汾Ϊ1
            if (!hasKey("goods_tag"))
                __version = 1;

            if (!hasKey("mac") || (*this)["mac"].empty())
                __version = 1;            
        }

        setValue("ver", __version);
    }

    virtual SuperString pack(const char* sep="&")const throw (CException)
    {
    if (__requestType == -1)
    {
        throw CException(ERR_RELAY_FAIL,"request_type not set");
    }
    std::string strParam = RequestBase::pack(sep);
    if (__mode == modeEncrypted)
    {
        // create abstract                
            std::string digest = createDigest(strParam);
            strParam += sep;
            strParam += "abstract=" + urlEncode(digest, *sep);
            // encrypted param
            std::string requestText = encrypt(__spid, strParam);                
            strParam = "request_text=" + urlEncode(requestText, '&');        
    }

    // ��װΪRelaySvr�����ʽ����
    std::stringstream ss;
    ss << 
        "request_type=" << __requestType <<
        "&sp_id=" << urlEncode(__spid, '&') << 
        "&head_u=" << urlEncode(__headUin, '&') << 
        "&ver=" << __version <<
        "&" << strParam;

    return ss.str();
    }

    int requestType()const {
    return __requestType;
    }

    int version()const {
    return __version;
    }

    // �Ƿ����MACǩ��
    bool hasMac()const {
        return (__version >= 2);
    }

private:
    int __requestType;
    int __version;
    int __mode;
    
    std::string __spid;
    std::string __headUin;
};



/*! @defgroup CftRequest_Wraper �������װ�����ɺ�
 * �������������װ�����������ʾ��:
   class CMyRequest {
   private:
        RequestBase& __req;
   public:
        CMyRequest(RequestBase& req) : __req(req)
        {}
        bool hasKey(const std::string& key)const { return __req.hasKey(); }
        void _item1(int v) { __req.setValue("item1", v); }
        int _item1()const { return __req.asInteger("item1"); }
        void _item2(int v) { __req.setValue("item2", v); }
        int _item2()const { return __req.asInteger("item2", 100); }
        void _item3(const std::string& v) { __req.setValue("item3", v); }
        int _item3()const { return __req.asString("item3"); }
        void _item4(const std::string& v) { __req.setValue("item4", v); }
        SuperString _item4()const { return __req.asString("item4", "abc"); }
   };        
 
 * @�� // start group
 */

#define DECLARE_REQ_CLASS(classname) \
        class C##classname { \
        private: \
           RequestBase& __req; \
        public: \
           C##classname(RequestBase& req) : __req(req) \
           {} \
           bool hasKey(const std::string& key)const { return __req.hasKey((key)); }

#define REQ_ADD_INT_ITEM(itemname) \
          void _##itemname(long v) { __req.setValue(#itemname, (v)); } \
          long _##itemname()const { return __req.asInteger(#itemname); }

#define REQ_ADD_INT_ITEM_WITH_DEFVAL(itemname, defaultVal) \
          void _##itemname(long v) { __req.setValue(#itemname, (v)); } \
          long _##itemname()const { return __req.asInteger(#itemname, (defaultVal)); }

#define REQ_ADD_STR_ITEM(itemname) \
          void _##itemname(const std::string& v) { __req.setValue(#itemname, (v)); } \
          SuperString _##itemname()const { return __req.asString(#itemname); }

#define REQ_ADD_STR_ITEM_WITH_DEFVAL(itemname, defaultVal) \
          void _##itemname(const std::string& v) { __req.setValue(#itemname, v); } \
          SuperString _##itemname()const { return __req.asString(#itemname, (defaultVal)); }

#define REQ_END_DECLARE() \
        };

#endif

