/**
* FileName: FunList.h
* Author: verminniu
* Version :1.0
* Date: 2008-01-16
* Description: �����б�
* ChangeList:
*			2008-01-16		Created by verminniu
*/

#ifndef   __AIRPLANE_FUNLIST__H
#define   __AIRPLANE_FUNLIST__H

// md5���ܺ���
#define    ENCODE_FUNC_MD5   "ASENCODE_MD5_FUN"

#endif
