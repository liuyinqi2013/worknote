/**
  * FileName: CompanyInfo.h
  * Author: verminniu
  * Version :1.0
  * Date: 2008-01-16
  * Description: ��˾�������
  * ChangeList:
  *			2008-01-16		Created by verminniu
  */

#ifndef     __COMPANYINFO_H
#define     __COMPANYINFO_H

#include     "OperateInfo.h"
#include     "TemplateConf.h"
#include     "Error.h"
#include     "exception.h"


#include     <map>
#include     <string>
using namespace std;

typedef map<string, COperateInfo> OperateInfoMap;

class CCompanyInfo{
public:
//private:
	// �����б�
	OperateInfoMap   m_ObjOperateInfoMap;

	string           m_strMd5Key;       // md5�����õ�key
//private:
	string           m_strSpid;         // ��˾��spid
	string           m_strCompanyName;  // ��˾����
	int              m_iOperateType;    // ����ʽ1:post        2:get
	string           m_strReqCharecterSet; // �����CharecterSet
	string           m_strResCharecterSet; // ���ص�CharecterSet

public:
	CCompanyInfo()
		{
		};
	
	CCompanyInfo(char * psSpid, 
				char * psCompanyName, int iOperateType, 
				const char * szReqCharecterSet, const char * szResCharecterSet);
	
	~CCompanyInfo(){};

public:
	// ���Ӳ���
	void addOperateConf(const char * szOperateName, const char * szOperateUrl, 
			const char * szErrSign, const char * szEnCodeFun, 
			const TemplateConf_T * pObjRequestConf, 
			const TemplateConf_T * pObjRespondConf,
			const TemplateConf_T * pObjErrInfoConf) throw(CException) ;

	// ������Ϣ
	void dispatchMsg(string strOperateName, 
			 KeyValueMap & objInMap, 
			 KeyValueMap & objOutMap, 
			 string & strOutBuf) throw(CException);

	void setSpid(string strSpid)
		{
			m_strSpid = strSpid;
		}

	void setMd5Key(string strMd5Key)
		{
			m_strMd5Key = strMd5Key;
		}

	void setCompanyName(string strCompanyName)
		{
			m_strCompanyName = strCompanyName;
		}

	void setOperateType(int iType)
		{
			m_iOperateType = iType;
		}
	
	void setReqCharecterSet(const char *  szReqCS)
		{
			m_strReqCharecterSet = szReqCS;
		}

	void setResCharecterSet(const char *  szResCS)
		{
			m_strResCharecterSet = szResCS;
		}
	string getMd5Key()
		{
			return m_strMd5Key;
		}
};




#endif

