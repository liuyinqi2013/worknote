/**
  * FileName: accesslog.h
  * Author: verminniu
  * Version :1.0
  * Date: 2008-01-16
  * Description: ��ӡ������־(������ʱ��)
  * ChangeList:
  *			2008-01-16		Created by verminniu
  */

#ifndef     __ACCESS_LOG_H
#define     __ACCESS_LOG_H

#include    <sys/time.h>
#include    <string>
using namespace std;

#include    "CftLogger.h"

#include "log.h"
extern CCftLogger*	gPtrProcessLog;			    		// ������־

class CAccessLog
{
private:
	struct timeval m_tvBegin;
	string m_strReq;
	int    m_iResult;
	string m_strServiceName;
public:
	CAccessLog(const char * szReq, 
		const char * szServiceName):
		m_strReq(szReq), m_iResult(0), m_strServiceName(szServiceName)
		{
			memset(&m_tvBegin, 0x00, sizeof(m_tvBegin));
    		gettimeofday(&m_tvBegin, NULL);
		}
	void setResult(int iResult)
		{
			m_iResult = iResult;
		}
	~CAccessLog()
		{
			struct timeval tvEnd;
    		memset(&tvEnd, 0x00, sizeof(tvEnd));
    		gettimeofday(&tvEnd, NULL);

			int iAccTime = (tvEnd.tv_sec - m_tvBegin.tv_sec) * 1000000 + tvEnd.tv_usec - m_tvBegin.tv_usec;
			if(NULL!=gPtrProcessLog){			
			gPtrProcessLog->info("%s|%d|%d|%-.128s", m_strServiceName.c_str(),
					m_iResult, iAccTime, m_strReq.c_str());
		}else{
			trpc_debug_log("%s|%d|%d|%-.128s", m_strServiceName.c_str(),
					m_iResult, iAccTime, m_strReq.c_str());
		}
		}
};

#endif

