#ifndef CSTR2MAP_H_HEADER_INCLUDED_BB1D0CFC
#define CSTR2MAP_H_HEADER_INCLUDED_BB1D0CFC

#include <string>
#include <vector>
#include <map>
using namespace std;

// typedef map<string,string> CStr2Map;
//##ModelId=44E2969501F4
typedef std::map<std::string,std::string> CStr2Map;

typedef std::vector<std::string> CStrVector;



#include "bsapi_namespace.h"

#endif /* CSTR2MAP_H_HEADER_INCLUDED_BB1D0CFC */
