#include "CAliasList.h"


const char * const cftapi::CAliasList::szReqType = "3000";
  
//##ModelId=44E2C0C301B5
string cftapi::CAliasList::GetValue(string key)
{
  return m_mRes[key];
}

//##ModelId=44E2C659030D
bool cftapi::CAliasList::Fetch(string uin,string uip,string chnid)
{
  m_mReq["uin"] = uin;
  m_mReq["client_ip"] = uip;
  m_mReq["channel_id"] = chnid;
  m_mReq["head_u"] = m_sOperId;
  m_mReq["ver"] = m_sVersion;
  m_mReq["sp_id"] = m_sSpId;
  m_mReq["request_type"] = szReqType;
  

  string sReq;
  if(m_mReq.GenString(sReq,"&","=") != 0)
  {
    m_sLastErrInfo = "pack error";
    return false;
  }
  
  char * pszRes; int iRes;
  
  if(!SendRecv(sReq.c_str(),sReq.size(),&pszRes,iRes))
    return false;
  
  if(pszRes == NULL)
    return false;
    
  m_mRes.SnapElement(pszRes);
  if(atoi(m_mRes["result"].c_str()) == 0)
  {
    return true;
  }
  return false;
}


