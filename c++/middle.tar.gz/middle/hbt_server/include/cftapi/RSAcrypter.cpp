#include "RSAcrypter.h"

#include <openssl/objects.h>
#include <openssl/sha.h>
#include <openssl/rand.h>
#include <openssl/pem.h>
#include <openssl/rsa.h>

#include <stdio.h>

extern "C" {
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
}

#ifdef DEBUG
#include <stdio.h>
#include <openssl/err.h>
#endif

#define bs 42 //From man RSA_public_encrypt... also see below

const unsigned int RSAcrypter::shasize=20;
static const char rnd_seed[] = "string to make the random number generator think it has entropy";

QPAYRKey* QPAYRKey_new()
{
    RSA *key = RSA_new();           // �����µ�rsa ʵ��
    return (QPAYRKey*)key;
}

void QPAYRKey_free(QPAYRKey* key)
{
    RSA_free((RSA*)key);
}

RSAcrypter::RSAcrypter(QPAYRKey *k):key(k){
    RAND_seed(rnd_seed, sizeof rnd_seed); /* or OAEP may fail */
}

QPAYRKey *RSAcrypter::getKey(){
  return key;
}


Crypter::buffer* RSAcrypter::public_encrypt(const unsigned char* const inbuf, int length){
  RSA* rsa = (RSA*)key;

  int size = RSA_size(rsa); // RSA modulus size in bytes
  int blksize = size-bs;  // From man RSA_public_encrypt
  int blocks=length/blksize;
  int rest=length%blksize;

#ifdef DEBUG
  //printf("size:%i blksize:%i blocks:%i rest:%i\n",size,blksize,blocks,rest);
#endif

  int ret = 0;
  buffer *outbuf;
  if (rest==0) 
  	outbuf=new buffer(blocks*size + 1);
  else 
  	outbuf=new buffer((blocks+1)*size + 1);
  if (outbuf == NULL)
  	return NULL;

  for (int i=0;i<blocks;i++){
    ret = RSA_public_encrypt(blksize,inbuf+i*blksize,outbuf->data+i*size,rsa, RSA_PKCS1_PADDING);

    if (ret < 0) {      // error
#ifdef DEBUG
      //printf("Enc i=%i\n",i);
      //unsigned long e =ERR_get_error();
      //puts(ERR_error_string(e,0));
#endif
      delete outbuf;
      return NULL;
    }

    // �����ۼ�
    outbuf->len += ret;
  }
  
  if (rest!=0){
    ret = RSA_public_encrypt(rest,inbuf+blocks*blksize,outbuf->data+blocks*size,rsa, RSA_PKCS1_PADDING);
    if (ret < 0) {
#ifdef DEBUG
      //printf("Enc i=%i\n",i);
      //unsigned long e =ERR_get_error();
      //puts(ERR_error_string(e,0));
#endif
      delete outbuf;
      return NULL;
    }
  }
  outbuf->len += ret;

  return outbuf;
}


Crypter::buffer* RSAcrypter::public_encrypt(const unsigned char* const inbuf,int length, int offset)
{
  RSA* rsa = (RSA*)key;
  int size = RSA_size(rsa); // RSA modulus size in bytes
  if (offset < 11 || offset > size)
      return NULL;

  int blksize = size-offset;  // From man RSA_public_encrypt
  int blocks=length/blksize;
  int rest=length%blksize;

#ifdef DEBUG
  //printf("size:%i blksize:%i blocks:%i rest:%i\n",size,blksize,blocks,rest);
#endif

  int ret = 0;
  buffer *outbuf;
  if (rest==0) 
  	outbuf=new buffer(blocks*size + 1);
  else 
  	outbuf=new buffer((blocks+1)*size + 1);
  if (outbuf == NULL)
  	return NULL;

  for (int i=0;i<blocks;i++){
    ret = RSA_public_encrypt(blksize,inbuf+i*blksize,outbuf->data+i*size,rsa, RSA_PKCS1_PADDING);

    if (ret < 0) {      // error
#ifdef DEBUG
      //printf("Enc i=%i\n",i);
      //unsigned long e =ERR_get_error();
      //puts(ERR_error_string(e,0));
#endif
      delete outbuf;
      return NULL;
    }

    // �����ۼ�
    outbuf->len += ret;
  }
  
  if (rest!=0){
    ret = RSA_public_encrypt(rest,inbuf+blocks*blksize,outbuf->data+blocks*size,rsa, RSA_PKCS1_PADDING);
    if (ret < 0) {
#ifdef DEBUG
      //printf("Enc i=%i\n",i);
      //unsigned long e =ERR_get_error();
      //puts(ERR_error_string(e,0));
#endif
      delete outbuf;
      return NULL;
    }
  }
  outbuf->len += ret;

  return outbuf;
}


Crypter::buffer* RSAcrypter::private_decrypt(const unsigned char* const inbuf,int length){
  RSA* rsa = (RSA*)key;
  int size = RSA_size(rsa); // RSA modulus size in bytes
  int blksize = size-bs;  // From man RSA_ublic_encrypt flen
  int blocks = length/size;  // Should leave no modulo

#ifdef DEBUG  
  //printf("size:%i blksize:%i blocks:%i\n",size,blksize,blocks);
#endif

  buffer *outbuf=new buffer(blocks*blksize + 1);  //At least big enough
  if (outbuf == NULL)
  	return NULL;
  
  int written=0;
  int ret = 0;
  for (int i=0;i<blocks;i++){
    ret = RSA_private_decrypt(size,inbuf+i*size,outbuf->data+written,rsa, RSA_PKCS1_PADDING);
    if (ret < 1) {
#ifdef DEBUG
      //printf("dec i=%i\n",i);
      unsigned long e =ERR_get_error();
      puts(ERR_error_string(e,0));
#endif
      delete outbuf;
      return NULL;
    }
    written += ret;
  }
  outbuf->len = written;
 
  return outbuf;
}


Crypter::buffer* RSAcrypter::private_decrypt(const unsigned char* const inbuf,int length, int offset)
{
  RSA* rsa = (RSA*)key;
  int size = RSA_size(rsa); // RSA modulus size in bytes
  if (offset < 11 || offset > size)
      return NULL;

  int blksize = size-offset;  // From man RSA_ublic_encrypt flen
  int blocks = length/size;  // Should leave no modulo

#ifdef DEBUG  
  //printf("size:%i blksize:%i blocks:%i\n",size,blksize,blocks);
#endif

  buffer *outbuf=new buffer(blocks*blksize + 1);  //At least big enough
  if (outbuf == NULL)
  	return NULL;
 
  int written=0;
  int ret = 0;
  for (int i=0;i<blocks;i++){
    ret = RSA_private_decrypt(size,inbuf+i*size,outbuf->data+written,rsa, RSA_PKCS1_PADDING);
    if (ret < 1) {
#ifdef DEBUG
      //printf("dec i=%i\n",i);
      unsigned long e =ERR_get_error();
      puts(ERR_error_string(e,0));
#endif
      delete outbuf;
      return NULL;
    }
    written += ret;
  }
  outbuf->len = written;
 
  return outbuf;
}

Crypter::buffer *RSAcrypter::private_sign(const unsigned char* const buf,int length){
  RSA* rsa = (RSA*)key;
  unsigned char *shadigest = new unsigned char[shasize + 1]; // 160 bit buffer
  // unsigned char *SHA1(const unsigned char *d, unsigned long n, unsigned char *md);
  shadigest=SHA1(buf,length,shadigest);
  if (shadigest==0) return NULL;


  buffer *ret = new buffer(RSA_size(rsa) + 1);
  if (ret == NULL)
  	return NULL;

  // int RSA_sign(int type, unsigned char *m, unsigned int m_len,
  //   unsigned char *sigret, unsigned int *siglen, RSA *rsa);

  if (RSA_sign(NID_sha1,shadigest,shasize,ret->data,&(ret->len),rsa) == 0) return NULL;

  // TODO: Check what length is actually returned....
  if (ret->len != (unsigned int) RSA_size(rsa)) puts("ERROR: CONCEPTUAL ERROR IN SIGN/VERIFY!!!!");

  delete[] shadigest;
  return ret;
}

int RSAcrypter::public_verify(unsigned char* buf,int length,unsigned char* sig, int slen){
  RSA* rsa = (RSA*)key;
  unsigned char *shadigest = new unsigned char[shasize + 1]; // 160 bit buffer
  if (shadigest == NULL)
  	return -1;
  // unsigned char *SHA1(const unsigned char *d, unsigned long n, unsigned char *md);
  shadigest=SHA1(buf,length,shadigest);
  if (shadigest == 0) return -1;

  //  int RSA_verify(int type, unsigned char *m, unsigned int m_len,
  //    unsigned char *sigbuf, unsigned int siglen, RSA *rsa);
  if (slen != RSA_size(rsa))
  	return -2;
  int ret = RSA_verify(NID_sha1,shadigest,shasize,sig,slen,rsa);
  if (ret != 1)
  	return -3;

  delete[] shadigest;
  return 0;
}

// ��ָ�����ļ��ж�ȡ��Կ��˽Կ
// type = 1, ��ȡ���ǹ�Կ
// type = 2, ��ȡ��˽Կ
int ReadKey(const char* const filename, int type, RSA* rsa)
{
    int fd = 0;
    int dsize = 0;
    int iret = 0;
    unsigned char szHeadBuf[8] = {0};
    unsigned char *ptrBuff = NULL;

    if (filename == NULL) {
        return FileNameEmpty;
    }

    // �򿪲���ȡkey file
    if ((fd = open(filename, O_RDONLY)) == -1) {
        return OpenKeyFileError;
    }
    lseek(fd, 0, SEEK_SET);

    // ��ȡe �ĳ���
    if (read(fd, szHeadBuf, 4) !=4) {
        iret = ReadKeyFileHeadError;
        goto Error;
    }
    memcpy(&dsize, szHeadBuf, 4);
    if (dsize < 0 || dsize > 4096) {
        iret = KeyFileFormatError;
        goto Error;
    	}
    // Ϊe �����ڴ�
    ptrBuff = (unsigned char*)new char[dsize];
    if (ptrBuff  == NULL) {
        iret = AllocMemError;
        goto Error;
    }
    // ��ȡe
    if (read(fd, ptrBuff , dsize) != dsize) {
        iret = KeyFileFormatError;
        goto Error;
    }
    rsa->e = BN_bin2bn(ptrBuff, dsize, rsa->e);
    delete []ptrBuff;
    ptrBuff = NULL;


    // ��ȡkey �ĳ���
    if (read(fd, szHeadBuf, 4) !=4) {
        iret = ReadKeyFileHeadError;
        goto Error;
    }
    memcpy(&dsize, szHeadBuf, 4);
    if (dsize < 0 || dsize > 4096) {
        iret = KeyFileFormatError;
        goto Error;
    }
    // Ϊkey �����ڴ�
    ptrBuff = (unsigned char*)new char[dsize];
    if (ptrBuff  == NULL) {
        iret = AllocMemError;
        goto Error;
    }
    // ��ȡkey
    if (read(fd, ptrBuff , dsize) != dsize) {
        iret = KeyFileFormatError;
        goto Error;
    }

    // ����rsa ����Ӧ���ֶ�
    if (type == 1) {
        // ��Կ
        rsa->n = BN_bin2bn(ptrBuff, dsize, rsa->n);
    } else if (type == 2) {
        // ˽Կ
        rsa->d = BN_bin2bn(ptrBuff , dsize, rsa->d);    
    } else {
        // δ֪����
        return UnknownType;
    }
    delete []ptrBuff;
    ptrBuff = NULL;

    close(fd);
    return 0;
Error:
    close(fd);
    fd = 0;
    if (ptrBuff != NULL)
       delete []ptrBuff;
    return iret;
}
 
// ��ָ�����ļ��ж�ȡrsa�ṹ
// �ɹ��Ƿ���ֵΪ0
// ����Ϊ����
int ReadRSAStruct(const char* const public_name, const char* const private_name, QPAYRKey* key)
{
    RSA* rsa = (RSA*)key;

    if (public_name == NULL && private_name == NULL) {
        return FileNameEmpty;
    }
    if (rsa == NULL)  {
        return RSAStructEmpty;
    }

    int iret = 0;
    if (public_name != NULL) {
        // ��ȡpublic key file
        if ((iret = ReadKey(public_name, 1, rsa)) != 0)
            return iret;
    }

    if (private_name != NULL) {
        // ��ȡprivate key file
        if ((iret = ReadKey(private_name, 2, rsa)) != 0)
            return iret;
    }

    return 0;
}


