#ifndef CIbsComm_H_HEADER_INCLUDED_BB1D1E7E
#define CIbsComm_H_HEADER_INCLUDED_BB1D1E7E

#include "CCftComm.h"

//##ModelId=44E2AA7102BF
class cftapi::CIbsComm : public cftapi::CCftComm
{
  public:
    //##ModelId=44E2B288032C
    bool SendRecv(const char * szReq,char ** pszRes,int &iRes);

  protected:
    
    static const int MAX_PACKET_SIZE = 999999; //����ĳ���
    
    struct  
    {
    	char szLen[6];
    	char szBuf[MAX_PACKET_SIZE + 1];
    } m_stReq,m_stRes;

};



#endif /* CIbsComm_H_HEADER_INCLUDED_BB1D1E7E */
