#ifndef CPaipaiBossClient_H_HEADER_INCLUDED_BB16EA56
#define CPaipaiBossClient_H_HEADER_INCLUDED_BB16EA56

#include "CStringMap.h"
#include "CCftComm.h"

//##ModelId=44E966D70271
class cftapi::CPaipaiBossClient : public cftapi::CCftComm
{
  public:
    //##ModelId=44E9671B00AB
    
	const char* getSendStr();
	const char* getResultStr();
	int GetRetCode();
	int QueryAuthInfo(bsapi::CStringMap &iodat);

    CPaipaiBossClient();
    virtual ~CPaipaiBossClient(){};
  protected:
	  int SendRecv();
	  typedef struct 
	  {
		  int iLen;
		  int iOpCode;
		  int iRetCode;
	  }PaiPaiBossHead;

	struct
	{
		PaiPaiBossHead stHead;
		char szContent[2036];
		char szPacket[2048];
	}m_stReq;

	  struct 
	  {
		PaiPaiBossHead stHead;
		  char szContent[2036];
		  char szPacket[2048];
	  }m_stRes;
};



#endif 
