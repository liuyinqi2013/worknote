// cftapi::CMobileVerifyCode.cpp: implementation of the cftapi::CMobileVerifyCode class.
//
//////////////////////////////////////////////////////////////////////

#include "CMobileVerifyCode.h"
#include "pack.h"


//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

cftapi::CMobileVerifyCode::CMobileVerifyCode()
{

}

cftapi::CMobileVerifyCode::~CMobileVerifyCode()
{

}

bool cftapi::CMobileVerifyCode::SendVerifyCode(
                                                    const string &sMobilePhone, 
                                                    const string &sAppId,
                                                    const string &sExtern,
                                                    const int iExpTime
                                               )
{
	MessageHeader head;
	GetPassAsk stAsk;
	
	memset(&stAsk, 0, sizeof(stAsk));
	
	char SendBuffer[8192]   =   {0};
	char RecvBuffer[8192]   =   {0};
	int iSendBufferSize;
	int iRecvBufferSize;
	head.MessageType = CODE_MAKE_PASS_ASK;
	head.BodyLength = 0;    //����

	m_iErrCode = 0;
	
	char *pPackage = SendBuffer;
	Pack_Make_Int (&pPackage, head.MessageType);
	
	char *pBodyLengthIndex = pPackage;
	Pack_Make_Int (&pPackage, head.BodyLength);
	
	strncpy (stAsk.sMobileNo, sMobilePhone.c_str(), sizeof (stAsk.sMobileNo) - 1);
	strncpy (stAsk.sPassType, sAppId.c_str(), sizeof (stAsk.sPassType) - 1);
	strncpy (stAsk.sMessage, CFT_VERIFYCODE_MSG, sizeof (stAsk.sMessage) - 1);
	snprintf (stAsk.sExpTime, sizeof(stAsk.sExpTime), "%ld", time(NULL)+iExpTime);
	strncpy (stAsk.sIP, "127.0.0.1", sizeof (stAsk.sIP) - 1);
	strncpy(stAsk.sExtern, sExtern.c_str(), sizeof(stAsk.sExtern) -1 );
	

	Pack_Make_OctetString (&pPackage, stAsk.sMobileNo,
		sizeof (stAsk.sMobileNo));
	Pack_Make_OctetString (&pPackage, stAsk.sPassType,
		sizeof (stAsk.sPassType));
	Pack_Make_OctetString (&pPackage, stAsk.sMessage,
		sizeof (stAsk.sMessage));
	Pack_Make_OctetString (&pPackage, stAsk.sExpTime,
		sizeof (stAsk.sExpTime));
	Pack_Make_OctetString (&pPackage, stAsk.sIP, 
	    sizeof (stAsk.sIP));
	Pack_Make_OctetString(&pPackage, stAsk.sExtern,
	    sizeof(stAsk.sExtern));
	//�����趨body length
	Pack_Make_Int (&pBodyLengthIndex, pPackage - pBodyLengthIndex - 4);
	iSendBufferSize = pPackage - SendBuffer;

	
	if(!SendRecv(SendBuffer,iSendBufferSize,RecvBuffer,iRecvBufferSize))
	{
		m_iErrCode = -1;
		return false;
	}
	
	
	char *p = RecvBuffer;
	char *pEnd = RecvBuffer + iRecvBufferSize - 1;
	GetPassRespond respond;
	
	if (Pack_Get_Int (&p, &head.MessageType, pEnd) < 0
		|| Pack_Get_Int (&p, (int *) &head.BodyLength, pEnd) < 0
		|| Pack_Get_Int (&p, (int *) &respond.Result, pEnd) < 0
		|| Pack_Get_OctetString (&p, respond.sMobileNo,
		sizeof (respond.sMobileNo), pEnd) < 0)
	{
	 	m_iErrCode = -1;
		m_sLastErrInfo = "SendVerifyCode Pack_Get Err";
		return false;
	}
	
	
	if (head.MessageType != CODE_MAKE_PASS_RESPOND || respond.Result != 0)
	{
		//m_sLastErrInfo = "SendVerifyCode Pack_Result Err:";
		m_iErrCode = respond.Result;
		m_sLastErrInfo = GetErrInfo(respond.Result);
		return false;
	}

	
	return true;
}
bool cftapi::CMobileVerifyCode::IsValidVerifyCode(
                                                    const string &sMobilePhone, 
                                                    const string &sVerifyCode, 
                                                    const string &sAppId,
                                                    const string &sExtern
                                                  )
{
	MessageHeader head;
	LoginAsk stAsk;	
	
	memset(&stAsk, 0, sizeof(stAsk));
	
	char SendBuffer[8192]   =   {0};
	char RecvBuffer[8192]   =   {0};
	int iSendBufferSize;
	int iRecvBufferSize;

	m_iErrCode = 0;
	head.MessageType = CODE_LOGIN_ASK;
	head.BodyLength = 0;    //����
	
	char *pPackage = SendBuffer;
	Pack_Make_Int (&pPackage, head.MessageType);
	
	char *pBodyLengthIndex = pPackage;
	Pack_Make_Int (&pPackage, head.BodyLength);
	

	strncpy (stAsk.sMobileNo, sMobilePhone.c_str(), sizeof (stAsk.sMobileNo) - 1);
	strncpy (stAsk.sPassType, sAppId.c_str(), sizeof (stAsk.sPassType) - 1);
	strncpy (stAsk.sPassword, sVerifyCode.c_str(), sizeof (stAsk.sPassword) - 1);
	strncpy (stAsk.sClientIP, "127.0.0.1", sizeof (stAsk.sClientIP) - 1);
	strncpy (stAsk.sExtern, sExtern.c_str(), sizeof(stAsk.sExtern) - 1);
	
	Pack_Make_OctetString (&pPackage, stAsk.sMobileNo,
		sizeof (stAsk.sMobileNo));
	Pack_Make_OctetString (&pPackage, stAsk.sPassType,
		sizeof (stAsk.sPassType));
	Pack_Make_OctetString (&pPackage, stAsk.sPassword,
		sizeof (stAsk.sPassword));
	Pack_Make_OctetString (&pPackage, stAsk.sClientIP,
		sizeof (stAsk.sClientIP));
	Pack_Make_OctetString (&pPackage, stAsk.sExtern,
	    sizeof (stAsk.sExtern));
	
	//�����趨body length
	Pack_Make_Int (&pBodyLengthIndex, pPackage - pBodyLengthIndex - 4);
	iSendBufferSize = pPackage - SendBuffer;

	if(!SendRecv(SendBuffer,iSendBufferSize,RecvBuffer,iRecvBufferSize))
	{
		m_iErrCode = -1;
		return false;
	}


	char *p = RecvBuffer;
	char *pEnd = RecvBuffer + iRecvBufferSize - 1;
	LoginRespond respond;
	
	if (Pack_Get_Int (&p, &head.MessageType, pEnd) < 0
		|| Pack_Get_Int (&p, (int *) &head.BodyLength, pEnd) < 0
		|| Pack_Get_Int (&p, (int *) &respond.Result, pEnd) < 0
		|| Pack_Get_OctetString (&p, respond.sMobileNo,
		sizeof (respond.sMobileNo), pEnd) < 0)
	{
		m_iErrCode = -2;
		m_sLastErrInfo = "IsValidVerifyCode Pack_Get Err";
		
		return false;
	}
	
	
	if (head.MessageType != CODE_LOGIN_RESPOND || respond.Result != 0)
	{
	//	m_sLastErrInfo = "IsValidVerifyCode Pack_Result Err:";
		m_iErrCode = respond.Result;
		m_sLastErrInfo = GetErrInfo(respond.Result);
		return false;
	}

	return true;
}

bool cftapi::CMobileVerifyCode::SendVerifyCode( const string &sMobilePhone, const int iExpTime )
{
    string strAppid(CFT_VERIFYCODE_TYPE), strsExtern("");
    SendVerifyCode(sMobilePhone, strAppid, strsExtern, iExpTime);
}

bool cftapi::CMobileVerifyCode:: SendRecv(const char * szReq,const int iReq,char *pszRes,int &iRes)
{
	bool bRet=false;
	xyz::CTcpSocket *pstClt = NULL;
	try
	{
		pstClt = new xyz::CTcpSocket (m_sSvrIp.c_str(),m_iSvrPort);
		
		pstClt->Write ((char *)szReq, iReq);
		

		iRes = pstClt->Read ((char *)pszRes, 1024,m_iSvrTmOut);	
		if(iRes > 0)
		{
			bRet = true;
		}
		else
		{
			m_sLastErrInfo = string("CMobileVerifyCode xyzsock exception:read err");
			bRet = false;
		}
		
	}
	catch (xyz::CException & e)
	{
		m_sLastErrInfo = string("CMobileVerifyCode xyzsock exception:");
		m_sLastErrInfo +=e.ErrorMessage ();
		bRet = false;
	}
	if (pstClt != NULL)
	{
		pstClt->Close ();
		delete pstClt;
	}
	
	return bRet;
}

// michaelli 2009/04/21 ����������ص�
int cftapi::CMobileVerifyCode::GetLastErrCode()
{
	return m_iErrCode;
}

string cftapi::CMobileVerifyCode::GetErrInfo(const int iErrCode)
{
	string sErrInfo;
	switch (iErrCode) 
	{
    case 0:
        sErrInfo = "Successful";
        break;
    case 1:
        sErrInfo = "���󲻳ɹ�";
        break;
    case 2:
        sErrInfo = "�ֻ��������";
        break;
    case 3:
        sErrInfo = "������������";
        break;
    case 4:
        sErrInfo = "�ֻ��������Ҳ���";
        break;
    case 5:
        sErrInfo = "���Ͷ���ʧ��";
        break;
    case 6:
        sErrInfo = "��֤������";
        break;
    case 7:
        sErrInfo = "�����ֻ���ǰ�Ѿ����������";
        break;
    case 8:
        sErrInfo = "�����ֻ���/����";
        break;
    case 9:
        sErrInfo = "���볤�Ȳ���";
        break;
    case 10:
        sErrInfo = "�������ݳ���";
        break;
    case 12:
        sErrInfo = "����ʽ����";
        break;
    case 13:
        sErrInfo = "������ڣ����޸�����";
        break;
    case 14:
        sErrInfo = "��������ʱ���ӳ���";
        break;
    case 16:
		sErrInfo = "passtype��ʽ����";
        break;
    case 17:
		sErrInfo = "message��ʽ����";
        break;
    case 18:
		sErrInfo = "����ʱ�䲻��ȷ";
        break;
   case 10010:
		sErrInfo = "�·���֤���Ƶ�������Ժ�����";
		break;
    case 20:
        sErrInfo = "��������";
        break;
    default:
        sErrInfo = "��������";
        break;
    }
	
	char szCode[13]={0};
	snprintf(szCode, sizeof(szCode), "[%d]", iErrCode);

    return string(szCode)+sErrInfo;

}
