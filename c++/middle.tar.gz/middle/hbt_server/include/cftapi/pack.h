#ifndef _PACK_H_
#define _PACK_H_

#define C_RCCS_NOT_CONNECTED		0
#define C_RCCS_CONNECTED		1
#define C_RCCS_BINDING                  2
#define C_RCCS_BINDED                   3
#define C_RCCS_WAITTING			4

#define C_DCS_BIN			0x04

typedef char DDWORD[8];
typedef char DWORD[4];
typedef char WORD[2];

typedef unsigned int  U_INT;
//typedef unsigned char BYTE;
typedef unsigned char U_WORD[2];
typedef unsigned char U_DWORD[4];
typedef unsigned char U_DDWORD[8];



#define C_MAX_PACK_LEN			2048

#define C_RET_VALID_PACK		0
#define C_RET_BUF_TOO_SHORT		-1
#define C_RET_INVALID_PACK		-2

//#ifdef __cplusplus
//extern "C"{
//#endif

void Pack_SetWordA(void *p, void *w);
void Pack_SetDWordA(void *p, void *dw);

void Pack_Make_Int(char **p, int i);
void Pack_Make_Byte(char **p, int i);
void Pack_Make_ShortInt(char **p, short i);
void Pack_Make_CString(char **p, char *Content);
void Pack_Make_CString2(char **p, char *Content,int iMaxLen);
void Pack_Make_OctetString(char **p, char *Content,int iLen);

int  Pack_Get_Int(char **p, int *i, char *endp);
int  Pack_Get_Byte(char **p, char *i, char *endp);
int  Pack_Get_ShortInt(char **p, short *i, char *endp);
int  Pack_Get_CString(char **p, char *Content, char *endp);
int  Pack_Get_CString2(char **p, char *Content, char *endp,int iMaxLen);
int  Pack_Get_OctetString(char **p, char *Content, int iLen,char *endp);

//#ifdef __cplusplus
//}
//#endif

#endif
