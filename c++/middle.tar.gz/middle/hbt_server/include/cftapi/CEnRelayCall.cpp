#include "CEnRelayCall.h"
#include "qpay_encrypt_client.h"
 
//##ModelId=44E2C0C301B5
string cftapi::CEnRelayCall::GetValue(string key, bool bEncode)
{
	if(bEncode)
		return m_mRes.UrlEncode(m_mRes[key]);
	else
		return m_mRes[key];
}


const char* cftapi::CEnRelayCall::getSendStr()
{

	return m_strSendStr.c_str();
}

const char* cftapi::CEnRelayCall::getEnSendStr()
{

	return m_EnSendStr.c_str();
}

const char* cftapi::CEnRelayCall::getResultStr()
{
	return m_pszRes?m_pszRes :"";
}

bool cftapi::CEnRelayCall::EncapsRequesPara(bsapi::CStringMap mReq, string& strResult)
{
	if(mReq.GenString(m_strSendStr,"$","=") != 0)
  	{
    		m_sLastErrInfo = "pack error";
    		return false;
  	}

	char szDigit[128];
	memset(szDigit,0,sizeof(szDigit));
  	GenerateDigest((char *)m_strSendStr.c_str(), szDigit, sizeof(szDigit)-1);
	m_strSendStr += "&abstract=";
	m_strSendStr += mReq.UrlEncode(szDigit);

	char szDest[1024*8];
  	memset(szDest,0,sizeof(szDest));
  
  	if(Encrypt(m_sSpId.c_str(),(char *)m_strSendStr.c_str(),szDest,sizeof(szDest)-1) != 0)
    		return false;

	strResult += "sp_id=";
	strResult += m_sSpId;
	
	strResult += "&request_text="  ;
	strResult += mReq.UrlEncode(szDest);
	return true;
	
}
 
//bool cftapi::CEnRelayCall::SendRecv2(bsapi::CStringMap mReq,bsapi::CStringMap & mRes)
bool cftapi::CEnRelayCall::SendRecv(bsapi::CStringMap mReq, int &iRes)
{    
	m_pszRes=0;
  if(mReq.GenString(m_strSendStr,m_sEleSep,m_sNvSep) != 0)
  {
    m_sLastErrInfo = "pack error";
    return false;
  }
//   cout << sReq <<endl;
  //
  char szDigit[128];
  memset(szDigit,0,sizeof(szDigit));
  GenerateDigest((char *)m_strSendStr.c_str(), szDigit, sizeof(szDigit)-1);
  m_strSendStr += "&abstract=";
  m_strSendStr += mReq.UrlEncode(szDigit);
  
//   cout << sReq <<endl;
  //
  char szDest[1024*5];
  memset(szDest,0,sizeof(szDest));
  
  if(Encrypt(m_sSpId.c_str(),(char *)m_strSendStr.c_str(),szDest,sizeof(szDest)-1) != 0)
    return false;
    
    bsapi::CStringMap t_mReq;
  t_mReq["ver"] = mReq["ver"];
  t_mReq["head_u"] = mReq["head_u"];
  t_mReq["sp_id"] = mReq["sp_id"];

  if( m_sReqType.empty() )
	  t_mReq["request_type"] = mReq["request_type"];
  else
  	 t_mReq["request_type"] = m_sReqType;
  
  //t_mReq["request_text"] = mReq.UrlEncode(szDest);
  t_mReq["request_text"] = szDest;

  //string sReq;
  m_EnSendStr = "";
  t_mReq.GenString(m_EnSendStr,"&","=");
  
  //char * pszRes ;
  //int iRes;
  
  if(!CRelayComm::SendRecv(m_EnSendStr.c_str(),m_EnSendStr.size(),&m_pszRes,iRes))
    return false;
  
  if(m_pszRes == NULL)
    return false;

/*
  bsapi::CStringMap mRes;
  mRes.SnapElement(m_pszRes);
  if(atoi(mRes["result"].c_str()) == 0)
  {
    return true;
  }
  */
  return true;
}

bool cftapi::CEnRelayCall::Call(bsapi::CStringMap iodat,  int &iRes)
{
	bsapi::CStringMap::iterator iter=iodat.begin();
	while( iter!=iodat.end())
	{
		m_mReq[(*iter).first]=(*iter).second;
		iter++;
	}
	if( m_mReq["head_u"].empty())
		m_mReq["head_u"] = m_sOperId;
	if(m_mReq["ver"].empty())
  		m_mReq["ver"] = m_sVersion;
	if(m_mReq["sp_id"].empty() )
  		m_mReq["sp_id"] = m_sSpId;
	

	 //if(!SendRecv(m_mReq,m_mRes))
	 if(!SendRecv(m_mReq, iRes) )
   		return false;

	 return true;
}


