#include "CTokenCoinList.h"


const char * const cftapi::CTokenCoinList::szReqType = "126";
/*
# ������б���ѯ�ӿ�
126:0:0:2:gwq_queryroll_service:RD_VoucherListQuery:RD_VoucherListQuerySuc:RD_VoucherListQueryFail
*/
  
//##ModelId=44E2C0C301B5
string cftapi::CTokenCoinList::GetValue(string key)
{
  return m_mRes[key];
}

//##ModelId=44E2C659030D
bool cftapi::CTokenCoinList::Fetch(string uin,string innerid,string bachid,string status,
  string stime,string etime,
  string offset,string limit,string uip)
{
  m_mReq["purchaser_id"] = uin;
  m_mReq["purchaser_uid"] = innerid;
  m_mReq["tde_id"] = bachid;
  m_mReq["overdue_flag"] = "1";
  m_mReq["login_ip"] = uip;
  m_mReq["offset"] = offset;
  m_mReq["limit"] = limit;
  m_mReq["s_time"] = stime;
  m_mReq["e_time"] = etime;
  m_mReq["status"] = status;
  
  m_mReq["head_u"] = m_sOperId;
  m_mReq["ver"] = m_sVersion;
  m_mReq["sp_id"] = m_sSpId;
  m_mReq["request_type"] = szReqType;
  
  string sReq;
  if(m_mReq.GenString(sReq,"&","=") != 0)
  {
    m_sLastErrInfo = "pack error";
    return false;
  }
  
  char * pszRes ; int iRes;
  
  if(!SendRecv(sReq.c_str(),sReq.size(),&pszRes,iRes))
    return false;
  
  if(pszRes == NULL)
    return false;
  
  //�����Ʒ���
  /*
    int retcd;    
    int retnum;
    int totalnum;
    int sizeofst;
    ST_TCPAYLIST stData[retnum];
  */
  memcpy((char *)&m_stHead,pszRes,sizeof(m_stHead));
  /*
  printf("%d-%d-%d-%d\r\n",
    m_stHead.iRetcode,
    m_stHead.iRetNum,
    m_stHead.iTotalNum,
//    m_stHead.iSize,
    sizeof(ST_GWQQUERY));
    */
  
  m_mRes["total_num"] = StringFrmInt(m_stHead.iTotalNum);
  m_mRes["ret_num"] = StringFrmInt(m_stHead.iRetNum);
  if( m_stHead.iRetcode == 0)
  {
    if( m_stHead.iRetNum != 0)
    {
      m_pstDataList = new ST_GWQQUERY[m_stHead.iRetNum];
      memcpy(m_pstDataList,pszRes + sizeof(m_stHead),
        sizeof(ST_GWQQUERY) * m_stHead.iRetNum);
        
      StoreMap();      
    }
    return true;
  }
  return false;
}
string cftapi::CTokenCoinList::StringFrmInt(int i)
{
	char szBuf[30];
	
	memset(szBuf,0,sizeof(szBuf));
	
  sprintf(szBuf,"%d",i);
	
	szBuf[29] = 0;
	
	return string(szBuf);
}
int cftapi::CTokenCoinList::GetCount(string status)
{
  int iRes = 0;
  
  for( int i = 0; i<m_stHead.iRetNum; i++)
  {
    if(m_pstDataList[i].Fstate == atoi(status.c_str()))
      iRes++;
  }
  
  return iRes;
}

void cftapi::CTokenCoinList::StoreMap()
{
  m_mRes["records"] = "";
  
  for( int i = 0; i<m_stHead.iRetNum; i++)
  {
    m_mRes["records"] += "<record>";
        m_mRes["records"] += "<name>";
        m_mRes["records"] += m_pstDataList[i].Fatt_name;  
        m_mRes["records"] += "</name>";
      m_mRes["records"] += "<type>";
      m_mRes["records"] += StringFrmInt(m_pstDataList[i].Ftype);
      m_mRes["records"] += "</type>";
        m_mRes["records"] += "<enddt>";
        m_mRes["records"] += m_pstDataList[i].Fetime;
        m_mRes["records"] += "</enddt>";
      m_mRes["records"] += "<status>";
      m_mRes["records"] += StringFrmInt(m_pstDataList[i].Fstate);
      m_mRes["records"] += "</status>";
        m_mRes["records"] += "<amount>";
        m_mRes["records"] += StringFrmInt(m_pstDataList[i].Ffee);
        m_mRes["records"] += "</amount>";
      m_mRes["records"] += "<bid>";
      m_mRes["records"] += StringFrmInt(m_pstDataList[i].Ftde_id);  
      m_mRes["records"] += "</bid>";
    m_mRes["records"] += "</record>";
  }
}

