#include "CAliasLoginPwd.h"

/*
#ȡ�ص�½����
3006:0:0:1:emsus_getpwd_service:GETPWD_ALIAS:GETPWD_ALIAS_SUC:GETPWD_ALIAS_FAIL
3007:0:0:1:emsus_valikey_service:VALIKEY_ALIAS:VALIKEY_ALIAS_SUC:VALIKEY_ALIAS_FAIL
3008:0:0:1:emsus_updatepwd_service:UPDATEPWD_ALIAS:UPDATEPWD_ALIAS_SUC:UPDATEPWD_ALIAS_FAIL
#�޸ĵ�½����
3009:0:0:1:emsus_modifypwd_service:MODIPWD_ALIAS:MODIPWD_ALIAS_SUC:MODIPWD_ALIAS_FAIL
*/
const char * const cftapi::CAliasLoginPwd::szReqType = "3009";
  
//##ModelId=44E2C0C301B5
string cftapi::CAliasLoginPwd::GetValue(string key, bool bEncode)
{
	if(bEncode)
		return m_mRes.UrlEncode(m_mRes[key]);
	else
		return m_mRes[key];
}


bool cftapi::CAliasLoginPwd::Modify(bsapi::CStringMap iodat )
{
  m_mReq["uin"] = iodat["uin"];
  m_mReq["client_ip"] = iodat["client_ip"];
  m_mReq["channel_id"] = iodat["channel_id"];
  
  m_mReq["old_pass_en"] = iodat["old_loginpwd"];
  m_mReq["old_pass_seed"] = iodat["old_loginpwd_seed"];
  m_mReq["old_pass_type"] = "2";
  m_mReq["new_pass_en"] = iodat["new_loginpwd"];
  m_mReq["new_pass_seed"] = iodat["new_loginpwd_seed"];
  m_mReq["new_pass_type"] = "2";
  
  
  m_mReq["head_u"] = m_sOperId;  
  m_mReq["ver"] = m_sVersion;
  m_mReq["sp_id"] = m_sSpId;
  m_mReq["request_type"] = "3009";
  
  
  if(!SendRecv(m_mReq,m_mRes))
    return false;
  
  return true;
}

