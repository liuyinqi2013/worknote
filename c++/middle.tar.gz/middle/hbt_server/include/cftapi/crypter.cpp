#include "crypter.h"
#include <string.h>


Crypter::buffer::buffer(int s):size(s){
  pre = new unsigned char[size+10+10]; //10 extra workbuffer front and behind
  data = pre + 10;
  len = 0;
}

Crypter::buffer::buffer(){
    pre = NULL;
    size = 0;
    len = 0;       // �������д洢�����ݵ�ʵ�ʳ���
    data = NULL;
}

Crypter::buffer::~buffer(){
  if (pre!=0){
    delete[] pre;
    pre=NULL;
    data = NULL;
  }
}

#ifdef INCLUDEMD5   //This is removed
Crypter::buffer* Crypter::buffer::md5(unsigned char*buf,int length){
  // md5 is defined in RFC 1321 
  // and implemented in crypto libray (openssl/md5.h)

  ret = new buffer(16);
  ret->data = MD5(buf,len,ret->data);
  if (ret->data==0) { // NOTE: This is undocumentet, but I assume it works this way. It will not break anything anyway.
    delete ret;
    ret=0;
  }
  return ret;
}
#endif

