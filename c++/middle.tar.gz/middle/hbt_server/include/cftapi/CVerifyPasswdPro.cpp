#include "CVerifyPasswdPro.h"


const char * const cftapi::CVerifyPasswdPro::szReqType = "112";
  
//##ModelId=44E2C0C301B5
string cftapi::CVerifyPasswdPro::GetValue(string key, bool bEncode)
{
	if(bEncode)
		return m_mRes.UrlEncode(m_mRes[key]);
	else
		return m_mRes[key];
}



bool cftapi::CVerifyPasswdPro::Verify(bsapi::CStringMap iodat )
{

	m_mReq["uin"] = iodat["uin"];
	m_mReq["ans1"] = iodat["ans1"];
	m_mReq["ans2"] = iodat["ans2"];
	m_mReq["spid"] = m_sSpId;
	
	m_mReq["client_ip"] = iodat["client_ip"];
	m_mReq["channel_id"] = iodat["channel_id"];
	m_mReq["app_id"] = iodat["app_id"];
	m_mReq["sp_time"] = iodat["sp_time"];
	
	
	m_mReq["head_u"] = m_sOperId;  
	m_mReq["ver"] = m_sVersion;
	m_mReq["sp_id"] = m_sSpId;
	m_mReq["request_type"] = szReqType;
	
	if(!SendRecv(m_mReq,m_mRes))
		return false;
	
	return true;
}
