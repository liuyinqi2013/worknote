#ifndef CEnRelayCall_H_HEADER_INCLUDED_BB1D1E69
#define CEnRelayCall_H_HEADER_INCLUDED_BB1D1E69

#include "CStringMap.h"
#include "CEnRelayComm.h"


//##ModelId=44E2B49A00DA
class cftapi::CEnRelayCall : public cftapi::CEnRelayComm
{
  public:
    //##ModelId=44E2C659030D
    string GetValue(string key, bool bEncode=true);

    bool Call(bsapi::CStringMap iodat, int &iRes);
  bool EncapsRequesPara(bsapi::CStringMap iodat, string& strResult);


   //��ȡ�����ַ���������ǰ
    const char* getSendStr();
   //���ܺ����ַ���
   const char* getEnSendStr();

   //���ؽ��
   const char* getResultStr();
    
  protected:    
    static const char * const szReqType ;
    //##ModelId=44E2C070001F
    bsapi::CStringMap m_mReq;


    //##ModelId=44E2C0850213
    bsapi::CStringMap m_mRes;

    //
    char *m_pszRes;
    string m_strSendStr;
    string m_EnSendStr;
	
    
    virtual bool SendRecv(bsapi::CStringMap mReq, int &iRes);

};


#endif /* CRegister_H_HEADER_INCLUDED_BB1D1E69 */
