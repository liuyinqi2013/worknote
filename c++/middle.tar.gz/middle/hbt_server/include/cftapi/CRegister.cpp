#include "CRegister.h"


const char * const cftapi::CRegister::szReqType = "3004";
  
//##ModelId=44E2C0C301B5
string cftapi::CRegister::GetValue(string key, bool bEncode)
{
	if(bEncode)
		return m_mRes.UrlEncode(m_mRes[key]);
	else
		return m_mRes[key];
}

//##ModelId=44E2C659030D
bool cftapi::CRegister::Reg(bsapi::CStringMap iodat )
{
  m_mReq["uin"] = iodat["uin"];
  m_mReq["client_ip"] = iodat["client_ip"];
  m_mReq["channel_id"] = iodat["channel_id"];
  
  m_mReq["login_type"] = iodat["login_type"];
  m_mReq["en_buf"] = iodat["paypwd"];
  m_mReq["time_stamp"] = iodat["paypwd_seed"];
  
  m_mReq["user_type"] = iodat["user_type"];
  m_mReq["sex"] = iodat["sex"];
  m_mReq["true_name"] = iodat["true_name"];
  m_mReq["com_name"] = iodat["com_name"];
  m_mReq["cre_type"] = iodat["cre_type"];
  m_mReq["cre_id"] = iodat["cre_id"];
  m_mReq["email"] = iodat["email"];
  m_mReq["mobile_phone"] = iodat["mobile_phone"];
  m_mReq["address"] = iodat["address"];
  m_mReq["postalcode"] = iodat["postalcode"];
  m_mReq["qes1"] = iodat["qes1"];
  m_mReq["ans1"] = iodat["ans1"];
  m_mReq["qes2"] = iodat["qes2"];
  m_mReq["ans2"] = iodat["ans2"];
  
  m_mReq["login_pass_en"] = iodat["loginpwd"];
  m_mReq["login_pass_seed"] = iodat["loginpwd_seed"];
 if(iodat["loginpwd"].size() == 32)
        m_mReq["login_pass_type"] = "4";
  else
        m_mReq["login_pass_type"] = "2";

  m_mReq["vali_type"] = "2";
  
  m_mReq["head_u"] = m_sOperId;  
  m_mReq["ver"] = m_sVersion;
  m_mReq["sp_id"] = m_sSpId;
  m_mReq["request_type"] = szReqType;
  
  
  if(!SendRecv(m_mReq,m_mRes))
    return false;
  
  return true;
}
