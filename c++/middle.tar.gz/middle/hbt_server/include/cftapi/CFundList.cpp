#include "CFundList.h"


const char * const cftapi::CFundList::szReqType = "106";
/*
# ��ѯ�ʽ���ˮ
106:0:2:2:query_blist_service:RD_FundWaterQuery:RD_FundWaterQuerySuc:RD_FundWaterQueryFail
*/
  
//##ModelId=44E2C0C301B5
string cftapi::CFundList::GetValue(string key)
{
  return m_mRes[key];
}

//##ModelId=44E2C659030D
bool cftapi::CFundList::Fetch(string uin,
  string stime,string etime,
  string offset,string limit,string uip)
{
  m_mReq["uin"] = uin;
  m_mReq["offset"] = offset;
  m_mReq["limit"] = limit;
  m_mReq["s_time"] = stime;
  m_mReq["e_time"] = etime;
  
  m_mReq["head_u"] = m_sOperId;
  m_mReq["ver"] = m_sVersion;
  m_mReq["sp_id"] = m_sSpId;
  m_mReq["request_type"] = szReqType;
  
  string sReq;
  if(m_mReq.GenString(sReq,"&","=") != 0)
  {
    m_sLastErrInfo = "pack error";
    return false;
  }
  
  char * pszRes ; int iRes;
  
  if(!SendRecv(sReq.c_str(),sReq.size(),&pszRes,iRes))
    return false;
  
  if(pszRes == NULL)
    return false;
  
  //�����Ʒ���
  /*
    int retcd;    
    int retnum;
    int totalnum;
    int sizeofst;
    ST_TCPAYLIST stData[retnum];
  */
  memcpy((char *)&m_stHead,pszRes,sizeof(m_stHead));
  /*
  printf("%d-%d-%d-%d\r\n",
    m_stHead.iRetcode,
    m_stHead.iRetNum,
    m_stHead.iTotalNum,
//    m_stHead.iSize,
    sizeof(ST_GWQQUERY));
    */
  
  m_mRes["total_num"] = StringFrmInt(m_stHead.iTotalNum);
  m_mRes["ret_num"] = StringFrmInt(m_stHead.iRetNum);
  if( m_stHead.iRetcode == 0)
  {
    if( m_stHead.iRetNum != 0)
    {
      m_pstDataList = new UserFundWater[m_stHead.iRetNum];
      memcpy(m_pstDataList,pszRes + sizeof(m_stHead),
        sizeof(UserFundWater) * m_stHead.iRetNum);
        
      StoreMap();      
    }
    return true;
  }
  return false;
}
string cftapi::CFundList::StringFrmInt(int i)
{
	char szBuf[30];
	
	memset(szBuf,0,sizeof(szBuf));
	
  sprintf(szBuf,"%d",i);
	
	szBuf[29] = 0;
	
	return string(szBuf);
}
int cftapi::CFundList::GetCout(string sub,string minamt,string maxamt)
{
  int iRes = 0;
  
  for( int i = 0; i<m_stHead.iRetNum; i++)
  {
    if((m_pstDataList[i].iAmount >= atoi(minamt.c_str()) )&&
       (m_pstDataList[i].iAmount <= atoi(maxamt.c_str()) )&&
       (m_pstDataList[i].iSubject <= atoi(sub.c_str()) ))
       iRes++;
  }
  return iRes;
}
  
void cftapi::CFundList::StoreMap()
{
  m_mRes["records"] = "";
  
  for( int i = 0; i<m_stHead.iRetNum; i++)
  {
    m_mRes["records"] += "<record>";
        m_mRes["records"] += "<time>";
        m_mRes["records"] += m_pstDataList[i].szTime;  
        m_mRes["records"] += "</time>";
      m_mRes["records"] += "<tid>";
      m_mRes["records"] += m_pstDataList[i].szTransactionId;
      m_mRes["records"] += "</tid>";      
        m_mRes["records"] += "<amount>";
        m_mRes["records"] += StringFrmInt(m_pstDataList[i].iAmount);
        m_mRes["records"] += "</amount>";
      m_mRes["records"] += "<subject>";
      m_mRes["records"] += StringFrmInt(m_pstDataList[i].iSubject);  
      m_mRes["records"] += "</subject>";
    m_mRes["records"] += "</record>";
  }
}

//int cftapi::CFundList::GetDataList(UserFundWater * datalist, int * count)
cftapi::UserFundWater * cftapi::CFundList::GetDataList()
{
//	if (datalist != NULL || count == NULL)
//		return -1;

//	datalist = m_pstDataList;
//	*count = m_stHead.iRetNum;

	return m_pstDataList;
}

