#ifndef CQueryPasswdPro_H_HEADER_INCLUDED_BB1D1E69
#define CQueryPasswdPro_H_HEADER_INCLUDED_BB1D1E69

#include "CStringMap.h"
#include "CRelayComm.h"



//##ModelId=44E2B49A00DA
class cftapi::CQueryPasswdPro : public cftapi::CRelayComm
{
  public:
    //##ModelId=44E2C659030D
    string GetValue(string key, bool bEncode=true);
    //##ModelId=44E2C0C301B5
    bool Query(bsapi::CStringMap iodat);

      
      
  private:    
    static const char * const szReqType ;
    //##ModelId=44E2C070001F
    bsapi::CStringMap m_mReq;


    //##ModelId=44E2C0850213
    bsapi::CStringMap m_mRes;

};


#endif /* CQueryPasswdPro_H_HEADER_INCLUDED_BB1D1E69 */
