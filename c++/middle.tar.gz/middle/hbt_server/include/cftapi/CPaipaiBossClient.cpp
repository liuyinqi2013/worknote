#include "CPaipaiBossClient.h"
#include <sstream>

cftapi::CPaipaiBossClient::CPaipaiBossClient()
{
	memset(&m_stReq, 0, sizeof(m_stReq));
	memset(&m_stRes, 0, sizeof(m_stRes));
}

const char* cftapi::CPaipaiBossClient::getSendStr()
{
	static char szHex[10240]={0};
	memset(szHex, 0, sizeof(szHex));
	snprintf(szHex, 7, "[%d]", m_stReq.stHead.iLen);
	char *p = szHex + strlen(szHex);
	for(int i=0; i<m_stReq.stHead.iLen; i++)
	{
		snprintf(p+(3*i), 4, "%02x ", (unsigned char)m_stReq.szPacket[i]);
	}

	return szHex;
}

const char* cftapi::CPaipaiBossClient::getResultStr()
{
	static char szHex[10240]={0};
	memset(szHex, 0, sizeof(szHex));
	snprintf(szHex, 7, "[%d]", m_stRes.stHead.iLen);
	char *p = szHex + strlen(szHex);
	for(int i=0; i<m_stRes.stHead.iLen; i++)
	{
		snprintf(p+(3*i), 4, "%02x ", (unsigned char)m_stRes.szPacket[i]);
	}
	
	return szHex;
}

int cftapi::CPaipaiBossClient::GetRetCode()
{
	return m_stRes.stHead.iRetCode;
}

//##ModelId=44E9671B00AB
int cftapi::CPaipaiBossClient::SendRecv()
{
  int iRetCode = 0;
bool bRet = false;


	memset(&m_stRes, 0, sizeof(m_stRes));

	int iContentLen = m_stReq.stHead.iLen - 12;
	if(iContentLen < 0 || iContentLen > sizeof(m_stReq.szContent))
	{
		m_stRes.stHead.iRetCode=2;
		m_sLastErrInfo = string("req packet err");
		return -1;
	}

	int iOffset=0;
	int iTmp;
	iTmp = htonl(m_stReq.stHead.iLen);
	memcpy(m_stReq.szPacket+iOffset, &iTmp, 4 );
	iOffset += 4;
	
	iTmp = htonl(m_stReq.stHead.iOpCode);
	memcpy(m_stReq.szPacket+iOffset, &iTmp, 4 );
	iOffset += 4;

	iTmp = htonl(m_stReq.stHead.iRetCode);
	memcpy(m_stReq.szPacket+iOffset, &iTmp, 4 );
	iOffset += 4;

	memcpy(m_stReq.szPacket+iOffset, m_stReq.szContent, iContentLen );

  
  xyz::CTcpSocket *pstClt = NULL;
  try
  {
	pstClt = new xyz::CTcpSocket (m_sSvrIp.c_str(),m_iSvrPort);
    pstClt->Write (m_stReq.szPacket, m_stReq.stHead.iLen);

	int iResLen = 0;
	int iCurLen =0;
	bool bHeadInit = false;
      while(true)
      {
        iResLen += pstClt->Read (((char *)&m_stRes.szPacket)+iResLen, sizeof(m_stRes.szPacket)-iResLen,m_iSvrTmOut);
	
	//���շ��ظ���
        if(iResLen <= iCurLen)
        {
		m_stRes.stHead.iRetCode = 2;
          bRet = false;
          m_sLastErrInfo = string("communicate failed.");
          break;
        }

	//�Ȱ�ͷ��
        if(iResLen >= 12)
        {
		if(!bHeadInit)
		{
			iOffset=0;
			memcpy(&iTmp, m_stRes.szPacket+iOffset, 4);
			m_stRes.stHead.iLen = ntohl(iTmp);
			iOffset += 4;

			memcpy(&iTmp, m_stRes.szPacket+iOffset, 4);
			m_stRes.stHead.iOpCode = ntohl(iTmp);
			iOffset += 4;

			memcpy(&iTmp, m_stRes.szPacket+iOffset, 4);
			m_stRes.stHead.iRetCode = ntohl(iTmp);
			iOffset += 4;

			bHeadInit = true;

			if(sizeof(m_stRes.szPacket) < m_stRes.stHead.iLen)
			{
				m_stRes.stHead.iLen = iResLen;
				m_stRes.stHead.iRetCode = 3;
				m_sLastErrInfo = string("res packet err");
				bRet = false;
				break;
			}
			else if(m_stRes.stHead.iRetCode != 0)
			{
				stringstream ss;
				ss << "res head err [" << m_stRes.stHead.iRetCode << "]";
				m_sLastErrInfo = ss.str();
				bRet = true;
				break;
			}
		}
		//��������
          if(iResLen >= m_stRes.stHead.iLen)
          {
		memcpy(m_stRes.szContent, m_stRes.szPacket+iOffset, m_stRes.stHead.iLen-12);

            bRet = true;
            break;
          }
        }
        iCurLen = iResLen;
      }
    

  }
  catch (xyz::CException & e)
  {
	  m_stRes.stHead.iRetCode=1;
    m_sLastErrInfo = string("xyzsock exception:");
    m_sLastErrInfo +=e.ErrorMessage ();
  }
  if (pstClt != NULL)
  {
    pstClt->Close ();
    delete pstClt;
  }
  return m_stRes.stHead.iRetCode;
}


int cftapi::CPaipaiBossClient::QueryAuthInfo(bsapi::CStringMap &iodat)
{
	int iRet;
	int iTmp;

	memset(&m_stReq, 0, sizeof(m_stReq));	
	m_stReq.stHead.iOpCode = 0x73;
	int iReqUin;
	iReqUin =  atoi(iodat["uin"].c_str());
	iTmp = htonl(iReqUin);
	memcpy(m_stReq.szContent, &iTmp, sizeof(iReqUin));
	m_stReq.stHead.iLen = 16;
	
	iRet = SendRecv();
	if(iRet != 0)
	{
		return iRet;
	}
	
	if(m_stRes.stHead.iLen != 108)
	{
		m_stRes.stHead.iRetCode=4;
		m_sLastErrInfo = string("content len err");
		return m_stRes.stHead.iRetCode;
	}
	
	char szTmpBuf[128] = {0};
	int iOffset = 0;

	memcpy(&iTmp, m_stRes.szContent+iOffset, 4);
	iOffset += 4;

	if(iReqUin != ntohl(iTmp))
	{
		m_stRes.stHead.iRetCode=5;
		m_sLastErrInfo = string("content packet err");
		return m_stRes.stHead.iRetCode;
	}

	memcpy(&iTmp, m_stRes.szContent+iOffset, 4);
        iOffset += 4;
	snprintf(szTmpBuf, sizeof(szTmpBuf), "%d", ntohl(iTmp));
	iodat["state"] = szTmpBuf;

	memcpy(szTmpBuf, m_stRes.szContent+iOffset, 32);
	iOffset += 32;
	iodat["name"] = szTmpBuf;

	memcpy(szTmpBuf, m_stRes.szContent+iOffset, 24);
	iOffset += 24;
	iodat["cre_id"] = szTmpBuf;

	
	memcpy(szTmpBuf, m_stRes.szContent+iOffset, 32);
	iOffset += 32;
	iodat["bank_card"] = szTmpBuf;

	
	return 0;
	
}
