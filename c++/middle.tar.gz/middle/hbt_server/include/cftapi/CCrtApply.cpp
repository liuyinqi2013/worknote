#include "CCrtApply.h"


const char * const cftapi::CCrtApply::szReqType = "2301";

string cftapi::CCrtApply::GetValue(string key, bool bEncode)
{
	if(bEncode)
		return m_mRes.UrlEncode(m_mRes[key]);
	else
		return m_mRes[key];
}
/*
# ע������֤��
2301:0:0:1:crt_register_service:Crt_Register:Crt_RegisterSuc:Crt_RegisterFail
*/  
/*******************************************************
 *������req�û�����ṹ�壬crtǩ�����֤������
 *�����true �ɹ� false ʧ��
 *���ܣ�ע���û�����֤�� 
*******************************************************/
//##ModelId=44E2C659030D
bool cftapi::CCrtApply::CrtRegister(const CrtApplyInfo& req,string &crt,bool bEncode)
{
  m_mReq["op_type"] = req.op_type;
  m_mReq["qqid"] = req.qqid;
  m_mReq["crt_type"] = req.crt_type; //�Ƹ�ͨ��վ֤��
  m_mReq["crt_addr"] = req.crt_addr;
  m_mReq["crt_csr"] = req.crt_csr;
  m_mReq["true_name"] = req.true_name;
  if(req.op_type=="1") m_mReq["card_type"] = req.card_type;
  if(req.op_type=="1") m_mReq["card_id"] = req.card_id;
  if(req.op_type=="1"&&!req.card_path.empty()) m_mReq["card_path"] = req.card_path;
  m_mReq["mobile_no"] = req.mobile_no;
  if(!req.memo.empty())  m_mReq["memo"] = req.memo;
  m_mReq["secu_ans1"] = req.secu_ans1;
  m_mReq["secu_ans2"] = req.secu_ans2;
  m_mReq["client_ip"] = req.ip;
  m_mReq["head_u"] = m_sOperId;
  m_mReq["ver"] = m_sVersion;
  m_mReq["sp_id"] = m_sSpId;
  m_mReq["request_type"] = szReqType;
  
  string sReq;
  if(m_mReq.GenString(sReq,"&","=") != 0)
  {
    m_sLastErrInfo = "pack error";
    return false;
  }
  
  //char * pszRes; int iRes;
  
  if(!SendRecv(m_mReq,m_mRes))
  {
    m_sLastErrInfo+=m_mRes["res_info"];
    return false;
  }
  //if(pszRes == NULL)
  //  return false;
    
  //m_mRes.SnapElement(pszRes);
  if(atoi(m_mRes["result"].c_str()) == 0)
  {
    crt=m_mRes["crt_crt"];
    return true;
  }
  m_sLastErrInfo=m_mRes["res_info"];
	/*
  if(atoi(m_mRes["result"].c_str()) == 1012)
  {
    m_mRes["retmsg"] = "NOTREG";
  }
	*/
  return false;
}


