#include "CMchSynQuery.h"
#include "qpay_encrypt_client.h"

const char * const cftapi::CMchSynQuery::szReqType = "140";

/*
# ������ѯ�ӿ�-���ʲ�ѯ  
140:0:0:2:syn_query_service:RD_Syn0QueryReq:RD_Syn0QueryReqSuc:RD_Syn0QueryReqFail
*/  
/*******************************************************
 *������sTransactionId ���׵��ţ�sMchSynRecords �̻�ͬ����Ϣ
 *�����0 Ϊ�ɹ�������Ϊ����  
 *���ܣ���ѯ���׵������̻���ͬ����Ϣ  
*******************************************************/
bool cftapi::CMchSynQuery::GetMchSynInfo(
	const std::string & sTransactionId,
	MCH_SYN_RECORD * sMchSynRecords)
{
	m_mReq["transaction_id"] = sTransactionId;
	m_mReq["request_type"] = szReqType;

	if(m_mReq["head_u"].empty())
		m_mReq["head_u"] = m_sOperId;
	if(m_mReq["ver"].empty())
		m_mReq["ver"] = m_sVersion;
	if(m_mReq["sp_id"].empty())
		m_mReq["sp_id"] = m_sSpId;

	char * pszRes;
	int iRes;

	if (!SendRecv(
		m_mReq,
		iRes))
	{
		return false;
	}

	string sReq;
	if(m_mReq.GenString(sReq,"&","=") != 0)
	{
		m_sLastErrInfo = "pack error";
		return false;
	}

	if(!CRelayComm::SendRecv(sReq.c_str(),sReq.size(),&pszRes,iRes))
		return false;
  
	if(pszRes == false)
		return false;
  
	int result=*(int *)pszRes;
	result=ntohl(result);
	if(result!=0)
	{
		char *pres_info=(char *)(pszRes+sizeof(int));
		m_sLastErrInfo=pres_info;
		return true;
	}

	int ret_num=*(int *)(pszRes+sizeof(int));
	if (ret_num != sizeof(MCH_SYN_RECORD))
	{
		char buf[100];
		snprintf(buf,sizeof(buf),"result pack length[%d] error should be[%d]",iRes,ret_num,sizeof(MCH_SYN_RECORD) );
		m_sLastErrInfo = buf;
		return false;
	}

//	sMchSynRecords = (MCH_SYN_RECORD *)(pszRes + 2*sizeof(int));
	memcpy(
		sMchSynRecords,
		pszRes + 2*sizeof(int),
		sizeof(MCH_SYN_RECORD));

	return true;
}

bool cftapi::CMchSynQuery::SendRecv(
	bsapi::CStringMap mReq,
	int &iRes)
{
	m_pszRes=0;
	if(mReq.GenString(m_strSendStr,"&","=") != 0)
	{
		m_sLastErrInfo = "pack error";
		return false;
	}

	char szDigit[128];
	memset(szDigit,0,sizeof(szDigit));
	GenerateDigest((char *)m_strSendStr.c_str(), szDigit, sizeof(szDigit)-1);
	m_strSendStr += "&abstract=";
	m_strSendStr += mReq.UrlEncode(szDigit);

	char szDest[1024*5];
	memset(szDest,0,sizeof(szDest));
  
	if(0 != Encrypt(m_sSpId.c_str(),
		(char*)m_strSendStr.c_str(),
		szDest,
		sizeof(szDest)-1))
		return false;
    
	bsapi::CStringMap t_mReq;
	t_mReq["ver"]	= mReq["ver"];
	t_mReq["head_u"]	= mReq["head_u"];
	t_mReq["sp_id"]	= mReq["sp_id"];

	if( m_sReqType.empty() )
		t_mReq["request_type"] = mReq["request_type"];
	else
		t_mReq["request_type"] = m_sReqType;

	t_mReq["request_text"] = szDest;

	m_EnSendStr = "";
	t_mReq.GenString(m_EnSendStr,"&","=");

	if(!CRelayComm::SendRecv(m_EnSendStr.c_str(),m_EnSendStr.size(),&m_pszRes,iRes))
		return false;

	if(m_pszRes == NULL)
		return false;

	return true;
}

const char* cftapi::CMchSynQuery::getResultStr()
{
	if (0 == *((int*)m_pszRes))
	{
		snprintf(m_vcRes,sizeof(m_vcRes),
			"retcode=%d&length=%d",
			*((int*)m_pszRes),
			*((int*)(m_pszRes+sizeof(int))));
	}
	else
	{
		snprintf(m_vcRes,sizeof(m_vcRes),
			"retcode=%d&retmsg=%s",
			*((int*)m_pszRes),
			m_pszRes+sizeof(int));
	}
	return m_vcRes;
}

const char* cftapi::CMchSynQuery::getRetcodeStr()
{
	snprintf(m_vcRetcode,sizeof(m_vcRetcode),
		"%d",
		*((int*)m_pszRes));
	return m_vcRetcode;
}

const char* cftapi::CMchSynQuery::getRetmsgStr()
{
	if (0 == *((int*)m_pszRes))
	{
		return "";
	}
	else
	{
		snprintf(m_vcRetmsg,sizeof(m_vcRetmsg),
			"%s",
			m_pszRes+sizeof(int));
		return m_vcRetmsg;
	}
}

