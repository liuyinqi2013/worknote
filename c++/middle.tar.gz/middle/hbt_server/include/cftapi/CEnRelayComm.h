#ifndef CEnRelayComm_H_HEADER_INCLUDED_BB1D1E7E
#define CEnRelayComm_H_HEADER_INCLUDED_BB1D1E7E

#include "CRelayComm.h"
#include "CStringMap.h"

//##ModelId=44E2AA7102BF
class cftapi::CEnRelayComm : public cftapi::CRelayComm
{
  public:
    //##ModelId=44E2B288032C
    bool SendRecv(bsapi::CStringMap mReq,bsapi::CStringMap & mRes);
   

};

#endif /* CEnRelayComm_H_HEADER_INCLUDED_BB1D1E7E */
