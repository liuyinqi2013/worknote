#include "CRelayCall.h"


//const char * const cftapi::CRelayCall::szReqType = "106";
//##ModelId=44E2C0C301B5
string cftapi::CRelayCall::GetValue(string key)
{
  return m_mRes[key];
}

bool cftapi::CRelayCall::Call(bsapi::CStringMap iodat,  int &iRes)
{
	bsapi::CStringMap::iterator iter=iodat.begin();
	while( iter!=iodat.end())
	{
		m_mReq[(*iter).first]=(*iter).second;
		iter++;
	}
	if( m_mReq["head_u"].empty())
		m_mReq["head_u"] = m_sOperId;
	if(m_mReq["ver"].empty())
  		m_mReq["ver"] = m_sVersion;
	if(m_mReq["sp_id"].empty())
  		m_mReq["sp_id"] = m_sSpId;
	

	 //if(!SendRecv(m_mReq,m_mRes))
	 if(!SendRecv(m_mReq, iRes) )
   		return false;

	 return true;
}

const char* cftapi::CRelayCall::getSendStr()
{

	return m_strSendStr.c_str();
}


const char* cftapi::CRelayCall::getResultStr()
{
	
	return m_pszRes?m_pszRes :"";
}

bool cftapi::CRelayCall::SendRecv(bsapi::CStringMap mReq, int &iRes)
{
	m_pszRes=0;
	if(mReq.GenString(m_strSendStr,"&","=") != 0)
  	{
    		m_sLastErrInfo = "pack error";
    		return false;
 	 }


	 if(!CRelayComm::SendRecv(m_strSendStr.c_str(),m_strSendStr.size(),&m_pszRes,iRes))
	 {	 	
	 	//if(m_sLastErrInfo.empty()) m_sLastErrInfo="unknown";
    		return false;
	 }
	 
	 return true;
}

