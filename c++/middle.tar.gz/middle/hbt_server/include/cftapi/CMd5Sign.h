#ifndef CMD5KEY_H_HEADER_INCLUDED_BB1D1E69
#define CMD5KEY_H_HEADER_INCLUDED_BB1D1E69

#include "CStringMap.h"
#include "CRelayComm.h"


//##ModelId=44E2B49A00DA
class cftapi::CMd5Sign : public cftapi::CRelayComm
{
  public:
    //##ModelId=44E2C659030D
    bool Verify(string uin,string str,string &sign);
    string Generate(string uin,string str);  
  private:    
    static const char * const szReqTypeVerify ;//815
    static const char * const szReqTypeCreate ;//816
    //##ModelId=44E2C070001F
    bsapi::CStringMap m_mReq;


    //##ModelId=44E2C0850213
    bsapi::CStringMap m_mRes;

};


#endif /* CMD5KEY_H_HEADER_INCLUDED_BB1D1E69 */
