#include "CIbsComm.h"


//##ModelId=44E2B288032C
bool cftapi::CIbsComm::SendRecv(const char * szReq,char ** pszRes,int &iRes)
{  
  int bRet = true;
  memset((char *)&m_stRes,0,sizeof(m_stRes));
  memset((char *)&m_stReq,0,sizeof(m_stReq));
  
  if((szReq == NULL)|| (strlen(szReq) > MAX_PACKET_SIZE) || (strlen(szReq) <= 0))    
  {
    m_sLastErrInfo = string("Invalid Request.");
    return false;
  }
  int iReqLen = sizeof(m_stReq.szLen) + strlen(szReq); 
  sprintf(m_stReq.szLen,"%06d",strlen(szReq));
  strncpy(m_stReq.szBuf,szReq,strlen(szReq));
  
  xyz::CTcpSocket *pstClt = NULL;
  try
  {
      pstClt = new xyz::CTcpSocket (m_sSvrIp.c_str(),m_iSvrPort);

      pstClt->Write ((char *)&m_stReq, iReqLen);
      
      int iResLen = 0,iCurLen =0,iResPackLen = -1;
      while(true)
      {
        iResLen += pstClt->Read (((char *)&m_stRes)+iResLen, sizeof(m_stRes)-iResLen,m_iSvrTmOut);
        
        if(iResLen <= iCurLen)
        {
          bRet = false;
          m_sLastErrInfo = string("communicate failed.");
          break;
        }
        if(iResLen >= sizeof(m_stRes.szLen))
        {
          if( iResPackLen == 0)
          {
            sscanf(m_stRes.szLen,"%06d",&iResPackLen);
            if((iResPackLen <= 0) || (iResPackLen > MAX_PACKET_SIZE))
            {
              bRet = false;
              break;
            }
          }
           
          if(iResLen >= iResPackLen + sizeof(m_stRes.szLen)) 
          {
            iRes = iResPackLen + sizeof(m_stRes.szLen); 
            *pszRes = m_stRes.szBuf;
            bRet = true;
            break;
          }
          else
          {
            bRet = false;
            m_sLastErrInfo = string("recv buffer  failed.");
            break;
          }
        }
        else
        {
          bRet = false;
          break;
        }
        
        iCurLen = iResLen;
      }
        

  }
  catch (xyz::CException & e)
  {
    m_sLastErrInfo = string("xyzsock exception:");
    m_sLastErrInfo +=e.ErrorMessage ();
    bRet = false;
  }
  if (pstClt != NULL)
  {
          pstClt->Close ();
    delete pstClt;
  }
  
  return bRet;
}


