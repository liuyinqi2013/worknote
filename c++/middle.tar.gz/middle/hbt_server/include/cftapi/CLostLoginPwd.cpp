#include "CLostLoginPwd.h"

/*
#ȡ�ص�½����
3006:0:0:1:emsus_getpwd_service:GETPWD_ALIAS:GETPWD_ALIAS_SUC:GETPWD_ALIAS_FAIL
3007:0:0:1:emsus_valikey_service:VALIKEY_ALIAS:VALIKEY_ALIAS_SUC:VALIKEY_ALIAS_FAIL
3008:0:0:1:emsus_updatepwd_service:UPDATEPWD_ALIAS:UPDATEPWD_ALIAS_SUC:UPDATEPWD_ALIAS_FAIL
#�޸ĵ�½����
3009:0:0:1:emsus_modifypwd_service:MODIPWD_ALIAS:MODIPWD_ALIAS_SUC:MODIPWD_ALIAS_FAIL
*/
const char * const cftapi::CLostLoginPwd::szReqType = "3006";
  
//##ModelId=44E2C0C301B5
string cftapi::CLostLoginPwd::GetValue(string key, bool bEncode)
{
	if(bEncode)
		return m_mRes.UrlEncode(m_mRes[key]);
	else
		return m_mRes[key];
}

//##ModelId=44E2C659030D
bool cftapi::CLostLoginPwd::GetAuthString(bsapi::CStringMap iodat )
{
  m_mReq["uin"] = iodat["uin"];
  m_mReq["email"] = iodat["uin"]; //��email�ʻ�����Ҫ�˲���
  m_mReq["qes1"] = iodat["qes1"];
  m_mReq["ans1"] = iodat["ans1"];
  m_mReq["qes2"] = iodat["qes2"];
  m_mReq["ans2"] = iodat["ans2"];
  m_mReq["client_ip"] = iodat["client_ip"];
  m_mReq["channel_id"] = iodat["channel_id"];
  
  m_mReq["head_u"] = m_sOperId;  
  m_mReq["ver"] = m_sVersion;
  m_mReq["sp_id"] = m_sSpId;
  m_mReq["request_type"] = "3006";
  
  
  if(!SendRecv(m_mReq,m_mRes))
    return false;
  
  return true;
}

bool cftapi::CLostLoginPwd::Update(bsapi::CStringMap iodat )
{
  m_mReq["uin"] = iodat["uin"];
  m_mReq["client_ip"] = iodat["client_ip"];
  m_mReq["channel_id"] = iodat["channel_id"];
  
  m_mReq["pkey"] = iodat["pkey"];
  m_mReq["qes1"] = iodat["qes1"];
  m_mReq["ans1"] = iodat["ans1"];
  m_mReq["qes2"] = iodat["qes2"];
  m_mReq["ans2"] = iodat["ans2"];
  m_mReq["login_pass_en"] = iodat["loginpwd"];
  m_mReq["login_pass_seed"] = iodat["loginpwd_seed"];
  m_mReq["login_pass_type"] = "2";
  
  m_mReq["update_type"] = iodat["update_type"];//1 email 2 mobile
  
  m_mReq["head_u"] = m_sOperId;  
  m_mReq["ver"] = m_sVersion;
  m_mReq["sp_id"] = m_sSpId;
  m_mReq["request_type"] = "3008";
  
  
  if(!SendRecv(m_mReq,m_mRes))
    return false;
  
  return true;
}

bool cftapi::CLostLoginPwd::ValidAuthString(bsapi::CStringMap iodat )
{
  m_mReq["uin"] = iodat["uin"];
  m_mReq["pkey"] = iodat["pkey"];
  m_mReq["client_ip"] = iodat["client_ip"];
  m_mReq["channel_id"] = iodat["channel_id"];
  
  
  m_mReq["head_u"] = m_sOperId;  
  m_mReq["ver"] = m_sVersion;
  m_mReq["sp_id"] = m_sSpId;
  m_mReq["request_type"] = "3007";
  
  
  if(!SendRecv(m_mReq,m_mRes))
    return false;
  
  return true;
}
