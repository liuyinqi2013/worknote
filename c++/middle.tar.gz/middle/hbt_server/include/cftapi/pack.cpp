#ifndef _PACK_C_
#define _PACK_C_

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <signal.h>
#include <unistd.h>
#include <stdarg.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <netinet/in.h>

void Pack_SetWordA(void *p, void *w)
{
	char *p1, *p2;

	p1 = (char *)p;
	p2 = (char *)w;

	memcpy(p1, p2, 2);
}

void Pack_SetDWordA(void *p, void *dw)
{
	char *p1, *p2;

	p1 = (char *)p;
	p2 = (char *)dw;
	
	memcpy(p1, p2, 4);
}

void Pack_Make_OctetString(char **p, char *Content,int iLen)
{
	memcpy(*p, Content,iLen);
	*p += iLen;	
}

void Pack_Make_CString(char **p, char *Content)
{
	strcpy(*p, Content);
	*p += strlen(Content) + 1;	
}

void Pack_Make_CString2(char **p, char *Content,int iMaxLen)
{
	int iStrLen;
	
	iStrLen = strlen(Content);
	
	if (iStrLen < iMaxLen)
	{
		strcpy(*p, Content);
		*p += iStrLen + 1;	
	}
	else
	{
		strncpy(*p, Content,iMaxLen-1);
		*p += iMaxLen-1;
		(*p)[0] = 0;
		*p += 1;
	}		
}

void Pack_Make_Int(char **p, int i)
{
	int ii;
	
	ii = htonl(i);
	Pack_SetDWordA(*p, &ii);
	*p += 4;
}

void Pack_Make_ShortInt(char **p, short i)
{
	short ii;
	
	ii = htons(i);
	Pack_SetWordA(*p, &ii);
	*p += 2;
}

void Pack_Make_Byte(char **p, int i)
{
       **p = (unsigned char)i;	
       (*p)++;
}

int  Pack_Get_OctetString(char **p, char *Content, int iLen,char *endp)
{
	
	if (*p + iLen-1 > endp) return -1;
	
	memcpy(Content, *p, iLen);
	
	*p += iLen;
	
	return 0;
}

int Pack_Get_CString(char **p, char *Content, char *endp)
{
	char *oldp;
	
	oldp = *p;
	while (**p)
	{
		(*p)++;
		 if (*p > endp)	return -1;
	}

	(*p)++;
	memcpy(Content, oldp, *p - oldp);

	return 0;
}

int  Pack_Get_CString2(char **p, char *Content,char *endp,int iMaxLen)
{
	char *oldp;
	
	oldp = *p;
	while (**p)
	{
		(*p)++;
		 if (*p > endp)	return -1;
	}

	(*p)++;
	
	if ((*p - oldp) > iMaxLen) return -1;
	
	memcpy(Content, oldp, *p - oldp);

	return 0;
}

int Pack_Get_Int(char **p, int *i, char *endp)
{
	if (*p + 3 > endp) return -1;
	Pack_SetDWordA(i, *p);
	*i = ntohl(*i);
	*p += 4;
	
	return 0;
}

int Pack_Get_ShortInt(char **p, short *i, char *endp)
{
	if (*p + 1 > endp) return -1;
	Pack_SetWordA(i, *p);
	*i = ntohs(*i);
	*p += 2;
	
	return 0;
}

int Pack_Get_Byte(char **p, char *i, char *endp)
{
	if (*p > endp) return -1;
	*i = (unsigned char) **p;
	(*p) ++;
	
	return 0;
}

#endif
