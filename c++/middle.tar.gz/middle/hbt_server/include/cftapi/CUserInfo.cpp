#include "CUserInfo.h"


const char * const cftapi::CUserInfo::szReqType = "101";
  
//##ModelId=44E2C0C301B5
string cftapi::CUserInfo::GetValue(string key)
{
  return m_mRes[key];
}

//##ModelId=44E2C659030D
bool cftapi::CUserInfo::GetInfo(string uin,string uip)
{
  m_mReq["uin"] = uin;
  m_mReq["u_login_ip"] = uip;
  m_mReq["head_u"] = m_sOperId;
  m_mReq["ver"] = m_sVersion;
  m_mReq["sp_id"] = m_sSpId;
  m_mReq["request_type"] = szReqType;
  
  string sReq;
  if(m_mReq.GenString(sReq,"&","=") != 0)
  {
    m_sLastErrInfo = "pack error";
    return false;
  }
  
  char * pszRes; int iRes;
  
  if(!SendRecv(sReq.c_str(),sReq.size(),&pszRes,iRes))
    return false;
  
  if(pszRes == NULL)
    return false;
    
  m_mRes.SnapElement(pszRes);
  if(atoi(m_mRes["result"].c_str()) == 0)
  {
    return true;
  }
  return false;
}


