#ifndef CCFTCOMM_H_HEADER_INCLUDED_BB1D0E38
#define CCFTCOMM_H_HEADER_INCLUDED_BB1D0E38

#include "cftapi_namespace.h"
#include "socket.h"
#include "exception.h"

//##ModelId=44DC4D4700CB
class cftapi::CCftComm
{
  public:
    //##ModelId=44DC4F410128
    virtual void Init(string sIp, int iPort = 0, int iTmOut = 5, string sEleSep="&", string sNvSep="=", int iTmOutConn=3);

    //##ModelId=44DC4F410138
    virtual string GetLastError() const;

virtual ~CCftComm(){};
     CCftComm(){};
  protected:
    //##ModelId=44DC4F510399
    string m_sSvrIp;

    //##ModelId=44DC4F51039A
    int m_iSvrPort;

    //##ModelId=44DC4F5103A9
    string m_sLastErrInfo;

    //##ModelId=44E2B2F7009C
    int m_iSvrTmOut;
    int m_iSvrTmOutConn;
    
    string m_sEleSep;
    string m_sNvSep;

};



#endif /* CCFTCOMM_H_HEADER_INCLUDED_BB1D0E38 */
