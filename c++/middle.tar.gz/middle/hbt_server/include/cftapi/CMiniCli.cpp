#include "CMiniCli.h"

#include "CStringArray.h"
/*
ѯ��
Ver=2&ServiceCode=PPRC&Spid=ZTC&PayChannelSubId=106&Uin=7457222&PayAmt=100&SerialNo=123&UserIP=192.168.0.1&Comm1=QQACCT_SAVE&Comm2=1&Comm3=10000&Comm4=1
*/

int cftapi::CMiniCli::Call()
{
	m_sRsp.clear();
	m_sReq = m_sTid;
	if(m_sReq != "")
	{
	    m_sReq += '&';
	}
	if(m_mReq.GenString(m_sReq,"&","=") != 0)
  {
    m_sLastErrInfo = "pack error";
    return 3;
  }
	if(SendRecv(m_sReq,m_sRsp) != 0)
		return 2;
	
	m_mRes.clear();
	m_mRes.SnapElement(m_sRsp);
	if(m_mRes["retcode"][0]=='0' && atoi(m_mRes["retcode"].c_str()) == 0)
	{
		return 0;
	}

	m_sLastErrInfo = m_sRsp;	
	return -2;
}

int cftapi::CMiniCli::Call(const string &sTid, bsapi::CStringMap &iodat)
{
	m_sTid = sTid;
	m_mReq = iodat;

	int iRet=Call();
	
	bsapi::CStringMap::iterator pos;
	for(pos=m_mRes.begin(); pos!=m_mRes.end(); pos++)
	{
		iodat[pos->first]=pos->second;
	}

	return iRet;
}

bool cftapi::CMiniCli::AddNewCftUser(bsapi::CStringMap &iodat)
{
  int iRetCode = 0;
  
  m_sTid = "00002001";
  
  m_mReq.clear();
  m_mReq["qq"] = iodat["qq"];
  m_mReq["flag"] = iodat["flag"];
  m_mReq["number"] = "0";
  m_mReq["voucher"] = iodat["voucher"];
  
  if(!iodat["setflag"].empty())
    m_mReq["setflag"] = iodat["setflag"];
 
  
  if(Call()!= 0)
  {
    iodat["retcode"] = m_mRes["retcode"];
    iodat["retmsg"] = m_mRes["retmsg"];
    return false;
  }
  else
  {
    return true;
  }
}
bool cftapi::CMiniCli::AddNewSpUser(bsapi::CStringMap &iodat)
{
  int iRetCode = 0;
  
  m_sTid = "00003002";
  
  m_mReq.clear();
  m_mReq["qq"] = iodat["qq"];
  m_mReq["spid"] = iodat["spid"];
  m_mReq["email"] = iodat["email"];
  m_mReq["telecode"] = iodat["telecode"];
  m_mReq["addr"] = iodat["addr"];
  m_mReq["truename"] = iodat["truename"];  
 
  
  if(Call()!= 0)
  {
    iodat["retcode"] = m_mRes["retcode"];
    iodat["retmsg"] = m_mRes["retmsg"];
    return false;
  }
  else
  {
    return true;
  }
}
bool cftapi::CMiniCli::AddZtcTransLog(bsapi::CStringMap &iodat)
{
  int iRetCode = 0;
  
  m_sTid = "00001003";
  
  m_mReq.clear();
  m_mReq["uvno"] = iodat["uvno"];
  m_mReq["cft_tid"] = iodat["cft_tid"];
  m_mReq["user"] = iodat["user"];
  m_mReq["payer"] = iodat["payer"];
  m_mReq["saler"] = iodat["saler"];
  m_mReq["price"] = iodat["price"];
  m_mReq["status"] = iodat["status"];
  m_mReq["remark"] = iodat["remark"];
 
  
  if(Call()!= 0)
  {
    iodat["retcode"] = m_mRes["retcode"];
    iodat["retmsg"] = m_mRes["retmsg"];
    return false;
  }
  else
  {
    return true;
  }
}
bool cftapi::CMiniCli::UptZtcTransLog(bsapi::CStringMap &iodat)
{
  //uvno=12345678&status=1
  int iRetCode = 0;
  
  m_sTid = "00001004";
  
  m_mReq.clear();
  m_mReq["uvno"] = iodat["uvno"];
  m_mReq["status"] = iodat["status"];
 
  
  if(Call()!= 0)
  {
    iodat["retcode"] = m_mRes["retcode"];
    iodat["retmsg"] = m_mRes["retmsg"];
    return false;
  }
  else
  {
    return true;
  }
}
//##ModelId=44E968F3035B
bool cftapi::CMiniCli::GetZtcUserInfo(bsapi::CStringMap &iodat)
{
  int iRetCode = 0;
  
  m_sTid = "00001001";
  
  m_mReq.clear();
  m_mReq["u"] = iodat["u"];
 
  
  if(Call()!= 0)
  {
    iodat["retcode"] = m_mRes["retcode"];
    iodat["retmsg"] = m_mRes["retmsg"];
    return false;
  }
  else
  {
    iodat["true_name"] = m_mRes["contactor"];
    	iodat["user_mobile"] = m_mRes["mobile"];
    	iodat["user_company"] = m_mRes["company"];
    	iodat["user_phone"] = m_mRes["phone"];
    	iodat["user_zip"] = m_mRes["zipcode"];
    	iodat["user_address"] = m_mRes["address"];
    	iodat["user_ip"] = m_mRes["accessip"];
    return true;
  }
    
}

bool cftapi::CMiniCli::RegsterActUser(bsapi::CStringMap &iodat)
{
	int iRetCode = 0;
  	m_mReq.clear();
	
  	m_sTid = "00002190";
  	m_mReq["user"]= iodat["user"];
	m_mReq["clientIp"]= iodat["clientIp"];
	m_mReq["flag"]= iodat["flag"];
	
  	

	 if(Call()!= 0)
  {
    iodat["retcode"] = m_mRes["retcode"];
    iodat["retmsg"] = m_mRes["retmsg"];
    return false;
  }
  else
  {
    	iodat["status"] = m_mRes["status"];   
	iodat["pay_user"] = m_mRes["pay_user"];   
    return true;
  }
	
}

bool cftapi::CMiniCli::QueryActStatus(bsapi::CStringMap &iodat)
{
 	int iRetCode = 0;
	m_mReq.clear();
	
  
  	m_sTid = "00002191";
  	m_mReq["user"]= iodat["user"];
	m_mReq["clientIp"]= iodat["clientIp"];
	m_mReq["flag"] 	  = iodat["flag"] ; 	

	 if(Call()!= 0)
  {
    iodat["retcode"] = m_mRes["retcode"];
    iodat["retmsg"] = m_mRes["retmsg"];
    return false;
  }
  else
  {
  	iodat["status"] = m_mRes["status"]; 
	iodat["pay_user"] = m_mRes["pay_user"]; 
	iodat["money"] = m_mRes["money"]; 
	iodat["trans_id"] = m_mRes["trans_id"]; 

    return true;
  }
  
}


bool cftapi::CMiniCli::UpdateActStatus(bsapi::CStringMap &iodat)
{
 	int iRetCode = 0;
	m_mReq.clear();
	
  
  	m_sTid = "00002192";
  	m_mReq["user"]= iodat["user"];
	m_mReq["clientIp"]= iodat["clientIp"];
	  	

	 if(Call()!= 0)
  {
    iodat["retcode"] = m_mRes["retcode"];
    iodat["retmsg"] = m_mRes["retmsg"];
    return false;
  }
  else
  {
    
    return true;
  }
  
}

bool cftapi::CMiniCli::InqIndex(bsapi::CStringMap &iodat)
{
  int iRetCode = 0;

  m_sTid = "00000000";

  m_mReq.clear();
  m_mReq["indtype"] = iodat["indtype"];
  m_mReq["indfld"] = iodat["indfld"];


  if(Call()!= 0)
  {
    iodat["retcode"] = m_mRes["retcode"];
    iodat["retmsg"] = m_mRes["retmsg"];
    return false;
  }
  else
  {
    iodat["retcode"] = m_mRes["retcode"];
    iodat["retmsg"] = m_mRes["retmsg"];
    iodat["count"] = m_mRes["count"];
    return true;
  }

}


bool cftapi::CMiniCli::AddIndex(bsapi::CStringMap &iodat)
{
  int iRetCode = 0;

  m_sTid = "00000002";

  m_mReq.clear();
  m_mReq["prifld"] = iodat["prifld"];
  m_mReq["indtype"] = iodat["indtype"];
  m_mReq["indfld"] = iodat["indfld"];


  if(Call()!= 0)
  {
    iodat["retcode"] = m_mRes["retcode"];
    iodat["retmsg"] = m_mRes["retmsg"];
    return false;
  }
  else
  {
    iodat["retcode"] = m_mRes["retcode"];
    iodat["retmsg"] = m_mRes["retmsg"];
    return true;
  }

}

bool cftapi::CMiniCli::DelIndex(bsapi::CStringMap &iodat)
{
  int iRetCode = 0;

  m_sTid = "00000003";

  m_mReq.clear();
  m_mReq["prifld"] = iodat["prifld"];
  m_mReq["indtype"] = iodat["indtype"];
  m_mReq["indfld"] = iodat["indfld"];


  if(Call()!= 0)
  {
    iodat["retcode"] = m_mRes["retcode"];
    iodat["retmsg"] = m_mRes["retmsg"];
    return false;
  }
  else
  {
    iodat["retcode"] = m_mRes["retcode"];
    iodat["retmsg"] = m_mRes["retmsg"];
    return true;
  }

}


bool cftapi::CMiniCli::CheckEleLimit(bsapi::CStringMap &iodat)
{
	bsapi::CStringArray arSec, arNod;
	bsapi::CStringMap mapReq;

	arSec.SetCommaText (iodat["index_rule"], "|");

	for (int i = 0; i < (int) arSec.size (); i++)
	{
		arNod.SetCommaText (arSec[i], ":");
		if (arNod.size () == 3)
		{
			if (iodat[arNod[1]].empty ())
				continue;
			mapReq.clear();

			mapReq["indtype"] = arNod[0];
  			mapReq["indfld"] = iodat[arNod[1]];
			
			if (InqIndex(mapReq)
			    && (atoi(mapReq["count"].c_str()) >= atoi (arNod[2].c_str ())))
			{

				iodat["err_type"]=arNod[0];
				return false;
			}

		}
		arNod.clear ();
	}

	return true;
}

bool cftapi::CMiniCli::AddEleIndex(bsapi::CStringMap &iodat)
{
	bsapi::CStringArray arSec, arNod;
	bsapi::CStringMap mapReq;

	arSec.SetCommaText (iodat["index_rule"], "|");

	for (int i = 0; i < (int) arSec.size (); i++)
	{
		arNod.SetCommaText (arSec[i], ":");
		if (arNod.size () == 3)
		{
			if (iodat[arNod[1]].empty ())
				continue;
			mapReq.clear();

			mapReq["indtype"] = arNod[0];
  			mapReq["indfld"] = iodat[arNod[1]];
  			mapReq["prifld"] = iodat["prifld"];
			
			if (!AddIndex(mapReq))
			{

				iodat["err_type"]=arNod[0];
				return false;
			}

		}
		arNod.clear ();
	}

	return true;
}
const char* cftapi::CMiniCli::getSendStr()
{
	return m_sReq.c_str();
}
const char* cftapi::CMiniCli::getResultStr()
{
	return m_sRsp.c_str();
}
