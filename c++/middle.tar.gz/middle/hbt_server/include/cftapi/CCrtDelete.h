#ifndef CCrtDelete_H_HEADER_INCLUDED_BB1D1E69
#define CCrtDelete_H_HEADER_INCLUDED_BB1D1E69

#include "CStringMap.h"
#include "CRelayComm.h"


//##ModelId=44E2B49A00DA
class cftapi::CCrtDelete : public cftapi::CRelayComm
{
  public:
    string GetValue(string key, bool bEncode=true);
    //##ModelId=44E2C0C301B5
    bool CrtDelete(
        // �û��ڲ�ID
        const string& uid,
        // ֤�����к�
        const string &cn, 
        // ������IP
        const string& uip);

  private:    
    static const char * const szReqType ;
    //##ModelId=44E2C070001F
    bsapi::CStringMap m_mReq;


    //##ModelId=44E2C0850213
    bsapi::CStringMap m_mRes;

};


#endif /* CCrtDelete_H_HEADER_INCLUDED_BB1D1E69 */
