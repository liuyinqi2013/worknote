#ifndef CRELAYCALL_H_HEADER_INCLUDED_BB1D1E69
#define CRELAYCALL_H_HEADER_INCLUDED_BB1D1E69

#include "CStringMap.h"
#include "CRelayComm.h"


//##ModelId=44E2B49A00DA
class cftapi::CRelayCall : public cftapi::CRelayComm
{
  public:
    //##ModelId=44E2C659030D
    string GetValue(string key);
    bool Call(bsapi::CStringMap iodat, int &iRes);
   
   
 //��ȡ�����ַ���������ǰ
    const char* getSendStr();
   //���ؽ��
    const char* getResultStr();
   
  protected:    
    static const char * const szReqType ;
    //##ModelId=44E2C070001F
    bsapi::CStringMap m_mReq;

    //##ModelId=44E2C0850213
    bsapi::CStringMap m_mRes;
        //
    char *m_pszRes;
    string m_strSendStr;
   
   virtual bool SendRecv(bsapi::CStringMap mReq, int &iRes);
   
};


#endif /* CFundList_H_HEADER_INCLUDED_BB1D1E69 */
