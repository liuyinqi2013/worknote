#include "CPayMoney.h"
#include "qpay_encrypt_client.h"

/*
# ����ȯ��������
83:0:0:1:gwq_userpub_service:RE_VoucherIssue:RE_VoucherIssueSuc:RE_VoucherIssueFail
*/
const char * const cftapi::CPayMoney::szReqType = "9";
  
//##ModelId=44E2C0C301B5
string cftapi::CPayMoney::GetValue(string key, bool bEncode)
{
	if(bEncode)
		return m_mRes.UrlEncode(m_mRes[key]);
	else
		return m_mRes[key];
}

//##ModelId=44E2C659030D
bool cftapi::CPayMoney::Pay(bsapi::CStringMap iodat )
{

  m_mReq["uin"] = iodat["uin"];
  m_mReq["transaction_id"] = iodat["transaction_id"];
  m_mReq["accept_uin"] = iodat["accept_uin"];
  m_mReq["email"] = iodat["email"];
  m_mReq["merchan_name"] = iodat["merchan_name"];
  m_mReq["total_fee"] = iodat["total_fee"];
  m_mReq["pay_type"] = iodat["pay_type"];
  m_mReq["merchan_url"] = iodat["merchan_url"];
  m_mReq["remark"] = iodat["remark"];
  m_mReq["pay_passwd"] = iodat["pay_passwd"];
  m_mReq["client_ip"] = iodat["client_ip"];
  
  m_mReq["head_u"] = m_sOperId;  
  m_mReq["ver"] = m_sVersion;
  m_mReq["sp_id"] = m_sSpId;
  m_mReq["request_type"] = "9";
  
  
  if(!SendRecv(m_mReq,m_mRes))
    return false;
  
  return true;
}

bool cftapi::CPayMoney::Confirm(bsapi::CStringMap iodat )
{
m_mReq.clear();
  m_mReq["uin"] = iodat["uin"];
  m_mReq["transaction_id"] = iodat["transaction_id"];
  m_mReq["flag"] = iodat["flag"];
  m_mReq["client_ip"] = iodat["client_ip"];
  
  m_mReq["head_u"] = m_sOperId;  
  m_mReq["ver"] = m_sVersion;
  m_mReq["sp_id"] = m_sSpId;
  m_mReq["request_type"] = "10";
  
  
  if(!SendRecv(m_mReq,m_mRes))
    return false;
  
  return true;
}

bool cftapi::CPayMoney::SendRecv(bsapi::CStringMap mReq,bsapi::CStringMap & mRes)
{
  string sReq;
 if(mReq["request_type"]=="9")
{
	sReq="uin=" + mReq["uin"] +"&transaction_id=" + mReq["transaction_id"] +"&accept_uin=" + mReq["accept_uin"] +"&email=" + mReq["email"] +"&merchan_name=" + mReq["merchan_name"] +"&total_fee=" + mReq["total_fee"] +"&pay_type=" + mReq["pay_type"] +"&merchan_url=" + mReq["merchan_url"] +"&remark=" + mReq["remark"] +"&pay_passwd=" + mReq["pay_passwd"] +"&client_ip=" + mReq["client_ip"] +"&head_u=" + mReq["head_u"] +"&ver=" + mReq["ver"] +"&sp_id=" + mReq["sp_id"] +"&request_type=" + mReq["request_type"]	;
}
else
{
  if(mReq.GenString(sReq,"&","=") != 0)
  {
    m_sLastErrInfo = "pack error";
    return false;
  }
}
//   cout << sReq <<endl;
  //
  char szDigit[128];
  memset(szDigit,0,sizeof(szDigit));
  GenerateDigest((char *)sReq.c_str(), szDigit, sizeof(szDigit)-1);
  sReq += "&abstract=";
  sReq += mReq.UrlEncode(szDigit);

//   cout << sReq <<endl;
  //
  char szDest[1024*5];
  memset(szDest,0,sizeof(szDest));

  if(Encrypt(m_sSpId.c_str(),(char *)sReq.c_str(),szDest,sizeof(szDest)-1) != 0)
    return false;

    bsapi::CStringMap t_mReq;
  t_mReq["ver"] = mReq["ver"];
  t_mReq["head_u"] = mReq["head_u"];
  t_mReq["sp_id"] = mReq["sp_id"];
  t_mReq["request_type"] = mReq["request_type"];
  //t_mReq["request_text"] = mReq.UrlEncode(szDest);
  t_mReq["request_text"] = szDest;

  sReq = "";
  t_mReq.GenString(sReq,"&","=");

  char * pszRes ; int iRes;

  if(!CRelayComm::SendRecv(sReq.c_str(),sReq.size(),&pszRes,iRes))
    return false;

  if(pszRes == NULL)
    return false;

  mRes.SnapElement(pszRes);
  if(atoi(mRes["result"].c_str()) == 0)
  {
    return true;
  }
  return false;
}
