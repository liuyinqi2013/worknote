// =====================================================================================
//       Filename:  CCreditQueryInfo.cpp
// 
//    Description:  ���ÿ��������: ���ÿ������ѯ��Ҫȥǰ��
// 
//        Version:  
//        Created:  
//       Revision:  
// 
//         Author:  felixhuang(felixhuang@tenpay.com)
//      Copyright:  Copyright (c) 2010, Tencent Co.Ltd
// 
// =====================================================================================
#include "CCreditQueryInfo.h"
 
string cftapi::CCreditQueryInfo::GetValue(string key, bool bEncode)
{
	if(bEncode)
		return m_mRes.UrlEncode(m_mRes[key]);
	else
		return m_mRes[key];
}

bool cftapi::CCreditQueryInfo::QueryCarde(bsapi::CStringMap iodat )
{
	m_mReq["uin"] = iodat["uin"];
	m_mReq["bank_type"] = iodat["bank_type"];
	m_mReq["creditcard_id"] = iodat["creditcard_id"];
	m_mReq["creditcard_id_md5"] = iodat["creditcard_id_md5"];
	m_mReq["history_flag"] = "1";
	m_mReq["save_flag"] = "0";
	m_mReq["client_ip"] = iodat["client_ip"];
	m_mReq["server_ip"] = iodat["server_ip"];

	m_mReq["head_u"] = iodat["head_u"];  
	m_mReq["ver"] = iodat["ver"];//�汾
	m_mReq["sp_id"] = iodat["sp_id"];//
	m_mReq["request_type"] = iodat["request_type"];

	if(!SendRecv(m_mReq,m_mRes))
		return false;

	return true;
}

bool cftapi::CCreditQueryInfo::RepayBank(bsapi::CStringMap iodat )
{
	m_mReq["total_fee"] = iodat["total_fee"];
	m_mReq["fee_type"] = iodat["fee_type"];
	m_mReq["vali_type"] = iodat["vali_type"];
	m_mReq["en_buf"] = iodat["en_buf"];
	m_mReq["time_stamp"] = iodat["time_stamp"];
	m_mReq["b_true_name"] = iodat["b_true_name"];
	m_mReq["transaction_id"] = iodat["transaction_id"];
	m_mReq["channel_id"] = iodat["channel_id"];
	m_mReq["bank_name"] = iodat["bank_name"];
	m_mReq["bank_area"] = iodat["bank_area"];
	m_mReq["bank_city"] = iodat["bank_city"];
	m_mReq["bank_type"] = iodat["bank_type"];


	m_mReq["uin"] = iodat["uin"];
	m_mReq["bank_type"] = iodat["bank_type"];
	m_mReq["bank_id"] = iodat["bank_id"];
	m_mReq["creditcard_id_md5"] = iodat["creditcard_id_md5"];
	m_mReq["login_ip"] = iodat["login_ip"];
	m_mReq["server_ip"] = iodat["server_ip"];

	m_mReq["head_u"] = iodat["uin"];  
	m_mReq["ver"] = iodat["ver"];//�汾
	m_mReq["sp_id"] = iodat["sp_id"];//
	m_mReq["request_type"] = iodat["request_type"];

	if(!SendRecv(m_mReq,m_mRes))
		return false;

	return true;
	/*
	string sReq;
	if(m_mReq.GenString(sReq,"&","=") != 0)
	{
		m_sLastErrInfo = "pack error";
		return false;
	}

	char * pszRes; int iRes;

	if(!CRelayComm::SendRecv(sReq.c_str(),sReq.size(),&pszRes,iRes))
		return false;
	
	if(pszRes == NULL)
		return false;

	m_mRes.SnapElement(pszRes);
	if(atoi(m_mRes["result"].c_str()) == 0)
	{
		return true;
	}
*/
	return false;
}

bool cftapi::CCreditQueryInfo::CheckInfoByPA(bsapi::CStringMap iodat )
{
	m_mReq["flag"] = iodat["flag"]; //���
	m_mReq["b_true_name"] = iodat["b_true_name"]; //����
	m_mReq["bank_type"] = iodat["bank_type"]; //��������
	m_mReq["channel_id"] = iodat["channel_id"]; //����ID
	m_mReq["fee_type"] = iodat["fee_type"]; //����
	m_mReq["bank_id"] = iodat["bank_id"]; //����
	m_mReq["login_ip"] = iodat["login_ip"];  //�û�ip
	m_mReq["server_ip"] = iodat["server_ip"]; //���÷�����ip 

    m_mReq["uin"] = iodat["uin"];
    m_mReq["bill_no"] = iodat["bill_no"];
	m_mReq["head_u"] = iodat["head_u"];  
	m_mReq["ver"] = iodat["ver"];//�汾
	m_mReq["sp_id"] = iodat["sp_id"];//
	m_mReq["request_type"] = iodat["request_type"];

    if(!SendRecv(m_mReq,m_mRes))
        return false;

    return true;
/*
	string sReq;
	if(m_mReq.GenString(sReq,"&","=") != 0)
	{
		m_sLastErrInfo = "pack error";
		return false;
	}

	char * pszRes; int iRes;

	//if(!SendRecv(sReq.c_str(),sReq.size(),&pszRes,iRes))
	if(!CRelayComm::SendRecv(sReq.c_str(),sReq.size(),&pszRes,iRes))
		return false;

	if(pszRes == NULL)
	return false;

	m_mRes.SnapElement(pszRes);
	if(atoi(m_mRes["result"].c_str()) == 0)
	{
		return true;
	}

	return false;*/
}
