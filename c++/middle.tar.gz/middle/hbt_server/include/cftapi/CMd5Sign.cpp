#include "CMd5Sign.h"

const char * const cftapi::CMd5Sign::szReqTypeVerify = "815";
const char * const cftapi::CMd5Sign::szReqTypeCreate = "816";
  


string cftapi::CMd5Sign::Generate(string uin,string str)
{
  m_mReq["uin"] = uin;
  m_mReq["sp_str"] = str;
  
  m_mReq["head_u"] = m_sOperId;
  m_mReq["ver"] = m_sVersion;
  m_mReq["sp_id"] = m_sSpId;
  m_mReq["request_type"] = szReqTypeCreate;
  
  string sReq;
  if(m_mReq.GenString(sReq,"&","=") != 0)
  {
    m_sLastErrInfo = "pack error";
    return "";
  }
  
  char * pszRes; int iRes;
  
  if(!SendRecv(sReq.c_str(),sReq.size(),&pszRes,iRes))
    return "";
  
  if(pszRes == NULL)
    return "";
    
  m_mRes.SnapElement(pszRes);
  if(atoi(m_mRes["result"].c_str()) == 0)
  {
    return m_mRes["sp_md5"];
  }
  
  return "";
}

//##ModelId=44E2C659030D
bool cftapi::CMd5Sign::Verify(string uin,string str,string &sign)
{
  m_mReq["uin"] = uin;
  m_mReq["sp_str"] = str;
  m_mReq["sp_md5"] = sign;
  
  m_mReq["head_u"] = m_sOperId;
  m_mReq["ver"] = m_sVersion;
  m_mReq["sp_id"] = m_sSpId;
  m_mReq["request_type"] = szReqTypeVerify;
  
  string sReq;
  if(m_mReq.GenString(sReq,"&","=") != 0)
  {
    m_sLastErrInfo = "pack error";
    return false;
  }
  
  char * pszRes; int iRes;
  
  if(!SendRecv(sReq.c_str(),sReq.size(),&pszRes,iRes))
    return false;
  
  if(pszRes == NULL)
    return false;
    
  m_mRes.SnapElement(pszRes);
  if(atoi(m_mRes["result"].c_str()) == 0)
  {
    return true;
  }
  
  return false;
}


