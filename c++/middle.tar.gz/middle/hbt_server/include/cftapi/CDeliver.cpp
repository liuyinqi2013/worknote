#include "CDeliver.h"

#include "CStringArray.h"
/*
ѯ��
Ver=2&ServiceCode=PPRC&Spid=ZTC&PayChannelSubId=106&Uin=7457222&PayAmt=100&SerialNo=123&UserIP=192.168.0.1&Comm1=QQACCT_SAVE&Comm2=1&Comm3=10000&Comm4=1
*/

int cftapi::CDeliver::Prepare(string ver,string spid,string bankid)
{
  sVer = ver;
  sSpid = spid;
  sPayChannelSubId = bankid;
  
  return 0;
}  
//##ModelId=44E968F3035B
int cftapi::CDeliver::GetPrice(bsapi::CStringMap &iodat)
{
  int iRetCode = 0;
  
  m_mReq.clear();
  m_mReq["Ver"] = sVer;
  m_mReq["ServiceCode"] = "PPRC";
  m_mReq["Spid"] = sSpid;
  m_mReq["PayChannelSubId"] = sPayChannelSubId;
  
  m_mReq["Uin"] = iodat["in_acct"];
  m_mReq["PayAmt"] = iodat["num"];
  m_mReq["SerialNo"] = iodat["tran_seq"];
  m_mReq["UserIP"] = iodat["ENV_ClientIp"];
  m_mReq["Comm2"] = "";
  switch(atoi(iodat["sell_type"].c_str()))
  {
  case 1: //Q�ҳ�ֵ
    m_mReq["Comm1"] = "QQACCT_SAVE";break;
  case 11://��Ϸ����
    m_mReq["Comm1"] = "XXQGAME";break;
  case 12://����
    m_mReq["Comm1"] = "XXQQF";break;
  case 13://����
    m_mReq["Comm1"] = "XXJZGW";break;
  case 5://��Ա
    m_mReq["Comm1"] = "LTMCLUB";break;
  case 14://Q��
    m_mReq["Comm1"] = "QQPOINT";
    m_mReq["Comm2"] = iodat["sell_sub_type"];    
    break;
  default:
    m_sLastErrInfo = string("��֧�ִ˲�Ʒ���͡�");
    return 1;break;    
  }
  m_mReq["Comm3"] = iodat["mch_id"];
  m_mReq["Comm4"] = "";
 
  string sReq;
  if(m_mReq.GenString(sReq,"&","=") != 0)
  {
    m_sLastErrInfo = "pack error";
    return 3;
  }
  
  string sRes;
  if(SendRecv(sReq,sRes) != 0)
    return 2;
    
  m_mRes.SnapElement(sRes);
  if((atoi(m_mRes["Result"].c_str()) == 0) && (atoi(m_mRes["ErrCode"].c_str()) == 0))
  {
    bsapi::CStringArray aTmp;
    aTmp.SetCommaText(m_mRes["ErrMsg"],"|");
    if(aTmp.size() != 2)
      return 5;
    iodat["price"] = aTmp[0]; 
    iodat["bargainor_id"] = aTmp[1]; 
    return 0;
  }
  iodat["retcode"] = m_mRes["ErrCode"];
  iodat["retmsg"] = m_mRes["ErrMsg"];
  return 4;
}

//##ModelId=44E968FF029F
int cftapi::CDeliver::FillQQAmt(bsapi::CStringMap &iodat)
{
  int iRetCode = 0;
  
  m_mReq.clear();
  m_mReq["Ver"] = sVer;
  m_mReq["Spid"] = sSpid;
  m_mReq["PayChannelSubId"] = sPayChannelSubId;
  m_mReq["ServiceCode"] = "CPYF";
  
  m_mReq["Uin"] = iodat["in_acct"];
  m_mReq["PayAmt"] = iodat["num"];
  m_mReq["SerialNo"] = iodat["cft_tid"].substr(18,10);
  m_mReq["UserIP"] = iodat["ENV_ClientIp"];
  switch(atoi(iodat["sell_type"].c_str()))
  {
  case 1: //Q�ҳ�ֵ
    m_mReq["Comm1"] = "QQACCT_SAVE";
    m_mReq["ServiceCode"] = "ACCT";break;
  case 11://��Ϸ����
    m_mReq["Comm1"] = "XXQGAME";break;
  case 12://����
    m_mReq["Comm1"] = "XXQQF";break;
  case 13://����
    m_mReq["Comm1"] = "XXJZGW";break;
  case 5://��Ա
    m_mReq["Comm1"] = "LTMCLUB";break;
  case 14://Q���ֵ
    m_mReq["Comm1"] = iodat["sell_sub_type"]; //"QQPOINT";
    m_mReq["ServiceCode"] = "FOOP";break;
  default:
    m_sLastErrInfo = string("��֧�ִ˲�Ʒ���͡�");
    return 1;break;    
  }
  m_mReq["Comm2"] = iodat["price"];
  m_mReq["Comm3"] = iodat["tran_seq"];
  m_mReq["Comm4"] = iodat["cft_tid"];
 
  string sReq;
  if(m_mReq.GenString(sReq,"&","=") != 0)
  {
    m_sLastErrInfo = "pack error";
    return 3;
  }
  
  string sRes;
  if(SendRecv(sReq,sRes) != 0)
    return 2;
    
  m_mRes.SnapElement(sRes);
  if((atoi(m_mRes["Result"].c_str()) == 0)  && (atoi(m_mRes["ErrCode"].c_str()) == 0))
  {
    return 0;
  }
  iodat["retcode"] = m_mRes["ErrCode"];
  iodat["retmsg"] = m_mRes["ErrMsg"];
  return 4;
}

//##ModelId=44E9691402CE
int cftapi::CDeliver::GetStatus(bsapi::CStringMap &iodat)
{
  int iRetCode = 0;
  
  m_mReq.clear();
  m_mReq["Ver"] = sVer;
  m_mReq["ServiceCode"] = "CPRC";
  m_mReq["Spid"] = sSpid;
  m_mReq["PayChannelSubId"] = sPayChannelSubId;
  
  m_mReq["Uin"] = iodat["in_acct"];
  m_mReq["PayAmt"] = iodat["num"];
  m_mReq["SerialNo"] = iodat["tran_seq"];
  m_mReq["UserIP"] = iodat["ENV_ClientIp"];
  switch(atoi(iodat["sell_type"].c_str()))
  {
  case 1: //Q�ҳ�ֵ
    m_mReq["Comm1"] = "QQACCT_SAVE";break;
  case 11://��Ϸ����
    m_mReq["Comm1"] = "XXQGAME";break;
  case 12://����
    m_mReq["Comm1"] = "XXQQF";break;
  case 13://����
    m_mReq["Comm1"] = "XXJZGW";break;
  case 5://��Ա
    m_mReq["Comm1"] = "LTMCLUB";break;
  case 14://Q��
    m_mReq["Comm1"] = "QQPOINT";break;
  default:
    m_sLastErrInfo = string("��֧�ִ˲�Ʒ���͡�");
    return 1;break;    
  }
  m_mReq["Comm2"] = "";
  m_mReq["Comm3"] = "";
  m_mReq["Comm4"] = "";
 
  string sReq;
  if(m_mReq.GenString(sReq,"&","=") != 0)
  {
    m_sLastErrInfo = "pack error";
    return 3;
  }
  
  string sRes;
  if(SendRecv(sReq,sRes) != 0)
    return 2;
    
  m_mRes.SnapElement(sRes);
  if((atoi(m_mRes["Result"].c_str()) == 0)  && (atoi(m_mRes["ErrCode"].c_str()) == 0))
  {
    return 0;
  }
  iodat["retcode"] = m_mRes["ErrCode"];
  iodat["retmsg"] = m_mRes["ErrMsg"];
  
  return 4;
}

