#include "CTokenCoinIssuer.h"

/*
# ����ȯ��������
83:0:0:1:gwq_userpub_service:RE_VoucherIssue:RE_VoucherIssueSuc:RE_VoucherIssueFail
*/
const char * const cftapi::CTokenCoinIssuer::szReqType = "83";
  
//##ModelId=44E2C0C301B5
string cftapi::CTokenCoinIssuer::GetValue(string key, bool bEncode)
{
	if(bEncode)
		return m_mRes.UrlEncode(m_mRes[key]);
	else
		return m_mRes[key];
}

//##ModelId=44E2C659030D
bool cftapi::CTokenCoinIssuer::Commit(bsapi::CStringMap iodat )
{
  m_mReq["bargainor_id"] = iodat["issuer_uin"];
  m_mReq["login_ip"] = iodat["client_ip"];
//  m_mReq["channel_id"] = iodat["channel_id"];
  m_mReq["tde_id"] = iodat["bid"];
  m_mReq["purchaser_id"] = iodat["accept_uin"];
  m_mReq["pay_passwd"] = iodat["issuer_passwd"];
  m_mReq["merchant_spid"] = iodat["merchant_spid"];
  
  m_mReq["head_u"] = m_sOperId;  
  m_mReq["ver"] = m_sVersion;
  m_mReq["sp_id"] = m_sSpId;
  m_mReq["request_type"] = "83";
  
  
  if(!SendRecv(m_mReq,m_mRes))
    return false;
  
  return true;
}