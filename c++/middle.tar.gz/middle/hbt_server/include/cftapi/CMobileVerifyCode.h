// cftapi::CMobileVerifyCode.h: interface for the cftapi::CMobileVerifyCode class.
//
//////////////////////////////////////////////////////////////////////

#ifndef CMobileVerifyCode_H__8ACD3A41_965B_481D_AF62_B6F7AB98602D__INCLUDED_
#define CMobileVerifyCode_H__8ACD3A41_965B_481D_AF62_B6F7AB98602D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "CRelayComm.h"

#define CFT_VERIFYCODE_TYPE    "msgnote"
#define CFT_VERIFYCODE_MSG             "�Ƹ�ͨ���������ֻ�����֤��Ϊ[%s](������Ϣ���)."

namespace cftapi{
struct MessageHeader
{
    int MessageType;
    unsigned int BodyLength;
};

struct GetPassAsk
{
    char sMobileNo[14];
    char sPassType[11];
    char sMessage[71];
	char sExpTime[11];
	char sIP[32]; //Client IP
	char sExtern[256];
};

struct GetPassRespond
{
    int Result;
    char sMobileNo[14];
};


//��¼��
struct LoginAsk
{
    char sMobileNo[14];
    char sPassType[11];
    char sPassword[16];
    char sClientIP[20];
    char sExtern[256];
};

struct LoginRespond
{
    int Result;
    char sMobileNo[14];
};
}

class cftapi::CMobileVerifyCode : public cftapi::CCftComm  
{
public:
	CMobileVerifyCode();
	virtual ~CMobileVerifyCode();
	bool SendVerifyCode(
	                        const string &sMobilePhone, 
        	                const string &sAppId = CFT_VERIFYCODE_TYPE, 
        	                const string &sExtern = "",
                            const int iExpTime=600
	                    );
	                    	
	bool IsValidVerifyCode(
	                            const string &sMobilePhone, 
	                            const string &sVerifyCode, 
	                            const string &sAppId = CFT_VERIFYCODE_TYPE,
	                            const string &sExtern = ""      
	                      );
	                      
	//������ʹ��iExpTime���ϴ��룬��֮���Ա���ͨ����                      
    bool SendVerifyCode( const string &sMobilePhone, const int iExpTime);
    //bool IsValidVerifyCode(const string &sMobilePhone, const string &sVerifyCode);
    
	int GetLastErrCode();

protected:
	string GetErrInfo(const int iErrCode);
	bool SendRecv(const char * szReq,const int iReq,char *pszRes,int &iRes);
	static const int CODE_MAKE_PASS_ASK = 3;
	static const int CODE_MAKE_PASS_RESPOND = 4;
	static const int CODE_LOGIN_ASK = 5;
	static const int CODE_LOGIN_RESPOND = 6;

	int m_iErrCode;

};

#endif // !defined(AFX_cftapi::CMobileVerifyCode_H__8ACD3A41_965B_481D_AF62_B6F7AB98602D__INCLUDED_)
