#ifndef CCacheClient_H_HEADER_INCLUDED_BB16EA56
#define CCacheClient_H_HEADER_INCLUDED_BB16EA56

#include "CCftComm.h"

//##ModelId=44E966D70271
class cftapi::CCacheClient : public cftapi::CCftComm
{
  public:
    //##ModelId=44E9671B00AB
    
	const char* getSendStr();
	const char* getResultStr();
	int GetRetCode();
	int GetUid(const string &sUin, string &sUid);
	int GetCreditFlag(const string &sUin, string &sFlag);
	int GetSubCreditFlag(const string &sUin, string &sFlag);
	int SetSubCreditFlagOn(const string &sUin);
	//����ֵ:22712010�����ÿ�һ��ͨ������ȡ���ɹ�,����ֵ��ȡ��������ʧ��
	int SetSubCreditFlagOff(const string &sUin);

    CCacheClient();
    virtual ~CCacheClient(){};
  protected:
	  int SendRecv();
	  struct 
	  {
		  int iLen;
		  int iOpCode;
		  char szContent[2040];
		  char szPacket[2048];
	  }m_stReq;

	  struct 
	  {
		  int iLen;
		  int iRetCode;
		  char szContent[2040];
		  char szPacket[2048];
	  }m_stRes;
};



#endif 
