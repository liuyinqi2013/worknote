#ifndef CCrtsList_H_HEADER_INCLUDED_BB1D1E69
#define CCrtsList_H_HEADER_INCLUDED_BB1D1E69

#include "CStringMap.h"
#include "CRelayComm.h"
#include <vector>

#pragma pack(1)
typedef struct _CrtInfo
{
  int iUid;
  char szCn[64];
  char szAddr[64];
  int iState;
  char szStartTime[20];
  char szEndTime[20];
  char szIP[16];
  char szCreateTime[20];
  char szModifyTime[20];
}CrtInfo;
#pragma pack()

typedef struct _CrtsQuery
{
  string uid;
  string cn;
  string stime;
  string etime;
  string limit;
  string offset;
  string state;
  string uip;
}CrtsQuery;

//##ModelId=44E2B49A00DA
class cftapi::CCrtsList : public cftapi::CRelayComm
{
  public:
    string GetValue(string key, bool bEncode=true);
    //##ModelId=44E2C0C301B5
    int GetList(
        // ����ṹ��
        const CrtsQuery& req, 
        //֤����Ϣ�б�
        std::vector<CrtInfo>& CrtVec,
        //֤������ 1:��վ��0:����
        int crtType=1
        );

	int GetTotalNum()
	{return TotalNum;};
	
  private:    
    static const char * const szReqType ;
    //##ModelId=44E2C070001F
    bsapi::CStringMap m_mReq;


    //##ModelId=44E2C0850213
    bsapi::CStringMap m_mRes;
	
	int TotalNum;

};


#endif /* CCrtsList_H_HEADER_INCLUDED_BB1D1E69 */
