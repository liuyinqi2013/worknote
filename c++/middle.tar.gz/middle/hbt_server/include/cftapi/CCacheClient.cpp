#include "CCacheClient.h"

cftapi::CCacheClient::CCacheClient()
{
	memset(&m_stReq, 0, sizeof(m_stReq));
	memset(&m_stRes, 0, sizeof(m_stRes));
}

const char* cftapi::CCacheClient::getSendStr()
{
	static char szHex[10240]={0};
	memset(szHex, 0, sizeof(szHex));
	snprintf(szHex, 7, "[%d]", m_stReq.iLen);
	char *p = szHex + strlen(szHex);
	for(int i=0; i<m_stReq.iLen; i++)
	{
		snprintf(p+(3*i), 4, "%02x ", (unsigned char)m_stReq.szPacket[i]);
	}

	return szHex;
}

const char* cftapi::CCacheClient::getResultStr()
{
	static char szHex[10240]={0};
	memset(szHex, 0, sizeof(szHex));
	snprintf(szHex, 7, "[%d]", m_stRes.iLen);
	char *p = szHex + strlen(szHex);
	for(int i=0; i<m_stRes.iLen; i++)
	{
		snprintf(p+(3*i), 4, "%02x ", (unsigned char)m_stRes.szPacket[i]);
	}
	
	return szHex;
}

int cftapi::CCacheClient::GetRetCode()
{
	return m_stRes.iRetCode;
}

//##ModelId=44E9671B00AB
int cftapi::CCacheClient::SendRecv()
{
  int iResLen = 0;
  int iRetCode = 0;

  
  xyz::CUdpSocket *pstClt = NULL;
  try
  {
    int iContentLen = m_stReq.iLen - 8;
	if(iContentLen < 0 || iContentLen > sizeof(m_stReq.szContent))
	{
		m_stRes.iRetCode=2;
		m_sLastErrInfo = string("req packet err");
		return -1;
	}

	int iOffset=0;
	int iTmp;
	iTmp = htonl(m_stReq.iLen);
	memcpy(m_stReq.szPacket+iOffset, &iTmp, 4 );
	iOffset += 4;
	
	iTmp = htonl(m_stReq.iOpCode);
	memcpy(m_stReq.szPacket+iOffset, &iTmp, 4 );
	iOffset += 4;
	memcpy(m_stReq.szPacket+iOffset, m_stReq.szContent, iContentLen );

	pstClt = new xyz::CUdpSocket (m_sSvrIp.c_str(),m_iSvrPort);
    pstClt->Write (m_stReq.szPacket, m_stReq.iLen);
    
    iResLen = pstClt->Read(m_stRes.szPacket,sizeof(m_stRes.szPacket), m_iSvrTmOut);
    
	iOffset=0;
	memcpy(&iTmp, m_stRes.szPacket+iOffset, 4);
	m_stRes.iLen = ntohl(iTmp);
	iOffset += 4;
	if(m_stRes.iLen != iResLen)
	{
		m_stRes.iLen = iResLen;
		m_stRes.iRetCode=3;
		m_sLastErrInfo = string("res packet err");
	}
	else
	{
		memcpy(&iTmp, m_stRes.szPacket+iOffset, 4);
		m_stRes.iRetCode = ntohl(iTmp);
		iOffset += 4;
		
		memcpy(m_stRes.szContent, m_stRes.szPacket+iOffset, m_stRes.iLen-8);
		
		if(m_stRes.iRetCode != 0)
		{
			m_sLastErrInfo = m_stRes.szContent;
		}
	}

	
    

  }
  catch (xyz::CException & e)
  {
	  m_stRes.iRetCode=1;
    m_sLastErrInfo = string("xyzsock exception:");
    m_sLastErrInfo +=e.ErrorMessage ();
  }
  if (pstClt != NULL)
  {
    pstClt->Close ();
    delete pstClt;
  }
  return m_stRes.iRetCode;
}

int cftapi::CCacheClient::GetUid(const string &sUin, string &sUid)
{
	int iRet;

	m_stReq.iOpCode = 1000;
	strncpy(m_stReq.szContent, sUin.c_str(), 65);
	m_stReq.iLen = 73;

	iRet = SendRecv();
	if(iRet != 0)
	{
		return iRet;
	}

	if(m_stRes.iLen != 77)
	{
		m_stRes.iRetCode=4;
		m_sLastErrInfo = string("content len err");
		return m_stRes.iRetCode;
	}

	char szTmpBuf[128] = {0};
	memcpy(szTmpBuf, m_stRes.szContent, 65);
	if(sUin != szTmpBuf)
	{
		m_stRes.iRetCode=5;
		m_sLastErrInfo = string("content packet err");
		return m_stRes.iRetCode;
	}

	int iTmp;
	memcpy(&iTmp, m_stRes.szContent+65, 4);
	unsigned int iUid = ntohl(iTmp);

	snprintf(szTmpBuf, sizeof(szTmpBuf), "%u", iUid);
	sUid = szTmpBuf;

	return 0;

}

int cftapi::CCacheClient::GetCreditFlag(const string &sUin, string &sFlag)
{
	int iRet;
	
	m_stReq.iOpCode = 1002;
	strncpy(m_stReq.szContent, sUin.c_str(), 65);
	m_stReq.iLen = 73;
	
	iRet = SendRecv();
	if(iRet != 0)
	{
		return iRet;
	}
	
	if(m_stRes.iLen != 77)
	{
		m_stRes.iRetCode=4;
		m_sLastErrInfo = string("content len err");
		return m_stRes.iRetCode;
	}
	
	char szTmpBuf[128] = {0};
	memcpy(szTmpBuf, m_stRes.szContent, 65);
	if(sUin != szTmpBuf)
	{
		m_stRes.iRetCode=5;
		m_sLastErrInfo = string("content packet err");
		return m_stRes.iRetCode;
	}
	
	int iTmp;
	memcpy(&iTmp, m_stRes.szContent+65, 4);
	unsigned int iUid = ntohl(iTmp);
	
	snprintf(szTmpBuf, sizeof(szTmpBuf), "%u", iUid);
	sFlag = szTmpBuf;
	
	return 0;
	
}

int cftapi::CCacheClient::GetSubCreditFlag(const string &sUin, string &sFlag)
{
    int iRet;
	
	m_stReq.iOpCode = 1008;
	strncpy(m_stReq.szContent, sUin.c_str(), 65);
	m_stReq.iLen = 73;
	
	iRet = SendRecv();
	if(iRet != 0)
	{
		return iRet;
	}
	
	if(m_stRes.iLen != 77)
	{
		m_stRes.iRetCode=4;
		m_sLastErrInfo = string("content len err");
		return m_stRes.iRetCode;
	}
	
	char szTmpBuf[128] = {0};
	memcpy(szTmpBuf, m_stRes.szContent, 65);
	if(sUin != szTmpBuf)
	{
		m_stRes.iRetCode=5;
		m_sLastErrInfo = string("content packet err");
		return m_stRes.iRetCode;
	}
	
	int iTmp;
	memcpy(&iTmp, m_stRes.szContent+65, 4);
	unsigned int iUid = ntohl(iTmp);
	
	snprintf(szTmpBuf, sizeof(szTmpBuf), "%u", iUid);
	sFlag = szTmpBuf;
	
	return 0;
	
}

int cftapi::CCacheClient::SetSubCreditFlagOn(const string &sUin)
{
    int iRet;
	
	m_stReq.iOpCode = 1006;
	strncpy(m_stReq.szContent, sUin.c_str(), 65);
	m_stReq.iLen = 73;
	
	iRet = SendRecv();

    return iRet;
}

int cftapi::CCacheClient::SetSubCreditFlagOff(const string &sUin)
{
    int iRet;
	
	m_stReq.iOpCode = 1007;
	strncpy(m_stReq.szContent, sUin.c_str(), 65);
	m_stReq.iLen = 73;
	
	iRet = SendRecv();

    return iRet;
}