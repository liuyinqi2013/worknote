#ifndef CTELNETCOMM_H_HEADER_INCLUDED_BB16EA56
#define CTELNETCOMM_H_HEADER_INCLUDED_BB16EA56

#include "CCftComm.h"

//##ModelId=44E966D70271
class cftapi::CTelnetComm : public cftapi::CCftComm
{
  public:
    //##ModelId=44E9671B00AB
    int SendRecv(string sReq, string &sRes);

    CTelnetComm(){};
    virtual ~CTelnetComm(){};
};



#endif /* CTELNETCOMM_H_HEADER_INCLUDED_BB16EA56 */
