#ifndef CTokenCoinIssuer_H_HEADER_INCLUDED_BB1D1E69
#define CTokenCoinIssuer_H_HEADER_INCLUDED_BB1D1E69

#include "CStringMap.h"
#include "CEnRelayComm.h"
/*
# ����ȯ��������
83:0:0:1:gwq_userpub_service:RE_VoucherIssue:RE_VoucherIssueSuc:RE_VoucherIssueFail
*/

//##ModelId=44E2B49A00DA
class cftapi::CTokenCoinIssuer : public cftapi::CEnRelayComm
{
  public:
    //##ModelId=44E2C659030D
    string GetValue(string key, bool bEncode=true);
    //##ModelId=44E2C0C301B5
    /*����*/  
      bool Commit(bsapi::CStringMap iodat);
  private:    
    static const char * const szReqType ;
    //##ModelId=44E2C070001F
    bsapi::CStringMap m_mReq;


    //##ModelId=44E2C0850213
    bsapi::CStringMap m_mRes;

};


#endif /* CTokenCoinIssuer_H_HEADER_INCLUDED_BB1D1E69 */
