#ifndef CRYPTER_H
#define CRYPTER_H

// All classes returning pointers to buffers are creating
// the buffers and giving them away. Caller is responsible for deleting.
// The size tells the size of the data. The actuall size is ten bytes longer,
// meaning there is space to add some data at the end if the user wants to.
// For example the user can add trailing zero to a textmessage before printing.

// md5(...) will create a md5 type message digest of any binary set of data.
// The md5 algorithm is specified in RFC1321 and is implemented in the crypto
// library. However it is undocumented.

class Crypter{
 public:


  class buffer{
    
  public:
    buffer(int size);
    ~buffer();

  public:
    unsigned int size;
    unsigned int len;       // �������д洢�����ݵ�ʵ�ʳ���
    unsigned char *data;
    unsigned char *pre;
   
  private:
    buffer();
    //TODO: X X ref and assignment operator
  };


 public:  // Receiver is responsible for deleting returned buffer
  virtual buffer* public_encrypt(const unsigned char* const buf,int length)=0;
  virtual buffer* private_decrypt(const unsigned char* const buf,int length)=0;
  virtual buffer* private_sign(const unsigned char* const buf,int length)=0;
  virtual int public_verify(unsigned char*buf,int length,unsigned char *sig, int slen)=0;
  //  virtual buffer* md5(unsigned char*buf,int length);

 protected: //TODO: Add copy constructor and assignment operator here too
  Crypter(){}

};

#endif

