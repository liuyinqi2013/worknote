
#include "qpay_encrypt_client.h"


extern "C" {
#include <string.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <pthread.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <errno.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/socket.h>
}
namespace cftapi {
// ���ӽ��ܼ��İ汾
//#define DECRYPT_CHECK

// ��Ҫ�������²������ڵ��õĴ�api�ĳ������޸�����ֵ����
int IntervalTime = 3600;   // ����ȡ�����ʱ����֪ʱ����, ����Ϊ��λ
key_t EncryptShmKey = 10654;
int ShmSize = 10 * 1024;    // 10k
static const int MAX_KEY_COUNT = 10;    // �����ڴ��пɴ�Ų�ͬspid ��key �ĸ���Ϊ10��

// ���Ա���
int qpay_encrypt_api_test = 0;

///#define QPAY_ENCRYPT_FIXED_KEY = "QPAY_ENCRYPT_CLIENT_FIXED_STRING";
static const unsigned char QPAY_ENCRYPT_FIXED_KEY[8] = {
    0x4a, 0x08, 0x80, 0x58, 0x13, 0xad, 0x46, 0x89
};
static const unsigned char QPAY_ENCRYPT_FIXED_IV[8] = {
    0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18
};


// ��ȡ��Կ�ĺ���ָ�룬������Ҫ������Կ�ĵط��������ø�ָ��
// ָ��ʵ�ʵĺ���
char szKeyIp[16] = {0};		// ������Կ������ip
unsigned short  iKeyPort = 0;		// ������Կ������port
int (*pGetNewSecretKey)(const char* const spid, EnSecretStrings* pstSecKey, ST_PUB_ANS* pstAns, 
	const char* const ip, unsigned short port) = NULL;


// int /*cftapi::*/qpay_generate_digest_sha1(const char* const szTobeDigest, unsigned char* szDest, int* iDestLen)
int qpay_generate_digest_sha1(const char* const szTobeDigest, unsigned char* szDest, int* iDestLen)
{
    EVP_Digest((void*)szTobeDigest, (unsigned long)strlen(szTobeDigest), szDest, NULL, EVP_sha1(), NULL);
    if (iDestLen != NULL)
            *iDestLen = SHA_DIGEST_LENGTH;
    
    return 0;
}

int /*cftapi::*/qpay_generate_digest_md5(const char* const szTobeDigest, unsigned char* szDest, int* iDestLen)
{
    EVP_Digest((void*)szTobeDigest, (unsigned long)strlen(szTobeDigest), szDest, NULL, EVP_md5(), NULL);
    if (iDestLen != NULL)
            *iDestLen = MD5_DIGEST_LENGTH;
    
    return 0;
}


// attach �����ڴ�
static char* /*cftapi::*/Attach(ST_PUB_ANS* pstAns)
{
    int shmfd = 0;
    char* pchShm = NULL;
    
    //attach the shared memory
    if((shmfd = shmget(EncryptShmKey, 0, SHM_R | SHM_W)) < 0) {
        pstAns->iResult = AttachShmError;
        sprintf(pstAns->szErrInfo, "[%d]%s", __LINE__, strerror(errno));
        return NULL;
    }
    
    if((pchShm = (char *)shmat(shmfd, NULL, 0)) == (void *)-1) {
        pstAns->iResult = AttachShmAddressError;
        sprintf(pstAns->szErrInfo, "[%d]%s", __LINE__, strerror(errno));
        return NULL;
    }
    
    return pchShm;
}


// ���������ڴ�
// return value:
//      NULL : ʧ��
//      other : �ɹ�
static char* /*cftapi::*/createShm(ST_PUB_ANS* pstAns)
{
    int shmfd = 0;
    char* pchShm = NULL;
    
    //create the shared memory
    if((shmfd = shmget(EncryptShmKey, ShmSize, IPC_CREAT | IPC_EXCL | 0777)) < 0) {
        if(errno != EEXIST) {
            pstAns->iResult = CreateShmError;
            sprintf(pstAns->szErrInfo, "[%d]%s", __LINE__, strerror(errno));
            return NULL;
        }

        //the shared memory is already exists.
        if ((pchShm = Attach(pstAns)) == NULL) {
            return NULL;
        }

        return pchShm;
    }

    // ���δ����ɹ�����ʼ��
    if((pchShm = (char *)shmat(shmfd, NULL, 0)) == (void *)-1) {
        pstAns->iResult = AttachShmAddressError;
        sprintf(pstAns->szErrInfo, "[%d]%s", __LINE__, strerror(errno));
        return NULL;
    }

    // ���δ�������ʼ�������ڴ�
    memset(pchShm, 0, ShmSize);

    return pchShm;
}

int /*cftapi::*/qpay_get_fixed_key(QPAY_KEY* pstKey, ST_PUB_ANS* pstAns, 
	FunGetFixedSecretKey* pGetFixedSecretKey,
//	int (*pGetFixedSecretKey)(const char* const spid, EnSecretStrings* pstSecKey, ST_PUB_ANS* pstAns, bool blGetNewKey = false), 
	bool blGetNewKey = false)
{
    EnSecretStrings stEnKeyStr;     // ��Կ���ַ�����ʽ��key

    if (pGetFixedSecretKey != NULL) {
        memset(&stEnKeyStr, 0x00, sizeof(stEnKeyStr));
        if (pGetFixedSecretKey(pstKey->szSpid, &stEnKeyStr, pstAns, blGetNewKey) != 0) {
            // ��ȡʧ��
            return -1;
        }
        
        // ת���ַ�����ʽ��key ����������ʽ��key
        des_string_to_key(stEnKeyStr.szKeyStr, &pstKey->desKey);
        des_string_to_key(stEnKeyStr.szIvStr, &pstKey->desIV);
    }
    else {
        memcpy(pstKey->desKey, QPAY_ENCRYPT_FIXED_KEY, sizeof(pstKey->desKey));
        memcpy(pstKey->desIV, QPAY_ENCRYPT_FIXED_IV, sizeof(pstKey->desIV));    
    }
    
    return 0;
}

// ���Խ׶�ֱ�ӷ�����Կ����(����Կ���ڻ�ȡ��Կʱʹ��), ��Ҫ���ĳɴӹ����ڴ��ж�ȡ
// pstKey->szSpid ��Ϊ�����������ȡ��spid ��Ӧ����Կ
int qpay_get_key_from_shm(QPAY_KEY* pstKey, ST_PUB_ANS* pstAns, bool blGetNewKey = false)
{
    QPAY_KEY* tmpKey = NULL;
    static char* pchShm = NULL;    // 0 ���������ڴ治����, 1 ����������
    EnSecretStrings stEnKeyStr;     // ��Կ���ַ�����ʽ��key

    // ��ȡpchShm �Ƿ񱻳�ʼ��
    if (pchShm == NULL) {
        // ĩ����ʼ��
        pchShm = createShm(pstAns);
        qpay_encrypt_api_test = 1;
        if (pchShm == NULL) {
            qpay_encrypt_api_test = 2;
            return -1;
        }
    }

    int idx = 0;
    int flag = 0;
    // �ѱ���ʼ��, ������spid ��Ӧ��key��λ��
    for (idx = 0, tmpKey = (QPAY_KEY*)pchShm; tmpKey->szSpid[0] != '\0' && idx < MAX_KEY_COUNT; tmpKey++, idx++) {
        if (strcmp(tmpKey->szSpid, pstKey->szSpid) == 0) {
            // ���ҳɹ����ñ�־λ
            flag = 1;
            break;
        }
    }

    // ���ش���ϵͳ��ʹ�õ�spid����
    if (idx >= MAX_KEY_COUNT) {
        snprintf(pstAns->szErrInfo, sizeof(pstAns->szErrInfo), "more then %d entry of key in shm", MAX_KEY_COUNT);
        pstAns->iResult = OverLoadKeyEntryInShm;
        return -1;
    }
    
    // �ж��Ƿ���ҵ�spid ��Ӧ��key��
    if (flag != 1) {
        // ĩ���ҵ�, ��ʹ���µ�key ��
        qpay_encrypt_api_test = 3;
        strncpy(tmpKey->szSpid, pstKey->szSpid, sizeof(tmpKey->szSpid));
        tmpKey->ttLastFTime = 0;
    }
    
    time_t tt = time(NULL);
    // �ж��Ƿ���δ������ϴ�ȡ��Կʱ�䳬 ��ָ��ʱ��
    if (blGetNewKey || (tt - tmpKey->ttLastFTime) >= IntervalTime) {
        // ���»�ȡһ����Կ
        if (pGetNewSecretKey != NULL) {
            // ���ô˺�����ȡ��Կ
            memset(&stEnKeyStr, 0x00, sizeof(stEnKeyStr));
            if (pGetNewSecretKey(tmpKey->szSpid, &stEnKeyStr, pstAns, szKeyIp, iKeyPort) != 0) {
                // ��ȡʧ��
                if (tmpKey->ttLastFTime == 0) {
                    // �״λ�ȡʧ�ܣ�������ʼ��Կ
                    memcpy(tmpKey->desKey, QPAY_ENCRYPT_FIXED_KEY, sizeof(tmpKey->desKey));
                    memcpy(tmpKey->desIV, QPAY_ENCRYPT_FIXED_IV, sizeof(tmpKey->desIV));
                }
                else {
                    // ���״��򲻸���
                }
            }
            else {
                // ��ȡ�ɹ�
                tmpKey->ttLastFTime = tt;

                // ת���ַ�����ʽ��key ����������ʽ��key
                des_string_to_key(stEnKeyStr.szKeyStr, &tmpKey->desKey);
                des_string_to_key(stEnKeyStr.szIvStr, &tmpKey->desIV);
            }
        }
        else {
            // ����ָ��Ϊ�գ����ʾֻʹ��api ���a�ϵ���Կ
            memcpy(tmpKey->desKey, QPAY_ENCRYPT_FIXED_KEY, sizeof(tmpKey->desKey));
            memcpy(tmpKey->desIV, QPAY_ENCRYPT_FIXED_IV, sizeof(tmpKey->desIV));
        }
    }

    // ������Կ, tmpKey --> pstKey
    memcpy(pstKey, tmpKey, sizeof(QPAY_KEY));
    
    return 0;
}

int  /*cftapi::*/encrypt_3des(QPAY_KEY* pstKey, const unsigned char* const szTobeEncrypt, int iTElen, unsigned char* szDest, int *iDestLen, ST_PUB_ANS* pstAns)
{
    // ������ܽ���Ĵ�С
    int iBlockCount = 0;
    iBlockCount = iTElen / sizeof(des_cblock);
    if (iTElen % sizeof(des_cblock) > 0)
       iBlockCount++;
       if (iDestLen != NULL)
        *iDestLen = iBlockCount * sizeof(des_cblock);
    
    // �����Կ
    des_key_schedule ks;
    switch(des_set_key_checked(&(pstKey->desKey), ks)){
        case -1:
            pstAns->iResult = KeyBadParity;
            sprintf(pstAns->szErrInfo, "qpay_en_3des_v1 error: Bad parity");
        break;
        case -2:
            pstAns->iResult = WeakKey;
            sprintf(pstAns->szErrInfo, "qpay_en_3des_v1 error: Key is weak\n");
            break;
        default:
            // good
            break;
    }
    
    // ����
    des_ncbc_encrypt(szTobeEncrypt, szDest, iTElen, ks, &pstKey->desIV, DES_ENCRYPT);
    return 0;
}

int /*cftapi::*/decrypt_3des(QPAY_KEY* pstKey, const unsigned char* const szTobeEncrypt, int iTElen, unsigned char* szDest, int *iDestLen, ST_PUB_ANS* pstAns)
{
    // ������ܽ���Ĵ�С
    int iBlockCount = 0;
    iBlockCount = iTElen / sizeof(des_cblock);
    if (iTElen % sizeof(des_cblock) > 0)
       iBlockCount++;
       if (iDestLen != NULL)
        *iDestLen = iBlockCount * sizeof(des_cblock);

    // �����Կ
    des_key_schedule ks;
    switch(des_set_key_checked(&(pstKey->desKey), ks)){
        case -1:
            pstAns->iResult = KeyBadParity;
            sprintf(pstAns->szErrInfo, "qpay_en_3des_v1 error: Bad parity");
            break;
        case -2:
            pstAns->iResult = WeakKey;
            sprintf(pstAns->szErrInfo, "qpay_en_3des_v1 error: Key is weak\n");
            break;
        default:
            // good
            break;
    }

    // ����
    des_ncbc_encrypt(szTobeEncrypt, szDest, iTElen, ks, &pstKey->desIV, DES_DECRYPT);

    return 0;
}

int /*cftapi::*/qpay_en_3des_v1(const char* szSpid, const unsigned char* const szTobeEncrypt, int iTElen, unsigned char* szDest, int *iDestLen, ST_PUB_ANS* pstAns)
{
//  printf("%s:%d\r\n",__FILE__,__LINE__);
    // ����SPID��ȡSP����Կ
    QPAY_KEY pstKey;
    memset(&pstKey, 0x00, sizeof(pstKey));
    strncpy(pstKey.szSpid, szSpid, sizeof(pstKey.szSpid) - 1);
    if (qpay_get_fixed_key(&pstKey, pstAns, NULL) != 0) {
//      printf("%s:%d",__FILE__,__LINE__);
        return -1;
    }

#ifdef DECRYPT_CHECK
    int iMd5BufLen = 0;
    int bufLen = iTElen + LENGTH_DIGEST_MD5 + 1;
    unsigned char szMd5Buf[LENGTH_DIGEST_MD5];
    AutoBuf stBuf(bufLen);   // szTobeEncrypt + '\0' + md5
    if (stBuf.getBuf() == NULL) {
        pstAns->iResult = MemoryAllocFailed;
        sprintf(pstAns->szErrInfo, "[%d]memcpy alloc failed", __LINE__);
        return -1;
    }

    // ��szTobeEncrypt ����md5
    qpay_generate_digest_md5((const char* const)szTobeEncrypt, szMd5Buf, &iMd5BufLen);
    // ��md5�Ľ������Դ��֮��
    memcpy(stBuf.getBuf(), szTobeEncrypt, iTElen);
    stBuf.getBuf()[iTElen] = '\0';
    memcpy(stBuf.getBuf() + iTElen + 1, szMd5Buf, LENGTH_DIGEST_MD5);
    // 3des ����
    encrypt_3des(&pstKey, (unsigned char*)stBuf.getBuf(), bufLen, szDest, iDestLen, pstAns);
#else
    encrypt_3des(&pstKey, szTobeEncrypt, iTElen, szDest, iDestLen, pstAns);
    
//printf("%s:%d\r\n",__FILE__,__LINE__);
#endif
    return 0;
}

int /*cftapi::*/qpay_en_3des_v2(const char* szSpid, const unsigned char* const szTobeEncrypt, int iTElen, unsigned char* szDest, int *iDestLen, ST_PUB_ANS* pstAns, 
		FunGetFixedSecretKey* pGetFixedSecretKey
//        int (*pGetFixedSecretKey)(const char* const spid, EnSecretStrings* pstSecKey, ST_PUB_ANS* pstAns, bool blGetNewKey = false)/* = NULL*/
        )
{
    QPAY_KEY pstKey;
    memset(&pstKey, 0x00, sizeof(pstKey));
    strncpy(pstKey.szSpid, szSpid, sizeof(pstKey.szSpid) - 1);    
    if (qpay_get_fixed_key(&pstKey, pstAns, pGetFixedSecretKey) != 0) {
        return -1;
    }

#ifdef DECRYPT_CHECK
    int iMd5BufLen = 0;
    int bufLen = iTElen + LENGTH_DIGEST_MD5 + 1;
    unsigned char szMd5Buf[LENGTH_DIGEST_MD5];
    AutoBuf stBuf(bufLen);   // szTobeEncrypt + '\0' + md5
    if (stBuf.getBuf() == NULL) {
        pstAns->iResult = MemoryAllocFailed;
        sprintf(pstAns->szErrInfo, "[%d]memcpy alloc failed", __LINE__);
        return -1;
    }

    // ��szTobeEncrypt ����md5
    qpay_generate_digest_md5((const char* const)szTobeEncrypt, szMd5Buf, &iMd5BufLen);
    // ��md5�Ľ������Դ��֮��
    memcpy(stBuf.getBuf(), szTobeEncrypt, iTElen);
    stBuf.getBuf()[iTElen] = '\0';
    memcpy(stBuf.getBuf() + iTElen + 1, szMd5Buf, LENGTH_DIGEST_MD5);
    // 3des ����
    encrypt_3des(&pstKey, (unsigned char*)stBuf.getBuf(), bufLen, szDest, iDestLen, pstAns);
#else
    encrypt_3des(&pstKey, szTobeEncrypt, iTElen, szDest, iDestLen, pstAns);
#endif

    return 0;
}


// ���pstBuf �����LENGTH_DIGEST_MD5 ���ֽڵ�ֵ�Ƿ�Ϊǰ���ֽڵ�md5���ֵ
// ǰ����pstBuf��һ���ַ����飬ǰn ���ֽ���ascii
int /*cftapi::*/check_md5(const char* const pstBuf, int len)
{
    int iMd5BufLen = 0;
    const char* pchMd5Value = pstBuf +strlen(pstBuf) + 1;	// pch ָ��pstBuf ��md5��ֵ����
    unsigned char szMd5Buf[LENGTH_DIGEST_MD5];  // md5 buf

    qpay_generate_digest_md5((const char* const)pstBuf, szMd5Buf, &iMd5BufLen);
    if (memcmp(szMd5Buf, pchMd5Value, LENGTH_DIGEST_MD5) != 0) {
        return -1;
    }

    return 0;
}

int /*cftapi::*/qpay_de_3des_v1(const char* szSpid, const unsigned char* const szTobeEncrypt, int iTElen, unsigned char* szDest, int *iDestLen, ST_PUB_ANS* pstAns)
{
    // �ڽ��ܵĺ����У���Ҫ�жϽ����Ƿ���ȷ������ȷ����Ҫȥ���»�ȡһ����Կ
    // ����SPID��ȡSP����Կ
    int len = 0;
    int* ptrLen = &len;
    QPAY_KEY pstKey;

#ifdef DECRYPT_CHECK
Again:
#endif
    memset(&pstKey, 0x00, sizeof(pstKey));
    strncpy(pstKey.szSpid, szSpid, sizeof(pstKey.szSpid) - 1);
    if (qpay_get_fixed_key(&pstKey, pstAns, NULL) != 0) {
        return -1;
    }

    if (iDestLen != NULL)
        ptrLen = iDestLen;
    decrypt_3des(&pstKey, szTobeEncrypt, iTElen, szDest, ptrLen, pstAns);

#ifdef DECRYPT_CHECK
    // ���md5ֵ�Ƿ�ƥ��
    if (check_md5((char*)szDest, *ptrLen) != 0) {
        // ��ƥ�䣬����Ϊ�ǽ���ʧ��, Զ�̻�ȡһ����Կ
        if (! blReGetKey) {
            blReGetKey = true;
            goto Again;
        }
	 // ���ν���ʧ�ܣ�����Ϊ����������ʧ��
	 pstAns->iResult = DecryptFailed;
	 sprintf(pstAns->szErrInfo, "[%d]check md5 failed twice", __LINE__);

	 return -1;
    }

    // ���Ϊ���ν��ܳɹ�������stAns
    if (blReGetKey == true) {
        strncpy(pstAns->szErrInfo, TWICE_DECRYPT_MARK, sizeof(pstAns->szErrInfo) - 1);
    }
#endif

    return 0;
}

int /*cftapi::*/qpay_de_3des_v2(const char* szSpid, const unsigned char* const szTobeEncrypt, int iTElen, unsigned char* szDest, int *iDestLen, ST_PUB_ANS* pstAns, 
		FunGetFixedSecretKey* pGetFixedSecretKey
//        int (*pGetFixedSecretKey)(const char* const spid, EnSecretStrings* pstSecKey, ST_PUB_ANS* pstAns, bool blGetNewKey = false)/* = NULL*/
        )
{
    bool blReGetKey = false;
    int len = 0;
    int* ptrLen = &len;
    QPAY_KEY pstKey;

#ifdef DECRYPT_CHECK
Again:
#endif
    memset(&pstKey, 0x00, sizeof(pstKey));
    strncpy(pstKey.szSpid, szSpid, sizeof(pstKey.szSpid) - 1);
    if (qpay_get_fixed_key(&pstKey, pstAns, pGetFixedSecretKey, blReGetKey) != 0) {
        return -1;
    }

    if (iDestLen != NULL)
        ptrLen = iDestLen;
    decrypt_3des(&pstKey, szTobeEncrypt, iTElen, szDest, ptrLen, pstAns);

#ifdef DECRYPT_CHECK
    // ���md5ֵ�Ƿ�ƥ��
    if (check_md5((char*)szDest, *ptrLen) != 0) {
        // ��ƥ�䣬����Ϊ�ǽ���ʧ��, Զ�̻�ȡһ����Կ
        if (! blReGetKey) {
            blReGetKey = true;
            goto Again;
        }
	 // ���ν���ʧ�ܣ�����Ϊ����������ʧ��
	 pstAns->iResult = DecryptFailed;
	 sprintf(pstAns->szErrInfo, "[%d]check md5 failed twice", __LINE__);

	 return -1;
    }
	
    // ���Ϊ���ν��ܳɹ�������stAns
    if (blReGetKey == true) {
        strncpy(pstAns->szErrInfo, TWICE_DECRYPT_MARK, sizeof(pstAns->szErrInfo) - 1);
    }
#endif

    return 0;
}

int /*cftapi::*/qpay_encode_base64(unsigned char* szTobeDigest, int iTDlen, unsigned char* szDest, int *iDestLen)
{

    int len = 0, len1 = 0;
    EVP_ENCODE_CTX  ctx;
    
    EVP_EncodeInit(&ctx);
    EVP_EncodeUpdate(&ctx, (unsigned char *)szDest, &len, szTobeDigest, iTDlen);
    EVP_EncodeFinal(&ctx, (unsigned char *)&szDest[len], &len1);
    len += len1;

    // delete '\n'
    szDest[len - 1] = '\0';
       if (iDestLen != NULL)
        *iDestLen = strlen((char*)szDest);

    return 0;
}


int /*cftapi::*/qpay_decode_base64(unsigned char* szTobeDigest, int iTDlen, unsigned char* szDest, int *iDestLen)
{
    int len = 0, len1 = 0;
    EVP_ENCODE_CTX  ctx;
    
    EVP_DecodeInit(&ctx);
    EVP_DecodeUpdate(&ctx, (unsigned char *)szDest, &len, szTobeDigest, iTDlen);
    EVP_DecodeFinal(&ctx, (unsigned char *)&szDest[len], &len1);
       len += len1;
       if (iDestLen != NULL)
        *iDestLen = len;

    return 0;
}

char */*cftapi::*/pt(unsigned char *md, int ilen, char *sDest)
{
    int i;

    for (i=0; i<ilen; i++)
        sprintf(&(sDest[i*2]),"%02x",md[i]);
        
    return(sDest);
}

unsigned char */*cftapi::*/un_pt(char* str, unsigned char* md, int isize)
{
    int i = 0;
    int len = strlen(str);
    char tmp_c = 0;
    long c = 0;

    while (i < len) {
    	i += 2;
       if (i > 2*isize)
	    break;

    	tmp_c = *(str + 2);
    	*(str + 2) = '\0';
        c = strtol(str, NULL, 16);
        *(str + 2) = tmp_c;
        //printf("%.2x\n", c);

        md[i/2 - 1] = (char)c;
        str += 2;
    }

    return md;
}

void /*cftapi::*/set_shm_key(key_t key)
{
    EncryptShmKey = key;
}



int GenerateDigest(char* src, char* dest, int dsize)
{
    int len = 0;
    unsigned char szDigest[21];
    memset(szDigest, 0x00, sizeof(szDigest));

    qpay_generate_digest_sha1(src, szDigest, &len);
#ifdef OPENSSL_BASE64
    qpay_encode_base64(szDigest, len, (unsigned char*)dest, NULL);
#else
    Base64_Encode((const unsigned char*)szDigest, len, dest, dsize, &len);
#endif

    return 0;
}

int Encrypt(const char* spid, char* src, char* dest, int dsize)
{
  cftapi::ST_PUB_ANS stAns;
  int olen;
  unsigned char szTmpString[1024*5] ;
  memset(szTmpString,0,sizeof(szTmpString));
  memset(&stAns,0,sizeof(stAns));

  qpay_en_3des_v1(spid, (unsigned char*)src, strlen(src), szTmpString, &olen, &stAns);
  if (stAns.iResult != 0) 
  {
    return stAns.iResult;
  }

  Base64_Encode(szTmpString, olen, dest, dsize, &olen);

  return 0;
}

};//namespace cftapi 