#include "CCrtUserAttr.h"


const char * const cftapi::CCrtUserAttr::szReqType = "2303";

string cftapi::CCrtUserAttr::GetValue(string key, bool bEncode)
{
	if(bEncode)
		return m_mRes.UrlEncode(m_mRes[key]);
	else
		return m_mRes[key];
}
/*
# ��ȡ֤���û�����
2303:0:0:1:crt_getattr_service:Crt_GetAttr:Crt_GetAttSuc:Crt_GetAttFail
*/  
/*******************************************************
 *������uid�û��ڲ�id��uip�û���¼ip
 *�����1 ��ͨ 2 δ��ͨ 3 ����
 *���ܣ���ѯ�û��Ƿ�ͨ����֤�� 
*******************************************************/
//##ModelId=44E2C659030D
string cftapi::CCrtUserAttr::CrtState(const string& uid,const string& uip)
{
  m_mReq["uid"] = uid;
  m_mReq["client_ip"] = uip;
  m_mReq["attribute"] = "1"; //��ѯ�û��Ƿ�֤ͨ��
  m_mReq["head_u"] = m_sOperId;
  m_mReq["ver"] = m_sVersion;
  m_mReq["sp_id"] = m_sSpId;
  m_mReq["request_type"] = szReqType;
  
  string sReq;
  if(m_mReq.GenString(sReq,"&","=") != 0)
  {
    m_sLastErrInfo = "pack error";
    return "";
  }
  
  char * pszRes; int iRes;
  
  if(!SendRecv(sReq.c_str(),sReq.size(),&pszRes,iRes))
    return "";
  
  if(pszRes == NULL)
    return "";
    
  m_mRes.SnapElement(pszRes);
  if(atoi(m_mRes["result"].c_str()) == 0)
  {
    //int value=atoi(m_mRes["value"].c_str());
    //return value;
    return m_mRes["value"];
  }
  m_sLastErrInfo+=m_mRes["res_info"];
	/*
  if(atoi(m_mRes["result"].c_str()) == 1012)
  {
    m_mRes["retmsg"] = "NOTREG";
  }
	*/
  return "";
}


