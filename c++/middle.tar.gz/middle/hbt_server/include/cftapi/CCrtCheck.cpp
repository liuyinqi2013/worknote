#include "CCrtCheck.h"


const char * const cftapi::CCrtCheck::szReqType = "2302";

string cftapi::CCrtCheck::GetValue(string key, bool bEncode)
{
	if(bEncode)
		return m_mRes.UrlEncode(m_mRes[key]);
	else
		return m_mRes[key];
}
/*
# ����֤��ǩ����֤
2302:0:0:1:crt_validate_service:Crt_Validate:Crt_ValidateSuc:Crt_ValidateFail
*/  
/*******************************************************
 *������uid�û��ڲ�id��cn֤�����кţ�uip�û���¼ip
 *�����true �ɹ� false ʧ��
 *���ܣ���֤ǩ��
*******************************************************/
//##ModelId=44E2C659030D
bool cftapi::CCrtCheck::VerifySign(const string& uid,const string &cn,const string &src,const string &res,const string& uip)
{
  m_mReq["uid"] = uid;
  m_mReq["cn"] = cn;
  m_mReq["client_ip"] = uip;
  m_mReq["sign_src"] = src;
  m_mReq["sign_res"] = res;
  m_mReq["crt_type"] = "1"; //�Ƹ�ͨ��վ֤��
  m_mReq["head_u"] = m_sOperId;
  m_mReq["ver"] = m_sVersion;
  m_mReq["sp_id"] = m_sSpId;
  m_mReq["request_type"] = szReqType;
  
  string sReq;
  if(m_mReq.GenString(sReq,"&","=") != 0)
  {
    m_sLastErrInfo = "pack error";
    return false;
  }
  
  char * pszRes; int iRes;
  
  if(!SendRecv(sReq.c_str(),sReq.size(),&pszRes,iRes))
    return false;
  
  if(pszRes == NULL)
    return false;
    
  m_mRes.SnapElement(pszRes);
  if(atoi(m_mRes["result"].c_str()) == 0)
  {
    return true;
  }
  m_sLastErrInfo=m_mRes["res_info"];
	/*
  if(atoi(m_mRes["result"].c_str()) == 1012)
  {
    m_mRes["retmsg"] = "NOTREG";
  }
	*/
  return false;
}


