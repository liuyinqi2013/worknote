#include "CQuerySave.h"


const char * const cftapi::CQuerySave::szReqType = "3012";
  
//##ModelId=44E2C0C301B5
string cftapi::CQuerySave::GetValue(string key)
{
  return m_mRes[key];
}

//##ModelId=44E2C659030D
bool cftapi::CQuerySave::Query(string &save_sign, const string &uin,  const string &s_time, const string &e_time)
{
	string sSTime=s_time;
	string sETime=e_time;

	/*
	if(sSTime.empty())
	{
		sSTime="1970-01-01";
	}

	if(sETime.empty())
	{
		struct tm *ptm;
    		time_t     now;

    		time(&now);
    		ptm = localtime(&now);
		char szDate[11]={0};
    		sprintf(szDate, "%04d-%02d-%02d",  ptm->tm_year+1900, ptm->tm_mon+1, ptm->tm_mday);
		sETime=szDate;
	}
	*/

  m_mReq["uin"] = uin;
  m_mReq["s_time"] = sSTime;
  m_mReq["e_time"] = sETime;
  m_mReq["head_u"] = m_sOperId;
  m_mReq["ver"] = m_sVersion;
  m_mReq["sp_id"] = m_sSpId;
  m_mReq["request_type"] = szReqType;
  

  string sReq;
  if(m_mReq.GenString(sReq,"&","=") != 0)
  {
    m_sLastErrInfo = "pack error";
    return false;
  }
  
  char * pszRes; int iRes;
  
  if(!SendRecv(sReq.c_str(),sReq.size(),&pszRes,iRes))
    return false;
  
  if(pszRes == NULL)
    return false;
    
  m_mRes.SnapElement(pszRes);
  save_sign = m_mRes["save_sign"];
  if(atoi(m_mRes["result"].c_str()) == 0)
  {
    return true;
  }
  return false;
}


