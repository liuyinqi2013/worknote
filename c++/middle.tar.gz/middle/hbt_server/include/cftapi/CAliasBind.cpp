#include "CAliasBind.h"
#include "qpay_encrypt_client.h"


const char * const cftapi::CAliasBind::szReqType = "3001";
  
//##ModelId=44E2C0C301B5
string cftapi::CAliasBind::GetValue(string key, bool bEncode)
{
	if(bEncode)
		return m_mRes.UrlEncode(m_mRes[key]);
	else
		return m_mRes[key];
}

//##ModelId=44E2C659030D
bool cftapi::CAliasBind::Bind(bsapi::CStringMap iodat )
{
  m_mReq["uin"] = iodat["uin"];
  m_mReq["client_ip"] = iodat["client_ip"];
  m_mReq["channel_id"] = iodat["channel_id"];
  m_mReq["en_buf"] = iodat["paypwd"];
  m_mReq["time_stamp"] = iodat["paypwd_seed"];
  m_mReq["alias_name"] = iodat["alias_name"];
  m_mReq["alias_type"] = iodat["alias_type"];
  m_mReq["login_pass_en"] = iodat["loginpwd"];
  m_mReq["login_pass_seed"] = iodat["loginpwd_seed"];
  if(iodat["loginpwd"].size() == 32)
  	m_mReq["login_pass_type"] = "4";
  else
  	m_mReq["login_pass_type"] = "2";
  m_mReq["vali_type"] = "2";
  
  m_mReq["head_u"] = m_sOperId;  
  m_mReq["ver"] = m_sVersion;
  m_mReq["sp_id"] = m_sSpId;
  m_mReq["request_type"] = "3001";
  
  
  if(!SendRecv(m_mReq,m_mRes))
    return false;
  
  return true;
}
bool cftapi::CAliasBind::Cancel(bsapi::CStringMap iodat)
{  
  m_mReq["uin"] = iodat["uin"];
  m_mReq["client_ip"] = iodat["client_ip"];
  m_mReq["channel_id"] = iodat["channel_id"];
  m_mReq["en_buf"] = iodat["paypwd"];
  m_mReq["time_stamp"] = iodat["paypwd_seed"];
  m_mReq["alias_name"] = iodat["alias_name"];
  m_mReq["alias_type"] = iodat["alias_type"];
  m_mReq["vali_type"] = "2";
  
  m_mReq["head_u"] = m_sOperId;  
  m_mReq["ver"] = m_sVersion;
  m_mReq["sp_id"] = m_sSpId;
  m_mReq["request_type"] = "3005";
  
  
  if(!SendRecv(m_mReq,m_mRes))
    return false;
  
  return true;
}
bool cftapi::CAliasBind::Confirm(bsapi::CStringMap iodat )
{
  m_mReq["uin"] = iodat["uin"];
  m_mReq["client_ip"] = iodat["client_ip"];
  m_mReq["channel_id"] = iodat["channel_id"];
  m_mReq["pkey"] = iodat["pkey"];
  m_mReq["login_pass_en"] = iodat["loginpwd"];
  m_mReq["login_pass_seed"] = iodat["loginpwd_seed"];
  if(iodat["loginpwd"].size() == 32)
  	m_mReq["login_pass_type"] = "3";
  else
  	m_mReq["login_pass_type"] = "2";
  	
  m_mReq["active_type"] = iodat["active_type"];
  
  m_mReq["head_u"] = m_sOperId;  
  m_mReq["ver"] = m_sVersion;
  m_mReq["sp_id"] = m_sSpId;
  m_mReq["request_type"] = "3002";
  
  
  if(!SendRecv(m_mReq,m_mRes))
    return false;
  
  return true;
}

bool cftapi::CAliasBind::Valid(bsapi::CStringMap iodat )
{
  m_mReq["uin"] = iodat["uin"];
  m_mReq["client_ip"] = iodat["client_ip"];
  m_mReq["channel_id"] = iodat["channel_id"];
  
  m_mReq["login_pass_en"] = iodat["loginpwd"];
  m_mReq["login_pass_seed"] = iodat["loginpwd_seed"];
  m_mReq["login_pass_type"] = "2";
  
  m_mReq["head_u"] = m_sOperId;  
  m_mReq["ver"] = m_sVersion;
  m_mReq["sp_id"] = m_sSpId;
  m_mReq["request_type"] = "3003";
  
  
  if(!SendRecv(m_mReq,m_mRes))
    return false;
  
  return true;
}

bool cftapi::CAliasBind::Confirm2(bsapi::CStringMap iodat )
{
  m_mReq["uin"] = iodat["uin"];
  m_mReq["client_ip"] = iodat["client_ip"];
  m_mReq["channel_id"] = iodat["channel_id"];
  m_mReq["pkey"] = iodat["pkey"];
//  m_mReq["login_pass_en"] = iodat["loginpwd"];
//  m_mReq["login_pass_seed"] = iodat["loginpwd_seed"];
//  if(iodat["loginpwd"].size() == 32)
//  	m_mReq["login_pass_type"] = "3";
//  else
//  	m_mReq["login_pass_type"] = "2";
  char cTmp[32] = {0};
  char szDest[64]={0};
  int len = 0;
  unsigned char szDigest[17] = {0};
  time_t tm = time(NULL);
  snprintf(cTmp,sizeof(cTmp),
	"%d",tm);
  m_mReq["login_pass_seed"] = cTmp;
  qpay_generate_digest_md5(cTmp, szDigest, &len);
  pt(szDigest, len, szDest);
  m_mReq["login_pass_en"] = szDest;
  m_mReq["login_pass_type"] = "5";

//  m_mReq["active_type"] = iodat["active_type"];
  m_mReq["active_type"] = "2";
  
  m_mReq["head_u"] = m_sOperId;  
  m_mReq["ver"] = m_sVersion;
  m_mReq["sp_id"] = m_sSpId;
  m_mReq["request_type"] = "3002";
  
  
  if(!SendRecv(m_mReq,m_mRes))
    return false;
  
  return true;
}
