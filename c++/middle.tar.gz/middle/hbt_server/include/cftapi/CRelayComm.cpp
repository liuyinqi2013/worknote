#include "CRelayComm.h"


//##ModelId=44E2B288032C
bool cftapi::CRelayComm::SendRecv(const char * szReq,int iReq,char ** pszRes,int &iRes)
{  
  int bRet = true;
  memset((char *)&m_stRes,0,sizeof(m_stRes));
  memset((char *)&m_stReq,0,sizeof(m_stReq));
  
  if((iReq <= 0 || iReq > MAX_PACKET_SIZE) ||
     (szReq == NULL)) 
  {
    m_sLastErrInfo = string("Invalid Request.");
    return false;
  }
  int iReqLen = sizeof(m_stReq.iLen) + iReq; 
  m_stReq.iLen = iReq; //Histtory problem,it should be net order
  memcpy(m_stReq.szBuf,szReq,iReq);
  
  xyz::CTcpSocket *pstClt = NULL;
  try
  {
      pstClt = new xyz::CTcpSocket (m_iSvrTmOutConn,m_sSvrIp.c_str(),m_iSvrPort);

      pstClt->Write ((char *)&m_stReq, iReqLen);
      
      int iResLen = 0,iCurLen =0;
      while(true)
      {
        iResLen += pstClt->Read (((char *)&m_stRes)+iResLen, sizeof(m_stRes)-iResLen,m_iSvrTmOut);
        
        if(iResLen <= iCurLen)
        {
          bRet = false;
          m_sLastErrInfo = string("communicate failed.");
          break;
        }
        if(iResLen >= sizeof(m_stRes.iLen))
        {
          if(iResLen >= m_stRes.iLen + sizeof(m_stRes.iLen)) 
          {
            iRes = m_stRes.iLen; //Histtory problem,it should be net order
            *pszRes = m_stRes.szBuf;
            bRet = true;
//debug {{
//printf("\nlen:%d\n",m_stRes.iLen);
//for( int jj=0;jj<m_stRes.iLen;jj++)
//{
//  printf("%02X",(unsigned char )m_stRes.szBuf[jj]);
//}
//printf("\n");
//}}
            break;
          }
        }        
        iCurLen = iResLen;
      }
        

  }
  catch (xyz::CException & e)
  {
    m_sLastErrInfo = string("xyzsock exception:");
    m_sLastErrInfo +=e.ErrorMessage ();
    bRet = false;
  }
  if (pstClt != NULL)
  {
          pstClt->Close ();
    delete pstClt;
  }
  
  return bRet;
}

//##ModelId=44E2BC6503C8
int cftapi::CRelayComm::Prepare(string req_type, string ver, string spid, string operid)
{
  m_sReqType = req_type;
  m_sVersion = ver;
  m_sSpId = spid;
  m_sOperId = operid;
  
  return 0;
}
const char* cftapi::CRelayComm::getSendStr()
{
	return m_stReq.szBuf;
}
const char* cftapi::CRelayComm::getResultStr()
{
	return m_stRes.szBuf;
}
