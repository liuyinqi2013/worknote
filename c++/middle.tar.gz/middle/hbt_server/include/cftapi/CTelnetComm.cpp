#include "CTelnetComm.h"

//##ModelId=44E9671B00AB
int cftapi::CTelnetComm::SendRecv(string sReq, string &sRes)
{
  int iResLen = 0;
  int iRetCode = 0;//0 wait tail;1 wait '\n'; 2 recv ok
  char cTmp;
  
  sReq += "\r\n";
  sRes = "";
  
  xyz::CTcpSocket *pstClt = NULL;
  try
  {
    pstClt = new xyz::CTcpSocket (m_sSvrIp.c_str(),m_iSvrPort);

    pstClt->Write (sReq.c_str(), sReq.size());
    
    do
    {
      iResLen = pstClt->Read(&cTmp,1,m_iSvrTmOut);
      if((cTmp == '\n') || (cTmp == '\r')||(cTmp == 0x00 ))
        if( !sRes.empty() )
          break;
        else
          continue;
          
      sRes += cTmp;
    }while(iResLen == 1);
    
//    cout << "___________________________________" << endl;
//    cout << "req:" << sReq <<endl;
//    cout << "res:" << sRes <<endl;
//    cout << "___________________________________" << endl;
  }
  catch (xyz::CException & e)
  {
    m_sLastErrInfo = string("xyzsock exception:");
    m_sLastErrInfo +=e.ErrorMessage ();
    iRetCode = 1;
  }
  if (pstClt != NULL)
  {
    pstClt->Close ();
    delete pstClt;
  }
  return iRetCode;
}

