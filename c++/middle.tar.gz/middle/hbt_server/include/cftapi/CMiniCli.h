#ifndef CMINICLI_H_HEADER_INCLUDED_BB16E7C3
#define CMINICLI_H_HEADER_INCLUDED_BB16E7C3

#include "CStringMap.h"
#include "CTelnetComm.h"
//##ModelId=44E967E10261
class cftapi::CMiniCli : public cftapi::CTelnetComm
{  
  string m_sTid;
  //##ModelId=44E2C070001F
    bsapi::CStringMap m_mReq;


    //##ModelId=44E2C0850213
    bsapi::CStringMap m_mRes;
    //##ModelId=44E968F3035B
    int Call() ;
	string m_sReq;
	string m_sRsp;
  public:
	const char* getSendStr();
   //���ؽ��
    const char* getResultStr();

    int Call(const string &sTid, bsapi::CStringMap &iodat);
    bool GetZtcUserInfo(bsapi::CStringMap &iodat);
    bool AddZtcTransLog(bsapi::CStringMap &iodat);
    bool UptZtcTransLog(bsapi::CStringMap &iodat);
      
    bool AddNewCftUser(bsapi::CStringMap &iodat);
    bool AddNewSpUser(bsapi::CStringMap &iodat);

    bool RegsterActUser(bsapi::CStringMap &iodat);
    bool QueryActStatus(bsapi::CStringMap &iodat);
    bool UpdateActStatus(bsapi::CStringMap &iodat);
    bool InqIndex(bsapi::CStringMap &iodat);
    bool AddIndex(bsapi::CStringMap &iodat);
    bool DelIndex(bsapi::CStringMap &iodat);
    bool CheckEleLimit(bsapi::CStringMap &iodat);
    bool AddEleIndex(bsapi::CStringMap &iodat);
    
  CMiniCli(){};
  virtual ~CMiniCli(){};
};



#endif /* CMINICLI_H_HEADER_INCLUDED_BB16E7C3 */
