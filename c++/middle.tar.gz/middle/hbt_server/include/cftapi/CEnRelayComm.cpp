#include "CEnRelayComm.h"
#include "qpay_encrypt_client.h"

//##ModelId=44E2B288032C
bool cftapi::CEnRelayComm::SendRecv(bsapi::CStringMap mReq,bsapi::CStringMap & mRes)
{  
  string sReq;
  if(mReq.GenString(sReq,"&","=") != 0)
  {
    m_sLastErrInfo = "pack error";
    return false;
  }
//   cout << sReq <<endl;
  //
  char szDigit[128];
  memset(szDigit,0,sizeof(szDigit));
  GenerateDigest((char *)sReq.c_str(), szDigit, sizeof(szDigit)-1);
  sReq += "&abstract=";
  sReq += mReq.UrlEncode(szDigit);
  
//   cout << sReq <<endl;
  //
  char szDest[1024*5];
  memset(szDest,0,sizeof(szDest));
  
  if(Encrypt(m_sSpId.c_str(),(char *)sReq.c_str(),szDest,sizeof(szDest)-1) != 0)
    return false;
    
    bsapi::CStringMap t_mReq;
  t_mReq["ver"] = mReq["ver"];
  t_mReq["head_u"] = mReq["head_u"];
  t_mReq["sp_id"] = mReq["sp_id"];
  t_mReq["request_type"] = mReq["request_type"];
  //t_mReq["request_text"] = mReq.UrlEncode(szDest);
  t_mReq["request_text"] = szDest;
  
  sReq = "";
  t_mReq.GenString(sReq,"&","=");
  
  char * pszRes ; int iRes;
  
  if(!CRelayComm::SendRecv(sReq.c_str(),sReq.size(),&pszRes,iRes))
    return false;
  
  if(pszRes == NULL)
    return false;
    
  mRes.SnapElement(pszRes);
  if(atoi(mRes["result"].c_str()) == 0)
  {
    return true;
  }
  return false;
}

