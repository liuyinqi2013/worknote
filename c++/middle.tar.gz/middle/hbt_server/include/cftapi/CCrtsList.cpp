#include "CCrtsList.h"


const char * const cftapi::CCrtsList::szReqType = "2304";

string cftapi::CCrtsList::GetValue(string key, bool bEncode)
{
	if(bEncode)
		return m_mRes.UrlEncode(m_mRes[key]);
	else
		return m_mRes[key];
}

/*
# ��ѯ�û�֤�� 
2304:0:0:2:crt_query_service:Crt_QueryCrt:Crt_QueryCrtSuc:Crt_QueryCrtFail
*/  
/*******************************************************
 *������uid�û��ڲ�id��uip�û���¼ip
 *�����1 ��ͨ 2 δ��ͨ 3 ����
 *���ܣ���ѯ�û��Ƿ�ͨ����֤�� 
*******************************************************/
//##ModelId=44E2C659030D
int cftapi::CCrtsList::GetList(const CrtsQuery& req,std::vector<CrtInfo>& CrtVec, int crtType)
{
  m_mReq["uid"] = req.uid;
  m_mReq["client_ip"] = req.uip;
  //������֤�����Ͳ�ѯ,Ĭ�ϲ���վ����crtType=1. added by chrisxiao
  if(crtType!=0)
  {
    char szCrtType[8]={0};
    snprintf(szCrtType,sizeof(szCrtType),"%d",crtType);
    m_mReq["crt_type"] = szCrtType;
  }
  
  m_mReq["offset"] = req.offset;
  if(!req.cn.empty()) m_mReq["cn"] = req.cn;
  if(!req.stime.empty()&&!req.etime.empty())
  {
    m_mReq["s_time"] = req.stime;
    m_mReq["e_time"] = req.etime;
  }
  if(!req.limit.empty()) m_mReq["limit"] = req.limit;
  if(!req.state.empty()) m_mReq["state"] = req.state;
  m_mReq["head_u"] = m_sOperId;
  m_mReq["ver"] = m_sVersion;
  m_mReq["sp_id"] = m_sSpId;
  m_mReq["request_type"] = szReqType;
  
  string sReq;
  if(m_mReq.GenString(sReq,"&","=") != 0)
  {
    m_sLastErrInfo = "pack error";
    return -1;
  }
  
  char * pszRes; int iRes;
  
  if(!SendRecv(sReq.c_str(),sReq.size(),&pszRes,iRes))
    return -1;
  
  if(pszRes == NULL)
    return -1;
  
  int result=*(int *)pszRes;
  result=ntohl(result);
  if(result!=0)
  {
    char *pres_info=(char *)(pszRes+sizeof(int));
    m_sLastErrInfo=pres_info;
    return -1;
  }
  int ret_num=*(int *)(pszRes+sizeof(int));
  //ret_num=ntohl(ret_num);
  int total_num=*(int *)(pszRes+2*sizeof(int));
  TotalNum = total_num;
  //total_num=ntohl(total_num);
  if(ret_num*sizeof(CrtInfo)!=iRes-3*sizeof(int))
  {
    char buf[100];
    snprintf(buf,sizeof(buf),"result pack length[%d] error should be[%d][%d][%d]",iRes,ret_num*sizeof(CrtInfo),ret_num,sizeof(CrtInfo) );
    m_sLastErrInfo = buf;
    return -1;
  }
  CrtInfo *pRes=(CrtInfo *)(pszRes+3*sizeof(int));
  CrtVec.clear();
  CrtInfo tmp;
  for(int i=0;i<ret_num;i++)
  {
    tmp=pRes[i];
    //tmp.iUid=ntohl(tmp.iUid);
    //tmp.iState=ntohl(tmp.iState);
    CrtVec.push_back(tmp);
  }
  return ret_num;
}


