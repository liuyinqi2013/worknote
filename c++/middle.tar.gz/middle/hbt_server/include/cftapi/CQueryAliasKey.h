#ifndef CQueryAliasKey_H_HEADER_INCLUDED_BB1D1E69
#define CQueryAliasKey_H_HEADER_INCLUDED_BB1D1E69

#include "CStringMap.h"
#include "CRelayComm.h"


//##ModelId=44E2B49A00DA
class cftapi::CQueryAliasKey : public cftapi::CRelayComm
{
  public:
    //##ModelId=44E2C659030D
    string GetValue(string key);
    //##ModelId=44E2C0C301B5
    bool Query(
        // �û���¼�� qq����
        string uin,
        //��������� 1���󶨼��� 2��ע�ἤ��
        string active_type,
        // ������IP
        string uip,
        string chnid);
  private:    
    static const char * const szReqType ;
    //##ModelId=44E2C070001F
    bsapi::CStringMap m_mReq;


    //##ModelId=44E2C0850213
    bsapi::CStringMap m_mRes;

};


#endif /* CQueryAliasKey_H_HEADER_INCLUDED_BB1D1E69 */
