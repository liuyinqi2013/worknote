#include "CCftComm.h"

//##ModelId=44DC4F410128
void cftapi::CCftComm::Init(string sIp, int iPort, int iTmOut, string sEleSep, string sNvSep, int iTmOutConn)
{
  m_sSvrIp = sIp;
  m_iSvrPort = iPort;
  m_iSvrTmOut = iTmOut;
  m_sEleSep = sEleSep;
  m_sNvSep = sNvSep;

  m_iSvrTmOutConn = iTmOutConn;
  
  m_sLastErrInfo = "";
}

//##ModelId=44DC4F410138
string cftapi::CCftComm::GetLastError() const
{
  return m_sLastErrInfo;
}

