/**
  * FileName: StaticParam.h
  * Author: verminniu
  * Version :1.0
  * Date: 2008-01-16
  * Description: ���泣��������Ϣ
  * ChangeList:
  *			2008-01-16		Created by verminniu
  */

#ifndef    __STATIC_PARAM_H
#define    __STATIC_PARAM_H

#include <time.h>
#include <string>
#include <map>
#include <sstream>
using namespace std;

// ���ò����б�
#define   STATIC_PARAM_TIMESTAMP "$(AS_TIMESTAMP)"

typedef  string (*DescStatic)();


class CStaticParam{
	map<string, DescStatic> __StringDescStaticMap;
	
public:
	CStaticParam();
	void DescParam(string& strInBuf);

	static string GetTimeStamp();
};

// �����ṩ�Ľӿ�
void DescStaticParam(string& strInBuf);

#endif
 

