#ifndef BillNO_Client_H
#define BillNO_Client_H

extern "C" {
#include <sys/types.h>
}


static const int  BILL_OPCODE_BANKCMB = 1;
static const int  BILL_OPCODE_BANKICBC = 2;


class BillNO{

private:
	int	m_iSocket;
	char	m_sErrMsg[200];
	char	m_sIP[20];
	int	m_iPort;
	
protected:
	int htconnect(char *domain,int port);
	int SockRead(int sockfd,char* buf,size_t count,size_t MinCount);
	int SendAndReceive(char *Buf,int iSendLen,int iMinRecvLen,int iMaxRecvLen, int timeOut=2000);

public:
	BillNO();
	BillNO(char* sIP,int iPort);  
	char *getErrMsg(char* sErrMsg){
		strcpy(sErrMsg,m_sErrMsg);
		return(sErrMsg);
	}

	int getBillNO(const int iOpCode,unsigned int* piBillNO, int timeOut=2000);	/*timeout ��λms */
};	

#endif
