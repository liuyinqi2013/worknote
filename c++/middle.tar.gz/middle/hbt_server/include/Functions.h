/**
* FileName: Functions.h
* Author: verminniu
* Version :1.0
* Date: 2008-01-16
* Description: ���в��������Ļ���
* ChangeList:
*			2008-01-16		Created by verminniu
*/

#ifndef     __AIRPLANE_FUNCTIONS_H
#define     __AIRPLANE_FUNCTIONS_H

#include "exception.h"

class CFunction
{
public:
	// ���ܺ���
	virtual void EncodeFun(const char * szInBuf, int iInLength, char * szOutBuf, int & iOutLength) throw(CException); 
};

#endif
