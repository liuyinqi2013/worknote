/**
 *     @file   codeConverter.h
 *     @brief  �ַ�������ת������
 *     @author bondshi
 *     @date   2006/08/14
 */

#ifndef __CODE_CONVERTER_H__
#define __CODE_CONVERTER_H__

//////////////////////////////////////////////////////////////////////////

#ifdef WIN32

#include <windows.h>
#define CP_UNICODE  1024

inline int
getCodePage(const char* page_name)
{    
    if (stricmp(page_name, "UNICODE") == 0)
        return 0;
    
    if (stricmp(page_name, "GB2312") == 0)
        return CP_ACP;

    if (stricmp(page_name, "UTF-8") == 0)
        return CP_UTF8;

    if (stricmp(page_name, "UTF-7") == 0)
        return CP_UTF7;

    return -1;
}

inline int 
codeConvertWin32(const char* src_page, const char* dst_page,
                 const char* szSource, int sourceSize,
                 char* szDestBuff, int destBuffSize
                )
{
    int srcCP = getCodePage(src_page);
    int dstCP = getCodePage(dst_page);
    if (srcCP == -1 || dstCP == -1)
        return -1;

    if (sourceSize == -1)
        sourceSize = strlen(szSource);

    int ret = -1;    
    if (srcCP == CP_UNICODE)
    {
        const WCHAR* wszText = (const WCHAR*)szSource;
        int wchCount = (sourceSize >> 1);
        
        ret = WideCharToMultiByte(dstCP, 0, wszText, wchCount, szDestBuff, destBuffSize, NULL, NULL);
        if (ret == 0)
            ret = -1;

        return ret;
    }

    if (dstCP == CP_UNICODE)
    {
        WCHAR* uniBuff = (WCHAR*)szDestBuff;
        int wchCount = destBuffSize / sizeof(WCHAR);

        ret = MultiByteToWideChar(srcCP, 0, szSource, sourceSize, uniBuff, wchCount);
        if (ret == 0)
            ret = -1;

        return (ret * sizeof(WCHAR));        
    }

    WCHAR* uniBuff = new WCHAR[sourceSize + 1];    
    memset(uniBuff, 0, 2 * (sourceSize + 1));
    ret = MultiByteToWideChar(srcCP, 0, szSource, sourceSize, uniBuff, sourceSize);
    if (ret == 0)
    {
        delete uniBuff;
        return -1;
    }

    ret = WideCharToMultiByte(dstCP, 0, uniBuff, -1, szDestBuff, destBuffSize, NULL, NULL);
    delete uniBuff;

    if (ret == 0)
        return -1;    

    return ret;
}

#else

#include <iconv.h>

inline int
codeConvertUnix(const char* src_page, const char* dst_page,
                const char* szSourceText, int inLength,
                char* szDestBuff, int bufSize)
{
    iconv_t conv;
    conv = iconv_open(dst_page, src_page);
    if (conv == (iconv_t)-1)
        return -1;
    
    char* ptrInput = (char*)szSourceText;
    char* ptrOutput = szDestBuff;
    
    size_t nInLeft = inLength;
    size_t nOutLeft = bufSize;
    
    size_t ret;
    ret = iconv(conv, &ptrInput, &nInLeft, &ptrOutput, &nOutLeft);
    iconv_close(conv);
    
    if (ret == (size_t)-1)
        return -1;
    
    return (bufSize - nOutLeft);
}

#endif // WIN32


inline int codeConvert(const char* src_page, const char* dst_page,
                       const char* szSource, int sourceSize,
                       char* szDestBuff, int destBuffSize
                       )
{
    int ret = -1;

#ifdef WIN32
    ret = codeConvertWin32(src_page, dst_page, szSource, sourceSize, szDestBuff, destBuffSize);
#else
    ret = codeConvertUnix(src_page, dst_page, szSource, sourceSize, szDestBuff, destBuffSize);
#endif
    return ret;
}

//////////////////////////////////////////////////////////////////////////

#endif // __CODE_CONVERTER_H__
