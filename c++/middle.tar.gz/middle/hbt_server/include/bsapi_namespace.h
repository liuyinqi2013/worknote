namespace bsapi
{
  class CStr2Map;
  class CStrVector;
  class CStringArray;
	class CStringMap;
};
