/**
* FileName: FunWrapper.h
* Author: verminniu
* Version :1.0
* Date: 2008-01-16
* Description: ��װ��������
* ChangeList:
* 		2008-01-16		Created by verminniu
*/


#ifndef    __AIRPLANE_FUNWRAPPER_H
#define    __AIRPLANE_FUNWRAPPER_H

#include   "Functions.h"
#include   "FunList.h"

#include   "Md5EncodeFun.h"
#include   "Error.h"
#include   "exception.h"

#include   <sstream>
using namespace std;

class CFunWrapper
{
private:
	CFunction *  m_ObjFun;
	
public:
	CFunWrapper();
	~CFunWrapper();

	void Init(const char * szFunName) throw(CException);
	void DeInit();
	void Encode(const char * szInBuf, int iInLength, char * szOutBuf, int & iOutLength) throw(CException); 
};

#endif

