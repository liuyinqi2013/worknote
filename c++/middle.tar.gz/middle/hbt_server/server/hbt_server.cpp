#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <libgen.h>

#include "trpc_server.h"



TRPC_EXPORT int
trpc_svr_loadconf(const char *conf_path)
{
    trpc_debug_log("Into trpc_svr_loadconf(%s)\n", conf_path);

    return 0;
}

TRPC_EXPORT int
trpc_svr_init(int argc, char **argv)
{
    trpc_debug_log("Into trpc_svr_init\n");

    return 0;
}

TRPC_EXPORT void
trpc_svr_done()
{
    trpc_debug_log("Into trpc_svr_done\n");

    return;
}
