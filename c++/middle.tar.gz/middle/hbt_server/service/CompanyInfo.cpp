/**
  * FileName: CompanyInfo.cpp
  * Author: verminniu
  * Version :1.0
  * Date: 2008-01-16
  * Description: ��˾���������ʵ��
  * ChangeList:
  *			2008-01-16		Created by verminniu
  */

#include "CompanyInfo.h"


extern CCftLogger*	gPtrAppLog;			    	// ��־�ļ�ָ��
extern CCftLogger*	gPtrSysLog;			    	// ��־�ļ�ָ��


CCompanyInfo::CCompanyInfo(char * psSpid, 
				char * psCompanyName, int iOperateType, 
				const char * szReqCharecterSet, const char * szResCharecterSet)
				:
m_strSpid(psSpid),
m_strCompanyName(psCompanyName),
m_iOperateType(iOperateType),
m_strReqCharecterSet(szReqCharecterSet),
m_strResCharecterSet(szResCharecterSet)
{

}

// ���Ӳ���
void
CCompanyInfo::addOperateConf(const char * szOperateName, const char * szOperateUrl, 
			const char * szErrSign, const char * szEnCodeFun, 
			const TemplateConf_T * pObjRequestConf, 
			const TemplateConf_T * pObjRespondConf,
			const TemplateConf_T * pObjErrInfoConf) throw(CException)
{
	//gPtrAppLog->debug("addOperateConf:[%s][%s][%s][%s]",szOperateName, szOperateUrl,
	//		szErrSign,szEnCodeFun);
	m_ObjOperateInfoMap[szOperateName].Init(szOperateName, szOperateUrl,szErrSign,
						szEnCodeFun, pObjRequestConf, pObjRespondConf, pObjErrInfoConf);
}

// ������Ϣ
void CCompanyInfo::dispatchMsg(string strOperateName, 
			       KeyValueMap & objInMap, 
			       KeyValueMap & objOutMap, 
			       string & strOutBuf) throw(CException)
{
	// ��Ӧ�Ĳ���������
	if(m_ObjOperateInfoMap.count(strOperateName) == 0)
	{
		stringstream ssErrMsg;
		ssErrMsg << "UnknownOperate spid: ["<< m_strSpid << "] OperateName: [" << strOperateName 
				<< "] CompnayName: [" << m_strCompanyName << "]";

		throw  CException(ERR_OP_UNKNOWN, ssErrMsg.str());
	}

	// ���ö�Ӧ�Ĳ���
	m_ObjOperateInfoMap[strOperateName].DispatchMsg(objInMap, objOutMap,  
			strOutBuf, m_iOperateType,  
			m_strReqCharecterSet.c_str(), m_strResCharecterSet.c_str());
}

