#include "udp_client.h"
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <sys/msg.h>
#include <netinet/in.h>
#include <netdb.h>        
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <string.h>
#include <time.h>
#include <errno.h>
#include <netdb.h>
#include <unistd.h>
#include <fcntl.h>

int CUdpClient::isReadyToRecv(int sockfd, int timeOut)  
{
	struct timeval tv;
	struct timeval *ptv;
	
	fd_set ready;
	
	int nRet;
	
	if (timeOut >= 2)
	{
		tv.tv_sec = timeOut;
		tv.tv_usec = 0;
		ptv = &tv;
	}
	else
	{
		tv.tv_sec = 10;
		tv.tv_usec = 0;
		ptv = &tv;
	}
	
	FD_ZERO (&ready);
	
	FD_SET (sockfd, &ready);
	
	nRet = select (sockfd + 1, &ready, NULL, NULL, ptv);
	switch (nRet)
	{
	case 0:
		return 0;
	case -1:
		return 0;
	}
	
	if (FD_ISSET (sockfd, &ready))
	{
		return 1;
	}
	
	return 0;
}

CUdpClient::CUdpClient()
{
  	m_sock=-1;
}

CUdpClient::~CUdpClient()
{
	if ( m_sock >= 0 )
	{
		tcp_close();
	}
}

int CUdpClient::init(int port,char * host)
{  
  m_sock = TcpConnect(port,host);
  if ( m_sock<0 ) {
     return ( -1 );	
  }
  return( 0 );  
}

int CUdpClient::tcp_close()
{  
   //shutdown(m_sock, 2);
   close(m_sock); 
   m_sock=-1;
   return ( 0 );	
}

int CUdpClient::recv_msg(unsigned char& msg_code,bsapi::CStringMap& paramter,int timeout)
{
	char recv_buf[MAX_UDP_DATA_LEN]={0};
	int ret = read_data(recv_buf,MAX_UDP_DATA_LEN,timeout);
	if ( ret < 4 || ret >= MAX_UDP_DATA_LEN)
	{
		return -1;
	}
	short recv_data_len = (unsigned char)recv_buf[0] *256 + (unsigned char)recv_buf[1];
	if ( recv_data_len != ret )
	{
		return -2;
	}
	paramter.SnapElement(recv_buf+4);
	return 0;
}

int CUdpClient::read_data( char *context,int len,int timeout )
{
    struct sockaddr_in from_addr;
  int i=0;
  
  if( isReadyToRecv(m_sock,timeout)!=1 ) 
  {
  	return( -1 );  
  }
  socklen_t src_len = sizeof(from_addr);
  i = recvfrom( m_sock, context, len,0, (struct sockaddr *)&from_addr, &src_len);
    
  return(i);

}
int CUdpClient::send_msg(unsigned char msg_code,bsapi::CStringMap& paramter)
{
	char msg_buf[MAX_UDP_DATA_LEN]={0};
	std::string strOutParam;
	paramter.GenString(strOutParam);
	short snd_data_len = 4+strOutParam.length();
	if ( snd_data_len >= MAX_UDP_DATA_LEN )
	{
		return -2;
	}
	strcpy((char*)(msg_buf+4),strOutParam.c_str());
	msg_buf[0] = (snd_data_len >> 8) & 0xff;
	msg_buf[1] = (snd_data_len ) & 0xff;
	msg_buf[2] = 0;
	msg_buf[3] = msg_code;

	int ret = write_data(msg_buf,snd_data_len);
	if ( ret < snd_data_len )
	{
		return -1;
	}
	return 0;
}
int CUdpClient::write_data( char *context,int len )
{
  int i=0;  
  i=sendto(m_sock,context,len,0,(struct sockaddr *)&dest_addr_, sizeof(struct sockaddr_in));
  return(i);
} 

#define SERV_PORT 27000
int CUdpClient::TcpConnect( int port, char *host)
{   
   struct hostent *h;
   int sock;
   struct sockaddr_in servaddr;

   sock = socket(AF_INET, SOCK_DGRAM,0);
   if ( sock<0 ) {     
     return(-1);
   }
   bzero(&servaddr, sizeof(servaddr));
   servaddr.sin_family = AF_INET;
   servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
   servaddr.sin_port = htons(SERV_PORT);

   

   h=gethostbyname( host );
   if ( !h ) 
   {     
     close (sock); 
     return(-1);
   }
   bzero(&dest_addr_,sizeof(dest_addr_));
   dest_addr_.sin_family = AF_INET;
   bcopy(h->h_addr,&dest_addr_.sin_addr,h->h_length);
   dest_addr_.sin_port = htons( port );
/*
   if(bind(sock, (struct sockaddr *)&servaddr, sizeof(servaddr)) == -1)
   {
   	IPC_ERROR (("TcpConnect bind error."));
   	close(sock);
   	return -1;
   }
   
   if(connect(sock, (struct sockaddr *)&dest_addr_, sizeof(dest_addr_)) == -1)
   {
   	IPC_ERROR (("TcpConnect connect error."));
   	close(sock);
   	return -1;
   }
*/   
   return( sock );
}



