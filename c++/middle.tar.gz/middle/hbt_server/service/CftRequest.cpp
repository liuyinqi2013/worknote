//
// CftRequest.cpp
// Tenpay Request Wrapper Class 
//
// bondshi
// 2007/07/06
//

#include "CftRequest.h"
#include "qpay_encrypt_client.h"
#include "base64.h"
#include "urlcodec.h"
#include "CftLogger.h"
#include "CStringMap.h"
#include <sstream>
#include "Error.h"
using namespace std;

static const int _MAX_REQUEST_SIZE = 4096;

extern CCftLogger*	gPtrAppLog;			    		// ��־�ļ�ָ��
extern CCftLogger*	gPtrSysLog;			    		// ��־�ļ�ָ��


//////////////////////////////////////////////////////////////////////////

string decrypt(const string& spid, const string& srcStr) throw(CException)
{
    int olen = 0;
    const char* pszSpid = spid.c_str();
    unsigned char szTmpString[_MAX_REQUEST_SIZE] = {0};

    // base64 decode
    int ret = Base64_Decode(srcStr.c_str(), srcStr.length(), szTmpString, sizeof(szTmpString), &olen);
    if (ret != 0) {
		stringstream ssErrMsg;
		ssErrMsg << "Base64_Decode fail: "<< srcStr.c_str() ;

		throw CException(ERR_APP_PARAM, ssErrMsg.str());
    }

    ST_PUB_ANS ans;
    memset(&ans, 0, sizeof(ans));

    // 3des decrypt
    char szBuff[_MAX_REQUEST_SIZE] = {0};
    qpay_de_3des_v1(pszSpid, szTmpString, olen, (unsigned char*)szBuff, &olen, &ans);

    if (ans.iResult != 0) { 
		stringstream ssErrMsg;
		ssErrMsg << "qpay_de_3des_v1 fail: "<< srcStr.c_str() ;

		throw CException(ERR_APP_PARAM, ssErrMsg.str());
 
    }

    // check digest "abstract=xxx"
    checkDigest(szBuff);

	gPtrAppLog->debug("szBuff: %s", szBuff);
	
    return szBuff;
}

string encrypt(const string& spid, const string& srcStr) throw(CException)
{     
    int olen;
    unsigned char szTmpString[_MAX_REQUEST_SIZE] = {0};

    ST_PUB_ANS ans;
    memset(&ans, 0, sizeof(ans));
    
    #if 0
	bsapi::CStringMap KeyValueMap;
	KeyValueMap["abstract"] = createDigest(srcStr);

	string strIn;
	KeyValueMap.GenString(strIn);

	strIn = srcStr + "&" + strIn;
    #endif
	
    qpay_en_3des_v1(spid.c_str(), 
        (unsigned char*)(srcStr.c_str()), srcStr.length(), 
        szTmpString, &olen, &ans
        );
    
    if (ans.iResult != 0) {
		stringstream ssErrMsg;
		ssErrMsg << "qpay_de_3des_v1 fail: "<< ans.szErrInfo ;

		throw CException(ERR_APP_PARAM, ssErrMsg.str());
    }

    char szBuff[_MAX_REQUEST_SIZE] = {0};
    Base64_Encode(szTmpString, olen, szBuff, sizeof(szBuff), &olen);
    return szBuff;
}

string createDigest(const string& srcStr) throw(CException)
{
    // generate digest
    unsigned char digestBytes[128] = {0};
    int olen = 0;         
    
    memset(digestBytes, 0, sizeof(digestBytes));
    int ret = qpay_generate_digest_sha1(srcStr.c_str(), 
	digestBytes, 
	&olen);
    
    if (ret != 0)
	{
		stringstream ssErrMsg;
		ssErrMsg << "generate digest fail: "<< srcStr.c_str() ;

		throw CException(ERR_APP_PARAM, ssErrMsg.str());
	}
    
    char digest[512] = {0};
    memset(digest, 0, sizeof(digest));
    Base64_Encode(digestBytes, olen, digest, sizeof(digest), &olen);
    return digest;
}

void checkDigest(const string& srcStr) throw(CException)
{
    const char* _abstractKey = "abstract=";
    static int _keyLen = 9;

    const char* pszSrcStr = srcStr.c_str();

    // get orignal digest value
    const char* psz1 = strstr(pszSrcStr, _abstractKey);
    if (psz1 == NULL || psz1 == pszSrcStr)
	{
		stringstream ssErrMsg;
		ssErrMsg << "no abstract/source field in src: " << pszSrcStr ;

		throw CException(ERR_APP_PARAM, ssErrMsg.str());
	}
	
    const char* psz2 = psz1 + _keyLen;
    const char* psz3 = strchr(psz2, '&');

    string digest1;
    if (psz3 == NULL)
        digest1 = psz2;
    else
        digest1 = string(psz2, psz3 - psz2);    
    
    // create compare digest    
    string src(pszSrcStr, psz1 - pszSrcStr - 1);
    string digest2 = createDigest(src);
    digest1 = urlDecode(digest1);

    // ����ͻ�������2006֮ǰ��API����, ժҪ�ַ�������ܻ�������
    // �ַ�,��Ҫȥ��
    digest1 = digest1.substr(0, digest2.length());    
    if (digest1 != digest2)
	{
		stringstream ssErrMsg;
		ssErrMsg << "check digest fail: " << pszSrcStr 
				<< " newdigest: " << digest2.c_str();

		throw CException(ERR_APP_PARAM, ssErrMsg.str());
	}
}



