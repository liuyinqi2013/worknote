// StringArray.cpp: implementation of the CStringArray class.
//
//////////////////////////////////////////////////////////////////////

#include "CStringArray.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

bsapi::CStringArray::CStringArray()
{

}

bsapi::CStringArray::~CStringArray()
{

}
void bsapi::CStringArray::SetCommaText(string value, string sep)
{
	SetCommaText(value.c_str(),sep.c_str());
}
void bsapi::CStringArray::SetCommaText(const char* value, const char *sep)
{
	erase(begin(), end());
	
	char* p;
	const char* s = value;
	do
	{
		p = strpbrk(s, sep);
		if (p)
		{
			if (p == s)
			{
				p++;
				s++;
			}
			else
			{
				string tmp(s, p - s);
				push_back(tmp);
				
				p++;
				s = p;
			}
		}
		else
		{
			if (strlen(s))
			{
				string tmp(s);
				push_back(tmp);
			}
		}
	} while (p);
}
