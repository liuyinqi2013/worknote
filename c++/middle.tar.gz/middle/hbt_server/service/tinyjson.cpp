#include "tinyjson.h"
#include <iostream>

extern CCftLogger*	gPtrAppLog;	// ��־�ļ�ָ��

void TinyJson::CJson::initConstStr()
{
	jsonObjBeginTag="{";
	jsonObjEndTag="}";
	jsonArrayBeginTag="["; 
	jsonArrayEndTag="]";
	jsonNameBeginTag="\"";
	jsonNameEndTag="\"";
	jsonStrValueBeginTag="\"";
	jsonStrValueEndTag="\"";
	jsonNameValueSeparator=":";
	jsonElementSeparator=",";
}

std::string TinyJson::CJson::getString(std::string name,std::string defaultStr)
{
	if (mStrMap.count(name) != 0)
	{
		return mStrMap[name];
	}
	else
	{
		return defaultStr;
	}
}

void TinyJson::CJson::setString(std::string name,const std::string& value)
{
	mStrMap[name] = value;

	if (empty()) setUnEmpty();
}


int TinyJson::CJson::getInt(std::string name,int defaultInt)
{
	if (mIntMap.count(name) != 0)
	{
		return mIntMap[name];
	}
	else
	{
		return defaultInt;
	}
}

void TinyJson::CJson::setInt(std::string name,const int& value)
{
	mIntMap[name] = value;

	if (empty()) setUnEmpty();
}

void TinyJson::CJson::setObj(std::string name,const CJson& mJson)
{
	mMapMap[name] = mJson;

	if (empty()) setUnEmpty();
}

TinyJson::CJson TinyJson::CJson::getObj(std::string name)
{
	if (mMapMap.count(name) != 0)
	{
		return mMapMap[name];
	}
	else
	{
		CJson mJson;
		return mJson;
	}
}

void TinyJson::CJson::setArray(std::string name,const TinyJsonArray& mJsonVec)
{
	mArrayMap[name]=mJsonVec;

	if (empty()) setUnEmpty();
}

TinyJson::TinyJsonArray TinyJson::CJson::getArray(std::string name)
{
	if (mArrayMap.count(name) != 0)
	{
		return mArrayMap[name];
	}
	else
	{
		TinyJsonArray mJsonVec;
		return mJsonVec;
	}
}

std::string TinyJson::CJson::TrimLeftSpace(std::string& inStr)
{
	if( inStr.empty() )
	{
		return inStr;
	}

	int i=0;
	while( (inStr[i]==' ' || inStr[i]=='\r' || inStr[i]=='\n') && i<inStr.size() )
	{
		i++;
	}

	//���ַ�����β��
	if( i>=inStr.size() )
	{
		std::string outStr="";
		return outStr;
	} 

	return inStr.substr(i);
}

std::string TinyJson::CJson::TrimRightSpace(std::string& inStr)
{
	if( inStr.empty() )
	{
		return inStr;
	}

	int i=inStr.size()-1;
	while( (inStr[i]==' ' || inStr[i]=='\r' || inStr[i]=='\n') && i>=0 )
	{
		i--;
	}

	//���ַ�����β��
	if( i<=-1 )
	{
		std::string outStr="";
		return outStr;
	} 

	return inStr.substr(0,i+1);
}

std::string TinyJson::CJson::TrimSpace(std::string& inStr)
{
	inStr=TrimLeftSpace(inStr);
	inStr=TrimRightSpace(inStr);

	return inStr;
}

bool TinyJson::CJson::isNumber(std::string instr)
{
	if( instr.empty() )
	{
		return false;
	}

	for(int i=0;i<instr.size();i++)
	{
		if( instr[i]<48 || instr[i]>57 )
		{
			return false;
		}
	}

	return true;
}

bool TinyJson::CJson::isFloat(std::string instr)
{
	if (instr.empty())
	{
		return false;
	}

	for (int i = 0; i < instr.size(); i++)
	{
		if (!((instr[i] >= 48 && instr[i] <= 57) || instr[i] == 46))  // �������ּ���С����
		{
			return false;
		}
	}

	return true;
}

bool TinyJson::CJson::isBool(std::string instr)
{
	if (instr.empty())
	{
		return false;
	}

	if (instr != "true" && instr != "false")
	{
		return false;
	}

	return true;
}

TinyJson::JsonValueType TinyJson::CJson::getValueType(std::string& inStr)
{
	inStr=TrimLeftSpace(inStr);
	if (inStr.empty())
	{
		return JSON_VALUE_NULL;
	}

	if (inStr[0] == jsonObjBeginTag[0])
	{
		return JSON_VALUE_OBJECT;
	}
	else if (inStr[0] == jsonArrayBeginTag[0])
	{
		return JSON_VALUE_ARRAY;
	}
	else if (inStr[0] == jsonStrValueBeginTag[0])
	{
		return JSON_VALUE_STRING;
	}

	std::string integStr;
	for (int i = 0; i < inStr.size(); i++)
	{
		if (inStr[i] == jsonObjEndTag[0] || inStr[i] == jsonArrayEndTag[0] || inStr[i] == jsonElementSeparator[0])
		{
			break;
		}
		integStr += inStr[i];
	}

	if (integStr[0]=='-')
	{
		integStr.erase(0,1);
	}

	if (isNumber(integStr))
	{
		return JSON_VALUE_INT;
	}

	if (isFloat(integStr))
	{
		return JSON_VALUE_FLOAT;
	}

	if (isBool(integStr))
	{
		return JSON_VALUE_BOOL;
	}

	return JSON_VALUE_NULL;
}

bool TinyJson::CJson::getArrayStart(std::string& arrayJsonStart,std::string& inStr)
{
	inStr = TrimLeftSpace(inStr);
	if (inStr.empty())
	{
		setError(ERR_INSTR_ERRFORMAT,"src format error[can not get array start tag]");
		return true;
	}

	if (inStr[0] == jsonArrayBeginTag[0])
	{
		arrayJsonStart=inStr.substr(0,1);
		inStr.erase(0,1);
		return false;
	}

	setError(ERR_INSTR_ERRFORMAT,"src format error[can not get array start tag]");
	return true;
}

bool TinyJson::CJson::getArrayEnd(std::string& arrayJsonEnd,std::string& inStr)
{
	inStr=TrimLeftSpace(inStr);
	if( inStr.empty() )
	{
		setError(ERR_INSTR_ERRFORMAT,"src format error[can not get array end tag]");
		return true;
	}

	if( inStr[0]==jsonArrayEndTag[0] )
	{
		arrayJsonEnd=inStr.substr(0,1);
		inStr.erase(0,1);
		return false;
	}

	setError(ERR_INSTR_ERRFORMAT,"src format error[can not get array end tag]");
	return true;
}


bool TinyJson::CJson::getObjStart(std::string& objJsonStart,std::string& inStr)
{
	inStr=TrimLeftSpace(inStr);
	if( inStr.empty() )
	{
		setError(ERR_INSTR_ERRFORMAT,"src format error[can not get obj start tag]");
		return true;
	}

	if( inStr[0]==jsonObjBeginTag[0] )
	{
		objJsonStart=inStr.substr(0,1);
		inStr.erase(0,1);
		return false;
	}

	setError(ERR_INSTR_ERRFORMAT,"src format error[can not get obj start tag]");
	return true;
}

bool TinyJson::CJson::getObjEnd(std::string& objJsonEnd,std::string& inStr)
{
	inStr=TrimLeftSpace(inStr);
	if( inStr.empty() )
	{
		setError(ERR_INSTR_ERRFORMAT,"src format error[can not get obj end tag]");
		return true;
	}

	if( inStr[0]==jsonObjEndTag[0] )
	{
		objJsonEnd=inStr.substr(0,1);
		inStr.erase(0,1);
		return false;
	}

	setError(ERR_INSTR_ERRFORMAT,"src format error[can not get obj end tag]");
	return true;
}

bool TinyJson::CJson::isArrayEnd(std::string& inStr)
{
	inStr=TrimLeftSpace(inStr);
	if( inStr.empty() )
	{
		return false;
	}

	if( inStr[0]==jsonArrayEndTag[0] )
	{
		return true;
	}

	return false;
}

bool TinyJson::CJson::isObjEnd(std::string& inStr)
{
	inStr = TrimLeftSpace(inStr);

	if (inStr.empty())
	{
		return false;
	}

	if (inStr[0] == jsonObjEndTag[0])
	{
		return true;
	}

	return false;
}

bool TinyJson::CJson::getName(std::string& name,std::string& inStr)
{
	inStr = TrimLeftSpace(inStr);

	if(inStr.empty())
	{
		setError(ERR_INSTR_ERRFORMAT,"src format error[can not get name]["+name+"]");
		return true;
	}

	if (inStr[0] != jsonNameBeginTag[0])
	{
		setError(ERR_INSTR_ERRFORMAT,"src format error[can not get name]["+name+"]");
		return true;
	}

	name="";
	for(int i=1;i<inStr.size();i++)
	{
		if( inStr[i]==jsonNameEndTag[0] )
		{
			break;
		}
		name+=inStr[i];
	}

	if( name.size()==inStr.size()-1 )
	{
		setError(ERR_INSTR_ERRFORMAT,"src format error[can not get name]["+name+"]");
		return true;
	}

	if( name.empty() )
	{
		setError(ERR_INSTR_ERRFORMAT,"src format error[can not get name]["+name+"]");
		return true;
	}

	inStr.erase(0,name.size()+2);

	return false;
}

bool TinyJson::CJson::getElemSeparator(std::string& separator,std::string& inStr)
{
	inStr=TrimLeftSpace(inStr);
	if( inStr.empty() )
	{
		setError(ERR_INSTR_ERRFORMAT,"src format error[can not get elem separator]");
		return true;
	}

	if( inStr[0]!=jsonElementSeparator[0] )
	{
		setError(ERR_INSTR_ERRFORMAT,"src format error[can not get elem separator]");
		return true;
	}

	separator=inStr.substr(0,1);

	inStr.erase(0,1);
	return false;
}

bool TinyJson::CJson::getValueSeparator(std::string& separator,std::string& inStr)
{
	inStr=TrimLeftSpace(inStr);
	if( inStr.empty() )
	{
		setError(ERR_INSTR_ERRFORMAT,"src format error[can not get separator]");
		return true;
	}

	if( inStr[0]!=jsonNameValueSeparator[0] )
	{
		setError(ERR_INSTR_ERRFORMAT,"src format error[can not get separator]");
		return true;
	}

	separator=inStr.substr(0,1);

	inStr.erase(0,1);
	return false;
}

bool TinyJson::CJson::Parse()
{
	if( jsonStr.empty() )
	{
		setError(ERR_INSTR_EMPTY,"src string is empty");
		return true;
	}
	std::string tailStr=TrimSpace(jsonStr);

	JsonValueType valueType=getValueType(tailStr);
	if( JSON_VALUE_NULL==valueType )
	{
		setError(ERR_INSTR_ERRFORMAT,"src format error[can not get value type]");
		return true;
	}

	switch( valueType )
	{
		case JSON_VALUE_OBJECT:
			{
				if( getValue(*this,tailStr) )
				{
					return true;
				}
				break;
			};
		case JSON_VALUE_ARRAY:
			{
				TinyJsonArray arrayValue;
				if( getValue(arrayValue,tailStr) )
				{
					return true;
				}
				setTypeArray();
				setArray("array",arrayValue);
				break;
			};
		default:
			{
				setError(ERR_INSTR_ERRFORMAT,"src format error");
				return true;
			};
	}
	if( !tailStr.empty() )
	{
		setError(ERR_INSTR_ERRFORMAT,"src format error");
		return true;
	}
	return false;
}

bool TinyJson::CJson::getValue(std::string& value,std::string& inStr)
{
	inStr=TrimLeftSpace(inStr);
	if( inStr.empty() )
	{
		setError(ERR_INSTR_ERRFORMAT,"src format error[can not get string value]");
		return true;
	}

	if( inStr[0]!=jsonStrValueBeginTag[0] )
	{
		setError(ERR_INSTR_ERRFORMAT,"src format error[can not get string value]");
		return true;
	}

	value="";
	for(int i=1;i<inStr.size();i++)
	{
		if( inStr[i]==jsonStrValueEndTag[0] )
		{
			break;
		}
		value+=inStr[i];
	}

	if( value.size()==inStr.size()-1 )
	{
		setError(ERR_INSTR_ERRFORMAT,"src format error[can not get value]");
		return true;
	}

	//����ֵΪ��
	//    if( value.empty() )
	//    {
	//        setError(ERR_INSTR_ERRFORMAT,"src format error[can not get value]");
	//        return true;
	//    }

	inStr.erase(0,value.size()+2);
	return false;
}

bool TinyJson::CJson::getValue(int& value,std::string& inStr)
{
	inStr=TrimLeftSpace(inStr);
	if( inStr.empty() )
	{
		setError(ERR_INSTR_ERRFORMAT,"src format error[can not get int value]");
		return true;
	}

	std::string integStr;
	for(int i=0;i<inStr.size();i++)
	{
		if( inStr[i]==jsonObjEndTag[0] || inStr[i]==jsonArrayEndTag[0] || inStr[i]==jsonElementSeparator[0] )
		{
			break;
		}
		integStr += inStr[i];
	}

	bool isUnsigned=true;

	if( integStr[0]=='-' )
	{
		integStr.erase(0,1);
		isUnsigned=false;
	}

	if( !isNumber(integStr) )
	{
		setError(ERR_INSTR_ERRFORMAT,"src format error[can not get int value]");
		return true;
	}

	if( isUnsigned )
	{
		value=atoi(integStr.c_str());
		inStr.erase(0,integStr.size());
	}
	else
	{
		value=-atoi(integStr.c_str());
		inStr.erase(0,integStr.size()+1);
	}

	return false;
}

bool TinyJson::CJson::getValue(float &value, std::string& inStr)
{
	inStr = TrimLeftSpace(inStr);

	if (inStr.empty())
	{
		setError(ERR_INSTR_ERRFORMAT,"src format error[can not get int value]");
		return true;
	}

	std::string integStr;
	for (int i = 0; i < inStr.size(); i++)
	{
		if (inStr[i] == jsonObjEndTag[0] || inStr[i] == jsonArrayEndTag[0] || inStr[i] == jsonElementSeparator[0])
		{
			break;
		}
		integStr += inStr[i];
	}

	bool isUnsigned = true;

	if (integStr[0] == '-')
	{
		integStr.erase(0,1);
		isUnsigned = false;
	}

	if (!isFloat(integStr))
	{
		setError(ERR_INSTR_ERRFORMAT,"src format error[can not get int value]");
		return true;
	}

	if (isUnsigned)
	{
		value = atof(integStr.c_str());
		inStr.erase(0, integStr.size());
	}
	else
	{
		value = -atof(integStr.c_str());
		inStr.erase(0, integStr.size()+1);
	}

	return false;
}

bool TinyJson::CJson::getValue(bool &value, std::string& inStr)
{
	inStr = TrimLeftSpace(inStr);

	if (inStr.empty())
	{
		setError(ERR_INSTR_ERRFORMAT,"src format error[can not get int value]");
		return true;
	}

	std::string integStr;
	for (int i = 0; i < inStr.size(); i++)
	{
		if (inStr[i] == jsonObjEndTag[0] || inStr[i] == jsonArrayEndTag[0] || inStr[i] == jsonElementSeparator[0])
		{
			break;
		}
		integStr += inStr[i];
	}

	if (integStr == "true")
	{
		value = true;
	}
	else
	{
		value = false;
	}

	inStr.erase(0, integStr.size());

	return false;
}

bool TinyJson::CJson::getValue(TinyJsonArray& arrayValue,std::string& inStr)
{
	inStr=TrimLeftSpace(inStr);
	if( inStr.empty() )
	{
		setError(ERR_INSTR_ERRFORMAT,"array src string is empty");
		return true;
	}

	//ȥ����Ŀ�ʼ��־
	std::string objArrayStart;
	if( getArrayStart(objArrayStart,inStr) )
	{
		return true;
	}

	//����ȡ���������־�����ֻ�п�ʼ�ͽ�����־�������Ǹ��ն�����ֱ�ӷ���
	std::string objArrayEnd;
	if( !getArrayEnd(objArrayEnd,inStr) )
	{
		return false;
	}

	while( !inStr.empty() && !isArrayEnd(inStr) )
	{
		CJson objValue;
		if( getValue(objValue,inStr) )
		{
			return true;
		}
		arrayValue.push_back(objValue);

		std::string elemSeparator;
		getElemSeparator(elemSeparator,inStr);
	}

	//��ȡ����Ľ�����־
	if( getArrayEnd(objArrayStart,inStr) )
	{
		return true;
	}

	return false;
}

bool TinyJson::CJson::getValue(CJson& objJson,std::string& tailStr)
{
	tailStr=TrimLeftSpace(tailStr);
	if( tailStr.empty() )
	{
		setError(ERR_INSTR_ERRFORMAT,"object src string is empty");
		return true;
	}

	//ȡ����Ŀ�ʼ��־
	std::string objJsonStart;
	if( getObjStart(objJsonStart,tailStr) )
	{
		return true;
	}

	//����ȡ���������־�����ֻ�п�ʼ�ͽ�����־�������Ǹ��ն�����ֱ�ӷ���
	std::string objJsonEnd;
	if( !getObjEnd(objJsonEnd,tailStr) )
	{
		return false;
	}

	while( !tailStr.empty() && !isObjEnd(tailStr) )
	{
		std::string name;
		std::string separator;
		JsonValueType valueType;

		if (getName(name,tailStr))
		{
			return true;
		}

		if (getValueSeparator(separator,tailStr))
		{
			return true;
		}

		valueType = getValueType(tailStr);
		if (JSON_VALUE_NULL == valueType)
		{
			setError(ERR_INSTR_ERRFORMAT,"src format error[can not get value type]");
			return true;
		}

		char str_tmp[64+1];
		switch (valueType)
		{
			case JSON_VALUE_STRING:
				{
					std::string strValue;
					if (getValue(strValue, tailStr))
					{
						return true;
					}
					objJson.setString(name,strValue);
					break;
				};
			case JSON_VALUE_INT:
				{
					int intValue;
					if (getValue(intValue,tailStr))
					{
						return true;
					}
					snprintf(str_tmp, sizeof(str_tmp), "%d", intValue);
					objJson.setString(name, str_tmp);
					break;
				};
			case JSON_VALUE_FLOAT:
				{
					float float_value;
					if( getValue(float_value,tailStr) )
					{
						return true;
					}
					snprintf(str_tmp, sizeof(str_tmp), "%.2f", float_value);
					objJson.setString(name, str_tmp);
					break;
				}
			case JSON_VALUE_BOOL:
				{
					bool flag = false;
					if (getValue(flag, tailStr))
					{
						return true;
					}
					if (flag)
					{
						snprintf(str_tmp, sizeof(str_tmp), "1");
					}
					else
					{
						snprintf(str_tmp, sizeof(str_tmp), "0");
					}
					objJson.setString(name, str_tmp);
					break;
				}
			case JSON_VALUE_OBJECT:
				{
					CJson objValue;
					if (getValue(objValue,tailStr))
					{
						return true;
					}
					objJson.setObj(name,objValue);
					break;
				};
			case JSON_VALUE_ARRAY:
				{
					TinyJsonArray arrayValue;
					if (getValue(arrayValue,tailStr))
					{
						return true;
					}
					objJson.setArray(name,arrayValue);
					break;
				};
			default:
				{
					setError(ERR_INSTR_ERRFORMAT,"object format error");
					return true;
				};
		}
		std::string elemSeparator;
		getElemSeparator(elemSeparator,tailStr);
	}

	//��ȡ����Ľ�����־
	if( getObjEnd(objJsonEnd,tailStr) )
	{
		return true;
	}

	return false;
}

std::ostream& operator<<(std::ostream& out,TinyJson::CJson& tJson)
{
	out << tJson.toString();

	return out;
}
/*
 * comview  ��ͼģʽ true�������ͼ������޸�ʽ����     falseֱ����ͼ������и�ʽ����
 * depth    �ݹ����
 * viewtagWidth   ��ʽ���ݿ���
 */

std::string TinyJson::CJson::toString(bool comview,unsigned int depth,unsigned int viewtagWidth)
{
	std::string viewTag;
	if( !comview )
	{
		std::string tmpStr;
		for(unsigned int i=0;i<viewtagWidth;i++)
		{
			tmpStr+="*";
		}
		viewTag+="\n";
		for(unsigned int i=0;i<depth;i++)
		{
			viewTag+=tmpStr;
		}

	}

	std::stringstream sstr;

	if( empty() )
	{
		sstr<<jsonObjBeginTag<<jsonObjEndTag;
		return sstr.str();
	}

	if( JSON_CLASS==getClassType() )
	{
		sstr<<viewTag<<jsonObjBeginTag;
		if( mStrMap.size()!=0 )
		{
			int length=mStrMap.size();
			int loop=0; //�����Ƿ��ӡ���һ���ָ���
			for(std::map<std::string,std::string>::iterator iter=mStrMap.begin();iter!=mStrMap.end();++iter)
			{
				loop++;
				sstr<<viewTag<<jsonNameBeginTag<<iter->first<<jsonNameEndTag
					<<jsonNameValueSeparator
					<<jsonStrValueBeginTag<<iter->second<<jsonStrValueEndTag;
				if( loop<length )
				{
					sstr<<jsonElementSeparator;
				}
			}
			if( mIntMap.size()!=0 || mMapMap.size()!=0 || mArrayMap.size()!=0 )
			{
				sstr<<jsonElementSeparator;
			}
		}

		if( mIntMap.size()!=0 )
		{
			int length=mIntMap.size();
			int loop=0; //�����Ƿ��ӡ���һ���ָ���
			for(std::map<std::string,int>::iterator iter=mIntMap.begin();iter!=mIntMap.end();++iter)
			{
				loop++;
				sstr<<viewTag<<jsonNameBeginTag<<iter->first<<jsonNameEndTag
					<<jsonNameValueSeparator
					<<iter->second;
				if( loop<length )
				{
					sstr<<jsonElementSeparator;
				}
			}
			if( mMapMap.size()!=0 || mArrayMap.size()!=0 )
			{
				sstr<<jsonElementSeparator;
			}
		}

		if( mMapMap.size()!=0 )
		{
			int length=mMapMap.size();
			int loop=0; //�����Ƿ��ӡ���һ���ָ���
			for(std::map<std::string,CJson>::iterator iter=mMapMap.begin();iter!=mMapMap.end();++iter)
			{
				loop++;
				sstr<<viewTag<<jsonNameBeginTag<<iter->first<<jsonNameEndTag
					<<jsonNameValueSeparator
					<<iter->second.toString(comview,depth+1,viewtagWidth);
				if( loop<length )
				{
					sstr<<jsonElementSeparator;
				}
			}
			if( mArrayMap.size()!=0 )
			{
				sstr<<jsonElementSeparator;
			}
		}

		if( mArrayMap.size()!=0 )
		{
			int length=mArrayMap.size();
			int loop=0; //�����Ƿ��ӡ���һ���ָ���
			for(std::map<std::string,TinyJsonArray>::iterator iter=mArrayMap.begin();iter!=mArrayMap.end();++iter)
			{
				loop++;
				sstr<<viewTag<<jsonNameBeginTag<<iter->first<<jsonNameEndTag
					<<jsonNameValueSeparator
					<<jsonArrayBeginTag;

				if( iter->second.size()==0 )
				{
					sstr<<jsonArrayEndTag;
				}
				else
				{
					for(int i=0;i<iter->second.size();++i)
					{
						sstr<<iter->second[i].toString(comview,depth+2,viewtagWidth);

						if( i<iter->second.size()-1 )
						{
							sstr<<jsonElementSeparator;
						}
					}
					sstr<<viewTag<<jsonArrayEndTag;
				}

				if( loop<length )
				{
					sstr<<jsonElementSeparator;
				}
			}
		}

		sstr<<viewTag<<jsonObjEndTag;
		return sstr.str();
	}
	else
	{
		sstr<<viewTag<<jsonArrayBeginTag;

		if( mArrayMap["array"].size()==0 )
		{
			sstr<<viewTag<<jsonArrayEndTag;
		}
		else
		{
			for(int i=0;i<mArrayMap["array"].size();++i)
			{
				sstr<<viewTag<<mArrayMap["array"][i].toString(comview,depth+1,viewtagWidth);

				if( i<mArrayMap["array"].size()-1 )
				{
					sstr<<viewTag<<jsonElementSeparator;
				}
			}
			sstr<<viewTag<<jsonArrayEndTag;
		}
	}

	return sstr.str();
}


TinyJson::JsonValueType TinyJson::CJson::find(const std::string& key)
{
	if( mStrMap.find(key)!=mStrMap.end() )
	{
		return JSON_VALUE_STRING;
	}

	if( mIntMap.find(key)!=mIntMap.end() )
	{
		return JSON_VALUE_INT;
	}

	if( mMapMap.find(key)!=mMapMap.end() )
	{
		return JSON_VALUE_OBJECT;
	}

	if( mArrayMap.find(key)!=mArrayMap.end() )
	{
		return JSON_VALUE_ARRAY;
	}

	return JSON_VALUE_NULL;
}

std::string& TinyJson::CJson::operator[](std::string& key)
{
	setUnEmpty();
	return mStrMap[key];
}

std::string& TinyJson::CJson::operator[](const std::string& key)
{
	setUnEmpty();
	return mStrMap[key];
}

TinyJson::CJson  TinyJson::CJson::operator + (const TinyJson::CJson& objJsonA)
{
	TinyJson::CJson outJson;

	outJson=objJsonA;

	for(std::map<std::string,std::string>::iterator iter=this->mStrMap.begin();iter!=this->mStrMap.end();++iter)
	{
		outJson.setString(iter->first,iter->second);
	}

	for(std::map<std::string,int>::iterator iter=this->mIntMap.begin();iter!=this->mIntMap.end();++iter)
	{
		outJson.setInt(iter->first,iter->second);
	}

	for(std::map<std::string,TinyJson::CJson>::iterator iter=this->mMapMap.begin();iter!=this->mMapMap.end();++iter)
	{
		outJson.setObj(iter->first,iter->second);
	}

	for(std::map<std::string,TinyJsonArray>::iterator iter=this->mArrayMap.begin();iter!=this->mArrayMap.end();++iter)
	{
		outJson.setArray(iter->first,iter->second);
	}

	return outJson;
}

int TinyJson::CJson::size()
{
	if( empty() )
	{
		return 0;
	}

	if( getClassType()==JSON_CLASS )
	{
		return mStrMap.size()+mIntMap.size()+mMapMap.size()+mArrayMap.size();
	}
	else if( getClassType()==JSON_ARRAY )
	{
		return mArrayMap["array"].size();
	}

	return 0;
}

std::vector<std::string> TinyJson::CJson::getAllName()
{
	std::vector<std::string> outVec;

	for(std::map<std::string,std::string>::iterator iter=this->mStrMap.begin();iter!=this->mStrMap.end();++iter)
	{
		outVec.push_back(iter->first);
	}

	for(std::map<std::string,int>::iterator iter=this->mIntMap.begin();iter!=this->mIntMap.end();++iter)
	{
		outVec.push_back(iter->first);
	}

	for(std::map<std::string,TinyJson::CJson>::iterator iter=this->mMapMap.begin();iter!=this->mMapMap.end();++iter)
	{
		outVec.push_back(iter->first);
	}

	for(std::map<std::string,TinyJsonArray>::iterator iter=this->mArrayMap.begin();iter!=this->mArrayMap.end();++iter)
	{
		outVec.push_back(iter->first);
	}

	return outVec;
}

bool TinyJson::CJson::PathEmpty(const std::string& path)
{
	if( path.empty() || path=="/" )
	{
		return true;
	}

	return false;
}


std::string TinyJson::CJson::RemoveOnePathFromTop(std::string& path)
{
	std::string outStr;
	if( PathEmpty(path) )
	{
		return "";
	}

	if( path[0]!='/' )
	{
		return "";
	}

	std::string::size_type loc=path.find_first_of('/',1);

	if( std::string::npos==loc )
	{
		outStr=path.substr(1);;
		path="";
		return outStr;
	}

	outStr=path.substr(1,loc-1);
	path.erase(0,loc);
	return outStr;
}

bool TinyJson::CJson::getPathObj(TinyJson::CJson& obj,std::string& name,std::string& path)
{
	if( PathEmpty(path) )
	{
		setError(ERR_PATH_PTHERROR,"error path["+path+"]");
		return true;
	}

	std::string elemName=RemoveOnePathFromTop(path);

	if( elemName.empty() )
	{
		setError(ERR_PATH_PTHERROR,"error path["+path+"]");
		return true;
	}

	if( PathEmpty(path) )
	{
		if( mStrMap.count(elemName)!=0 || mIntMap.count(elemName)!=0 || mMapMap.count(elemName)!=0 || mArrayMap.count(elemName)!=0 )
		{
			name=elemName;
			obj=*this;
			return false;
		}
		else
		{
			setError(ERR_PATH_NOTEXIST,"error path["+path+"] not exist");
			return true;
		}
	}

	if( mMapMap.count(elemName)!=0 )
	{
		return mMapMap[elemName].getPathObj(obj,name,path);
	}
	else
	{
		setError(ERR_PATH_NOTEXIST,"error path["+path+"] not exist");
		return true;
	}

	return true;
}

bool TinyJson::CJson::getStringWithPath(std::string& value,std::string path)
{
	std::string searchPath=path;

	TinyJson::CJson objJson;
	std::string name;

	if( getPathObj(objJson,name,searchPath) )
	{
		return true;
	}

	value=objJson.getString(name);
	return false;
}

bool TinyJson::CJson::getIntWithPath(int& value,std::string path)
{
	std::string searchPath=path;

	TinyJson::CJson objJson;
	std::string name;

	if( getPathObj(objJson,name,searchPath) )
	{
		return true;
	}

	value=objJson.getInt(name);
	return false;
}

bool TinyJson::CJson::getObjWithPath(TinyJson::CJson& value,std::string path)
{
	std::string searchPath=path;

	TinyJson::CJson objJson;
	std::string name;

	if( getPathObj(objJson,name,searchPath) )
	{
		return true;
	}

	value=objJson.getObj(name);
	return false;
}

bool TinyJson::CJson::getArrayWithPath(TinyJson::TinyJsonArray& value,std::string path)
{
	std::string searchPath=path;

	TinyJson::CJson objJson;
	std::string name;

	if( getPathObj(objJson,name,searchPath) )
	{
		return true;
	}

	value=objJson.getArray(name);
	return false;
}

