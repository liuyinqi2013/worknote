/*
 * CHbtDBOperatorService.cpp
 *
 *  Created on: 2012-2-3
 *      Author: leungma
 */

#include "CHbtDBOperatorService.h"

extern CConfig* gPtrConfig; // ȫ������ָ��
extern CCftLogger* gPtrAppLog; // ��־�ļ�ָ��
extern CCftLogger* gPtrSysLog; // ��־�ļ�ָ��
extern CMySQL* gPtrMysql; // mysql����


CHbtDBOperatorService::CHbtDBOperatorService()
{
	// TODO Auto-generated constructor stub

}

CHbtDBOperatorService::~CHbtDBOperatorService()
{
	// TODO Auto-generated destructor stub
}

void CHbtDBOperatorService::ProcessMsg(TRPC_SVCINFO* pRequst)
		throw (CException)
{

	// ��������
	KeyValueMap objInMap;
	KeyValueMap objOutMap;

	//����Ĳ���������ΪMAP����
	string strInBuf = pRequst->idata;
	analyzeCgiParam(strInBuf, objInMap, ANALYZE_PARAM_NONE);

	gPtrSysLog->debug("DBTest Begin ...hbt123!");
	try
	{
		gPtrMysql->Begin();
		stringstream ss;
		//ss << "show tables;";
		//ss << "select * from test.t_user where Fuserid='adam'";
		ss << "insert into test.t_user values ('hbt1', '1234','hbttest');";
		gPtrSysLog->debug("begin db");
		gPtrMysql->Query(ss.str().c_str(), ss.str().length());

    		//KeyValueMap objResultMap;
    		//if(0 == gPtrMysql -> FetchResultMap(objResultMap))
    		//{

		//	gPtrSysLog->debug("getting Fpasswd ...................hbt123!");
		gPtrMysql->Commit();
    		//}
	} catch (const CException & e)
	{
		gPtrMysql->Rollback();
		gPtrSysLog->error("[%d][%d][%s] uin[%s]", getpid(), e.error(),
				e.what(), objInMap["uin"].c_str());
		stringstream errss;
		errss<<e.what();
		if(string::npos!=errss.str().find("Duplicate")){
			throw CException(ERROR_UIN_DUP,"uin dup");
		}else{
			throw e;
		}
	}

	gPtrSysLog->debug("DBTest End ...hbt123!");

	//ҵ������ɺ�����������
	string strOutData;
	objOutMap["retDat"] = string("lucky");
	objOutMap["name"] = string("adam");
	objOutMap["test"] = string("����");
	objOutMap.GenString(strOutData);
	gPtrSysLog->debug("test strOutData2[%s]", strOutData.c_str());
	packMessage(RES_OK, strOutData.c_str(), pRequst, PACKMSG_TYPE_OK);
}
