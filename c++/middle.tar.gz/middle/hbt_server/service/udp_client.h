#ifndef  _UDPSOCKET_CLIENT_
#define  _UDPSOCKET_CLIENT_

#include <sys/types.h>
#include <sys/socket.h>
#include <string.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include <unistd.h>
#include "CStringMap.h"

#define MAX_UDP_DATA_LEN 1024

class CUdpClient
{
  public:
    CUdpClient();
    ~CUdpClient();
     
    int init(int port,char * host);
    int tcp_close();
    int read_data( char *, int,int timeout);
    int write_data( char *, int);

    int send_msg(unsigned char msg_code,bsapi::CStringMap& paramter);
    int recv_msg(unsigned char& msg_code,bsapi::CStringMap& paramter,int timeout=10);
    
  private:   
    int  m_sock;
    struct sockaddr_in dest_addr_;
    int TcpConnect( int port, char *host); 
    int isReadyToRecv(int sockfd, int timeOut);
};

#endif

