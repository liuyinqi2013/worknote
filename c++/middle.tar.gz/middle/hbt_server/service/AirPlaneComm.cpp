/**
 * FileName: AirPlaneComm.h
 * Author: verminniu
 * Version :1.0
 * Date: 2008-01-16
 * Description: һЩ������ͷ�ļ��ͷ���ʵ��
 * ChangeList:
 *			2008-01-16		Created by verminniu
 */

#include "AirPlaneComm.h"
#include "CftRequest.h"

extern CCftLogger* gPtrAppLog; // ��־�ļ�ָ��
extern CCftLogger* gPtrSysLog; // ��־�ļ�ָ��


int GetMd5(const char *key, int len, char *szRes)
{
	if (key == NULL)
		return -1;

	struct MD5Context md5c;
	unsigned char digest[64]; /* RATS: ignore (size OK) */
	char buf[16]; /* RATS: ignore (size OK) */
	char resultstr[128]; /* RATS: ignore (size OK) */
	//char *ptr;
	int i;

	MD5Init(&md5c);
	MD5Update(&md5c, (unsigned char *) key, len);
	MD5Final(digest, &md5c);

	bzero(resultstr, 128);
	for (i = 0; i < 16; i++)
	{
		memset(buf, 0, 16);
		sprintf(buf, "%02x", digest[i]);
		strcat(resultstr, buf); /* RATS: ignore (len OK) */
	}

	if ('\0' == resultstr[0])
	{
		return -1;
	}
	else
	{
		strncpy(szRes, resultstr, 32);
		return 0;
	}
}

char *
strchug(char *pBuf)
{
	char *start;

	for (start = pBuf; *start && isspace(*start); start++)
		;

	strcpy(pBuf, start);

	return pBuf;
}

char *
strchomp(char * pBuf)
{
	char *s;

	if (!*pBuf)
		return pBuf;

	for (s = pBuf + strlen(pBuf) - 1; s >= pBuf && isspace(*s); s--)
		*s = '\0';

	return pBuf;
}

int isValidStr(char * pBuf)
{
	// ���#��ͷ
	if (pBuf[0] == '#')
		return 1;

	if (strstr(pBuf, "@PortChg_URL"))//���ڰ���@PortChg_URL��ע������
	{
		return 0;
	}

	// ���<!--��ͷ
	if (strncmp(pBuf, "<!--", 4) == 0)
		return 1;

	return 0;
}

int analyzeCgiParam(const string & strBuf, KeyValueMap& objKeyValue, int iType)
{
	int iRet = 0;

	string strTmp;

	strTmp = strBuf;

	if (iType == ANALYZE_PARAM_NONE)
	{
		// ������
		iRet = objKeyValue.SnapElement(strTmp);
	}
	else if (iType == ANALYZE_PARAM_DECODE)
	{
		// ��Ҫ����
		KeyValueMap TmpMap;
		string strDecode;

		TmpMap.SnapElement(strTmp);

		strDecode = decrypt(TmpMap["sp_id"], TmpMap["request_text"]);

		iRet = objKeyValue.SnapElement(strDecode);
	}

	return iRet;
}

// ת��xml�����ַ�
int MyEscape(string &src, string org, string sub)
{
	string::size_type pos = 0;

	if (org.empty() || src.empty())
		return 1;

	for (; 1;)
	{
		pos = src.find(org, pos);
		if (pos != string::npos)
		{
			src.replace(pos, org.length(), sub);
			pos += sub.length();
		}
		else
			break;
	}
	return 0;
}

string& XmlEscape(string &src)
{
	MyEscape(src, "&", "&amp;");
	MyEscape(src, "<", "&lt;");
	MyEscape(src, ">", "&gt;");
	MyEscape(src, "\"", "&#x22;");
	MyEscape(src, "'", "&#x27;");
	MyEscape(src, "/", "&#x2f;");

	return src;
}

// ����time_t�ṹ��������
int getDays(time_t tFrom, time_t tTo)
{
	time_t tTmp = tTo - tFrom;

	return (int) (tTmp / SECOND_PER_DAYS);
}

// ת��yyyymmddΪtime_t��ʽ
time_t getTimeT(const char * pszDate)
{
	struct tm tTime;

	memset(&tTime, 0x00, sizeof(tTime));

	int iTmp = atoi(pszDate);

	// ȡ��
	tTime.tm_year = iTmp / 10000 - 1900;

	iTmp %= 10000;

	// ��
	tTime.tm_mon = iTmp / 100 - 1;

	tTime.tm_mday = iTmp % 100;

	return mktime(&tTime);
}

//����hash�㷨������ִ�
int GetHashNum(const char *szStr)
{
	char szRes[32 + 1] =
	{ 0 };
	int iHashTmp = 0;

	GetMd5(szStr, strlen(szStr), szRes);
	iHashTmp = 1000 + szRes[strlen(szRes) - 3] % 10 * 100 + szRes[strlen(szRes)
			- 2] % 10 * 10 + szRes[strlen(szRes) - 1] % 10;

	return iHashTmp;
}

// ��ȡdb��table���
int GetDBAndTable(const char* szStr, int& iDbNum, int &iTbNum)
{
	int iHashNum = 0;
	iHashNum = GetHashNum(szStr);

	iDbNum = Sdb1(iHashNum);
	iTbNum = Stb1(iHashNum);

	return 0;
}

// ��ȡ������
string GetTableName(const char * szUin, const char * szDBName,
		const char * szTableName)
{
	int iDbNum, iTbNum;
	GetDBAndTable(szUin, iDbNum, iTbNum);

	stringstream ssTableName;
	ssTableName << szDBName << setfill('0') << setw(2) << iDbNum << "."
			<< szTableName << iTbNum;

	return ssTableName.str();
}

int Sdb1(int s)
{
	if (s < 1000)
		return -1;

	char buf[8], sz[16];
	bzero(buf, 8);
	bzero(sz, 16);

	sprintf(sz, "%d", s);
	memcpy(buf, sz + strlen(sz) - 2, 2);
	return atoi(buf);
}

int Stb1(int s)
{
	if (s < 1000)
		return -1;

	char buf[8], sz[16];
	bzero(buf, 8);
	bzero(sz, 16);

	sprintf(sz, "%d", s);
	memcpy(buf, sz + strlen(sz) - 3, 1);
	return atoi(buf);
}

/**
 * Description:    �����ؽ�������������
 * Input:             iRetcode         ������
 *                       pResult          ʵ�ʷ�������
 *                    iType            �����ʽ:
 *										PACKMSG_TYPE_OK  = 0   "result=0&res_info=ok&%s"
 *										PACKMSG_TYPE_ERR = 1   "result=%d&res_info=%s"
 * Output:           pRequst         �������ݴ�Žṹ
 * Return:           ������Ϣ�ĳ���
 * Note:              �������¸�ʽ���:
 *                       ������(int)|���س���(int)|������Ϣ(text)
 */
void packMessage(int iRetcode, const char* pResult, TRPC_SVCINFO* pRequst,
		int iType)
{
	switch (iType)
	{
	case PACKMSG_TYPE_OK:
	{
		pRequst->olen = snprintf(pRequst->odata, sizeof(pRequst->odata),
				"result=0&res_info=ok&%s", pResult);
		break;
	}
	case PACKMSG_TYPE_ERR:
	{
		pRequst->olen = snprintf(pRequst->odata, sizeof(pRequst->odata),
				"result=%d&res_info=%s", iRetcode, pResult);
		break;
	}
	case PACKMSG_TYPE_ALL:
	{
		pRequst->olen = snprintf(pRequst->odata, sizeof(pRequst->odata), "%s",
				pResult);
		break;
	}
	default:
	{
		pRequst->olen = snprintf(pRequst->odata, sizeof(pRequst->odata),
				"result=%d&res_info=Unknow PackMsgType %d", ERR_OTHER_UNKNOW,
				iType);
		break;
	}
	}
}

int GetTimeNow(char *str)
{
	time_t tt;
	struct tm stTm;

	tt = time(NULL);
	memset(&stTm, 0, sizeof(stTm));
	localtime_r(&tt, &stTm);
	sprintf(str, "%04d-%02d-%02d %02d:%02d:%02d", stTm.tm_year + 1900,
			stTm.tm_mon + 1, stTm.tm_mday, stTm.tm_hour, stTm.tm_min,
			stTm.tm_sec);

	return 0;
}

// ����ʱ��
void GetTime(time_t tTime, string & strTime)
{
	struct tm stTm;

	char str[21] =
	{ 0 };

	memset(&stTm, 0, sizeof(stTm));
	localtime_r(&tTime, &stTm);
	sprintf(str, "%04d-%02d-%02d %02d:%02d:%02d", stTm.tm_year + 1900,
			stTm.tm_mon + 1, stTm.tm_mday, stTm.tm_hour, stTm.tm_min,
			stTm.tm_sec);

	strTime = string(str);
}

string SubMini(const string& strTime, int iMini)
{
	struct tm stTm;

	memset(&stTm, 0, sizeof(stTm));
	sscanf(strTime.c_str(), "%04d-%02d-%02d %02d:%02d:%02d", &stTm.tm_year,
			&stTm.tm_mon, &stTm.tm_mday, &stTm.tm_hour, &stTm.tm_min,
			&stTm.tm_sec);

	stTm.tm_year -= 1900;
	stTm.tm_mon -= 1;
	time_t tTmp = mktime(&stTm) + iMini * 60;

	struct tm stDesTm;

	char str[21] =
	{ 0 };
	localtime_r(&tTmp, &stDesTm);
	sprintf(str, "%04d-%02d-%02d %02d:%02d:%02d", stDesTm.tm_year + 1900,
			stDesTm.tm_mon + 1, stDesTm.tm_mday, stDesTm.tm_hour,
			stDesTm.tm_min, stDesTm.tm_sec);

	return str;
}

//��instr��sqrΪ�ָ�����ֵ�outVec��
int SplitString(string &instr, vector<string> &outVec, char sqr)
{
	string::iterator iterTmp, iterBegin;
	int cnt = 0;

	outVec.clear();
	for (iterBegin = iterTmp = instr.begin(); iterTmp != instr.end();)
	{
		if (*iterTmp == sqr)
		{
			outVec.push_back(string(iterBegin, iterTmp));
			iterBegin = ++iterTmp;
			cnt++;
			continue;
		}
		++iterTmp;
	}
	if (iterBegin != instr.end())
	{
		outVec.push_back(string(iterBegin, instr.end()));
		cnt++;
	}

	return (cnt);
}

string toLowerCase(string instr)
{
	char tc = 0;
	string tostr;
	for (string::iterator iter = instr.begin(); iter != instr.end(); iter++)
	{
		if (*iter > 64 && *iter < 91)
		{
			tc = *iter + 32;
		}
		else if ((*iter >= 'a' && *iter <= 'z') || (*iter >= '0' && *iter
				<= '9'))
		{
			tc = *iter;
		}
		else
		{
			continue;
		}
		tostr.push_back(tc);
	}
	return (tostr);
}

// �ص�����
int Curl_Writer(char *data, size_t size, size_t nmemb, std::string *writerData)
{
	if (writerData == NULL)
		return 0;

	writerData->append(data, size * nmemb);

	return size * nmemb;
}

// post ����Url
void Curl_CallUrlPost(const string& urlStr, const string & strInBuf,
		string& strOutBuf, const string & host) throw (CException)
{
	CURL *conn = NULL;
	CURLcode code;

	string strRequest = urlStr;

	conn = curl_easy_init();

	if (conn == NULL)
	{
		throw CException(ERR_CURL_INIT, "Failed to create CURL");
	}

	// ���ó�ʱʱ��
	code = curl_easy_setopt(conn, CURLOPT_TIMEOUT, DEFAULT_URLCALL_TIME_OUT);
	if (code != CURLE_OK)
	{
		stringstream ssErrMsg;
		ssErrMsg << "Failed to set CURLOPT_POST connectionn["
				<< strRequest.c_str() << "][" << code << "]["
				<< curl_easy_strerror(code) << "]";

		throw CException(ERR_TEMP_PARAM, ssErrMsg.str());
	}

	// ��������ͷ
	curl_slist *chunk = NULL;
	chunk = curl_slist_append(chunk, "Content-Type: text/xml");
	code = curl_easy_setopt(conn, CURLOPT_HTTPHEADER, chunk);
	if (code != CURLE_OK)
	{
		stringstream ssErrMsg;
		ssErrMsg << "Failed to set CURLOPT_POST connectionn["
				<< strRequest.c_str() << "][" << code << "]["
				<< curl_easy_strerror(code) << "]";

		throw CException(ERR_TEMP_PARAM, ssErrMsg.str());
	}

	// ���������url
	code = curl_easy_setopt(conn, CURLOPT_URL, strRequest.c_str());
	if (code != CURLE_OK)
	{
		stringstream ssErrMsg;
		ssErrMsg << "Failed to set URL CURL connectionn[" << strRequest.c_str()
				<< "][" << code << "][" << curl_easy_strerror(code) << "]";

		throw CException(ERR_TEMP_PARAM, ssErrMsg.str());
	}
	/*
	 * leungma 2012-02-08 �޸ģ����ָ����host����ô���������header�У����Ӷ�host���趨
	 */
	if ("" != host && !host.empty())
	{
		curl_slist *chunk1 = NULL;
		string tmpHost="Host: "+host;
		chunk1 = curl_slist_append(chunk1, tmpHost.c_str());
		curl_easy_setopt(conn, CURLOPT_HTTPHEADER, chunk1);
		gPtrAppLog->debug("curl set host[%s]",tmpHost.c_str());
	}
	/*
	 * leungma 2012-02-08 �޸ģ����ָ����host����ô���������header�У����Ӷ�host���趨
	 * END
	 */
	// ��������ʽΪpost
	code = curl_easy_setopt(conn, CURLOPT_POST, 1);
	if (code != CURLE_OK)
	{
		stringstream ssErrMsg;
		ssErrMsg << "Failed to set CURLOPT_POST connectionn["
				<< strRequest.c_str() << "][" << code << "]["
				<< curl_easy_strerror(code) << "]";

		throw CException(ERR_TEMP_PARAM, ssErrMsg.str());
	}

	// �����������
	code = curl_easy_setopt(conn, CURLOPT_POSTFIELDS, strInBuf.c_str());
	if (code != CURLE_OK)
	{
		stringstream ssErrMsg;
		ssErrMsg << "Failed to set postdata connectionn[" << strRequest.c_str()
				<< "][" << code << "][" << curl_easy_strerror(code) << "]";

		throw CException(ERR_TEMP_PARAM, ssErrMsg.str());
	}

	// ���÷��ش���ȡ�ص�����
	code = curl_easy_setopt(conn, CURLOPT_WRITEFUNCTION, Curl_Writer);
	if (code != CURLE_OK)
	{
		stringstream ssErrMsg;
		ssErrMsg << "Failed to set writer connectionn[" << strRequest.c_str()
				<< "][" << code << "][" << curl_easy_strerror(code) << "]";

		throw CException(ERR_TEMP_PARAM, ssErrMsg.str());
	}

	// ���ûص���������(����ص�������ȡ������)
	code = curl_easy_setopt(conn, CURLOPT_WRITEDATA, &strOutBuf);
	if (code != CURLE_OK)
	{
		stringstream ssErrMsg;
		ssErrMsg << "Failed to set writer data[" << strRequest.c_str() << "]["
				<< code << "][" << curl_easy_strerror(code) << "]";

		throw CException(ERR_TEMP_PARAM, ssErrMsg.str());
	}

	// ����url
	code = curl_easy_perform(conn);
	if (code != CURLE_OK)
	{
		stringstream ssErrMsg;
		ssErrMsg << "Failed to curl_easy_perform[" << strRequest.c_str()
				<< "][" << code << "][" << curl_easy_strerror(code) << "]";

		throw CException(ERR_CURL_PERFORM, ssErrMsg.str());
	}

	curl_easy_cleanup(conn);
}

// get ����Url
void Curl_CallUrlGet(const string& urlStr, const string & strInBuf,
		string& strOutBuf, const string & host) throw (CException)
{
	CURL *conn = NULL;
	CURLcode code;

	// ƴ������http://www.test.com/xxx.cgi?xxx�ĸ�ʽ
	string strRequest = urlStr + "?" + strInBuf;

	conn = curl_easy_init();

	if (conn == NULL)
	{
		throw CException(ERR_CURL_INIT, "Failed to create CURL");
	}

	// ���������url
	code = curl_easy_setopt(conn, CURLOPT_URL, strRequest.c_str());
	if (code != CURLE_OK)
	{
		stringstream ssErrMsg;
		ssErrMsg << "Failed to set URL CURL connectionn[" << strRequest.c_str()
				<< "][" << code << "][" << curl_easy_strerror(code) << "]";

		throw CException(ERR_TEMP_PARAM, ssErrMsg.str());
	}
	/*
	 * leungma 2012-02-08 �޸ģ����ָ����host����ô���������header�У����Ӷ�host���趨
	 */
	if ("" != host && !host.empty())
	{
		curl_slist *chunk1 = NULL;
		string tmpHost="Host: "+host;
		chunk1 = curl_slist_append(chunk1, tmpHost.c_str());
		curl_easy_setopt(conn, CURLOPT_HTTPHEADER, chunk1);
		gPtrAppLog->debug("curl set host[%s]",tmpHost.c_str());
	}
	/*
	 * leungma 2012-02-08 �޸ģ����ָ����host����ô���������header�У����Ӷ�host���趨
	 * END
	 */

	// ���ûص�����
	code = curl_easy_setopt(conn, CURLOPT_WRITEFUNCTION, Curl_Writer);
	if (code != CURLE_OK)
	{
		stringstream ssErrMsg;
		ssErrMsg << "Failed to set writer connectionn[" << strRequest.c_str()
				<< "][" << code << "][" << curl_easy_strerror(code) << "]";

		throw CException(ERR_TEMP_PARAM, ssErrMsg.str());
	}

	// ���ûص���������(����ص�������ȡ������)
	code = curl_easy_setopt(conn, CURLOPT_WRITEDATA, &strOutBuf);
	if (code != CURLE_OK)
	{
		stringstream ssErrMsg;
		ssErrMsg << "Failed to set writer data[" << strRequest.c_str() << "]["
				<< code << "][" << curl_easy_strerror(code) << "]";

		throw CException(ERR_TEMP_PARAM, ssErrMsg.str());
	}

	// ����URL
	code = curl_easy_perform(conn);
	if (code != CURLE_OK)
	{
		stringstream ssErrMsg;
		ssErrMsg << "Failed to curl_easy_perform[" << strRequest.c_str()
				<< "][" << code << "][" << curl_easy_strerror(code) << "]";

		throw CException(ERR_CURL_PERFORM, ssErrMsg.str());
	}

	curl_easy_cleanup(conn);
}

// Զ�̵���Url
void Curl_CallUrl(const string& urlStr, const string & strInBuf,
		string& strOutBuf, int iType) throw (CException)
{

	switch (iType)
	{
	case CALL_TYPE_POST:
		Curl_CallUrlPost(urlStr, strInBuf, strOutBuf);
		break;
	case CALL_TYPE_GET:
		Curl_CallUrlGet(urlStr, strInBuf, strOutBuf);
		break;
	default:
		stringstream ssErrMsg;
		ssErrMsg << "Unknown call type: " << iType;

		throw CException(ERR_TEMP_TYPE, ssErrMsg.str());
	}
}

/**
 * leungma 2012-02-08 �����µķ�������
 * ��֧��ͨ��HTTPЭ�飬����ָ��IP�������е�ĳ����Դ
 *  host��Ŀ���ַ������
 *  port��Ŀ���ַ�Ķ˿ں�
 *  ip��Ŀ���ַ��IP
 *  pathname��Ŀ���ַ����Դ�ļ�������·��
 *  reqStrBuf:����
 *  resStrBuf:������Ӧ
 *  iType:���÷�ʽCALL_TYPE_POST/CALL_TYPE_GET
 */
void Curl_CallUrlHttp(const string & host, //
		const string & port, //
		const string & ip,//
		const string & pathname, //
		const string & reqStrBuf, //
		string & resStrBuf,//
		int iType//
)
{

	/*
	 * Ŀ���ַ��URL
	 */
	stringstream urlss;
	urlss << "http://";
	if (ip.empty())
	{
		urlss << host;
	}
	else
	{
		urlss << ip;
	}
	if (!port.empty())
	{
		urlss << ":" << port;
	}
	if (pathname.empty())
	{
		urlss << "/";
	}
	else
	{
		urlss << pathname;
	}
	string strRequest = urlss.str();
	gPtrAppLog->debug("Curl_CallUrlHttp url[%s]",strRequest.c_str());
	switch (iType)
	{
	case CALL_TYPE_POST:
		Curl_CallUrlPost(strRequest, reqStrBuf, resStrBuf, host);
		break;
	case CALL_TYPE_GET:
		Curl_CallUrlGet(strRequest, reqStrBuf, resStrBuf, host);
		break;
	default:
		stringstream ssErrMsg;
		ssErrMsg << "Unknown call type: " << iType;

		throw CException(ERR_TEMP_TYPE, ssErrMsg.str());
	}
}

string doubleToPerCent(string& instr)
{
	if (instr.empty())
	{
		return "0";
	}

	stringstream ssReq;

	ssReq << atof(instr.c_str()) * 100;

	return ssReq.str();
}

string percentToDouble(string& inStr, int effNum/*=1*/)
{
	stringstream ssReq;

	if (inStr.empty())
	{
		ssReq << setprecision(effNum) << 0;

		return ssReq.str();
	}

	ssReq << setiosflags(ios::fixed) << setprecision(effNum) << (double) (atol(
			inStr.c_str()) / 100);

	return ssReq.str();
}

void stringReplace(string &strsrc, const string & strfind, const string &strnew)
{
        string::size_type pos=0;
        string::size_type srclen=strfind.size();
        string::size_type dstlen=strnew.size();
        while( (pos=strsrc.find(strfind, pos)) != string::npos)
        {
                strsrc.erase(pos, srclen);
                strsrc.insert(pos,strnew);
                pos += dstlen;
        }
}

//�����û�����ķǷ��ַ�
string getSafeInput(string str)
{
	if("" == str || str.length() <= 0)
		return string("");
	string tmpstr = str;
	
	stringReplace(tmpstr,"\r\n","");
	stringReplace(tmpstr,"&","��");
	stringReplace(tmpstr,"|","��");
	stringReplace(tmpstr,";","��");
	stringReplace(tmpstr,"$","");
	stringReplace(tmpstr,"%","");
//	stringReplace(tmpstr,"@","��");
	stringReplace(tmpstr,"<","��");
	stringReplace(tmpstr,">","��");
	stringReplace(tmpstr,")","��");
	stringReplace(tmpstr,"(","��");
	stringReplace(tmpstr,"+","");
	stringReplace(tmpstr,"0x0d","");
	stringReplace(tmpstr,"0x0a","");
	stringReplace(tmpstr,",","��");
	stringReplace(tmpstr,"#","��");
	stringReplace(tmpstr,"=","��");
	stringReplace(tmpstr,"\"","��");
	stringReplace(tmpstr,"'","��");
	stringReplace(tmpstr,"\\","��");
	stringReplace(tmpstr,"0x4f","");
	stringReplace(tmpstr," ","");

	return tmpstr;
}


string i2s(const int i)
{
	char sTmp[64] ={0};
	sprintf(sTmp, "%d", i);
	return string(sTmp);
}



