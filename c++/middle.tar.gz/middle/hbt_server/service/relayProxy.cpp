//
// relayProxy.cpp
// RelaySvr Client Proxy
//
// bondshi
// 2007/06/04
//

#include <ace/SOCK_Connector.h>
#include <ace/SOCK_Stream.h>
#include <ace/OS.h>
#include <ace/INET_Addr.h>

#include "myTime.h"
#include "relayProxy.h"
#include "timeStamp.h"

using namespace std;

extern CCftLogger*	gPtrAppLog;			    		// ��־�ļ�ָ��
extern CCftLogger*	gPtrSysLog;			    		// ��־�ļ�ָ��

static int MAX_PACKET_SIZE = 32*1024; // max relay response size

//////////////////////////////////////////////////////////////////////////

//
// implementation of RelayProxy
//
RelayProxy::RelayProxy() : __timeout(10), __resData(NULL), __resSize(0)
{
}

RelayProxy::RelayProxy(const char* szServerIp, int port, int timeout) : 
    __timeout(timeout),
    __resData(NULL),
    __resSize(0)
{
    addServer(szServerIp, port);
}
    
RelayProxy::~RelayProxy()
{
    delete __resData;
    __resData = NULL;
    __resSize = 0;
}

void RelayProxy::call(const char* pszRequest, int size, RequestBase& response)
{
    int pid = getpid();
    char sSid[20];
    snprintf(sSid,20,"%d",pid);
    TimeStamp t(sSid);
    
    _call(pszRequest, size);

    t.end();

    response.parse(__resData, "&");

    if (response.asInteger("result", -1) == 10010)
    {
        // relay����service��ʱ
        saveCallFail(pszRequest, size);
    }
}
       
void RelayProxy::_call(const char* pszRequest, int size)
{
    int count = __sentries.size();
    if (count == 0)
    {
        throw CException(ERR_APP_PARAM, "relay server not supply");
    }
            
    // ��ʼ�������
    srand(time(NULL) * ACE_OS::getpid());        
    int s0 = rand() % count;
    int idx = s0;
    struct timeval tv1,tv2;
    
    // log request text
    gPtrAppLog->debug("Relay SNDREQ(%d bytes):%s", size, pszRequest);
    
    for(;;) 
    {
        try
        {
            gettimeofday(&tv1,NULL); //����ǰʱ��
            _call(__sentries[idx], pszRequest, size);
            gettimeofday(&tv2,NULL);//���ú�ʱ��

            // call ok, break loop
            break;
        }
        catch (const CException& ex)
        {
            // ���ͱ���
            string msg = string("RELAY-ERROR:") + ex.what();
            gPtrAppLog->debug("%s", msg.c_str());

            // ������һ̨������
            idx = ++idx % count;
            if (idx == s0) // all relaysvr have been failed, break loop
            {
                // relay ����ʧ�ܼ��������ظ�������־��
                saveCallFail(pszRequest, size);
                throw ex;
            }
        }
    }

    long long CallTimeBegin=0,CallTimeEnd=0,calltime=0;
    CallTimeBegin=tv1.tv_sec*1000000+tv1.tv_usec;
    CallTimeEnd=tv2.tv_sec*1000000+tv2.tv_usec;
    
    calltime=CallTimeEnd-CallTimeBegin;    //���û���ʱ��
    
    // log response
    gPtrAppLog->debug("Relay RCVRES(%d bytes) cost[%08lld]:%s", __resSize, calltime, __resData);
}

void RelayProxy::_binCall(const char* pszRequest, int size)
{
    int pid = getpid();
    char sSid[20];
    snprintf(sSid,20,"%d",pid);
    TimeStamp t(sSid);

    // send & recv
    _call(pszRequest, size);

    t.end();

    // parse response
    int ret;
    char* p = __resData;
    size_t s = __resSize;
    if (s < sizeof(int)) // check size
        throw CException(ERR_RELAY_FAIL, SuperString::format("invalid response package size:%d bytes", __resSize));
    
    memcpy(&ret, p, sizeof(int));
    p += sizeof(int);
    s -= sizeof(int);
    
    // check return value
    if (ret != 0) {
        int rt = 0;
        const char* pszToken = "request_type=";
        const char* pszTmp = strstr(pszRequest, pszToken);
        if (pszTmp != NULL) {
            rt = atoi(pszTmp + strlen(pszToken) + 1);
        }        

        throw CException(ERR_RELAY_FAIL,pszRequest);
    }
}

void RelayProxy::_call(const SERVICE_ENTRY& si, const char* pszRequest, int size)
{
    ACE_Time_Value tmout(__timeout);        
    ACE_SOCK_Connector conn;
    ACE_SOCK_Stream sock;

    // reset recv buff
    delete __resData;
    __resData = NULL;
    __resSize = 0;
    char* rbuff = NULL;

    try
    {
    int ret;
    ret = conn.connect(sock, ACE_INET_Addr(si._port, si._addr.c_str()), &tmout);
    if (ret < 0)
    {
        int e = ACE_OS::last_error();
        throw CException(ERR_RELAY_FAIL, 
        SuperString::format(
        "connect fail:addr=%s:%d,syserr=[%d,%s]",
        si._addr.c_str(), si._port,
        e, ACE_OS::strerror(e)
        ));    
    }

    struct iovec sv[2];
    sv[0].iov_base = &size;
    sv[0].iov_len = sizeof(int);
    sv[1].iov_base = (void*)pszRequest;
    sv[1].iov_len = size;

    ret = sock.sendv(sv, 2, &tmout);
    if (ret < 0)
    {
        int e = ACE_OS::last_error();
        throw CException(ERR_RELAY_FAIL, 
        SuperString::format(
        "send request fail:addr=%s:%d,syserr=[%d,%s]",
        si._addr.c_str(), si._port,
        e, ACE_OS::strerror(e)
        ));    
    }

    int rsize = 0;
    ret = sock.recv_n(&rsize, 4, &tmout);
    if (ret < 0)
    {
        int e = ACE_OS::last_error();
        throw CException(ERR_RELAY_FAIL, 
        SuperString::format(
        "recv response head fail:addr=%s:%d,syserr=[%d,%s]",
        si._addr.c_str(), si._port,
        e, ACE_OS::strerror(e)
        ));    
    }
    else if (rsize > MAX_PACKET_SIZE)
    {
        throw CException(ERR_RELAY_FAIL, 
        SuperString::format(
        "response size exceed system limit:addr=%s:%d, rsize=%d, maxsize=%d",
        si._addr.c_str(), si._port,
        rsize, MAX_PACKET_SIZE
        ));
    }

    rbuff = new char[rsize + 1];
    memset(rbuff, 0, rsize + 1);
    ret = sock.recv_n(rbuff, rsize, &tmout);
    if (ret != rsize)
    {
        int e = ACE_OS::last_error();
        throw CException(ERR_RELAY_FAIL, 
        SuperString::format(
        "recv response body fail:addr=%s:%d,rsize=%d,return=%d,syserr=[%d,%s]",
        si._addr.c_str(), si._port,
        rsize, ret,
        e, ACE_OS::strerror(e)
        ));    
    }

    sock.close();
    __resData = rbuff;
    __resSize = rsize;
    }
    catch (...)
    {        
    delete[] rbuff;
    sock.close();
    throw;
    }
}

void RelayProxy::saveCallFail(const char * pszRequestStr, int size)
{
    gPtrAppLog->debug("V2;%s;%s\n", MyTime::now().tostr().c_str(), string(pszRequestStr, size).c_str());
}


