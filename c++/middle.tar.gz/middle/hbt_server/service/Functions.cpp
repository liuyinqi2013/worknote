#include "Functions.h"

void
CFunction::EncodeFun(const char * szInBuf,int iInLength,char * szOutBuf,int & iOutLength) throw(CException) {};

