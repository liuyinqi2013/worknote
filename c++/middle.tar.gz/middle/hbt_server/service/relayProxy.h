//
// relayProxy.h
// RelaySvr Client Proxy
//
// bondshi
// 2007/06/04
//

#ifndef __RELAY_PROXY_H__
#define __RELAY_PROXY_H__


//#include "server_error.h"
#include "sstring.h"
#include "exception.h"
#include "CftRequest.h"
#include "CftLogger.h"
#include <string>
#include <vector>

//////////////////////////////////////////////////////////////////////////

class RelayProxy
{
public:
    RelayProxy();
    RelayProxy(const char* szServerIp, int port = 22000, int timeout = 10);
    virtual ~RelayProxy();

    // �ı�Ӧ��
    void call(const char* pszRequest, int size, RequestBase& response);    
    
    void call(const char* pszRequest, RequestBase& response) {
    call(pszRequest, strlen(pszRequest), response);
    }

    void call(const std::string& strReq, RequestBase& response) {
    call(strReq.c_str(), strReq.length(), response);
    }

    // �����Ʋ�ѯӦ��, �������п��Բ���ļ�¼����
    template<typename struct_t>
        int binCall(const char* pszRequest, int size, std::vector<struct_t>& results);

    template<typename struct_t>
        int binCall(const char* pszRequest, std::vector<struct_t>& results) {
        return binCall(pszRequest, strlen(pszRequest), results);
    }

    template<typename struct_t>
        int binCall(const std::string& strReq, std::vector<struct_t>& results) {
        return binCall(strReq.c_str(), strReq.length(), results);
    }

    template<typename struct_t>
        bool binCall(const char* pszRequest, int size, struct_t& result) {
        std::vector<struct_t> results;
        binCall(pszRequest, size, results);
        if (results.size() > 0) {
            memcpy(&result, &results[0], sizeof(struct_t));
            return true;
        }

        return false;
    }

    template<typename struct_t>
        bool binCall(const char* pszRequest, struct_t& result) {
        return binCall(pszRequest, strlen(pszRequest), result);
    }

    template<typename struct_t>
        bool binCall(const std::string& strReq, struct_t& result) {
        return binCall(strReq.c_str(), strReq.length(), result);
    }

    // config object
    void addServer(const char* szServerIp, int port = 22000) {
    __sentries.push_back(SERVICE_ENTRY(szServerIp, port));
    }

    void addServer(const std::string& serverIp, int port = 22000) {
    __sentries.push_back(SERVICE_ENTRY(serverIp, port));
    }    

    void setTimeout(int timeout) {
    __timeout = timeout;
    }

    void setFailCallSavePath(const std::string& filePath) {
        __failCallSaveFile = filePath;
    }

    // for debug
    const char* getResBuff()const {
    return __resData;
    }

    int getResSize()const {
    return __resSize;
    }
  
protected:
    struct _SERVICE_ENTRY
    {
        std::string _addr;
    int _port;

    _SERVICE_ENTRY() : _port(22000)    
    {}

    _SERVICE_ENTRY(const std::string& addr, int port) : _addr(addr), _port(port)
    {}
    };

    typedef struct _SERVICE_ENTRY SERVICE_ENTRY;
    typedef std::vector<SERVICE_ENTRY> sentry_vector;

    // do call relay
    void _call(const SERVICE_ENTRY& si, const char* pszRequest, int size);
    void _call(const char* pszRequest, int size);
    void _binCall(const char* pszRequest, int size);

    char* binDataPtr()const {
        return (__resData)?(__resData + sizeof(int)):NULL;        
    }

    int binDataSize()const {
        return (__resSize)?(__resSize - sizeof(int)):0;
    }

    void saveCallFail(const char* pszRequestStr, int size);      

private:
    sentry_vector __sentries;
    int __timeout;

    // save failed request
    std::string __failCallSaveFile;
    
    // buffer for response data
    char* __resData;    
    int __resSize;
};

class RelayException : public Exception
{
public:
    RelayException(
    RelayProxy& relay, 
    const std::string& message, 
    const ExceptionSource& src    
    );

    RelayProxy& relaySvr() {
    return __relaySvr;
    }

    virtual std::string tostr()const; 

protected:
    RelayProxy& __relaySvr;
};
#define RELAY_EXCEPTION(relay, msg) RelayException((relay), (msg), CURRENT_SOURCE)
// generic implementation for template function of RelayProxy
//
template <typename struct_t> inline int 
RelayProxy::binCall(const char* pszRequest, int size, std::vector<struct_t>& results)
{
    _binCall(pszRequest, size);

    // ���������ݻ�������С
    char* p = binDataPtr();
    int s = binDataSize();    
    
    if (s < (int)sizeof(int)) // check size
        throw RELAY_EXCEPTION(*this, SuperString::format("invalid response package size:%d bytes", __resSize));    

    // parse response
    int num = 0, total = 0; 
    memcpy(&num, p, sizeof(int));
    s -= sizeof(int);
    p += sizeof(int);
    if (s < (int)sizeof(int))
        throw RELAY_EXCEPTION(*this, SuperString::format("invalid response package size:%d bytes,num=%d", __resSize, num));

    memcpy(&total, p, sizeof(int));
    s -= sizeof(int);
    p += sizeof(int);
    if (s < (num * (int)sizeof(struct_t)))
        throw RELAY_EXCEPTION(*this, 
                SuperString::format("invalid response package size:%d bytes,num=%d,total=%d,strcut=%d",
                    __resSize, num, total, sizeof(struct_t))
                );    

    // ������¼��������
    for (int i = 0; i < num; ++i) {
        struct_t* pst = (struct_t*)p;
        results.push_back(*pst);
        p += sizeof(struct_t);
    }

    /** 
    // for debug
    FILE* binLog = fopen("/tmp/binlog.dat", "w+b");
    if (binLog)
    {
        fwrite(binDataPtr(), 1, binDataSize(), binLog);
        fclose(binLog);
    }    
    */

    // ���ط�������������Ŀ
    return total;        
}

//////////////////////////////////////////////////////////////////////////

#endif // __RELAY_PROXY_H__

