/**
* FileName: FunWrapper.cpp
* Author: verminniu
* Version :1.0
* Date: 2008-01-16
* Description: ��װ����������ʵ��
* ChangeList:
* 		2008-01-16		Created by verminniu
*/

#include "FunWrapper.h"

extern CCftLogger*	gPtrAppLog;			    	// ��־�ļ�ָ��
extern CCftLogger*	gPtrSysLog;			    	// ��־�ļ�ָ��


#define TRY_CREATE_FUNC_OBJ(sc1,sc2,funptr,funclass) \
	if (strcmp((sc1),(sc2)) == 0) \
    { \
			funptr = new funclass(); \
            goto END_CREATE;    \
	}

CFunWrapper::CFunWrapper()
{
	m_ObjFun = NULL;
}

CFunWrapper::~CFunWrapper()
{
	DeInit();
}

void CFunWrapper::Init(const char * szFunName) throw(CException)
{
	// ��ʼ��֮ǰ���ͷ���ǰ�Ŀռ�
	DeInit();
	
	TRY_CREATE_FUNC_OBJ(szFunName, ENCODE_FUNC_MD5, m_ObjFun, CMd5Encode);
	
END_CREATE:
	if (m_ObjFun == NULL)
	{
		stringstream ssErrMsg;
		ssErrMsg << "Not Find Function: " << szFunName;
		throw CException(ERR_FUN_UNKNOWN, ssErrMsg.str());
	}

	//gPtrAppLog->debug("CFunWrapper::Init: %s success", szFunName);
}

void CFunWrapper::DeInit()
{
	if(m_ObjFun)
	{
		delete m_ObjFun;
		m_ObjFun = NULL;
	}
}

void CFunWrapper::Encode(const char * szInBuf, int iInLength, char * szOutBuf, int & iOutLength) throw(CException)
{
	//gPtrAppLog->debug("Encode::EncodeFun szInBuf: %s", szInBuf);
	
	m_ObjFun->EncodeFun(szInBuf, iInLength, szOutBuf, iOutLength);
}
