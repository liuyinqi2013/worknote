/*
*adamfeng: 2012-06-01
*/
#include "sstring.h"
#include <string>
#include "relayProxy.h"
#include "CftRequest.h"
#include "CBaseType.h"

void InitCftSecRelayProxy ( RelayProxy & relay );
void CftSecRelayRequest(int request_type, const char *sp_id, CStr2Map &mapReq, RequestBase &tPayResult, int bModeEncrypted);


