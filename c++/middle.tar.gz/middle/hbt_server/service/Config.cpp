/**
  * FileName: Config.cpp
  * Author: verminniu
  * Version :1.0
  * Date: 2008-01-16
  * Description: ������Ϣ
  * ChangeList:
  *			2008-01-16		Created by verminniu
  *			2008-06-30		jiggersong ������ѯ�������Դ���
  */

#include      "Config.h"

extern CCftLogger*	gPtrAppLog;			    	// ��־�ļ�ָ��
extern CCftLogger*	gPtrSysLog;			    	// ��־�ļ�ָ��

// ��ȡϵͳ����
void
CConfig::readSysConf() throw(CException)
{
	XmlConfig config(m_strFileName.c_str());
	if( !config ) 
	{
		stringstream ssErrMsg;
		ssErrMsg << "XmlConfig Init [" << m_strCompanyConfFile<< "]: " << config.getLastError();
	
		throw CException(ERR_LOAD_CFG, ssErrMsg.str());
	}

	// ��ȡ���ݿ�������Ϣ
	m_strDBHost = config.getValue(DB_HOST_PATH, DEFAULT_STRING_NULL);
	if( m_strDBHost == DEFAULT_STRING_NULL ) 
	{
		stringstream ssErrMsg;
		ssErrMsg << "Not Find Node: " << DB_HOST_PATH;
	
		throw CException(ERR_NULL_XML_NODE, ssErrMsg.str());
	}

	m_strDBUser = config.getValue(DB_USER_PATH, DEFAULT_STRING_NULL);
	if( m_strDBUser == DEFAULT_STRING_NULL ) 
	{
		stringstream ssErrMsg;
		ssErrMsg << "Not Find Node: " << DB_USER_PATH;
	
		throw CException(ERR_NULL_XML_NODE, ssErrMsg.str());
	}

	m_strDBPass = config.getValue(DB_PASS_PATH, DEFAULT_STRING_NULL);
	if( m_strDBPass == DEFAULT_STRING_NULL ) 
	{
		stringstream ssErrMsg;
		ssErrMsg << "Not Find Node: " << DB_PASS_PATH;
	
		throw CException(ERR_NULL_XML_NODE, ssErrMsg.str());
	}
	
	m_strDBPort = config.getValue(DB_PORT_PATH, DEFAULT_STRING_NULL);
	if( m_strDBPort == DEFAULT_STRING_NULL ) 
	{
		stringstream ssErrMsg;
		ssErrMsg << "Not Find Node: " << DB_PORT_PATH;
	
		throw CException(ERR_NULL_XML_NODE, ssErrMsg.str());
	}

	m_iDBOverTime = config.getValue(DB_PASS_PATH, DEFAULT_DB_OVERTIME);
	

	//relay
	sRelayIP = config.getValue(CONF_RELAY_SERVERIP, DEFAULT_STRING_NULL);
	if( sRelayIP == DEFAULT_STRING_NULL ) 
	{
		stringstream ssErrMsg;
		ssErrMsg << "Not Find Node: " << CONF_RELAY_SERVERIP;
	
		throw CException(ERR_NULL_XML_NODE, ssErrMsg.str());
	}	

	iRelayPort = config.getValue(CONF_RELAY_SERVERPORT, 22000);
	iRelayTimeOut = config.getValue(CONF_RELAY_TIMEOUT, 10);

	//������APP
	m_strBillServerIp = config.getValue(CONF_BILL_SERVERIP, DEFAULT_STRING_NULL);
	if(m_strBillServerIp  == DEFAULT_STRING_NULL ) 
	{
		stringstream ssErrMsg;
		ssErrMsg << "Not Find Node: " << CONF_BILL_SERVERIP;
	
		throw CException(ERR_NULL_XML_NODE, ssErrMsg.str());
	}	

	m_iBillPort = config.getValue(CONF_BILL_SERVERPORT, 7950);
	m_iAppid = config.getValue(CONF_BILL_APPID, 4);
	

	m_strCompanyConfFile = config.getValue(CONF_COMPANY, DEFAULT_STRING_NULL);
	if( m_strCompanyConfFile == DEFAULT_STRING_NULL ) 
	{
		stringstream ssErrMsg;
		ssErrMsg << "Not Find Node: " << CONF_COMPANY;
	
		throw CException(ERR_NULL_XML_NODE, ssErrMsg.str());
	}	


}
#if 0

// ��ȡ��־����
void CConfig::readLogConf() throw(CException)
{
	// �����ļ�
	XmlConfig config(m_strLogConfFile.c_str());
	if( !config ) 
	{
		stringstream ssErrMsg;
		ssErrMsg << "XmlConfig Init [" << m_strLogConfFile<< "]: " << config.getLastError();
	
		throw CException(ERR_LOAD_CFG, ssErrMsg.str());
	}

	TiXmlNode* pRootNode = config.getNode("/root");
	if(NULL == pRootNode )
	{
		stringstream ssErrMsg;
		ssErrMsg << "Not Find Node: " << "/root";
	
		throw CException(ERR_NULL_XML_NODE, ssErrMsg.str());
	}

	XmlNodeWrapper rootNode(pRootNode);    
	TiXmlNode* pNodeRecords = rootNode->FirstChild("log");	
	TiXmlNode* pLogLevel = NULL;
	pNodeRecords=pNodeRecords->NextSibling("log");

	pName = pNodeRecords->FirstChild("LogLevel");	
	if(NULL == pName)
	{
		stringstream ssErrMsg;
		ssErrMsg << "Not Find Node: " << "LogLevel";

		throw CException(ERR_NULL_XML_NODE, ssErrMsg.str());
	}

	log_level = XmlNodeWrapper(pName).getValue("");

	m_ObjCompanyInfo[strSpid].setSpid(strSpid.c_str());

	gPtrAppLog->debug("strSpid:%s", strSpid.c_str());
	gPtrAppLog->debug("CompanystrSpid:%s", m_ObjCompanyInfo[strSpid].m_strSpid.c_str());
	
	pName = pNodeRecords->FirstChild("company_name");	
	if(pName == NULL)
	{
		stringstream ssErrMsg;
		ssErrMsg << "Not Find Node: " << "company_name";

		throw CException(ERR_NULL_XML_NODE, ssErrMsg.str());
	}

}

#endif

// ��ȡ��˾����
void
CConfig::readCompanyConf() throw(CException)
{
	// �����ļ�
	XmlConfig config(m_strCompanyConfFile.c_str());
	if( !config ) 
	{
		stringstream ssErrMsg;
		ssErrMsg << "XmlConfig Init [" << m_strCompanyConfFile<< "]: " << config.getLastError();
	
		throw CException(ERR_LOAD_CFG, ssErrMsg.str());
	}

	TiXmlNode* pRootNode = config.getNode("/root");
	if(NULL == pRootNode )
	{
		stringstream ssErrMsg;
		ssErrMsg << "Not Find Node: " << "/root";
	
		throw CException(ERR_NULL_XML_NODE, ssErrMsg.str());
	}

	XmlNodeWrapper rootNode(pRootNode);    
	TiXmlNode* pNodeRecords = rootNode->FirstChild("company");	
	TiXmlNode* pName = NULL;
	for(; pNodeRecords; pNodeRecords=pNodeRecords->NextSibling("company") )
	{
		pName = pNodeRecords->FirstChild("company_spid");	
		if(pName == NULL)
		{
			continue;
		}

		string strSpid = XmlNodeWrapper(pName).getValue("");

		m_ObjCompanyInfo[strSpid].setSpid(strSpid.c_str());

		gPtrAppLog->debug("strSpid:%s", strSpid.c_str());
		gPtrAppLog->debug("CompanystrSpid:%s", m_ObjCompanyInfo[strSpid].m_strSpid.c_str());
		
		pName = pNodeRecords->FirstChild("company_name");	
		if(pName == NULL)
		{
			stringstream ssErrMsg;
			ssErrMsg << "Not Find Node: " << "company_name";
	
			throw CException(ERR_NULL_XML_NODE, ssErrMsg.str());
		}

		m_ObjCompanyInfo[strSpid].setCompanyName(XmlNodeWrapper(pName).getValue(""));

		gPtrAppLog->debug("company_name:%s", m_ObjCompanyInfo[strSpid].m_strCompanyName.c_str());
		
		pName = pNodeRecords->FirstChild("operate_type");	
		if(pName == NULL)
		{
			stringstream ssErrMsg;
			ssErrMsg << "Not Find Node: " << "operate_type";
	
			throw CException(ERR_NULL_XML_NODE, ssErrMsg.str());
		}
	
		m_ObjCompanyInfo[strSpid].setOperateType(XmlNodeWrapper(pName).getValue(-1));

		gPtrAppLog->debug("operate_type:%d", m_ObjCompanyInfo[strSpid].m_iOperateType);
		
		pName = pNodeRecords->FirstChild("reqcharacterset");	
		if(pName == NULL)
		{
			stringstream ssErrMsg;
			ssErrMsg << "Not Find Node: " << "reqcharacterset";
	
			throw CException(ERR_NULL_XML_NODE, ssErrMsg.str());
		}
	
		m_ObjCompanyInfo[strSpid].setReqCharecterSet(XmlNodeWrapper(pName).getValue("").c_str());

		gPtrAppLog->debug("reqcharacterset:%s", m_ObjCompanyInfo[strSpid].m_strReqCharecterSet.c_str());
		
		pName = pNodeRecords->FirstChild("rescharacterset");	
		if(pName == NULL)
		{
			stringstream ssErrMsg;
			ssErrMsg << "Not Find Node: " << "rescharacterset";
	
			throw CException(ERR_NULL_XML_NODE, ssErrMsg.str());
		}
	
		m_ObjCompanyInfo[strSpid].setResCharecterSet(XmlNodeWrapper(pName).getValue("").c_str());

		gPtrAppLog->debug("rescharacterset:%s", m_ObjCompanyInfo[strSpid].m_strResCharecterSet.c_str());
		
		pName = pNodeRecords->FirstChild("md5key");	
		if(pName == NULL)
		{
			stringstream ssErrMsg;
			ssErrMsg << "Not Find Node: " << "md5key";
	
			throw CException(ERR_NULL_XML_NODE, ssErrMsg.str());
		}
	
		m_ObjCompanyInfo[strSpid].setMd5Key(XmlNodeWrapper(pName).getValue("").c_str());

		gPtrAppLog->debug("md5key:%s", m_ObjCompanyInfo[strSpid].m_strMd5Key.c_str());
		
		pName = pNodeRecords->FirstChild("operate_conf");	
		if(pName == NULL)
		{
			stringstream ssErrMsg;
			ssErrMsg << "Not Find Node: " << "operate_conf";
	
			throw CException(ERR_NULL_XML_NODE, ssErrMsg.str());
		}

		// �������в���
		TiXmlNode* pTmpNodeRecords = pName->FirstChild("operate");	
		TiXmlNode* pTmpName = NULL;
		
		for(; pTmpNodeRecords; pTmpNodeRecords=pTmpNodeRecords->NextSibling("operate") )
		{
			string	strOperateName;		// ��������
			string	strOperateUrl;		// �������õ�Url
			string  strErrSign;			// �����־	

			string  strEnCodeFunc;                         // ���ܴ�����������

			TemplateConf_T   ObjRequestConf;			// �����������    (Ϊģ���滻)
			TemplateConf_T   ObjRespondConf;			// ���ز���������  (Ϊkey:valueģʽ)
			TemplateConf_T   ObjErrInfoConf;			// ������Ϣ������  (Ϊkey:valueģʽ)

			pTmpName = pTmpNodeRecords->FirstChild("operate_name");	
			
			if(pTmpName == NULL)
			{
				continue;
			}

			strOperateName = XmlNodeWrapper(pTmpName).getValue("");

			gPtrAppLog->debug("operate_name:%s", strOperateName.c_str());

			pTmpName = pTmpNodeRecords->FirstChild("operate_url");	
			if(pTmpName == NULL)
			{
				stringstream ssErrMsg;
				ssErrMsg << "Not Find Node: " << "operate_url";
		
				throw CException(ERR_NULL_XML_NODE, ssErrMsg.str());
			}

			strOperateUrl = XmlNodeWrapper(pTmpName).getValue("");

			pTmpName = pTmpNodeRecords->FirstChild("operate_url");	
			if(pTmpName == NULL)
			{
				stringstream ssErrMsg;
				ssErrMsg << "Not Find Node: " << "operate_url";
		
				throw CException(ERR_NULL_XML_NODE, ssErrMsg.str());
			}

			strOperateUrl = XmlNodeWrapper(pTmpName).getValue("");

			pTmpName = pTmpNodeRecords->FirstChild("err_sign");	
			if(pTmpName == NULL)
			{
				stringstream ssErrMsg;
				ssErrMsg << "Not Find Node: " << "err_sign";
		
				throw CException(ERR_NULL_XML_NODE, ssErrMsg.str());
			}

			strErrSign = XmlNodeWrapper(pTmpName).getValue("");

			pTmpName = pTmpNodeRecords->FirstChild("encodefun");	
			if(pTmpName == NULL)
			{
				strEnCodeFunc = "";
			}
			else
			{
				strEnCodeFunc = XmlNodeWrapper(pTmpName).getValue("");
			}

			// ģ��������Ϣ
			// ����ģ��
			pTmpName = pTmpNodeRecords->FirstChild("request_temptype");	
			if(pTmpName == NULL)
			{
				stringstream ssErrMsg;
				ssErrMsg << "Not Find Node: " << "request_temptype";
		
				throw CException(ERR_NULL_XML_NODE, ssErrMsg.str());
			}

			ObjRequestConf.iTemplateType = XmlNodeWrapper(pTmpName).getValue(-1);

			pTmpName = pTmpNodeRecords->FirstChild("request_temp");	
			if(pTmpName == NULL)
			{
				stringstream ssErrMsg;
				ssErrMsg << "Not Find Node: " << "request_temp";
		
				throw CException(ERR_NULL_XML_NODE, ssErrMsg.str());
			}

			strncpy(ObjRequestConf.szTemplateFile, XmlNodeWrapper(pTmpName).getValue("").c_str(), sizeof(ObjRequestConf.szTemplateFile) - 1);

			// ����ģ��
			pTmpName = pTmpNodeRecords->FirstChild("respond_temptype");	
			if(pTmpName == NULL)
			{
				stringstream ssErrMsg;
				ssErrMsg << "Not Find Node: " << "respond_temptype";
		
				throw CException(ERR_NULL_XML_NODE, ssErrMsg.str());
			}

			ObjRespondConf.iTemplateType = XmlNodeWrapper(pTmpName).getValue(-1);

			pTmpName = pTmpNodeRecords->FirstChild("respond_temp");	
			if(pTmpName == NULL)
			{
				stringstream ssErrMsg;
				ssErrMsg << "Not Find Node: " << "respond_temp";
		
				throw CException(ERR_NULL_XML_NODE, ssErrMsg.str());
			}

			strncpy(ObjRespondConf.szTemplateFile, XmlNodeWrapper(pTmpName).getValue("").c_str(), sizeof(ObjRequestConf.szTemplateFile) - 1);

			// ����ģ��
			pTmpName = pTmpNodeRecords->FirstChild("err_temptype");	
			if(pTmpName == NULL)
			{
				stringstream ssErrMsg;
				ssErrMsg << "Not Find Node: " << "err_temptype";
		
				throw CException(ERR_NULL_XML_NODE, ssErrMsg.str());
			}

			ObjErrInfoConf.iTemplateType = XmlNodeWrapper(pTmpName).getValue(-1);

			pTmpName = pTmpNodeRecords->FirstChild("err_temp");	
			if(pTmpName == NULL)
			{
				stringstream ssErrMsg;
				ssErrMsg << "Not Find Node: " << "err_temp";
		
				throw CException(ERR_NULL_XML_NODE, ssErrMsg.str());
			}

			strncpy(ObjErrInfoConf.szTemplateFile, XmlNodeWrapper(pTmpName).getValue("").c_str(), sizeof(ObjRequestConf.szTemplateFile) - 1);

			// ���Ӳ���
			m_ObjCompanyInfo[strSpid].addOperateConf(strOperateName.c_str(), 
					strOperateUrl.c_str(),  strErrSign.c_str(), strEnCodeFunc.c_str(), 
					&ObjRequestConf, &ObjRespondConf, &ObjErrInfoConf);
		}
	}
}

// ��ȡcache��ʱʱ������
void 
CConfig::readCacheValidConf() throw(CException)
{
	FILE *fp=NULL;
	char buf[MAX_CONF_LINE_LENGTH+1];

	// �����ܼ�����
	int  iCount = 0;
	int  iMinute = 0;

	fp=fopen(m_strCacheValidFile.c_str(), "r");

	//gPtrAppLog->debug("[%s][%d]%s", __FILE__,__LINE__,m_strCacheValidFile.c_str());
	
	if (fp == NULL) 
	{
		stringstream ssErrMsg;
		ssErrMsg << "["<<__FILE__<<"]["<< __LINE__<< "]Not Find File: " << m_strCacheValidFile;

		throw CException(ERR_LOAD_CFG, ssErrMsg.str());
	}

	memset(buf, 0, MAX_CONF_LINE_LENGTH+1);
		
	while(fgets(buf, MAX_CONF_LINE_LENGTH, fp) && iCount < MAX_CACHE_DAYS)
	{
		iCount = 0;
		iMinute = 0;
		
		// ɾ����β���׿հ��ַ�
		strstrip(buf);
		
		// ȥ��ע��
		if (isValidStr(buf) != 0) continue;

		//gPtrAppLog->debug("[%s][%d]%s", __FILE__,__LINE__,buf);

		// �� day:time���н���
		char * pStrBuf = NULL;
		
		// ��ȡday
		pStrBuf = strtok(buf,NOTE_DELIMIT);
		if(!pStrBuf)
		{
			// û��key������
			continue;
		}
		
		iCount = atoi(pStrBuf);
		
		// ��ȡtime
		pStrBuf = strtok(NULL,NOTE_DELIMIT);
		if(!pStrBuf)
		{
			// ��keyû��value���������
			stringstream ssErrMsg;
			ssErrMsg << "Not Find Value Day: " << iCount;

			throw CException(ERR_TEMP_TYPE, ssErrMsg.str());
		}

		iMinute = atoi(pStrBuf);

		// д������(ת��Ϊ����)
		m_arrCacheValidTime[iCount] = iMinute * 60;
		
		// ���洮���
		memset(buf, 0x00, sizeof(buf));
	}

	// �������δ����ȫ������Ϊ���һ��ʱ��
	while(iCount < MAX_CACHE_DAYS)
	{
		m_arrCacheValidTime[iCount] = iMinute * 60;
		++iCount;
	}

	fclose(fp);
}

// ��ȡ��ѯ������������
void 
CConfig::readQueryRetryConf() throw(CException)
{
	FILE *fp=NULL;
	char buf[MAX_CONF_LINE_LENGTH+1];
    
	//��������ļ�δ������ֱ�ӷ���
	if( m_strQueRetryConfFile.empty() )return;

    int iCode=0;//�������
    int iTimes=0;//���Դ���

	fp=fopen(m_strQueRetryConfFile.c_str(), "r");
	if (fp == NULL) 
	{
		stringstream ssErrMsg;
		ssErrMsg << "["<<__FILE__<<"]["<< __LINE__<< "]Not Find File: " << m_strQueRetryConfFile;

		throw CException(ERR_LOAD_CFG, ssErrMsg.str());
	}

	memset(buf, 0, MAX_CONF_LINE_LENGTH+1);
		
	while(fgets(buf, MAX_CONF_LINE_LENGTH, fp) )
	{
		// ɾ����β���׿հ��ַ�
		strstrip(buf);
		
		// ȥ��ע��
		if (isValidStr(buf) != 0) continue;

		// �� code:times���н���
		char * pStrBuf = NULL;
		
		// ��ȡcode
		pStrBuf = strtok(buf,NOTE_DELIMIT);
		if(!pStrBuf)
		{
			// û��key������
			continue;
		}
		
		iCode = atoi(pStrBuf);
		
		// ��ȡtime
		pStrBuf = strtok(NULL,NOTE_DELIMIT);
		if(!pStrBuf)
		{
			// ��keyû��value���������
			stringstream ssErrMsg;
			ssErrMsg << "Not Find Value Times: " << iCode;

			throw CException(ERR_TEMP_TYPE, ssErrMsg.str());
		}

		iTimes = atoi(pStrBuf);
		
        //������Դ���MAX_QUERY_RETRYTIMES
        if( iTimes>MAX_QUERY_RETRYTIMES )iTimes=MAX_QUERY_RETRYTIMES;
            
		// д������(ת��Ϊ����)
		m_ErrCodeToRetryTimes[iCode] = iTimes;
		
		// ���洮���
		memset(buf, 0x00, sizeof(buf));
	}

	fclose(fp);
}

// ��ȡ������Ϣת������
void 
CConfig::readErrConf() throw(CException)
{
	FILE *fp=NULL;
	char buf[MAX_CONF_LINE_LENGTH+1];

	fp=fopen(m_strErrToCodeFile.c_str(), "r");

	//gPtrAppLog->debug("[%s][%d]%s", __FILE__,__LINE__,m_strCacheValidFile.c_str());
	
	if (fp == NULL) 
	{
		stringstream ssErrMsg;
		ssErrMsg << "["<<__FILE__<<"]["<< __LINE__<< "]Not Find File: " << m_strCacheValidFile;

		throw CException(ERR_LOAD_CFG, ssErrMsg.str());
	}

	memset(buf, 0, MAX_CONF_LINE_LENGTH+1);
		
	while(fgets(buf, MAX_CONF_LINE_LENGTH, fp))
	{
		string strErrinfo;
		int    iErrno;
		
		// ɾ����β���׿հ��ַ�
		strstrip(buf);
		
		// ȥ��ע��
		if (isValidStr(buf) != 0) continue;

		//gPtrAppLog->debug("[%s][%d]%s", __FILE__,__LINE__,buf);

		// �� errinfo|errno���н���
		char * pStrBuf = NULL;
		
		// ��ȡday
		pStrBuf = strtok(buf,"|");
		if(!pStrBuf)
		{
			// û��key������
			continue;
		}

		// ȥ����β�Ŀո�
		strstrip(pStrBuf);
		strErrinfo = pStrBuf;
		
		// ��ȡtime
		pStrBuf = strtok(NULL,"|");
		if(!pStrBuf)
		{
			// ��keyû��value���������
			continue;
		}

		iErrno = atoi(pStrBuf);

		// д��map
		m_ErrToCode[strErrinfo] = iErrno;
		
		// ���洮���
		memset(buf, 0x00, sizeof(buf));
	}

	fclose(fp);

	// ȫ����ӡ������������
	for(map<string, int>::iterator it = m_ErrToCode.begin();
			it != m_ErrToCode.end(); ++it)
	{
		gPtrAppLog->debug("[%s]|[%d]", it->first.c_str(), it->second);
	}
}


// ��ȡ�����ļ�
void 
CConfig::readConf() throw(CException)
{
	// ��ȡϵͳ�����ļ�
	readSysConf();

	// ��ȡcache�����ļ�
//	readCacheValidConf();

    // ��ȡ��ѯ�������������ļ�
//    readQueryRetryConf();

	// ��ȡ��˾�����ļ�
	readCompanyConf();

	// ��ȡ��־�����ļ�
//	readLogConf();
	
	// ��ȡ������Ϣ�����ļ�
//	readErrConf();
	//read fare and ei
//	readFareEi();
}


// ��ȡ������Ϣת������
void 
CConfig::readFareEi() throw(CException)
{
        gPtrAppLog->debug("read Fare Ei file : %s",m_strFareEiFile.c_str());
	FILE *fp=NULL;
	char buf[MAX_CONF_LINE_LENGTH+1];

	fp=fopen(m_strFareEiFile.c_str(), "r");

	
	if (fp == NULL) 
	{
		stringstream ssErrMsg;
		ssErrMsg << "["<<__FILE__<<"]["<< __LINE__<< "]Not Find File: " << m_strFareEiFile;

		throw CException(ERR_LOAD_CFG, ssErrMsg.str());
	}

	memset(buf, 0, MAX_CONF_LINE_LENGTH+1);
		
	while(fgets(buf, MAX_CONF_LINE_LENGTH, fp))
	{
		string 		index;
		string    fareEiStr;
		
		// ɾ����β���׿հ��ַ�
		strstrip(buf);
		
		// ȥ��ע��
		if (isValidStr(buf) != 0) continue;

		//gPtrAppLog->debug("[%s][%d]%s", __FILE__,__LINE__,buf);

		// �� index|farerestriction or ei ���н���
		char * pStrBuf = NULL;
		
		// ��ȡindex
		pStrBuf = strtok(buf,"|");
		if(!pStrBuf)
		{
			// û��key������
			continue;
		}

		// ȥ����β�Ŀո�
		strstrip(pStrBuf);
		index = pStrBuf;
		
		// ��ȡvalue
		pStrBuf = strtok(NULL,"|");
		if(!pStrBuf)
		{
			// ��keyû��value���������
			continue;
		}
		fareEiStr=pStrBuf;
		// д��map
		m_FareEi[index] = fareEiStr;
		
		// ���洮���
		memset(buf, 0x00, sizeof(buf));
	}

	fclose(fp);

	// ȫ����ӡ������������
	for(map<string, string>::iterator it = m_FareEi.begin();
			it != m_FareEi.end(); ++it)
	{
		gPtrAppLog->error("[%s]|[%s]", it->first.c_str(), it->second.c_str());
	}
}


