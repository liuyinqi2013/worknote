/*
����:
       1. ִ������

Created by Song, 2003-03
Change list:

*/

#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <libgen.h>
#include <errno.h>

#include "socket.h"
#include "trpc_server.h"

#include <string>
using namespace std;

#define     RES_BUF_HEAD    "LENGTH:"

// ��������,�鷳
static const int MAX_COMMAND_DATA_LEN = 65536;

static int
call_cmd(const char * pAdminIP, int iPort, const char *pCmd)
{
    static const int RET_HEADER_LENGTH = 128;
    char buf[MAX_COMMAND_DATA_LEN];
    int bytes;
    Socket sock;
    try {
        sock.create();
        sock.connect(pAdminIP, iPort);

        bytes = sprintf(buf, " %s\n", pCmd);
        printf("%s", buf);
        sock.send(buf, bytes + 1);

        memset(buf, 0x00, sizeof(buf));

        // �Ƚ���LENGTH: xxx ����, 128�ֽ��㹻
        bytes = sock.receive(buf, RET_HEADER_LENGTH);

        // ͷΪLENGTH:
        int total_length = atoi(buf + sizeof("LENGTH:"));

        // ��ͷ�ܳ���Ϊ
        int head_length = strstr(buf, "\n") - buf;

        int need_recv = total_length + head_length - bytes;

        if (total_length + head_length > MAX_COMMAND_DATA_LEN) {
            printf("ret msg too long %d > %d\n", 
                total_length + head_length, MAX_COMMAND_DATA_LEN);
        }

        char * read_ptr = buf + bytes;
        while(need_recv > 0){
            bytes = sock.receive(read_ptr, need_recv);

            if (bytes <=0) {
                perror("receive error");
                return -1;
            }

            read_ptr += bytes;
            need_recv -= bytes;
        }

        printf("%s", buf);
    }
    catch(SocketException & e) {
        fprintf(stderr, "ERROR: %s\n", e.what());
        return -1;
    }

    return 0;
}

static void
usage(const char *sProcName)
{
    printf
        ("Usage: %s IP AdminPort cmd \tִ��middle����\n",
         sProcName);
}

int
main(int argc, char **argv)
{
    if (argc < 4) {
        usage(argv[0]);
        return -1;
    }

    if (call_cmd(argv[1], atoi(argv[2]), argv[3]) != 0) {
        return -1;
    }

    return 0;
}

