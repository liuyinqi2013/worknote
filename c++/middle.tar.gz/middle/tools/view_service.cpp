/*
����: 
       1.  �鿴service��so�ļ����service�б�

Created by Song, 2003.08
Change list:

*/


#include <algorithm>
#include <functional>
#include <string>
#include <vector>
using namespace std;


#include <cstdio>
#include <cstring>
#include <ctype.h>
#include <dlfcn.h>
#include <assert.h>
#include <errno.h>

#include "trpc_service.h"

static Service_InitializeFunc_T * _pfnServiceInit;
static GetFirstRunTimeServiceFunc_T * _pfnGetFirstRunTime;
static ServiceSoInitFunc_T * _pfnSoInit;
static ServiceSoFiniFunc_T * _pfnSoFini;

int
ViewService(const char * sSoFile)
{
    // ���ض�̬��
    void * pSoHnd = dlopen(sSoFile, RTLD_LAZY);
    if (pSoHnd == NULL) {
        fprintf(stderr,  "dlopen %s\n", dlerror());
        return -1;
    }

    // ȡ����ָ��
    _pfnServiceInit = (Service_InitializeFunc_T *)
        dlsym(pSoHnd, SERVICE_TRPC_SERVICE_INIT_NAME);
    if (_pfnServiceInit == NULL) {
        fprintf(stderr,  "dlsym %s: %s\n",
                SERVICE_TRPC_SERVICE_INIT_NAME, dlerror());
        return -1;
    }

    // ������������������NULL
    _pfnSoInit = (ServiceSoInitFunc_T *) dlsym(pSoHnd, SERVICE_SO_INIT_NAME);
    _pfnSoFini = (ServiceSoFiniFunc_T *) dlsym(pSoHnd, SERVICE_SO_FINI_NAME);

    _pfnGetFirstRunTime = (GetFirstRunTimeServiceFunc_T *)
        dlsym(pSoHnd, SERVICE_GET_FIRST_RUNTIME_NAME);
    if (_pfnGetFirstRunTime == NULL) {
        fprintf(stderr,  "dlsym %s: %s\n",
                SERVICE_GET_FIRST_RUNTIME_NAME, dlerror());
        return -1;
    }


    printf("_init: 	%s\n", _pfnSoInit != NULL ? "yes":"no");
    printf("_fini: 	%s\n", _pfnSoFini != NULL ? "yes":"no");

    vector<string> vService;
    for (CRunTimeService * p = _pfnGetFirstRunTime();
         p != NULL; p = p->_pNext) {
        if (strcmp(p->_pszServiceName, "CRunTimeService") == 0) {
            continue;
        }

	vService.push_back(string(p->_pszServiceName));
    }

    sort(vService.begin(), vService.end());
    for (vector<string>::const_iterator iter = vService.begin();
    iter != vService.end();
    ++iter){
    	printf("Service: %s\n", iter->c_str());
    }

    return 0;
}

static void
PrintUsage(const char * sProcName)
{
	fprintf(stderr, "Usage: %s sofile\n", sProcName);
}

int
main(int argc, char ** argv)
{
	if (argc < 2){
		PrintUsage(argv[0]);
		return -1;
	}

	const char * sSoFile = argv[1];
	char sRealSoFile[256];
	if (sSoFile[0] != '/'){
		sprintf(sRealSoFile, "./%s", sSoFile);
	}
	else{
		strcpy(sRealSoFile, sSoFile);
	}
	
	return ViewService(sRealSoFile);
}

