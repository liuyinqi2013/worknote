#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/time.h>
#include <sys/types.h>
#include <assert.h>

#ifndef false
#define false (0 != 0)
#endif

#ifndef true
#define true (0 == 0)
#endif


#include "trpc_client.h"

TRPC_INFO *g_pTrpcHnd;

static int
test_Login(const char * sIP)
{
    int iRetVal;

    g_pTrpcHnd = trpc_info_create(sIP, 28000, "trpc", "middle", 300);
    iRetVal = trpc_open(g_pTrpcHnd);
    if (iRetVal != 0) {
        fprintf(stderr, "iRetVal: %d\n", iRetVal);
        fprintf(stderr, "ERROR: %s\n", trpc_error(g_pTrpcHnd));
        return -1;
    }
    return 0;
}

static int
test_TrpcCall(const char * sServiceName, const char * sIn)
{
    char sOut[32000];
    size_t iOutSize;
    int iRetVal;

    iOutSize = sizeof(sOut);
    iRetVal = trpc_call(g_pTrpcHnd, sServiceName,
                            sIn, strlen(sIn), sOut, &iOutSize);
    if (iRetVal != 0) {
        fprintf(stderr, "iRetVal: %d\n", iRetVal);
        fprintf(stderr, "ERROR: %s\n", trpc_error(g_pTrpcHnd));
        return -1;
    }

    printf("%.*s\n", (int)iOutSize, sOut);
    return 0;
}


static int
test(const char * sIP, const char * sServiceName, const char * sIn)
{
    int iRetVal = 0;
    if (test_Login(sIP) != 0){
        return -1;
    }

    iRetVal = test_TrpcCall(sServiceName, sIn);
    
    trpc_close(g_pTrpcHnd);

    return iRetVal;
}

int
main(int argc, char **argv)
{
    if (argc < 4){
        fprintf(stderr, "Usage: %s IP ServiceName InData\n", argv[0]);
	return -1;
    }

    return test(argv[1], argv[2], argv[3]);
}
