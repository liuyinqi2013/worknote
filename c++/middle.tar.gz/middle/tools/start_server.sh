#!/usr/bin/expect --

spawn telnet localhost 28001
expect "Escape character is '^]'."
send "start upay_server\r"

