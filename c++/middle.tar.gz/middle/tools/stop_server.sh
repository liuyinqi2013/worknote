#!/usr/bin/expect --

spawn telnet localhost 28001
expect "Escape character is '^]'."
send "stop upay_server\r"
