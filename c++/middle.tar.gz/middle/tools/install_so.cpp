/*
����:
       1. ����service��̬��

Created by Song, 2003-03
Change list:

*/

#include <stdio.h>
#include <string.h>
#include <libgen.h>
#include <errno.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
       
#include "socket.h"
#include "trpc_server.h"

static int
install_so(const char *sSrcSoFile, const char *sServerName)
{
    char sTrpcHome[256];

    const char *pTrpcHome = getenv(TRPC_HOME_NAME);
    if (pTrpcHome == NULL) {
        fprintf(stderr, "ERROR: environment variable '%s' not found\n",
                TRPC_HOME_NAME);
        return -1;
    }
    if (strcmp(pTrpcHome, "") == 0) {
        fprintf(stderr, "'ERROR: %s' is ''\n", TRPC_HOME_NAME);
        return -1;
    }

    strcpy(sTrpcHome, pTrpcHome);
    size_t nLen = strlen(sTrpcHome);
    if (nLen > 0 && sTrpcHome[nLen - 1] != '/') {
        strcpy(sTrpcHome + nLen, "/");
    }

    char sSoFileName[256];
    strcpy(sSoFileName, sSrcSoFile);
    strcpy(sSoFileName, basename(sSoFileName));
    nLen = strlen(sSoFileName);
    if (nLen < 3 || strcmp(sSoFileName + nLen - 3, ".so") != 0) {
        fprintf(stderr, "so file must ends with '.so'\n");
        return -1;
    }

    char sDestSoFile[256];
    time_t tNow = time(NULL);
    struct tm tm;
    localtime_r(&tNow, &tm);
    sprintf(sDestSoFile, "%sso/%s/%s.%04d%02d%02d%02d%02d%02d",
            sTrpcHome,
            sServerName,
            sSoFileName,
            tm.tm_year + 1900, tm.tm_mon + 1,
            tm.tm_mday, tm.tm_hour, tm.tm_min, tm.tm_sec);

    // �����־Ŀ¼�����ڣ�����Ŀ¼
    char sSoDir[256];
    strcpy(sSoDir, sDestSoFile);
    strcpy(sSoDir, dirname(sSoDir));
    struct stat stStat;
    if (stat(sSoDir, &stStat) != 0) {
        if (mkdir(sSoDir, 0775) < 0) {
            fprintf(stderr, "mkdir %s: %s\n", sSoDir, strerror(errno));
            return -1;
        }
    }
    
    // cp sSoFile sDestSoFile
    char sCommand[1024];
    sprintf(sCommand, "cp %s %s", sSrcSoFile, sDestSoFile);
    printf("%s\n", sCommand);
    if (system(sCommand) != 0) {
        return -1;
    }

    return 0;
}

static int
load_so(const char * pAdminIP, int iPort, const char *sServerName)
{
    char buf[MAX_TRPC_DATA_LEN];
    int bytes;
    Socket sock;
    try {
        sock.create();
        sock.connect(pAdminIP, iPort);

        bytes = sprintf(buf, "call loadso %s\n", sServerName);
        printf("%s", buf);
        sock.send(buf, bytes + 1);
        bytes = sock.receive(buf, sizeof(buf));
        printf("%.*s", bytes, buf);
    }
    catch(SocketException & e) {
        fprintf(stderr, "ERROR: %s\n", e.what());
        return -1;
    }

    return 0;
}

static void
usage(const char *sProcName)
{
    printf("Usage: %s sofile ServerName\t\t\tֻcp�ļ�\n", sProcName);
    printf
        ("Usage: %s sofile ServerName IP AdminPort\tcp�ļ�������server���¼���so\n",
         sProcName);
}

int
main(int argc, char **argv)
{
    bool bIsLoadso = false;
    const char * pAdminIP = NULL;
    int iAdminPort = 0;
    if (argc < 3 || argc == 4) {
        usage(argv[0]);
        return -1;
    }

    const char *pSofile = argv[1];
    const char *pServerName = argv[2];
    if (argc >= 5) {
        bIsLoadso = true;
        pAdminIP = argv[3];
        iAdminPort = atoi(argv[4]);
    }

    if (install_so(pSofile, pServerName) != 0) {
        return -1;
    }

    if (bIsLoadso) {
        if (load_so(pAdminIP, iAdminPort, pServerName) != 0) {
            return -1;
        }
    }

    return 0;
}
