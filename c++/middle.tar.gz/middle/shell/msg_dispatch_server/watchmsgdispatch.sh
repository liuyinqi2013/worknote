#!/bin/sh

cd /usr/local/middle/shell/msg_dispatch_server

numcs=`ps -ef|grep msd_dispatch.sh |grep -v "grep" | grep -v watch|wc -l`

if [ ${numcs} -eq 0  ] 
then
  echo "msd_dispatch need restart"
  date >> ./watch.log
  echo "msd_dispatch not exist, restart" >> ./watch.log
  sleep 2
  exec ./msd_dispatch.sh &
fi
