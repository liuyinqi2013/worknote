#!/bin/sh
#����˵����
#author:collin.jey
day=`date +%Y%m%d`
WORKPATH="/usr/local/middle/shell/msg_dispatch_server"
LogPath="${WORKPATH}/log"
LOG="${LogPath}/msg_dispatch.log"
listidf="${WORKPATH}/msg_dispatch.cs"
MYSQL='/usr/local/mysql/bin/mysql'

cd $WORKPATH
date >> ${LOG}
>${listidf}

timestamp=`date +%s`

while [ 1 ]
do
> ${listidf}

"handling msg_dispatch..." >> ${LOG}
Table="message_db.t_message_snd_req"
DBHOST=192.168.0.115
DBPORT=3306
DBUSER=testMiddle
DBPWD=testMiddle

sql="select Fmsg_id from $Table  where (Fstate='1' or Fstate = '3') and Fsnd_num < Fmax_num " 

st=`date +%s`
$MYSQL >> ${listidf} -u ${DBUSER} -h${DBHOST} -P${DBPORT} -p${DBPWD} -f -N <<!
$sql
!

echo "sending to cgi..."
while read listid
do
if [ -z "${listid}" ] ; then
        continue;
fi
echo ${listid}
dd=`date +"%Y%m%d %T"`
echo "[${dd}]${listid}" >> ${LOG}
curl "http://192.168.0.119/cgi-bin/v2.0/msg_dispatch.cgi?msg_id=${listid}" -x192.168.0.119:80
done < ${listidf}

echo "sending to cgi done"


dd=`date +"%Y%m%d %T"`
echo "${dd}" >> ${LOG}
echo "loop done time"
echo "" >> ${LOG}
echo "" >> ${LOG}
echo "" >> ${LOG}
echo "" >> ${LOG}
echo "" >> ${LOG}
echo "" >> ${LOG}
sleep 15 
done

exit
