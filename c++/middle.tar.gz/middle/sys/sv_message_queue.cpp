/*
����: 
       1.  System V ��Ϣ���е�C++��װ

Created by Song, 2003.01
Change list:

*/

#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <errno.h>

#include "sv_message_queue.h"

SVMessageQueue::SVMessageQueue()
:  _key(-1), _oflag(0), _msgid(-1), _is_init(false)
{
    _error_text[0] = '\0';
}

SVMessageQueue::SVMessageQueue(key_t key, int oflag)
{
    init(key, oflag);
}

void
SVMessageQueue::init(key_t key, int oflag)
{
    _key = key;
    _oflag = oflag;
    _msgid = -1;

    _is_init = true;

    _error_text[0] = '\0';
}

SVMessageQueue::~SVMessageQueue()
{
    close();
}

int
SVMessageQueue::create()
{
    if (!_is_init) {
        sprintf(_error_text, "not init");
        return -1;
    }

    _msgid = msgget(_key, _oflag | IPC_CREAT | IPC_EXCL);
    if (_msgid < 0) {
        if (errno != EEXIST) {
            sprintf(_error_text, "msgget: %s", strerror(errno));
            return -1;
        }
        else {
            // �Ѵ��� 
            return 1;
        }
    }

    return 0;
}

int
SVMessageQueue::open()
{
    if (!_is_init) {
        sprintf(_error_text, "not init");
        return -1;
    }

    _msgid = msgget(_key, _oflag);
    if (_msgid < 0) {
        sprintf(_error_text, "msgget: %s", strerror(errno));
        return -1;
    }

    return 0;
}

int
SVMessageQueue::close()
{
//      _msgid = -1;
    return 0;
}

int
SVMessageQueue::send(SVMessage & msg, size_t msgsize, int mflags)
{
    if (msgsnd(_msgid, (struct msgbuf *) &msg, msgsize, mflags) < 0) {
        sprintf(_error_text, "msgsnd: %s", strerror(errno));
        return -1;
    }
    return 0;
}

int
SVMessageQueue::recv(SVMessage & msg, size_t msgsize, long mtype, int mflags)
{
    if (msgrcv(_msgid, (struct msgbuf *) &msg, msgsize, mtype, mflags) < 0) {
        sprintf(_error_text, "msgrcv: %s", strerror(errno));
        return -1;
    }
    return 0;
}

int
SVMessageQueue::remove()
{
    return control(IPC_RMID);
}

int
SVMessageQueue::control(int cmd, struct msgid_ds *ds /*= 0*/ )
{
    if (msgctl(_msgid, cmd, (struct msqid_ds *) ds) < 0) {
        sprintf(_error_text, "msgctl: %s", strerror(errno));
        return -1;
    }
    return 0;
}
