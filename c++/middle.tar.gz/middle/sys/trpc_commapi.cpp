#include <stdio.h>
#include <errno.h>
#include <unistd.h>
#include <string>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/time.h>
#include <fcntl.h>
#include <signal.h>
#include <libgen.h>
#include <stdarg.h>
#include <signal.h>
#include <ctype.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <unistd.h>
#include <errno.h>
#include <assert.h>
#include <limits.h>

#include "trpc_commapi.h"


/* blame Elliot for these next five routines */
char *
strchug(char *string)
{
    char *start;

    for (start = string; *start && isspace(*start); start++);

    strcpy(string, start);

    return string;
}


char *
strchomp(char *string)
{
    char *s;

    if (!*string)
        return string;

    for (s = string + strlen(string) - 1; s >= string && isspace(*s); s--)
        *s = '\0';

    return string;
}

char *
TrimQuotation(char *string)
{
    size_t len = strlen(string);
    if (string[0] == '"') {
        //  ȥ����ߵ�"
        strcpy(string, string + 1);
        --len;
    }

    if (len > 0) {
        // ȥ���ұߵ�"
        if (string[len - 1] == '"') {
            string[len - 1] = '\0';
        }
    }

    return string;
}

int
DaemonInit(int nochdir, int noclose)
{
    daemon(1, 0);

    signal(SIGINT, SIG_IGN);

    signal(SIGHUP, SIG_IGN);
    signal(SIGQUIT, SIG_IGN);
    signal(SIGPIPE, SIG_IGN);
    signal(SIGTTOU, SIG_IGN);
    signal(SIGTTIN, SIG_IGN);
    signal(SIGCHLD, SIG_IGN);
    signal(SIGTERM, SIG_IGN);
    ignore_pipe();

    return 0;
}


/* This ignores the SIGPIPE signal.  This is usually a good idea, since
   the default behaviour is to terminate the application.  SIGPIPE is
   sent when you try to write to an unconnected socket.  You should
   check your return codes to make sure you catch this error! */
void
ignore_pipe(void)
{
    struct sigaction sig;

    sig.sa_handler = SIG_IGN;
    sig.sa_flags = 0;
    sigemptyset(&sig.sa_mask);
    sigaction(SIGPIPE, &sig, NULL);
}

int
CheckProcess(pid_t pid)
{
    char sPath[256];
    snprintf(sPath, sizeof(sPath), "/proc/%d", pid);

    struct stat stStat;
    if (stat(sPath, &stStat) < 0) {
        return -1;
    }

    return 0;
}

char *
GetToken(char *sToken, int iTokenSize, char *sString, const char *sSeparator)
{
    char *pe;
    int iBytesToCopy;
    int i;

    strstrip(sString);
    pe = strstr(sString, sSeparator);
    if (pe == NULL) {
        if (sToken != NULL) {
            sToken[iTokenSize - 1] = 0;
            strncpy(sToken, sString, iTokenSize - 1);
            strstrip(sToken);
        }
        return sString + strlen(sString);
    }
    else {
        if (sToken != NULL) {
            iBytesToCopy = pe - sString;

            if (iBytesToCopy > iTokenSize - 1) {
                iBytesToCopy = iTokenSize - 1;
            }

            for (i = 0; i < iBytesToCopy; i++) {
                sToken[i] = sString[i];
            }
            sToken[iBytesToCopy] = 0;
            strstrip(sToken);
        }
        return pe + strlen(sSeparator);
    }
}

void
PrintHex(const void *p, size_t sLen)
{
    size_t i;

    assert(NULL != p);
    assert(0 < sLen);

    for (i = 0; i < sLen; i++) {
        if ((i != 0) && (i % 8 == 0)) {
            printf("  ");
        }

        if ((i != 0) && (i % 16 == 0)) {
            printf("\n");
        }

        printf("%02x ", (unsigned char) (*((char *) p + i)));
    }

    printf("\n");
}

char *
get_unix_time(char *strtime)
{
    time_t t;
    struct tm tm;

    t = time(NULL);
    localtime_r(&t, &tm);
    strftime(strtime, 15, "%Y%m%d%H%M%S", &tm);

    return strtime;
}

char *
time2shortstr(time_t t, char *strtime)
{
    struct tm tm;

    localtime_r(&t, &tm);
    strftime(strtime, 15, "%Y%m%d%H%M%S", &tm);

    return strtime;
}

char *
time2longstr(time_t t, char *strtime)
{
    struct tm tm;

    localtime_r(&t, &tm);
    strftime(strtime, 20, "%Y-%m-%d %H:%M:%S", &tm);

    return strtime;
}

time_t
str2time(const char * strtime)
{
	struct tm tm;
	sscanf(strtime, "%04d%02d%02d%02d%02d%02d",
		&tm.tm_year, &tm.tm_mon, &tm.tm_mday,
		&tm.tm_hour, &tm.tm_min, &tm.tm_sec);
	tm.tm_year -= 1900;
	tm.tm_mon -= 1;
	tm.tm_isdst = 0;
	
	return mktime(&tm);
}

void
pr_cpu_time(int (*fuc_print) (const char *format, ...))
{
    double user, sys;
    struct rusage myusage, childusage;
    static struct timeval startTime;
    struct timeval nowTime;
    static int flag = 0;
    double totalTime;

    if (flag == 0) {
        flag = 1;
        gettimeofday(&startTime, NULL);
        return;
    }

    if (getrusage(RUSAGE_SELF, &myusage) < 0)
        fuc_print("getrusage error\n");
    if (getrusage(RUSAGE_CHILDREN, &childusage) < 0)
        fuc_print("getrusage error\n");

    user = (double) myusage.ru_utime.tv_sec +
        myusage.ru_utime.tv_usec / 1000000.0;
    user += (double) childusage.ru_utime.tv_sec +
        childusage.ru_utime.tv_usec / 1000000.0;
    sys = (double) myusage.ru_stime.tv_sec +
        myusage.ru_stime.tv_usec / 1000000.0;
    sys += (double) childusage.ru_stime.tv_sec +
        childusage.ru_stime.tv_usec / 1000000.0;

    gettimeofday(&nowTime, NULL);
    totalTime = (nowTime.tv_sec - startTime.tv_sec)
        + (nowTime.tv_usec - startTime.tv_usec) / 1000000.0;
    totalTime += 0.12;

    fuc_print("user time = %g, sys time = %g, total time = %.2f\n",
              user, sys, totalTime);
}

static void
memfatal(const char *s)
{
    printf("%s: Not enough memory.\n", s);
    exit(1);
}

int 
IsAllDigits(const char * buf)
{
    const char * p = buf;

    if (p == NULL)
    {
        return -1;
    }

    while (*p != '\0')
    {
        if (! isdigit(*p))
        {
            return -1;
        }
        p++;
    }

    return 0;
}

void
SplitString(const char *sStr,
                       const char *sDelimiter,
                       int iMaxTokens, vector < string > &vArray)
{
    vArray.clear();

    // ȥ��ǰ��Ŀո�
    while (isspace(*sStr)) {
        ++sStr;
    }

    const char *s = strstr(sStr, sDelimiter);

    if (s) {
        int iDelimiterLen = strlen(sDelimiter);

        do {
            int iLen = s - sStr;
            int iRealLen = iLen;
            // ȥ������Ŀո�

            for (const char *p = s - 1; p > sStr && isspace(*p); --p) {
                --iRealLen;
            }
            vArray.push_back(string(sStr, iRealLen));

            sStr = s + iDelimiterLen;

            // ȥ��ǰ��Ŀո�
            while (isspace(*sStr)) {
                ++sStr;
            }
            s = strstr(sStr, sDelimiter);
        }
        while (--iMaxTokens && s && *s);
    }

    if (*sStr) {
        // ȥ������Ŀո�
        int iRealLen = strlen(sStr);
        for (const char *p = sStr + iRealLen - 1;
        p > sStr && isspace(*p);
        --p) {
            --iRealLen;
        }
        vArray.push_back(string(sStr, iRealLen));
    }

    return;
}

char **
strsplit(const char *string, const char *delimiter, int max_tokens)
{
    char **str_array, *s;
    int i;

    if (max_tokens < 1)
        max_tokens = INT_MAX;

    i = 0;
    str_array = NULL;

    s = strstr(string, delimiter);
    if (s) {
        int delimiter_len = strlen(delimiter);

        do {
            int len;
            char *new_string;

            len = s - string;
            new_string = (char *) xmalloc("new_string", len + 1);
            strncpy(new_string, string, len);
            new_string[len] = 0;
            str_array =
                (char **) xrealloc(str_array, (i + 2) * sizeof(char *));
            str_array[i] = new_string;
            str_array[++i] = NULL;

            string = s + delimiter_len;
            s = strstr(string, delimiter);
        }
        while (--max_tokens && s);
    }
    if (*string) {
        str_array = (char **) xrealloc(str_array, (i + 2) * sizeof(char *));
        str_array[i] = xstrdup(string);
        str_array[++i] = NULL;
    }

    return str_array;
}

void
strfreev(char **str_array)
{
    if (str_array) {
        int i;

        for (i = 0; str_array[i] != NULL; i++)
            free(str_array[i]);

        free(str_array);
    }
}

void *
xmalloc(char *var_name, size_t size)
{
    void *res;

    res = malloc(size);
    if (!res) {
        printf("%s\t", var_name);
        memfatal("malloc");
    }
    return res;
}

void *
xrealloc(void *obj, size_t size)
{
    void *res;

    if (obj)
        res = realloc(obj, size);
    else
        res = malloc(size);
    if (!res)
        memfatal("realloc");
    return res;
}

char *
xstrdup(const char *s)
{
    int l = strlen(s);
    char *s1 = (char *) malloc(l + 1);

    if (!s1)
        memfatal("strdup");
    memcpy(s1, s, l + 1);
    return s1;
}

