/*
����: 
       1.  System V �����ڴ��C++��װ

Created by Song, 2003.01
Change list:

*/

#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <errno.h>

#include "sv_shared_memory.h"

SVSharedMemory::SVSharedMemory()
:  _key(-1),
_oflag(0), _shmsize(0), _shmid(-1), _shm_ptr(NULL), _is_init(false)
{
    _error_text[0] = '\0';
}

SVSharedMemory::SVSharedMemory(key_t key, int oflag, size_t shmsize)
{
    init(key, oflag, shmsize);
    _error_text[0] = '\0';
}

void
SVSharedMemory::init(key_t key, int oflag, size_t shmsize)
{
    _key = key;
    _oflag = oflag;
    _shmsize = shmsize;
    _shmid = -1;
    _shm_ptr = NULL;

    _is_init = true;

    _error_text[0] = '\0';
}

SVSharedMemory::~SVSharedMemory()
{
    dettach();
}

int
SVSharedMemory::create()
{
    if (!_is_init) {
        sprintf(_error_text, "not init");
        return -1;
    }

    _shmid = shmget(_key, _shmsize, _oflag | IPC_CREAT | IPC_EXCL);
    if (_shmid < 0) {
        if (errno != EEXIST) {
            /* ���� */
            sprintf(_error_text, "shmget: key==%d, size==%d:5555 %s",
                    _key, _shmsize, strerror(errno));
            return -1;
        }
        else {
            // �Ѿ�����
            return 1;
        }
    }

    //try to access shm
    _shm_ptr = (char *) shmat(_shmid, NULL, 0);
    if (_shm_ptr == (char *) -1) {
        sprintf(_error_text, "shmat shmid==%d: %s", _shmid, strerror(errno));
        //if access failed, try to remove the sharedMemory
        remove();
        return -1;
    }

    // ��ʼ��Ϊ0
    memset(_shm_ptr, 0, _shmsize);

    dettach();
    return 0;
}

int
SVSharedMemory::open_and_attach()
{
    if (!_is_init) {
        sprintf(_error_text, "not init");
        return -1;
    }

    _shmid = shmget(_key, _shmsize, _oflag);
    if (_shmid < 0) {
        /* ���� */
        sprintf(_error_text, "shmget: key==%d, size==%d: %s",
                _key, _shmsize, strerror(errno));
        return -1;
    }

    //try to access shm
    _shm_ptr = (char *) shmat(_shmid, NULL, 0);
    if (_shm_ptr == (char *) -1) {
        sprintf(_error_text, "shmat shmid==%d: %s", _shmid, strerror(errno));
        //if access failed, try to remove the sharedMemory
        remove();
        return -1;
    }

    return 0;
}

int
SVSharedMemory::attach(void *virtual_addr /*= 0*/ , int flag /*= 0*/ )
{
    _shm_ptr = (char *) shmat(_shmid, virtual_addr, flag);
    if (_shm_ptr == (char *) -1) {
        sprintf(_error_text, "shmat shmid==%d: %s", _shmid, strerror(errno));
        //if access failed, try to remove the sharedMemory
        remove();
        return -1;
    }

    return 0;
}

int
SVSharedMemory::dettach()
{
    if (_shm_ptr != NULL) {
        if (shmdt(_shm_ptr) < 0) {
            sprintf(_error_text, "shmdt: %s", strerror(errno));
            return -1;
        }
        _shm_ptr = NULL;
    }

    return 0;
}

int
SVSharedMemory::remove()
{
    dettach();
    return control(IPC_RMID);
}

int
SVSharedMemory::control(int cmd, struct shmid_ds *ds)
{
    if (shmctl(_shmid, cmd, (struct shmid_ds *) ds) < 0) {
        sprintf(_error_text, "shmctl: %s", strerror(errno));
        return -1;
    }

    return 0;
}
