
#include    "trpc_warning.h"

int CTrpcWarning::warning(const char SystemId[], const char ErrorId[], const char Content[])
{
    return __warning(SystemId, ErrorId, Content);
}

int CTrpcWarning::warning(const char ErrorId[], const char Content[])
{
    return __warning(MIDDLE_SYS_ID, ErrorId, Content);
}

int CTrpcWarning::__warning(const char SystemId[], const char ErrorId[], const char Content[])
{
    if (m_ptrEnable != NULL && *m_ptrEnable == 0)
    {  
        trpc_debug_log("Warning IP: %s, Port: %d, SysId: %s, ErrorId: %s, Contend: %s, m_ptrEnable: %d\n",
                m_szIP, m_iPort, SystemId, ErrorId, Content, *m_ptrEnable);
        return 0;
    }
    
    trpc_error_log("Warning IP: %s, Port: %d, SysId: %s, ErrorId: %s, Contend: %s\n",
                m_szIP, m_iPort, SystemId, ErrorId, Content);

    // ����У��
    if (strlen(SystemId) >= MAX_WARNING_TYPE_LENGTH)
    {
        snprintf(_error_text, sizeof(_error_text),
            "SystemId len[%d] error [%s]", strlen(SystemId), SystemId);

        return -1;
    }
    
    if (strlen(ErrorId) >= MAX_WARNING_TYPE_LENGTH)
    {
        snprintf(_error_text, sizeof(_error_text),
            "ErrorId len[%d] error [%s]", strlen(ErrorId), ErrorId);

        return -1;
    }

	// ���memo����,�ض�,������
	/*
    if (strlen(Content) >= MAX_WARNING_CONTENT_LENGTH)
    {
        snprintf(_error_text, sizeof(_error_text),
            "Content len[%d] error [%s]", strlen(Content), Content);

        return -1;
    }
	*/

    // ƴ�������
    RecvDataItem packet;
	memset(&packet, 0x00, sizeof(packet));
    strncpy(packet.mType, "warning", sizeof(packet.mType) - 1);
    strncpy(packet.mUserID, "0", sizeof(packet.mUserID) - 1);  
    strncpy(packet.mSystemId, SystemId, sizeof(packet.mSystemId) - 1);
    strncpy(packet.mlevel, m_szLevel, sizeof(packet.mlevel) - 1);  
    strncpy(packet.mErrorId, ErrorId, sizeof(packet.mErrorId) - 1);
    strncpy(packet.mErrorContent, Content, sizeof(packet.mErrorContent) - 1);  

    // ����socket,��������
    try
    {
        Socket handle;

        handle.create(SOCK_DGRAM);

        handle.send_to(&packet, sizeof(packet),(uint16_t)m_iPort, m_szIP);
    }
    catch(SocketException& ce)
    {
        snprintf(_error_text, sizeof(_error_text),
            "SocketException : %s", ce.what());

        return -1;
    }
    catch(...)
    {
        snprintf(_error_text, sizeof(_error_text),
            "SysException");  

        return -1;
    }

    return 0;
}



