/*
����: 
       1.  Service��̬�ⲿ�ֵĻ����ܹ�

Created by Song, 2003-01,02
Change list:

*/

#include <stdio.h>

#include "trpc_service.h"
#include "trpc_error.h"
#include "dr_list.h"

static char *_pszCRunTimeService = "CRunTimeService";
static CRunTimeService _obj_CRunTimeService = { _pszCRunTimeService,
    NULL,
    NULL
};

static SERVICE_CLASS_INIT _initObj_CRunTimeService(&_obj_CRunTimeService);


extern "C" CRunTimeService *
GetFirstRunTimeService()
{
    return _obj_CRunTimeService._pFirst;
}


CRunTimeService *
    CRunTimeService::_pFirst =
    NULL;


SERVICE_CLASS_INIT::SERVICE_CLASS_INIT(CRunTimeService * pRunTimeService)
{
    pRunTimeService->_pNext = CRunTimeService::_pFirst;
    CRunTimeService::_pFirst = pRunTimeService;
}


// trpc_ipc_call ����ں���ָ��
TrpcIpcCallFun_T *g_pfnTrpcIpcCall = NULL;

// trpc_error_call ����ں���ָ��
TrpcErrorCallFun_T *g_pfnTrpcErrorCall = NULL;

// trpc_warning ����ں���ָ��
TrpcWarningFun_T * g_pfnTrpcWarning = NULL;

// trpc_stat�����ָ��
TrpcStateFun_T * g_pfnTrpcStat = NULL;

// trpc_set_error �����ָ��
TrpcSetErrorFun_T * g_pfnTrpcSetError = NULL;

map < string, void *> *g_pMapParam = NULL;


// so �ĳ�ʼ�����������ü���ȫ�ֱ���
// ����Server ��so ֮������ݴ���
extern "C" void
Trpc_Service_Initialize(ServiceInitInfo_T * pInitInfo)
{
    // ��һ��֮ǰ����ʹ��trpc_debug_log��
    g_pLog = pInitInfo->pLog;

    g_pfnTrpcIpcCall = pInitInfo->pfnTrpcIpcCall;
    g_pfnTrpcErrorCall = pInitInfo->pfnTrpcErrorCall;
    g_pfnTrpcWarning = pInitInfo->pfnTrpcWarning;
    g_pfnTrpcStat = pInitInfo->pfnTrpcStat;
    g_pfnTrpcSetError = pInitInfo->pfnTrpcSetError;

    g_pMapParam = pInitInfo->pMapParam;
    trpc_debug_log("Into Trpc_Service_Initialize\n");
}

TRPC_EXPORT int
trpc_set_param(const char *name, void *param)
{
    if (g_pMapParam == NULL) {
        return -1;
    }

    (*g_pMapParam)[name] = param;

    return 0;
}

TRPC_EXPORT void *
trpc_get_param(const char *name)
{
    if (g_pMapParam == NULL) {
        return NULL;
    }
    return (*g_pMapParam)[name];
}


