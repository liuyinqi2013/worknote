
#include    <sys/types.h>
#include    <sys/stat.h>
#include    <unistd.h>
#include    <fcntl.h>

#include    <string.h>
#include    <errno.h>
#include    <libgen.h>

extern int errno;

#include    "data_file.h"

CDataFile::CDataFile(const long int max_node_num, const long int size_per_node, const char * file_name)
    :
    __max_node_num(max_node_num),
    // ������������,����state��С
    __node_size(size_per_node + sizeof(int)),
    __data_size(size_per_node),
    __node_num(0),
    __file_name(file_name),
    __file_size(__node_size * max_node_num),
    __fd(VALIE_FD),
    __zero_data(NULL)
{
    __zero_data = (char *)malloc(size_per_node);
    memset(__zero_data, 0x00, size_per_node);
    memset(__error_text, 0x00, sizeof(__error_text));
}

CDataFile::~CDataFile()
{
    Close();

    if(__zero_data){
        free(__zero_data);
        __zero_data = NULL;
    }
}

long int CDataFile::NodeNum()
{
    return __node_num;
}

long int CDataFile::NodeSize()
{
    return __node_size;
}

long int CDataFile::DataSize()
{
    return __data_size;
}

long int CDataFile::MaxNodeNum()
{
    return __max_node_num;
}

const char * CDataFile::FileName()
{
    return __file_name.c_str();
}

// offset Ϊʵ���ļ��е�ƫ��
int CDataFile::Read(long int file_offset, char * out_data_ptr, long int data_size)
{
    // ���ļ�
    if(Open() != 0){
        return -1;
    }
        
    ssize_t ret;

    ret = pread(__fd, out_data_ptr, data_size, file_offset);

    if (ret < 0){
        snprintf(__error_text, sizeof(__error_text), 
            "pread faild, file=%s,error=%s", __file_name.c_str(), strerror(errno));

        // close file
        Close();

        return -1;
    }
    else if (ret != data_size){
        // will never go here
        snprintf(__error_text, sizeof(__error_text), 
            "pread size error req: %ld, ret: %ld", (long int)ret, (long int)data_size);

        // close file
        Close();

        return -1;
    }

    return 0;
}

// offset Ϊʵ���ļ��е�ƫ��
int CDataFile::Write(long int file_offset, const char * in_data_ptr, long int data_size)
{
    if(Open() != 0){
        return -1;
    }

    ssize_t ret;

    ret = pwrite(__fd, in_data_ptr, data_size, file_offset);

    if (ret < 0){
        snprintf(__error_text, sizeof(__error_text), 
            "pwrite faild, file=%s,error=%s", __file_name.c_str(), strerror(errno));

        // close file
        Close();

        return -1;
    }
    else if (ret != data_size){
        // will never go here
        snprintf(__error_text, sizeof(__error_text), 
            "pwrite size error req: %ld, ret: %ld", (long int)ret, (long int)data_size);

        // close file
        Close();

        return -1;
    }

    ret = Sync();
    if (ret != 0){
        return -1;
    }

    return 0;
}

int CDataFile::Open()
{
    int ret = 0;
    
    // �Ѿ���,�����ظ�open
    if (__fd != VALIE_FD){
        return 0;
    }
    
    bool need_create = false;

    // ����ļ��Ƿ����,�жϴ�С�Ƿ�ƥ��
    ret = FileExist();
    
    if (ret > 0){
        need_create = true;
    }
    else if (ret < 0){
        return -1;
    }

    if (need_create){
        __fd = open(__file_name.c_str(), O_EXCL | O_CREAT | O_RDWR, S_IRUSR | S_IWUSR);
        if (__fd < 0) 
        {       
            snprintf(__error_text, sizeof(__error_text), 
                "fopen faild, file=%s,error=%s", __file_name.c_str(), strerror(errno));
            __fd = VALIE_FD;
            return -1;
        }
                    
        u_char item = 0;
        char buf[10000];
        memset(buf, 0, sizeof(buf));                
           
        //ѭ�����������ļ�����
        for (int i=0; i < __file_size / (int)sizeof(buf); i++)   write(__fd, buf, sizeof(buf));                
        for (int i=0; i < __file_size % (int)sizeof(buf); i++)   write(__fd, &item, sizeof(item));  

        Close();
    }  

    __fd = open(__file_name.c_str(), O_RDWR);
    if (__fd < 0){
        snprintf(__error_text, sizeof(__error_text), 
            "fopen faild, file=%s,error=%s", __file_name.c_str(), strerror(errno));
        __fd = VALIE_FD;
        return -1;
    }

    return 0;
}

int CDataFile::Sync()
{
    // file not open return
    if (__fd == VALIE_FD){
        return 0;
    }

    // fsync
    // if (fsync(__fd) < 0){
    if (fdatasync(__fd) < 0){
        snprintf(__error_text, sizeof(__error_text), 
            "fsync faild, file=%s,error=%s", __file_name.c_str(), strerror(errno));
        Close();
        return -1;
    }

    return 0;
}


void CDataFile::Close()
{
    if (__fd == VALIE_FD){
        return;
    }

    close(__fd);
    __fd = VALIE_FD;
}

long int CDataFile::toFileOffset(long int offset)
{
    return offset * NodeSize();
}


int CDataFile::Get(long int offset, long int &flag, char * out_data_ptr, long int data_size)
{
    if (data_size != DataSize()){     
        snprintf(__error_text, sizeof(__error_text), 
            "data_size error old: %ld, now: %ld", DataSize(), data_size);

        return -1;
    }
    
    long int ret = 0;

    // get state
    ret = Read(toFileOffset(offset), (char *)&flag, sizeof(flag));

    if (ret != 0)
    {
        return ret;
    }
    
    // get data
    ret = Read(toFileOffset(offset) + sizeof(flag), (char *)out_data_ptr, data_size);

    if (ret != 0)
    {
        return ret;
    }

    return 0;
}

int CDataFile::Get(long int offset, char * out_data_ptr, long int data_size)
{
    long int flag;

    return Get(offset, flag, out_data_ptr, data_size);
}


int CDataFile::Set(long int offset, const long int flag, const char * in_data_ptr, long int data_size)
{
    if (data_size != DataSize()){     
        snprintf(__error_text, sizeof(__error_text), 
            "data_size error old: %ld, now: %ld", DataSize(), data_size);

        return -1;
    }

    long int ret = 0;
    
    // set state
    ret = Write(toFileOffset(offset), (const char *)&flag, sizeof(flag));

    if (ret != 0)
    {
        return ret;
    }
    
    // set data
    ret = Write(toFileOffset(offset) + sizeof(flag), (const char *)in_data_ptr, data_size);

    if (ret != 0)
    {
        return ret;
    }

    // ++ current num
    ++__node_num;

    return ret;
}

int CDataFile::Set(long int offset,const char * in_data_ptr, long int data_size)
{
    long int flag = 0;
    
    return Set(offset, flag, in_data_ptr, data_size);
}

int CDataFile::Del(long int offset)
{
    // clean all 
    long int ret = 0;

    ret = Write(toFileOffset(offset), __zero_data, __node_size);
    
    if (ret != 0)
    {
        return ret;
    }

    // -- current num
    --__node_num;

    return ret;
}

// ��ȡflag
int CDataFile::GetFlag(long int offset, long int &flag)
{
    return Read(toFileOffset(offset), (char *)&flag, sizeof(flag));
}

// �ļ��Ƿ����
// �����ڷ��� > 0
// ���ڷ��� == 0 
// �������� < 0
int CDataFile::FileExist()
{
    int ret = 0;
    
    // ���Ŀ¼�Ƿ����, �����ڴ���Ŀ¼
    char log_dir[256];
    strcpy(log_dir, __file_name.c_str());
    strcpy(log_dir, dirname(log_dir));
    struct stat dir_stat;
    if (stat(log_dir, &dir_stat) != 0) {
        if (mkdir(log_dir, 0775) < 0) {
            fprintf(stderr, "mkdir %s: %s\n", log_dir, strerror(errno));
            return -1;
        }
    }

    // ����ļ��Ƿ����,�жϴ�С�Ƿ�ƥ��
    struct stat file_state;
    if (stat(__file_name.c_str(), &file_state) < 0){  
        snprintf(__error_text, sizeof(__error_text), 
            "stat faild, file=%s,error=%s", __file_name.c_str(), strerror(errno));
        ret = 1;
    }
    else if (file_state.st_size != __file_size){
        snprintf(__error_text, sizeof(__error_text), 
            "file size error old: %ld, now: %ld", (long int)file_state.st_size, (long int)__file_size);
        ret = -1;
    }

    return ret;
}

