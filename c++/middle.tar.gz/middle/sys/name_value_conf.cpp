/*
����: 
       1.  NameValue������

Created by Song, 2003-02,03
Change list:

*/

#include <stdio.h>

#include "name_value_conf.h"

CNameValueConf::CNameValueConf(const char *sConfigPath,
                               unsigned uMaxRows, const char *sSectionName)
    :
CConfig(sConfigPath, uMaxRows),
_strSectionName(sSectionName)
{

}

CNameValueConf::~CNameValueConf()
{

}

int
CNameValueConf::ReadFromFile()
{
    _uRows = 0;
    _vData.clear();

    int iRetVal = ReadConfig(_strConfigPath.c_str(),
                             _strSectionName.c_str(),
                             ReadRecordEntrance,
                             (void *) this);

    if (iRetVal != 0) {
        return iRetVal;
    }

    // ����
    qsort(&_vData[0], _vData.size(), sizeof(_vData[0]), CmpNameValue_T);

    return 0;
}

/**
 * Funciton:  NameValue_T�ṹ�ıȽϺ��������������
  ����:
  a:  ��¼1ָ��
  b: ��¼2ָ��
  
 return value 0: a == b
                 > 0:  a > b
                 < 0:  a < b
**/
int
CNameValueConf::CmpNameValue_T(const void *a, const void *b)
{
    const NameValue_T *p1 = (const NameValue_T *) a;
    const NameValue_T *p2 = (const NameValue_T *) b;

    return strcmp(p1->sName, p2->sName);
}

/**
 * Funciton:  NameValue_T�ṹ�ıȽϺ��������ڲ��ҵ�
  ����:
  a:  ��¼1ָ��
  b: ��¼2ָ��
  
 return value 0: a == b
                 > 0:  a > b
                 < 0:  a < b
**/
int
CNameValueConf::CmpNameValue_T_2(const void *a, const void *b)
{
    const char *p1 = (const char *) a;
    const NameValue_T *p2 = (const NameValue_T *) b;

    return strcmp(p1, p2->sName);
}

/**
 * Funciton:  ReadConfig�����Ļص�����
  ����:
  str:  ReadConfig�ж�ȡ��һ�����ü�¼��
  arg: ReadConfig�ص�ʱ�����ָ��
  
 return value 
 	��ReadRecord
**/
int
CNameValueConf::ReadRecordEntrance(char *str, void *arg)
{
    CNameValueConf *pThis = (CNameValueConf *) arg;
    return pThis->ReadRecord(str);
}

/**
 * Funciton:  ����һ�����ü�¼
  ����:
  str:  ��������ü�¼�ı�
  
 return value 0: successful
                 > 0:  ��¼��Ч
                 < 0:  have error(s)
**/
int
CNameValueConf::ReadRecord(char *str)
{
    NameValue_T stRecord;
    NameValue_T *p = &stRecord;

    memset(&stRecord, 0, sizeof(stRecord));

    char *pe = str;
    pe = GetToken(p->sName, sizeof(p->sName), pe, "=");
    strncpy(p->sValue, pe, sizeof(p->sValue) - 1);
    strstrip(p->sValue);

    // ����Ƿ����ظ���¼
    for (size_t i = 0; i < _vData.size(); ++i) {
        if (CmpNameValue_T(&_vData[i], p) == 0) {
            // �Ѿ�������ͬ��¼
            // ���������¼��������
            return 1;
        }
    }

    // �����¼
    _vData.push_back(stRecord);
    return 0;
}

int
CNameValueConf::_GetNameValue(const void *data,
                              size_t uRows,
                              const char *sName,
                              void *sValue,
                              int iType, size_t nValueSize /*= 0*/ )
{
    const NameValue_T *p = (const NameValue_T *) bsearch(sName,
                                                         data,
                                                         uRows,
                                                         sizeof(NameValue_T),
                                                         CmpNameValue_T_2);
    if (p == NULL) {
        // �Ҳ���
        return 1;
    }

    switch (iType) {
        case CT_TYPE_STR:
            strncpy((char *) sValue, p->sValue, nValueSize);
            ((char *) sValue)[nValueSize - 1] = '\0';
            break;

        case CT_TYPE_INT:
            *(int *) sValue = atoi(p->sValue);
            break;

        case CT_TYPE_LONG:
            *(long *) sValue = atol(p->sValue);
            break;

        case CT_TYPE_DOUBLE:
            *(double *) sValue = atof(p->sValue);
            break;

        case CT_TYPE_UNSIGNED:
            *(unsigned *) sValue = atoi(p->sValue);
            break;

        default:
            sprintf(_error_text, "not suport data type %d", iType);
            return -1;
    }

    return 0;
}

const NameValue_T *
CNameValueConf::GetRecord(unsigned uRow)
{
    if (uRow >= _vData.size()) {
        sprintf(_error_text, "uRow >= _vData.size(): %d >= %d\n",
                uRow, _vData.size());
        return NULL;
    }

    return &_vData[uRow];
}

void
CNameValueConf::PrintNameValue_T(const NameValue_T * p,
                                 int (*fnPrintf) (const char *fmt, ...))
{
    fnPrintf("[%s] 	-- [%s]\n", p->sName, p->sValue);
}

void
CNameValueConf::Print(int (*fnPrintf) (const char *fmt, ...)) const
{
    fnPrintf("rows: %d\n", _vData.size());
    const NameValue_T *p = &_vData[0];
    for (size_t i = 0; i < _vData.size(); ++i, ++p) {
        PrintNameValue_T(p, fnPrintf);
    }
}
