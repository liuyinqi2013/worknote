/*
����: 
       1.  �����ڴ����õĻ���

Created by Song, 2003-02,03
Change list:

*/

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <assert.h>

#include "config.h"

CConfig::CConfig(const char *sConfigPath, unsigned uMaxRows)
:  _strConfigPath(sConfigPath), _uMaxRows(uMaxRows), _uRows(0)
{
    _error_text[0] = '\0';
}

CConfig::~CConfig()
{

}

int
CConfig::ReadConfig(const char *sConfigFile,
                    const char *sSectionName,
                    int (*fnGetRecord) (char *str, void *arg),
                    void *arg /*= NULL*/ )
{
    assert(sSectionName != NULL);

    FILE *fp = fopen(sConfigFile, "r");
    if (fp == NULL) {
        sprintf(_error_text, "fopen %s: %s", sConfigFile, strerror(errno));
        return -1;
    }

    char *sBuffer = new char[MAX_LINE_SIZE];
    bool bSectionStartIsFound = false;
    bool bSectionEndIsFound = false;

    string sSectionStart("<");
    sSectionStart += sSectionName;
    sSectionStart += ">";

    string sSectionEnd("</");
    sSectionEnd += sSectionName;
    sSectionEnd += ">";

    for (;;) {
        if (fgets(sBuffer, MAX_LINE_SIZE, fp) == NULL) {
            if (feof(fp)) {
                // ���ļ�β
                if (!bSectionStartIsFound) {
                    sprintf(_error_text, "section start \"<%s>\" not found",
                            sSectionName);
                    goto _error;
                }
                else {
                    break;
                }
            }
            else {
                sprintf(_error_text, "fgets %s: %s",
                        sConfigFile, strerror(errno));
                goto _error;
            }
        }

        /* get ride of '\n' */
        sBuffer[MAX_LINE_SIZE - 1] = '\0';
        strstrip(sBuffer);
        if (sBuffer[0] == '#' || sBuffer[0] == '\0')
            continue;

        if (strncmp(sBuffer, sSectionEnd.c_str(), sSectionEnd.length()) == 0) {
            // �����Ѷ���
            bSectionEndIsFound = true;
            break;
        }


        if (!bSectionStartIsFound) {
            if (strncmp
                (sBuffer, sSectionStart.c_str(),
                 sSectionStart.length()) == 0) {
                // �ҵ�sSectionStart
                bSectionStartIsFound = true;
            }
        }
        else {
            // ���ûص�������ȡ���ݼ�¼
            if (_uRows >= _uMaxRows) {
                sprintf(_error_text, "too many rows: MaxRows==%d", _uMaxRows);
                goto _error;
            }

            int iRetVal = fnGetRecord(sBuffer, arg);
            if (iRetVal == 0) {
                ++_uRows;
            }
            else if (iRetVal < 0) {
                goto _error;
            }
        }
    }

    // û�п�ʼ��
    if (!bSectionStartIsFound) {
        sprintf(_error_text, "section start \"<%s>\" not found",
                sSectionName);
        goto _error;
    }

    // û�н�����
    if (!bSectionEndIsFound) {
        sprintf(_error_text, "section end \"</%s>\" not found", sSectionName);
        goto _error;
    }

    delete[]sBuffer;
    fclose(fp);

    return 0;

  _error:

    delete[]sBuffer;
    fclose(fp);
    return -1;
}

bool CConfig::StrIsNumber(const char *str)
{
    if (*str == '\0') {
        return false;
    }

    for (const char *p = str; *p != '\0'; ++p) {
        if (!isdigit(*p) && (*p != '-') && (*p != '.')) {
            return false;
        }
    }
    return true;
}
