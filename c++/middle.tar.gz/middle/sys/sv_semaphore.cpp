/*
����: 
       1.  System V �źŵƵ�C++��װ

Created by Song, 2003.01
Change list:

*/

#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <unistd.h>
#include <errno.h>

#include "sv_semaphore.h"

SVSemaphore::SVSemaphore()
:  _key(-1), _semflg(0), _nsems(0), _semid(-1), _is_init(false)
{

    _error_text[0] = '\0';
}

SVSemaphore::SVSemaphore(key_t key, int semflg, int nsems)
{
    init(key, semflg, nsems);
}

void
SVSemaphore::init(key_t key, int semflg, int nsems)
{
    _key = key;
    _semflg = semflg;
    _nsems = nsems;
    _semid = -1;

    _is_init = true;

    _error_text[0] = '\0';
}

SVSemaphore::~SVSemaphore()
{
    close();
}

int
SVSemaphore::create(ushort * init_array /*= NULL*/ )
{
    if (!_is_init) {
        sprintf(_error_text, "not init");
        return -1;
    }

    _semid = semget(_key, _nsems, IPC_CREAT | IPC_EXCL | _semflg);
    if (_semid < 0) {
        if (errno == EEXIST) {
            return 1;
        }
        else {
            sprintf(_error_text, "semget (key==%d, num==%d):%s",
                    _semid, _nsems, strerror(errno));
            return -1;
        }
    }

    // �ɹ�����
    ushort *array;
    if (init_array != NULL) {
        array = init_array;
    }
    else {
        array = new ushort[_nsems];
        for (int i = 0; i < _nsems; ++i) {
            array[i] = 1;
        }
    }
    union SVSemUn arg;
    arg.array = array;
    if (control(0, SETALL, arg) != 0) {
        remove();
        if (init_array == NULL) {
            delete[]array;
        }
        return -1;
    }

    if (init_array == NULL) {
        delete[]array;
    }

    lock(0);
    unlock(0);

    return 0;
}

int
SVSemaphore::open()
{
    if (!_is_init) {
        sprintf(_error_text, "not init");
        return -1;
    }

    const static int MAX_TRIES = 5;

    _semid = semget(_key, 0, _semflg);
    if (_semid < 0) {
        sprintf(_error_text, "semget (key==%d, num==%d):%s",
                _key, _nsems, strerror(errno));
        return -1;
    }

    struct semid_ds seminfo;
    union SVSemUn arg;
    arg.buf = &seminfo;

    bool is_timeout = true;
    for (int i = 0; i < MAX_TRIES; ++i) {
        /* waiting for the sem to be initialized */
        if (control(0, IPC_STAT, arg) < 0) {
            sprintf(_error_text, "semctl: %s", strerror(errno));
            return -1;
        }
        if (arg.buf->sem_otime != 0) {
            is_timeout = false;
            break;
        }

        /* waiting for 0.1 second */
        usleep(100000);
    }

    if (is_timeout) {
        sprintf(_error_text, "waiting initializing sem: time out");
        errno = ETIMEDOUT;
        return -1;
    }

    return 0;
}

int
SVSemaphore::close()
{
//      _semid = -1;
    return 0;
}

int
SVSemaphore::lock(short semnum, short sem_flg /*= SEM_UNDO*/ )
{
    struct sembuf sops;

    sops.sem_num = semnum;
    sops.sem_op = -1;
    sops.sem_flg = sem_flg;

    if (semop(_semid, &sops, 1) < 0) {
        sprintf(_error_text, "semop: %s", strerror(errno));
        return -1;
    }

    return 0;
}

int
SVSemaphore::unlock(short semnum, short sem_flg /*= SEM_UNDO*/ )
{
    struct sembuf sops;

    sops.sem_num = semnum;
    sops.sem_op = 1;
    sops.sem_flg = sem_flg;

    if (semop(_semid, &sops, 1) < 0) {
        sprintf(_error_text, "semop: %s", strerror(errno));
        return -1;
    }

    return 0;
}

int
SVSemaphore::operation(struct sembuf *sops, unsigned nsops)
{
    if (semop(_semid, sops, nsops) < 0) {
        sprintf(_error_text, "semop: %s", strerror(errno));
        return -1;
    }

    return 0;
}

int
SVSemaphore::remove()
{
    if (_semid >= 0) {
        if (semctl(_semid, 0, IPC_RMID) < 0) {
            sprintf(_error_text, "semctl: %s", strerror(errno));
            return -1;
        }
    }

    return 0;
}

int
SVSemaphore::control(int semnum, int cmd, SVSemUn arg)
{
    if (semctl(_semid, semnum, cmd, arg) < 0) {
        sprintf(_error_text, "semctl: %s", strerror(errno));
        return -1;
    }

    return 0;
}
