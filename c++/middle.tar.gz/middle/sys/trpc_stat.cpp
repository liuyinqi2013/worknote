
#include    "trpc_stat.h"


int CTrpcStat::Send(int iStatId, int iValue)
{
    return __send(iStatId, iValue);
}

int CTrpcStat::__send(int iStatId, int iValue)
{
    if (m_ptrEnable != NULL && *m_ptrEnable == 0)
    {
        trpc_debug_log("Send Stat IP: %s, Port: %d, StatId: %d. *m_ptrEnable: %d\n",
                m_szIP, m_iPort, iStatId, *m_ptrEnable);
        
        return 0;
    }

    recItemPkg packet;
    memset(&packet, 0, sizeof(packet));
    packet.iCmd = SET_ITEM;
    packet.iStatId = iStatId;
    packet.iSourceIp = 0;
    
    packet.iValue = iValue;
    
    packet.Encode();

    trpc_debug_log("Send Stat IP: %s, Port: %d, StatId: %d\n",
            m_szIP, m_iPort, iStatId);

    // ����socket,��������
    try
    {
        Socket handle;

        handle.create(SOCK_DGRAM);

        handle.send_to(&packet, sizeof(packet),(uint16_t)m_iPort, m_szIP);
    }
    catch(SocketException& ce)
    {
        snprintf(_error_text, sizeof(_error_text),
            "SocketException : %s", ce.what());

        return -1;
    }
    catch(...)
    {
        snprintf(_error_text, sizeof(_error_text),
            "SysException");

        return -1;
    }

    return 0;
}



