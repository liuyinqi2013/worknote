#include <stdio.h>

#include "trpc_server.h"
#include "name_value_conf.h"

unsigned MAX_TRPC_SERVER_NO ;
unsigned MAX_TRPC_PROCESS_NO ;
unsigned MAX_SERVER_CONF_ROWS ;
unsigned MAX_QUEUE_ROWS_PER_SERVER ;

int ServerNOOK(unsigned int server_no)
{
    if (server_no < NORMAL_SERVER_NO_BEGIN || server_no > MAX_TRPC_SERVER_NO)
        return -1;

    return 0;
}


int	ReadStaticConfig(const char *psTrpcHome)
{   
	int iRetVal;
	char sTrpcConfPath[256];

    string sTrpcHome=psTrpcHome;
	size_t nLen = sTrpcHome.length();
    if (nLen == 0 || sTrpcHome[nLen - 1] != '/') {
        sTrpcHome += "/";
    }
	
	snprintf(sTrpcConfPath, sizeof(sTrpcConfPath), "%sconf/trpc.conf",
             sTrpcHome.c_str());
			 
	CNameValueConf * pConf = new CNameValueConf(sTrpcConfPath,
                                               MAX_STATIC_CONF_ROWS,
                                               SECTION_NAME_STATIC_CONF);

         iRetVal = pConf->ReadFromFile();
	
	if (iRetVal != 0) {
        fprintf(stderr,"ReadStaticConfig: %s\n", pConf->get_error_text());
        delete pConf;
        return -1;
    }

    //const int NAME_ARRAY_SIZE = 7;
    
    const int NAME_ARRAY_SIZE = 2;
    
    int iRetArr[NAME_ARRAY_SIZE];

    char sNameArr[NAME_ARRAY_SIZE][128] = {
        {"MaxServerNo"},
        {"MaxProcessNo"}
    };
    
    iRetArr[0] = pConf->GetNameValue(sNameArr[0], MAX_TRPC_SERVER_NO, DEFAULT_MAX_TRPC_SERVER_NO);
    iRetArr[1] = pConf->GetNameValue(sNameArr[1], MAX_TRPC_PROCESS_NO, DEFAULT_MAX_TRPC_PROCESS_NO);

    MAX_SERVER_CONF_ROWS = MAX_TRPC_SERVER_NO;

    for (int i = 0; i < NAME_ARRAY_SIZE; ++i) {
        if (iRetArr[i] != 0) {
            fprintf(stderr,"ReadStaticConfig: StaticConfig not found: [%s]",
                    sNameArr[i]);
            delete pConf;
            return -1;
        }
    }

    delete pConf;
    
    return 0;
}

