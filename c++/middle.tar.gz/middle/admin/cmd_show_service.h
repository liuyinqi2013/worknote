#ifndef __C_CMD_SHOW_SERVIVCE_H
#define __C_CMD_SHOW_SERVIVCE_H

#include "command.h"

class CCmdShowService: public CCommand
{
    DECLARE_DYNCREATE(CCmdShowService);

public:
    CCmdShowService();
    virtual ~CCmdShowService();

    virtual int Process(CommandInfo_T& stCmdInfo);

private:
    int ShowService(const vector<string>& vCmdArray,
            CommandInfo_T& stCmdInfo);

    int Help(CommandInfo_T& stCmdInfo);
};

#endif
