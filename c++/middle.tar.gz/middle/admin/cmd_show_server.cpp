#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <assert.h>

#include "cmd_show_server.h"

IMPLEMENT_DYNCREATE(CCmdShowServer, CCommand);

CCmdShowServer::CCmdShowServer()
:  CCommand()
{

}

CCmdShowServer::~CCmdShowServer()
{

}

int
CCmdShowServer::ShowAllServer(const vector < string > &vCmdArray,
                              CommandInfo_T & stCmdInfo)
{
    trpc_debug_log("Into CCmdShowServer::ShowServer\n");

    CShmServerConf *pServerConf = _pShmConfObjs->GetServerConf();
    unsigned uRows = pServerConf->GetShmRows();

    AppendCmdInfo(stCmdInfo,
                  "%-32s%-12s%-8s%-16s%-12s%-2s%-2s%-2s%-12s%-12s\n",
                  "ServerName", "ServerNo", "ProcNo", "Status", "LogLevel", "K", "W", "S", "TimeOut", "QueueNum");

    for (unsigned i = 0; i < uRows; ++i) {
        ServerConf_T *p = pServerConf->GetServerInfoPtr(i);
        if (p == NULL) {
            continue;
        }

        char sLogLevel[32];
        char sStatus[32];
        if (p->iStatus == CT_PROC_RUNNING) {
            strcpy(sStatus, "Running");
        }
        else {
            strcpy(sStatus, "Stop");
        }
        AppendCmdInfo(stCmdInfo,
                      "%-32s%-12d%-8d%-16s%-12s%-2d%-2d%-2d%-12d%-12d\n",
                      p->sServerName,
                      p->uServerNo,
                      p->uProcessNum,
                      sStatus,
                      CLog::get_log_level_str(p->iLogLevel, sLogLevel),
                      p->uCanKill,
                      p->uWarning,
                      p->uStat,
                      p->uTimeOut,
                      _pQueue->GetServerMq(p->uServerNo));		  	
    }

    AppendCmdInfo(stCmdInfo, "\n");

    return 0;
}

int
CCmdShowServer::ShowServer(const vector < string > &vCmdArray,
                           CommandInfo_T & stCmdInfo)
{
    trpc_debug_log("Into CCmdShowServer::ShowServer\n");

    //unsigned uServerNo = atoi(vCmdArray[2].c_str());
 
    ServerConf_T *p = GetServerPtr(vCmdArray[2].c_str());
    // ServerConf_T *p = pServerConf->GetServerInfoPtr(uServerNo);
    if (p == NULL) {
        AppendCmdInfo(stCmdInfo, "Server [%s] not found\n", vCmdArray[2].c_str());
        return 1;
    }


    AppendCmdInfo(stCmdInfo,
                  "\n%-16s%-12s%-8s%-12s%-10s\n",
                  "ServerName", "ServerNo", "ProcNo", "LogLevel", "So");

    char sLogLevel[32];
    AppendCmdInfo(stCmdInfo,
                  "%-16s%-12d%-8d%-12s",
                  p->sServerName,
                  p->uServerNo,
                  p->uProcessNum,
                  CLog::get_log_level_str(p->iLogLevel, sLogLevel));
    for (unsigned i = 0; i < p->uSoNum; ++i) {
        if (i == 0) {
            AppendCmdInfo(stCmdInfo, "%s", p->sSoFileArray[i]);
        }
        else {
            AppendCmdInfo(stCmdInfo, ",%s", p->sSoFileArray[i]);
        }
    }

    AppendCmdInfo(stCmdInfo, "\n\n");

    // Process����Ϣ
    AppendCmdInfo(stCmdInfo,
                  "    %-6s%-22s%-22s%-22s\n",
                  "pid", "start_time", "heatbeat_time", "loadso_time");

    char sStartTime[32];
    char sHeartbeatTime[32];
    char sLoadSoTime[32];
    for (unsigned i = 0; i < p->uProcessNum; ++i) {
        const ProcessInfo_T *pProcInfo = p->stProcInfoArray + i;
        AppendCmdInfo(stCmdInfo,
                      "    %-6d%-22s%-22s%-22s\n",
                      pProcInfo->pid,
                      time2longstr(pProcInfo->tStartTime, sStartTime),
                      time2longstr(pProcInfo->tHeartbeatTime, sHeartbeatTime),
                      time2longstr(pProcInfo->tLoadSo, sLoadSoTime));
    }

    AppendCmdInfo(stCmdInfo, "\n");

    return 0;
}

int
CCmdShowServer::Help(CommandInfo_T & stCmdInfo)
{
    trpc_debug_log("Into CCmdShowServer::Help\n");

    AppendCmdInfo(stCmdInfo, "Usage: show server [server_no]\n\n");

    return 0;
}

int
CCmdShowServer::Process(CommandInfo_T & stCmdInfo)
{
    trpc_debug_log("Into CCmdShowServer::Process\n");

    // show server [server_no]
    vector < string > vCmdArray;
    SplitString(stCmdInfo.idata, " ", 8, vCmdArray);

    if (vCmdArray.size() < 3) {
        ShowAllServer(vCmdArray, stCmdInfo);
    }
    else {
        ShowServer(vCmdArray, stCmdInfo);
    }

    return 0;
}
