#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <libgen.h>

#include "trpc.h"
#include "admin.h"

int
main(int argc, char **argv)
{
/*
	if (argc < 2){
		fprintf(stderr, "Usage: %s  config_file\n", argv[0]);
		return -1;
	}
*/

    // ȡServer������
    char sServerName[256];
    strncpy(sServerName, argv[0], sizeof(sServerName));
    sServerName[sizeof(sServerName) - 1] = '\0';
    strcpy(sServerName, basename(sServerName));

    // ȡ����
    const char *pTrpcHome = getenv(TRPC_HOME_NAME);
    if (pTrpcHome == NULL) {
        fprintf(stderr, "ERROR: environment variable \"%s\" not found\n",
                TRPC_HOME_NAME);
        return -1;
    }

    if (ReadStaticConfig(pTrpcHome) != 0){
        fprintf(stderr, "ERROR: ReadStaticConfig\n");
    }
     
    CAdminServer *pServer = new CAdminServer(pTrpcHome, sServerName);

    if (pServer->Init() != 0) {
        fprintf(stderr, "ERROR: CAdminServer::Init: %s\n",
                pServer->get_error_text());
        goto _error;
    }

    if (pServer->Run() != 0) {
        fprintf(stderr, "ERROR: CAdminServer::Run: %s\n",
                pServer->get_error_text());
        goto _error;
    }

    delete pServer;
    return 0;

  _error:
    delete pServer;
    return -1;
}
