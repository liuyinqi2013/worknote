/*
����: 
       1.  ָ��·��������

Created by Song, 2003-02,03
Change list:

*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <regex.h>
#include <errno.h>

#include "conf_cmd_route.h"

CConfCmdRoute::CConfCmdRoute(const char *sConfigPath,
                             unsigned uMaxRows,
                             CAdminConfObjs * pAdminConfObjs)
:  CConfig(sConfigPath, uMaxRows), _pAdminConfObjs(pAdminConfObjs)
{
    assert(_pAdminConfObjs != NULL);
}

CConfCmdRoute::~CConfCmdRoute()
{
    for (vector < CmdRouteConf_T >::iterator iter = _vData.begin();
         iter != _vData.end(); ++iter) {
        if (iter->bRegIsComp) {
            regfree(&iter->regex);
        }
        delete iter->pCmdObj;
    }
}

int
CConfCmdRoute::ReadFromFile()
{
    _uRows = 0;
    _vData.clear();

    int iRetVal = ReadConfig(_strConfigPath.c_str(),
                             SECTION_NAME,
                             ReadRecordEntrance,
                             (void *) this);

    if (iRetVal != 0) {
        return iRetVal;
    }

    for (vector < CmdRouteConf_T >::iterator iter = _vData.begin();
         iter != _vData.end(); ++iter) {
        // �����������ʽ
        if (SetRegex(iter->sRegex, &iter->regex) != 0) {
            return -1;
        }
        iter->bRegIsComp = true;

        // �������������
        // ��̬����
        CObject *pObject = TCreateObject(iter->sClassName);
        if (pObject == NULL) {
            sprintf(_error_text, "CreateObject %s Fail", iter->sClassName);
            return -1;
        }

        // ��̬����ת��
        iter->pCmdObj = dynamic_cast < CCommand * >(pObject);
        if (iter->pCmdObj == NULL) {
            sprintf(_error_text, "dynamic_cast<CCommand *>(%s) Fail",
                    iter->sClassName);
            return -1;
        }

        // ��ʼ��
        if (iter->pCmdObj->Init(_pAdminConfObjs) != 0) {
            sprintf(_error_text, "CCommand::Init: %s",
                    iter->pCmdObj->get_error_text());
            return -1;
        }
    }

    return 0;
}

/**
 * Funciton:  ReadConfig�����Ļص�����
  ����:
  str:  ReadConfig�ж�ȡ��һ�����ü�¼��
  arg: ReadConfig�ص�ʱ�����ָ��
  
 return value 
 	��ReadRecord
**/
int
CConfCmdRoute::ReadRecordEntrance(char *str, void *arg)
{
    CConfCmdRoute *pThis = (CConfCmdRoute *) arg;
    return pThis->ReadRecord(str);
}

/**
 * Funciton:  ����һ�����ü�¼
  ����:
  str:  ��������ü�¼�ı�
  
 return value 0: successful
                 > 0:  ��¼��Ч
                 < 0:  have error(s)
**/
int
CConfCmdRoute::ReadRecord(char *str)
{
    CmdRouteConf_T stRecord;
    CmdRouteConf_T *p = &stRecord;

    memset(&stRecord, 0, sizeof(stRecord));

    char *pe = str;
    pe = GetToken(p->sRegex, sizeof(p->sRegex), pe, DELIMITER_STR);
    strncpy(p->sClassName, pe, sizeof(p->sClassName) - 1);
    strstrip(p->sClassName);

    p->bRegIsComp = false;

    // �����¼
    _vData.push_back(stRecord);

    return 0;
}

int
CConfCmdRoute::SetRegex(const char *sRegex, regex_t * pReg)
{
    // ��Сд������
    static const int iFlags = REG_NOSUB | REG_EXTENDED | REG_ICASE;
    int iRetVal;

    char sRealRegex[256];

    // �Զ���^$��
    if (strcmp(sRegex, "*") == 0) {
        strcpy(sRealRegex, ".*");
    }
    else {
        snprintf(sRealRegex, sizeof(sRealRegex), "^(%s)$", sRegex);
    }

    // �����������ʽ
    iRetVal = regcomp(pReg, sRealRegex, iFlags);
    if (iRetVal != 0) {
        sprintf(_error_text, "regcomp %s: %s\n", sRealRegex, strerror(errno));
        return -1;
    }

    return 0;
}

CCommand *
CConfCmdRoute::SearchCmdObj(const char *sCmd)
{
    for (vector < CmdRouteConf_T >::iterator iter = _vData.begin();
         iter != _vData.end(); ++iter) {
        if (regexec(&iter->regex, sCmd, (size_t) 0, NULL, 0) == 0) {
            if (iter->pCmdObj == NULL) {
                sprintf(_error_text, "pCmdObj==NULL");
            }
            return iter->pCmdObj;
        }
    }

    sprintf(_error_text, "CmdRoute not found: %s", sCmd);
    return NULL;
}

const CmdRouteConf_T *
CConfCmdRoute::GetRecord(unsigned uRow)
{
    if (uRow >= _vData.size()) {
        sprintf(_error_text, "uRow >= _vData.size(): %d >= %d\n",
                uRow, _vData.size());
        return NULL;
    }

    return &_vData[uRow];
}

void
CConfCmdRoute::PrintCmdRouteConf_T(const CmdRouteConf_T * p,
                                   int (*fnPrintf) (const char *fmt, ...))
{
    fnPrintf("[%s] 	-- [%s] -- %p\n",
             p->sRegex, p->sClassName, p->pCmdObj);
}

void
CConfCmdRoute::Print(int (*fnPrintf) (const char *fmt, ...)) const
{
    fnPrintf("rows: %d\n", _vData.size());
    const CmdRouteConf_T *p = &_vData[0];
    for (size_t i = 0; i < _vData.size(); ++i, ++p) {
        PrintCmdRouteConf_T(p, fnPrintf);
    }
}
