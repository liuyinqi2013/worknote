#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <assert.h>

#include "cmd_rm_service.h"

IMPLEMENT_DYNCREATE(CCmdRmService, CCommand);

CCmdRmService::CCmdRmService()
:  CCommand()
{

}

CCmdRmService::~CCmdRmService()
{

}

int
CCmdRmService::RmService(const vector < string > &vCmdArray,
                             CommandInfo_T & stCmdInfo)
{
    trpc_debug_log("Into CCmdRmService::RmService\n");

    const char * pServiceName = vCmdArray[1].c_str();

    CShmServiceConf *pServiceConf = _pShmConfObjs->GetServiceConf();
    if (pServiceConf->Lock() != 0) {
        sprintf(_error_text, "CShmServiceConf::Lock: %s",
                pServiceConf->get_error_text());
        trpc_error_log("%s\n", _error_text);
        AppendCmdInfo(stCmdInfo, "ERROR: %s\n\n", _error_text);
        return -1;
    }
    
    ServiceInfo_T * p = pServiceConf->Get(pServiceName);
    if (p != NULL){
        // �ӹ����ڴ���ɾ��
        pServiceConf->Remove(p);
        AppendCmdInfo(stCmdInfo,
                  "OK\n\n");
    }
    else{
        // �Ҳ���
        AppendCmdInfo(stCmdInfo,
                  "Service not found\n\n");
    }

    pServiceConf->UnLock();

    return 0;
}

int
CCmdRmService::Help(CommandInfo_T & stCmdInfo)
{
    trpc_debug_log("Into CCmdRmService::Help\n");

    AppendCmdInfo(stCmdInfo, "Usage: rmservice service_name\n\n");

    return 0;
}

int
CCmdRmService::Process(CommandInfo_T & stCmdInfo)
{
    trpc_debug_log("Into CCmdRmService::Process\n");

    // show service [server_no]
    vector < string > vCmdArray;
    SplitString(stCmdInfo.idata, " ", 8, vCmdArray);

    if (vCmdArray.size() < 2
    || (vCmdArray.size() >= 3 && strcmp(vCmdArray[2].c_str(), "-h") == 0)) {
        Help(stCmdInfo);
    }
    else {
        RmService(vCmdArray, stCmdInfo);
    }

    return 0;
}
