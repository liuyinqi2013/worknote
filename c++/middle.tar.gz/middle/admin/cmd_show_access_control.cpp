#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <assert.h>

#include "cmd_show_access_control.h"

IMPLEMENT_DYNCREATE(CCmdShowAccessControl, CCommand);

CCmdShowAccessControl::CCmdShowAccessControl()
:  CCommand()
{

}

CCmdShowAccessControl::~CCmdShowAccessControl()
{

}

int
CCmdShowAccessControl::ShowAccessControl(const vector < string > &vCmdArray,
                                         CommandInfo_T & stCmdInfo)
{
    trpc_debug_log("Into CCmdShowAccessControl::ShowAllService\n");

    CShmAccessControl *pAccessControl = _pShmConfObjs->GetAccessControl();
    unsigned uRows = pAccessControl->GetShmRows();

    AppendCmdInfo(stCmdInfo,
                  "  %-17s%-12s%-12s%-12s%-16s\n",
                  "IP", "UserName", "Passwd", "IsByServer", "Array");

    for (unsigned i = 0; i < uRows; ++i) {
        const AccessMaskControl_T *p = pAccessControl->GetRecord(i);
        if (p == NULL) {
            continue;
        }

        AppendCmdInfo(stCmdInfo,
                      "  %-17s%-12s%-12s%-12s",
                      p->sIP,
                      p->sUserName,
                      p->sPasswd, p->bIsByServer ? "true" : "false");
        for (unsigned k = 0; k < p->uArrayNum; ++k) {
            if (k == 0) {
                AppendCmdInfo(stCmdInfo, "%s", p->sServiceArray[k]);
            }
            else {
                AppendCmdInfo(stCmdInfo, ",%s", p->sServiceArray[k]);
            }
        }

        AppendCmdInfo(stCmdInfo, "\n");
    }

    AppendCmdInfo(stCmdInfo, "\n");

    return 0;
}

int
CCmdShowAccessControl::Help(CommandInfo_T & stCmdInfo)
{
    trpc_debug_log("Into CCmdShowAccessControl::Help\n");

    AppendCmdInfo(stCmdInfo, "Usage: show acl\n\n");

    return 0;
}

int
CCmdShowAccessControl::Process(CommandInfo_T & stCmdInfo)
{
    trpc_debug_log("Into CCmdShowAccessControl::Process\n");

    // show service [server_no]
    vector < string > vCmdArray;
    SplitString(stCmdInfo.idata, " ", 8, vCmdArray);

    if (vCmdArray.size() >= 3 && strcmp(vCmdArray[2].c_str(), "-h") == 0) {
        Help(stCmdInfo);
    }
    else {
        ShowAccessControl(vCmdArray, stCmdInfo);
    }

    return 0;
}
