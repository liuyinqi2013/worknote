#ifndef __C_CMD_RM_SERVIVCE_H
#define __C_CMD_RM_SERVIVCE_H

#include "command.h"

class CCmdRmService: public CCommand
{
    DECLARE_DYNCREATE(CCmdRmService);

public:
    CCmdRmService();
    virtual ~CCmdRmService();

    virtual int Process(CommandInfo_T& stCmdInfo);

private:
    int RmService(const vector<string>& vCmdArray,
            CommandInfo_T& stCmdInfo);

    int Help(CommandInfo_T& stCmdInfo);
};

#endif
