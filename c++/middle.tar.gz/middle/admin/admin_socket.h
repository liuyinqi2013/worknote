#ifndef __C_ADMIN_SOCKET_H
#define __C_ADMIN_SOCKET_H

/*
����:
       1. trpcԶ�̹��̵��ð��Ķ�ӦSocket��


Created by Song, 2003.02-03
Change list:

*/

#include <time.h>

#include "socket.h"
#include "trpc.h"


class AdminSocket: public Socket
{
private:
    AdminSocket(const AdminSocket& sock); // no implementation
    void operator = (const AdminSocket& sock); // no implementation

// Construction
public:
    AdminSocket();

    virtual ~AdminSocket();

public:
    // ReceiveMessage�ķ���ֵ
    static const int RECV_CLOSE = 0;  // Socket���Է�close
    static const int RECV_OK = 1;  // �յ�һ��������trpc��
    static const int RECV_HAVE_MORE = 2;  // ����û������
    static const int RECV_FMT_ERROR = 3;  // ����ʽ���� 
    
    int RecvRequest();
    int RecvRespond();

    int SendMessage(const void * msg, size_t len, int timeout);


public:
    inline void SetIPAndPort() {get_peer_name(_strIP, _iPort);}
    inline const char * GetIP(){return _strIP.c_str();}
    inline uint16_t GetPort(){ return _iPort;}

    inline time_t GetLastAccessTime()
        {return _tLastAccessTime;}
    inline void SetLastAccessTime(time_t tLastAccessTime)
        {_tLastAccessTime = tLastAccessTime;}

public:
    static const int DATA_BUF_SIZE = 65536;
    int GetDataLen() const {return _iDataLen;}
    const char * GetData() const {return _sData;}
    
private:
    string _strIP;
    uint16_t _iPort;

    time_t _tLastAccessTime;

    int _iDataLen;
    char _sData[DATA_BUF_SIZE];
    bool _bRequestIsNew;
};

#endif
