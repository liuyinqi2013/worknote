#ifndef __C_CMD_SHOW_ACCESS_CONTROL_H
#define __C_CMD_SHOW_ACCESS_CONTROL_H

#include "command.h"

class CCmdShowAccessControl: public CCommand
{
    DECLARE_DYNCREATE(CCmdShowAccessControl);

public:
    CCmdShowAccessControl();
    virtual ~CCmdShowAccessControl();

    virtual int Process(CommandInfo_T& stCmdInfo);

private:
    int ShowAccessControl(const vector<string>& vCmdArray,
            CommandInfo_T& stCmdInfo);

    int Help(CommandInfo_T& stCmdInfo);
};

#endif
