#include <stdio.h>
#include <string.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <libgen.h>

#include <errno.h>
#include <assert.h>

#include "cmd_errclean.h"

IMPLEMENT_DYNCREATE(CCmdErrClean, CCommand);

CCmdErrClean::CCmdErrClean()
:  CCommand()
{

}

CCmdErrClean::~CCmdErrClean()
{

}

int
CCmdErrClean::ErrClean(const vector < string > &vCmdArray,
                 CommandInfo_T & stCmdInfo)
{
    trpc_debug_log("Into CCmdErrClean::ErrClean\n");

    // errclean
    const char *pBuf = vCmdArray[1].c_str();

    // �����offsetɾ������������ offset �Ƿ�Ϊȫ����
    if (vCmdArray.size() > 2) {
        if (IsAllDigits(vCmdArray[2].c_str()) != 0) {
            AppendCmdInfo(stCmdInfo, "Cmd ERROR: %s\n\n", stCmdInfo.idata);

            return -1;
        }
    }

    // �Ҹ�Server ����Ϣ
    ServerConf_T stServerInfo;
    int iRetVal = GetServerInfo(pBuf, stServerInfo);
    if (iRetVal < 0) {
        AppendCmdInfo(stCmdInfo, "ERROR: %s\n\n", _error_text);
        return -1;
    }
    else if (iRetVal > 0) {
        AppendCmdInfo(stCmdInfo,
                        "ERROR: ServerName|ServerNo not found: %s\n\n", pBuf);
        return 1;
    }

    // ����Server �Ĺ����ڴ淢����
    CServerShmCmd *pShmCmd = _pShmConfObjs->GetServerCmd();
    if (pShmCmd->Lock() != 0) {
        sprintf(_error_text, "CServerShmCmd::Lock: %s",
                pShmCmd->get_error_text());
        trpc_error_log("%s\n", _error_text);
        AppendCmdInfo(stCmdInfo, "ERROR: %s\n\n", _error_text);
        return -1;
    }

    // ƴ����ʱ����,����Ϊ
    // errclean server_no offset �ĸ�ʽ,������server����
    char sRealCmd[256] = {0};

    if (vCmdArray.size() == 2) {
        // ������нڵ�
        snprintf(sRealCmd, sizeof(sRealCmd) - 1, "%s %d", 
            vCmdArray[0].c_str(), stServerInfo.uServerNo);
    } else {
        snprintf(sRealCmd, sizeof(sRealCmd) - 1, "%s %d %s", 
            vCmdArray[0].c_str(), stServerInfo.uServerNo, vCmdArray[2].c_str());
    }

    // �������� -- ���뵽err�����������
    if (pShmCmd->Insert(ERR_SERVER_NO, sRealCmd) != 0) {
        sprintf(_error_text, "CServerShmCmd::Insert: %s",
                pShmCmd->get_error_text());
        trpc_error_log("%s\n", _error_text);
        AppendCmdInfo(stCmdInfo, "ERROR: %s\n\n", _error_text);

        pShmCmd->UnLock();
        return -1;
    }
    pShmCmd->UnLock();
    
    AppendCmdInfo(stCmdInfo, "OK\n\n", _error_text);
    
    return 0;
}

int
CCmdErrClean::Help(CommandInfo_T & stCmdInfo)
{
    trpc_debug_log("Into CCmdErrClean::Help\n");

    AppendCmdInfo(stCmdInfo,
                  "Usage: errclean [server_name|server_no] [offset]\n\n");

    return 0;
}

int
CCmdErrClean::Process(CommandInfo_T & stCmdInfo)
{
    trpc_debug_log("Into CCmdErrClean::Process\n");

    // start ServerName [logsize [lognum]]
    vector < string > vCmdArray;
    SplitString(stCmdInfo.idata, " ", 8, vCmdArray);

    if (vCmdArray.size() < 2
        || (vCmdArray.size() > 1 &&
            strcmp(vCmdArray[1].c_str(), "-h") == 0)) {
        Help(stCmdInfo);
    }
    else {
        ErrClean(vCmdArray, stCmdInfo);
    }

    return 0;
}

