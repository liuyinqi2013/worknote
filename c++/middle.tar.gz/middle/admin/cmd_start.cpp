#include <stdio.h>
#include <string.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <libgen.h>

#include <errno.h>
#include <assert.h>

#include "cmd_start.h"

IMPLEMENT_DYNCREATE(CCmdStart, CCommand);

CCmdStart::CCmdStart()
:  CCommand()
{

}

CCmdStart::~CCmdStart()
{

}

int
CCmdStart::Start(const vector < string > &vCmdArray,
                 CommandInfo_T & stCmdInfo)
{
    trpc_debug_log("Into CCmdStart::Start\n");

    int iConfIpcKey;
    int iLogSize;
    int iLogNum;
    const char *sServerName = vCmdArray[1].c_str();

    CShmNameValueConf *pConstConf = _pShmConfObjs->GetConstConf();
    if (pConstConf->GetNameValue("ConfIpcKey", iConfIpcKey) != 0) {
        // ��Const �������Ҳ���ConfIpcKey
        AppendCmdInfo(stCmdInfo,
                      "ERROR: ConstConf: 'ConfIpcKey' not found\n\n");

        return 1;
    }

    const int NAME_ARRAY_SIZE = 2;
/*
    char *sNameArr[NAME_ARRAY_SIZE] = {
        {"DefaultLogSize"},
        {"DefaultLogNum"}
    };
*/
    char sNameArr[NAME_ARRAY_SIZE][128] = {
        {"DefaultLogSize"},
        {"DefaultLogNum"}
    };

    CShmNameValueConf *pMainConf = _pShmConfObjs->GetMainConf();
    int iRetArr[NAME_ARRAY_SIZE];
    iRetArr[0] = pMainConf->GetNameValue(sNameArr[0], iLogSize);
    iRetArr[1] = pMainConf->GetNameValue(sNameArr[1], iLogNum);

    for (int i = 0; i < NAME_ARRAY_SIZE; ++i) {
        if (iRetArr[i] != 0) {
            AppendCmdInfo(stCmdInfo,
                          "ERROR: MainConf: '%s' not found\n\n", sNameArr[i]);
            return 1;
        }
    }

    // ȷ��logsize �� lognum
    if (vCmdArray.size() >= 3) {
        int n = atoi(vCmdArray[2].c_str());
        if (n > 1000) {
            iLogSize = n;
        }
    }
    if (vCmdArray.size() >= 4) {
        int n = atoi(vCmdArray[3].c_str());
        if (n > 0) {
            iLogNum = n;
        }
    }

    // �����Ϊall
    if (strncmp(sServerName, "all", sizeof("all")) != 0)
    {
        char sLogPath[256];
        snprintf(sLogPath, sizeof(sLogPath), "%s%s/%s",
                 _strLogDir.c_str(), sServerName, sServerName);
        
        int iRetVal = StartServer(sServerName, iConfIpcKey,
                                  sLogPath, iLogSize, iLogNum);
        if (iRetVal < 0) {
            AppendCmdInfo(stCmdInfo, "ERROR: %s\n\n", _error_text);
            return -1;
        }
        else if (iRetVal > 0) {
            // �Ҳ���Server
            AppendCmdInfo(stCmdInfo,
                          "ERROR: Server '%s' not found in Server Conf\n\n",
                          sServerName);
            return 1;
        }
    }
    else
    {
        CShmServerConf *pServerConf = _pShmConfObjs->GetServerConf();
                
        unsigned int iServerNum = pServerConf->GetShmRows();
        
        // �������з���,��������
        for (unsigned i = 0; i < iServerNum; ++i)
        {
            ServerConf_T *p = pServerConf->GetServerInfoPtr(i);
            if (p == NULL)
            {
                continue;
            }
                  
            char sLogPath[256];
            snprintf(sLogPath, sizeof(sLogPath), "%s%s/%s",
                   _strLogDir.c_str(), p->sServerName, p->sServerName);

            int iRetVal = StartServer(p->sServerName, iConfIpcKey,
                                    sLogPath, iLogSize, iLogNum);
            if (iRetVal < 0) {
                continue;
            }
            else if (iRetVal > 0) {
                continue;
            }
        }
    }

    AppendCmdInfo(stCmdInfo, "Start Server '%s' OK\n\n", sServerName);

    return 0;
}

int
CCmdStart::Help(CommandInfo_T & stCmdInfo)
{
    trpc_debug_log("Into CCmdStart::Help\n");

    AppendCmdInfo(stCmdInfo,
                  "Usage: start ServerName[all] [logsize [lognum]]\n\n");

    return 0;
}

int
CCmdStart::Process(CommandInfo_T & stCmdInfo)
{
    trpc_debug_log("Into CCmdStart::Process\n");

    // start ServerName [logsize [lognum]]
    vector < string > vCmdArray;
    SplitString(stCmdInfo.idata, " ", 8, vCmdArray);

    if (vCmdArray.size() == 1
        || (vCmdArray.size() > 1 &&
            strcmp(vCmdArray[1].c_str(), "-h") == 0)) {
        Help(stCmdInfo);
    }
    else {
        Start(vCmdArray, stCmdInfo);
    }

    return 0;
}
