#include <stdio.h>
#include <string.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <libgen.h>

#include <errno.h>
#include <assert.h>

#include "monitor.h"
#include "trpc_server.h"

CMonitor::CMonitor()
:  CCommand()
{

}

CMonitor::~CMonitor()
{

}

int
CMonitor::CheckAllServer()
{
//trpc_debug_log("Into CMonitor::CheckAllServer\n");

    CShmNameValueConf *pConstConf = _pShmConfObjs->GetConstConf();
    if (pConstConf->GetNameValue("ConfIpcKey", _iConfIpcKey) != 0) {
        // ��Const �������Ҳ���ConfIpcKey
        trpc_error_log("ConstConf: 'ConfIpcKey' not found\n\n");

        return 1;
    }

    const int NAME_ARRAY_SIZE = 2;
/*
    char *sNameArr[NAME_ARRAY_SIZE] = {
        {"DefaultLogSize"},
        {"DefaultLogNum"}
    };
*/

    char sNameArr[NAME_ARRAY_SIZE][128] = {
        {"DefaultLogSize"},
        {"DefaultLogNum"}
    };

    CShmNameValueConf *pMainConf = _pShmConfObjs->GetMainConf();
    int iRetArr[NAME_ARRAY_SIZE];
    iRetArr[0] = pMainConf->GetNameValue(sNameArr[0], _iLogSize);
    iRetArr[1] = pMainConf->GetNameValue(sNameArr[1], _iLogNum);

    for (int i = 0; i < NAME_ARRAY_SIZE; ++i) {
        if (iRetArr[i] != 0) {
            trpc_error_log("MainConf: '%s' not found\n\n", sNameArr[i]);
            return 1;
        }
    }

    char sHeartbeatStr[32];
    int iHeartbeatTimeout;
    strcpy(sHeartbeatStr, "HeartbeatTimeout");
    pMainConf->GetNameValue(sHeartbeatStr, iHeartbeatTimeout,
                            DEFAULT_HEATBEAT_TIME_OUT);

    // ������Server �Ƿ���ڣ������ڵĻ�����������
    CShmServerConf *pServerConf = _pShmConfObjs->GetServerConf();
    unsigned uServerNum = pServerConf->GetShmRows();
    for (unsigned i = 0; i < uServerNum; ++i) {
        CheckServer(i, iHeartbeatTimeout);
    }

    return 0;
}

int
CMonitor::CheckServer(unsigned uServerNo, int iTimeOut)
{
//trpc_debug_log("Into CMonitor::CheckServer\n");

    // �Ҹ�Server ����Ϣ
    ServerConf_T stServerInfo;
    int iRetVal = GetServerInfoByNo(uServerNo, stServerInfo);

    // added by verminniu
    int iTmpTimeOut = 0;

    if(!stServerInfo.uTimeOut) {
        iTmpTimeOut = iTimeOut;
    } else {
        iTmpTimeOut = stServerInfo.uTimeOut;
    }
    
    if (iRetVal < 0) {
        return -1;
    }
    else if (iRetVal > 0) {
        return 1;
    }

    if (stServerInfo.iStatus != CT_PROC_RUNNING) {
        // �Ѿ�stop�Ľ��̲���Ҫ����
        return 0;
    }

    ProcessInfo_T * pProcInfo = new ProcessInfo_T[MAX_TRPC_PROCESS_NO];
    iRetVal = GetProcessInfo(uServerNo,pProcInfo);
    if (iRetVal < 0) {
        delete[] pProcInfo;
        return -1;
    }
    else if (iRetVal > 0) {
        delete[] pProcInfo;
        return 1;
    }

    const char *sServerName = stServerInfo.sServerName;

    // ȫ������warning_server�Ŀ�ִ���ļ�
    string strServerPath = _strBinDir + sServerName;
    // Usage: %s  server_no process_no conf_ipc_key logfile logsize lognum
    char args[8][256];
    snprintf(args[0], sizeof(args[0]), "%s", sServerName);
    snprintf(args[1], sizeof(args[0]), "%d", uServerNo);
    snprintf(args[2], sizeof(args[0]), "%d", 0);        // ����Ϊ0������һ���������޸�
    snprintf(args[3], sizeof(args[0]), "%d", _iConfIpcKey);
    snprintf(args[4], sizeof(args[0]), "%s%s/%s",
             _strLogDir.c_str(), sServerName, sServerName);
    snprintf(args[5], sizeof(args[0]), "%d", _iLogSize);
    snprintf(args[6], sizeof(args[0]), "%d", _iLogNum);


    time_t tNow = time(NULL);
    if (uServerNo >= NORMAL_SERVER_NO_BEGIN) {
        // ��ͨserver��ÿ������ͣ���˶�Ҫ������
        for (unsigned i = 0; i < stServerInfo.uProcessNum; ++i) {
            ProcessInfo_T *p = pProcInfo+ i;
            bool bIsDown = false;

            if (tNow - p->tHeartbeatTime > iTmpTimeOut) {
                // ����������ʱ
                bIsDown = true;
                trpc_debug_log("%ld - %ld, %d\n", tNow, p->tHeartbeatTime, iTmpTimeOut);
                trpc_write_log("Process(ServerName==%s, no==%d) time out(%d)\n",
                               sServerName, i, iTmpTimeOut);
            }
            else if (CheckProcess(p->pid) != 0) {
                // ���̲���
                bIsDown = true;
                trpc_write_log("Process(ServerName==%s, no==%d) not found\n",
                               sServerName, i);
            }

            if (bIsDown) {
                if(stServerInfo.uCanKill)
                {
                    trpc_write_log("Killed Process(ServerName==%s, no==%d, pid==%d)\n",
                               sServerName, i, p->pid);
                    if (CheckProcess(p->pid) == 0) {
                        kill(p->pid, SIGKILL);
                    }
                }
                
                pid_t pid = ExecServer(strServerPath.c_str(), i, uServerNo, args);
                if (pid < 0) {
                    trpc_error_log("ExecServer: %s\n", _error_text);
                    delete[] pProcInfo;
                    return -1;
                }

                trpc_write_log("ExecServer %s successful\n", sServerName);
            }
        }

        
    }
    else {        
        // middled
        bool bIsDown = false;
        for (unsigned i = 0; i < stServerInfo.uProcessNum; ++i) {
            ProcessInfo_T *p = pProcInfo + i;

            if (tNow - p->tHeartbeatTime > iTimeOut) {
                // ����������ʱ
                bIsDown = true;
                trpc_write_log("Process(ServerName==%s, no==%d) time out\n",
                               sServerName, i);
            }
            else if (CheckProcess(p->pid) != 0) {
                // ���̲���
                bIsDown = true;
                trpc_write_log("Process(ServerName==%s, no==%d) not found\n",
                               sServerName, i);
            }

            if (bIsDown) {
                break;
            }
        }

        if (bIsDown) {
            // ����һ������ͣ����ɱ�����н���
            char sCommand[256];
            snprintf(sCommand, sizeof(sCommand), "killall -9 %s", sServerName);

            trpc_error_log("Server [%d] is Down : %s\n",
                           uServerNo, sCommand);
            // strcpy(sCommand, "killall -9 middled");
            system(sCommand);

/*
            for (unsigned i = 0; i < stServerInfo.uProcessNum; ++i) {
                ProcessInfo_T *p = stServerInfo.stProcInfoArray + i;
                if (CheckProcess(p->pid) == 0) {
                    kill(p->pid, SIGKILL);
                }
            }
*/
            // ����middled
            pid_t pid = ExecServer(strServerPath.c_str(), 0, uServerNo, args);

            //begin added by verminniu 2007-9-10
            //�ȴ�middled�����н��̶�����
            sleep(3);
            //end added by verminniu 2007-9-10
            
            if (pid < 0) {
                trpc_error_log("ExecServer: %s\n", _error_text);
                delete[] pProcInfo;
                return -1;
            }

            trpc_write_log("ExecServer %s successful\n", sServerName);
        }
    }

    delete[] pProcInfo;
    return 0;
}

int
CMonitor::Process(CommandInfo_T & stCmdInfo)
{
//trpc_debug_log("Into CMonitor::Process\n");

    CheckAllServer();
    return 0;
}
