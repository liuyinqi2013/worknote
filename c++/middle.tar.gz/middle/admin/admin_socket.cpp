/*
����:
       1. trpcԶ�̹��̵��ð��Ķ�ӦSocket��


Created by Song, 2003.02-03
Change list:

*/

#include <cstdio>
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>
#include <errno.h>

#include "admin_socket.h"
#include "trpc_commapi.h"

AdminSocket::AdminSocket()
:  _strIP(),
_iPort(0), _tLastAccessTime(0), _iDataLen(0), _bRequestIsNew(true)
{
    _error_text[0] = '\0';
}

AdminSocket::~AdminSocket()
{

}

/**
 * Funciton:  ��ȡ�������buf
  ����:
  
 return value:  RECV_CLOSE ���ӹر�
                 RECV_OK �������ض���
                 RECV_HAVE_MORE ����û����
                 RECV_FMT_ERROR ����ʽ����
                 < 0 have error(s)
**/
int
AdminSocket::RecvRequest()
{
    if (_bRequestIsNew) {
        _iDataLen = 0;
    }

    if (_iDataLen >= DATA_BUF_SIZE) {
        // ���ݻ�����������'\n' ��û���֣������ٶ�����
        sprintf(_error_text, "DataLen too large: %d >= %d",
                _iDataLen, DATA_BUF_SIZE);
        return RECV_FMT_ERROR;
    }

    int iBytes = receive(_sData + _iDataLen, DATA_BUF_SIZE - _iDataLen);
    if (iBytes == 0) {
        return RECV_CLOSE;
    }

    char *p = _sData + _iDataLen;
    for (int i = 0; i < iBytes; ++i) {
        if (p[i] == '\n') {
            p[i] = '\0';
            _iDataLen += i + 1;
            _bRequestIsNew = true;

            if (_iDataLen > 0) {
                strstrip(_sData);
                _iDataLen = strlen(_sData) + 1;
                return RECV_OK;
            }
            else {
                // ����
                return RECV_HAVE_MORE;
            }
        }
    }

    return RECV_HAVE_MORE;
}

/**
 * Funciton:  ��ȡtrpc�İ���buf
  ����:
  
 return value:  RECV_CLOSE ���ӹر�
                 RECV_OK �������ض���
                 RECV_HAVE_MORE ����û����
                 RECV_FMT_ERROR ����ʽ����
                 < 0 have error(s)
**/
int
AdminSocket::RecvRespond()
{
    if (_bRequestIsNew) {
        _iDataLen = 0;
    }

    if (_iDataLen >= DATA_BUF_SIZE) {
        // ���ݻ�����������'\n' ��û���֣������ٶ�����
        sprintf(_error_text, "DataLen too large: %d >= %d",
                _iDataLen, DATA_BUF_SIZE);
        return RECV_FMT_ERROR;
    }

    int iBytes = receive(_sData + _iDataLen, DATA_BUF_SIZE - _iDataLen);
    if (iBytes == 0) {
        return RECV_CLOSE;
    }

    for (int i = _iDataLen; i < iBytes; ++i) {
        if (_sData[i] == '\n') {
            iBytes = i;
            _bRequestIsNew = false;
            _iDataLen += iBytes;
            return RECV_OK;
        }
    }

    return RECV_HAVE_MORE;
}

int
AdminSocket::SendMessage(const void *msg, size_t len, int timeout)
{
    const char *buf = (const char *) msg;
    size_t bytes_sent = 0;
    int this_send;

    while (bytes_sent < len) {
        do {
            if (timeout > 0) {
                // �ж��Ƿ�ʱ
                fd_set write_fds;
                FD_ZERO(&write_fds);
                FD_SET(fd(), &write_fds);

                timeval stTimeOut;
                stTimeOut.tv_sec = timeout;
                stTimeOut.tv_usec = 0;
                int iRet = select(fd() + 1, (fd_set *) 0, &write_fds,
                                  (fd_set *) 0, &stTimeOut);
                if (iRet == 0) {
                    sprintf(_error_text, "send time out(timeout==%d)",
                            timeout);
                    throw SocketException(_error_text);
                }
                else if (iRet < 0) {
                    sprintf(_error_text, "select: %s", strerror(errno));
                    throw SocketException(_error_text);
                }
            }

            // ����
            this_send = send(buf, len - bytes_sent);
        }
        while ((this_send < 0) && (errno == EINTR));

        if (this_send <= 0) {
            return this_send;
        }
        bytes_sent += this_send;
        buf += this_send;
    }

    return len;
}
