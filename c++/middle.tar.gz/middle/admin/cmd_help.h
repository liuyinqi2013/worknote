#ifndef __C_CMD_HELP_H
#define __C_CMD_HELP_H

#include "command.h"

class CCmdHelp: public CCommand
{
    DECLARE_DYNCREATE(CCmdHelp);

public:
    CCmdHelp();
    virtual ~CCmdHelp();

    virtual int Process(CommandInfo_T& stCmdInfo);

private:
    int Help(const vector<string>& vCmdArray,
            CommandInfo_T& stCmdInfo);
};

#endif


