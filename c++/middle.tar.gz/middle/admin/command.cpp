#include <stdio.h>
#include <stdarg.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <libgen.h>

#include <errno.h>
#include <assert.h>

#include "command.h"

IMPLEMENT_DYNAMIC(CCommand, CObject);

CCommand::CCommand()
:  _bIsInit(false), _pShmConfObjs(NULL)
{

}

CCommand::~CCommand()
{

}

int
CCommand::Init(CAdminConfObjs * pAdminConfObjs)
{
    _strTrpcHome = pAdminConfObjs->GetTrpcHome();
    _pShmConfObjs = pAdminConfObjs->GetShmConfObjs();
    _pQueue = pAdminConfObjs->GetTrpcQueue();
    _pMainConf = pAdminConfObjs->GetMainConf();

    _strBinDir = _strTrpcHome + "bin/";
    _strLogDir = _strTrpcHome + "log/";
    _strConfDir = _strTrpcHome + "conf/";
    _strSoDir = _strTrpcHome + "so/";

    _strCommBin = _strBinDir + TRPC_SERVER_BIN_NAME;

    return 0;
}

int 
CCommand::IsServerNo(const char * buf)
{
    return IsAllDigits(buf);
}

int
CCommand::ResetCmdInfo(CommandInfo_T & stCmdInfo)
{
    stCmdInfo.olen = 0;
    return 0;
}

int
CCommand::AppendCmdInfo(CommandInfo_T & stCmdInfo, const char *fmt, ...)
{
    CommandInfo_T *p = &stCmdInfo;
    int iLeftLen = sizeof(p->odata) - p->olen;
    int iLen;

    va_list ap;
    va_start(ap, fmt);
    iLen = vsnprintf(p->odata + p->olen, iLeftLen, fmt, ap);
    va_end(ap);

    p->olen += iLen;
    return p->olen;
}

ServerConf_T * 
CCommand::GetServerPtr(const char * buf)
{
    if (IsServerNo(buf) == 0)
    {
        return GetServerPtrByNo((unsigned)atoi(buf));
    }
    else
    {
        return GetServerPtrByName(buf);
    }

    // never go here
    return NULL;
}

ServerConf_T * 
CCommand::GetServerPtrByNo(const unsigned int uServerNo)
{
    CShmServerConf *pServerConf = _pShmConfObjs->GetServerConf();

    if (pServerConf == NULL)
        return NULL;
    
    return pServerConf->GetServerInfoPtr(uServerNo);
}

ServerConf_T *
CCommand::GetServerPtrByName(const char *sServerName)
{
    CShmServerConf *pServerConf = _pShmConfObjs->GetServerConf();
    unsigned uRows = pServerConf->GetShmRows();
    for (unsigned i = 0; i < uRows; ++i) {
        ServerConf_T *p = pServerConf->GetServerInfoPtr(i);
        if (p != NULL && strcmp(p->sServerName, sServerName) == 0) {
            return p;
        }
    }

    return NULL;
}

int 
CCommand::GetServerInfo(const char * sBuf, ServerConf_T& stServerInfo)
{
    if (IsServerNo(sBuf) == 0)
    {
        return GetServerInfoByNo((unsigned)atoi(sBuf), stServerInfo);
    }
    else
    {
        return GetServerInfoByName(sBuf, stServerInfo);
    }

    // never go here
    return -1;
}

int
CCommand::GetServerInfoByName(const char *sServerName, ServerConf_T & stServerInfo)
{
    CShmServerConf *pServerConf = _pShmConfObjs->GetServerConf();
    if (pServerConf->Lock() != 0) {
        sprintf(_error_text, "pServerConf->Lock: %s",
                pServerConf->get_error_text());
        return -1;
    }

    ServerConf_T *p = GetServerPtrByName(sServerName);
    if (p != NULL) {
        memcpy(&stServerInfo, p, sizeof(stServerInfo));
    }
    pServerConf->UnLock();

    if (p == NULL){
	// �Ҳ���
        return 1;
    }
    return 0;
}

int
CCommand::GetServerInfoByNo(unsigned uServerNo, ServerConf_T & stServerInfo)
{
    CShmServerConf *pServerConf = _pShmConfObjs->GetServerConf();
    if (pServerConf->Lock() != 0) {
        sprintf(_error_text, "pServerConf->Lock: %s",
                pServerConf->get_error_text());
        return -1;
    }


    ServerConf_T *pServerInfo = pServerConf->GetServerInfoPtr(uServerNo);
    if (pServerInfo != NULL) {
        memcpy(&stServerInfo, pServerInfo, sizeof(ServerConf_T));
    }
    pServerConf->UnLock();

    if (pServerInfo == NULL) {
        // �Ҳ���
        return 1;
    }

    return 0;
}

int
CCommand::StartServer(const char *sServerName,
                      int iConfIpcKey,
                      const char *sLogPath, int iLogSize, int iLogNum)
{
    trpc_debug_log("Into CCommand::StartServer\n");

    // �Ҹ�Server ����Ϣ
    ServerConf_T stServerInfo;
    int iRetVal = GetServerInfo(sServerName, stServerInfo);
    if (iRetVal < 0) {
        return -1;
    }
    else if (iRetVal > 0) {
        return 1;
    }

    ProcessInfo_T * pProcInfo=new ProcessInfo_T[MAX_TRPC_PROCESS_NO];
    iRetVal = GetProcessInfo(stServerInfo.uServerNo, pProcInfo);
    if (iRetVal < 0) {
        delete[] pProcInfo;
        return -1;
    }
    else if (iRetVal > 0) {
        delete[] pProcInfo;
        return 1;
    }

    // �鿴�Ƿ���ڸ�Server �Ŀ�ִ���ļ�
    // ȫ������warning_server
    // string strPath = _strBinDir + sServerName;
    string strPath = _strBinDir + sServerName;
    
    // ����Server
    // Usage: %s  server_no process_no conf_ipc_key logfile logsize lognum
    char args[8][256];
    snprintf(args[0], sizeof(args[0]), "%s", sServerName);
    snprintf(args[1], sizeof(args[0]), "%d", stServerInfo.uServerNo);
    snprintf(args[2], sizeof(args[0]), "%d", 0);        // ����Ϊ0������һ���������޸�
    snprintf(args[3], sizeof(args[0]), "%d", iConfIpcKey);
    snprintf(args[4], sizeof(args[0]), "%s", sLogPath);
    snprintf(args[5], sizeof(args[0]), "%d", iLogSize);
    snprintf(args[6], sizeof(args[0]), "%d", iLogNum);

    // �鿴�Ƿ��н���������
    for (unsigned i = 0; i < stServerInfo.uProcessNum; ++i) {
        const ProcessInfo_T *p = pProcInfo + i;
        if (CheckProcess(p->pid) == 0) {
            // ���̻���
            sprintf(_error_text,
                    "Process(proc_no==%d, pid==%d) still running", i, p->pid);

            delete[] pProcInfo;
            return -1;
        }
    }
    
    // ����Server
    if (strcasecmp(sServerName, "middled") == 0) {
        // middled
        int pid = ExecServer(strPath.c_str(),
                             0,
                             stServerInfo.uServerNo,
                             args);
        if (pid < 0) {
            delete[] pProcInfo;
            return -1;
        }
    }
    else {
        // ��ͨserver
        for (unsigned i = 0; i < stServerInfo.uProcessNum; ++i) {
            int pid = ExecServer(strPath.c_str(),
                                 i,
                                 stServerInfo.uServerNo,
                                 args);
            if (pid < 0) {

                delete[] pProcInfo;
                return -1;
            }
        }
    }
    
    delete[] pProcInfo;
    return 0;
}

int
CCommand::ExecServer(const char *sServerPath,
                     unsigned uProcessNo, unsigned uServerNo, char args[][256])
{
    trpc_debug_log("Into CCommand::ExecServer(%s)\n", sServerPath);
    
    if (uServerNo >= NORMAL_SERVER_NO_BEGIN) {
        // ��ͨ����,ɾ����ǰ��bin�ļ�,����������һ��,��Ӱ���Ѿ�����ʹ�õķ���
        if (unlink(sServerPath) != 0) {
            if (errno != ENOENT) {
                sprintf(_error_text, "unlink %s: %s", sServerPath, strerror(errno));
                return -1;
            }
        }

        // link һ����ʱ����������
        if (symlink(_strCommBin.c_str(), sServerPath) != 0) {
            sprintf(_error_text, "symlink %s->%s: %s", 
                _strCommBin.c_str(), sServerPath, strerror(errno));
            return -1;
        }

        trpc_debug_log("symlink %s->%s\n", 
                _strCommBin.c_str(), sServerPath);
    }

    // ���bin�ļ��Ƿ����
    struct stat stStat;
    if (stat(sServerPath, &stStat) < 0) {
        sprintf(_error_text, "stat %s: %s", sServerPath, strerror(errno));
        return -1;
    }
    
    snprintf(args[2], sizeof(args[0]), "%d", uProcessNo);

    // ��������
    pid_t pid = fork();
    if (pid == 0) {
        // child
        // ��������Ŀ¼����ҪΪ��coredump ʱcore�ļ�д���Լ���Ŀ¼
        char sDirName[256];
        strcpy(sDirName, sServerPath);
        if (chdir(dirname(sDirName)) < 0) {
            trpc_error_log("chdir %s: %s\n", sDirName, strerror(errno));
            exit(-1);
        }

        // ����server
        if (execl(sServerPath, args[0], args[1], args[2],
                  args[3], args[4], args[5], args[6], (char *) 0) < 0) {
            trpc_error_log("execl %s: %s\n", sServerPath, strerror(errno));
            exit(-1);
        }
        trpc_error_log("should not reach here\n");
        exit(-1);
    }
    else if (pid > 0) {
        // parent
        /*
           if (waitpid(pid, NULL, 0) < 0){
           sprintf(_error_text, "waitpid %d: %s", pid, strerror(errno));
           return -1;
           } */
        // ���ȴ�child ����
        // return pid;
    }
    else {
        sprintf(_error_text, "fork(proc_no==%d): %s",
                uProcessNo, strerror(errno));
        return -1;
    }

    if (uServerNo >= NORMAL_SERVER_NO_BEGIN) {
        trpc_debug_log("unlink: %s\n", sServerPath);
        // ɾ����ʱ��������
        unlink(sServerPath);
    }
    
    return pid;
}
int
CCommand::GetProcessInfo(unsigned uServerNo, ProcessInfo_T * stProcessInfo)
{
    CShmServerConf *pServerConf = _pShmConfObjs->GetServerConf();
    if (pServerConf->Lock() != 0) {
        sprintf(_error_text, "pServerConf->Lock: %s",
                pServerConf->get_error_text());
        return -1;
    }


    ServerConf_T *pServerInfo = pServerConf->GetServerInfoPtr(uServerNo);
    if (pServerInfo != NULL) {
        memcpy(stProcessInfo, pServerInfo->stProcInfoArray, sizeof(ProcessInfo_T) * MAX_TRPC_PROCESS_NO);
    }
    pServerConf->UnLock();

    if (pServerInfo == NULL) {
        // �Ҳ���
        return 1;
    }

    return 0;
}

