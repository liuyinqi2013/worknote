ipcrm msg `ipcs -q | grep phc | awk '{printf("%s ", $2)}'`
ipcrm shm `ipcs -m | grep phc | awk '{printf("%s ", $2)}'`
ipcrm sem `ipcs -s | grep phc | awk '{printf("%s ", $2)}'`
