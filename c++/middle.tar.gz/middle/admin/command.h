#ifndef __C_COMMAND_H
#define __C_COMMAND_H

#include <string>
#include <vector>
using namespace std;

#include "object.h"
#include "trpc.h"
#include "trpc_queue.h"
#include "admin_conf_objs.h"
#include "log.h"
#include "trpc_commapi.h"

// ������ĸ�ʽ��
// ����\n

//  Ӧ����ĸ�ʽ
// LENGTH=�����ֽ���\n
// ����

// ���������������,û����ʾ,�����ȸĸ�
//const size_t MAX_COMMAND_DATA_LEN = 32768;
const size_t MAX_COMMAND_DATA_LEN = 65536;

struct CommandInfo_T
{
    size_t ilen;
    char idata[MAX_COMMAND_DATA_LEN];
    size_t olen;
    char odata[MAX_COMMAND_DATA_LEN];
};

class CCommand: public CObject
{
    DECLARE_DYNAMIC(CCommand);
    
public:
    CCommand();
    virtual ~CCommand();

    int Init(CAdminConfObjs * pAdminConfObjs);

    virtual int Process(CommandInfo_T& stCmdInfo) = 0;
    
    const char * get_error_text() const {return _error_text;}

    static int ResetCmdInfo(CommandInfo_T& stCmdInfo);
    static int AppendCmdInfo(CommandInfo_T& stCmdInfo, const char * fmt, ...);

    // ����Ƿ�Ϊ��������,�򵥱���,���ȫ��Ϊ����,��Ϊ�Ƿ�������
    static int IsServerNo(const char * buf);

protected:
    // ��ȡserver ָ��
    ServerConf_T * GetServerPtr(const char * buf);
    
    ServerConf_T * GetServerPtrByName(const char * sServerName);
    ServerConf_T * GetServerPtrByNo(const unsigned int uServerNo);

    // ����
    int GetServerInfo(const char * sBuf,
            ServerConf_T& stServerInfo);
    
    int GetServerInfoByName(const char * sServerName,
            ServerConf_T& stServerInfo);
    
    int GetServerInfoByNo(unsigned uServerNo,
            ServerConf_T& stServerInfo);
    
    int GetProcessInfo(unsigned uServerNo, ProcessInfo_T * stProcessInfo);

    int StartServer(const char * sServerName,
                int iConfIpcKey,
                const char * sLogPath,
                int iLogSize,
                int iLogNum);

    int ExecServer(const char * sServerPath,
            unsigned uProcessNo,
            unsigned uServerNo, 
            char args[][256]);
    
    
protected:
    bool _bIsInit;
    string _strTrpcHome;

    string _strBinDir;
    string _strLogDir;
    string _strConfDir;
    string _strSoDir;

    string _strCommBin;
    
    CShmConfObjs * _pShmConfObjs;
    CTrpcQueue * _pQueue;
    CNameValueConf * _pMainConf;
    
    char _error_text[256];
};


#endif
