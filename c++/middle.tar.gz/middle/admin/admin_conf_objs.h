#ifndef __C_ADMIN_CONF_OBJS_H
#define __C_ADMIN_CONF_OBJS_H

#include <string>
using namespace std;

#include <assert.h>

#include "shm_conf_objs.h"
#include "trpc_queue.h"
#include "name_value_conf.h"

class CAdminConfObjs
{
public:
    CAdminConfObjs(const char * sTrpcHome,
            CShmConfObjs * pShmConfObjs,
            CTrpcQueue * pQueue,
            CNameValueConf * pMainConf)
    :_strTrpcHome(sTrpcHome),
    _pShmConfObjs(pShmConfObjs),
    _pQueue(pQueue),
    _pMainConf(pMainConf)
    {
        assert(_pShmConfObjs != NULL);
        assert(_pQueue != NULL);
        assert(_pMainConf != NULL);
    }
    
    ~CAdminConfObjs(){}

    const char * GetTrpcHome(){return _strTrpcHome.c_str();}
    CShmConfObjs * GetShmConfObjs(){return _pShmConfObjs;}
    CTrpcQueue * GetTrpcQueue(){return _pQueue;}
    CNameValueConf * GetMainConf(){return _pMainConf;}

private:
    string _strTrpcHome;
    CShmConfObjs * _pShmConfObjs;
    CTrpcQueue * _pQueue;
    CNameValueConf * _pMainConf;
};


#endif

