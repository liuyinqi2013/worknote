#ifndef __C_CMD_LOAD_H
#define __C_CMD_LOAD_H

#include "command.h"

class CCmdLoad: public CCommand
{
    DECLARE_DYNCREATE(CCmdLoad);

public:
    CCmdLoad();
    virtual ~CCmdLoad();

    virtual int Process(CommandInfo_T& stCmdInfo);

private:
    int Load(CShmConfig * pShmConfig,
            const char * sConfigName,
            CommandInfo_T& stCmdInfo);
    
    int Help(const vector<string>& vCmdArray,
            CommandInfo_T& stCmdInfo);

    int LoadAll(const vector<string>& vCmdArray,
            CommandInfo_T& stCmdInfo);

    int LoadMain(const vector<string>& vCmdArray,
            CommandInfo_T& stCmdInfo);
    int LoadAccessControl(const vector<string>& vCmdArray,
            CommandInfo_T& stCmdInfo);

    int LoadServerConf(const vector<string>& vCmdArray,
            CommandInfo_T& stCmdInfo);

};

#endif


