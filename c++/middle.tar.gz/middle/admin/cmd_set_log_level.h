#ifndef __C_CMD_SET_LOG_LEVEL_H
#define __C_CMD_SET_LOG_LEVEL_H

#include "command.h"

class CCmdSetLogLevel: public CCommand
{
    DECLARE_DYNCREATE(CCmdSetLogLevel);

public:
    CCmdSetLogLevel();
    virtual ~CCmdSetLogLevel();

    virtual int Process(CommandInfo_T& stCmdInfo);

private:
    int Help(CommandInfo_T& stCmdInfo);
    int Set(const vector<string>& vCmdArray,
            CommandInfo_T& stCmdInfo);
};

#endif

