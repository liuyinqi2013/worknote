#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <assert.h>

#include "cmd_show_cmd.h"

IMPLEMENT_DYNCREATE(CCmdShowCmd, CCommand);

CCmdShowCmd::CCmdShowCmd()
:  CCommand()
{

}

CCmdShowCmd::~CCmdShowCmd()
{

}

int
CCmdShowCmd::ShowCmd(const vector < string > &vCmdArray,
                     CommandInfo_T & stCmdInfo)
{
    trpc_debug_log("Into CCmdShowCmd::ShowCmd\n");

    unsigned uServerNo = atoi(vCmdArray[2].c_str());

    CServerShmCmd *pShmCmd = _pShmConfObjs->GetServerCmd();
    unsigned uRows = pShmCmd->GetCmdsPerServer();

    AppendCmdInfo(stCmdInfo,
                  "%-20s%-12s%s\n", "InsertedTime", "SeqNo", "Cmd");

    char sTime[32];
    for (unsigned i = 0; i < uRows; ++i) {
        const ServerCommand_T *p = pShmCmd->GetRecord(uServerNo, i);
        if (p == NULL) {
            continue;
        }

        AppendCmdInfo(stCmdInfo,
                      "%-20s%-12d%s\n",
                      time2shortstr(p->tInsertedTime, sTime),
                      p->iSeqNo, p->sCommand);
    }

    AppendCmdInfo(stCmdInfo, "\n");

    return 0;
}

int
CCmdShowCmd::Help(CommandInfo_T & stCmdInfo)
{
    trpc_debug_log("Into CCmdShowCmd::Help\n");

    AppendCmdInfo(stCmdInfo, "Usage: show conf\n\n");

    return 0;
}

int
CCmdShowCmd::Process(CommandInfo_T & stCmdInfo)
{
    trpc_debug_log("Into CCmdShowCmd::Process\n");

    // show cmd server_no
    vector < string > vCmdArray;
    SplitString(stCmdInfo.idata, " ", 8, vCmdArray);

    if (vCmdArray.size() < 3
        || (vCmdArray.size() >= 3 &&
            strcmp(vCmdArray[2].c_str(), "-h") == 0)) {
        Help(stCmdInfo);
    }
    else {
        ShowCmd(vCmdArray, stCmdInfo);
    }

    return 0;
}
