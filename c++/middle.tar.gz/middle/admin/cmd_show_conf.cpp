#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <assert.h>

#include "cmd_show_conf.h"

IMPLEMENT_DYNCREATE(CCmdShowConf, CCommand);

CCmdShowConf::CCmdShowConf()
:  CCommand()
{

}

CCmdShowConf::~CCmdShowConf()
{

}

int
CCmdShowConf::ShowConf(const vector < string > &vCmdArray,
                       CommandInfo_T & stCmdInfo)
{
    trpc_debug_log("Into CCmdShowConf::ShowConf\n");

    // Main Conf
    CShmNameValueConf *pConstConf = _pShmConfObjs->GetConstConf();
    unsigned uRows = pConstConf->GetShmRows();

    AppendCmdInfo(stCmdInfo, "<Const>\n");

    for (unsigned i = 0; i < uRows; ++i) {
        const NameValue_T *p = pConstConf->GetRecord(i);
        if (p == NULL) {
            continue;
        }

        AppendCmdInfo(stCmdInfo, "  %s=%s\n", p->sName, p->sValue);
    }

    AppendCmdInfo(stCmdInfo, "</Const>\n\n");

    // Main Conf
    CShmNameValueConf *pMainConf = _pShmConfObjs->GetMainConf();
    uRows = pMainConf->GetShmRows();

    AppendCmdInfo(stCmdInfo, "<Main>\n");

    for (unsigned i = 0; i < uRows; ++i) {
        const NameValue_T *p = pMainConf->GetRecord(i);
        if (p == NULL) {
            continue;
        }
        AppendCmdInfo(stCmdInfo, "  %s=%s\n", p->sName, p->sValue);
    }

    AppendCmdInfo(stCmdInfo, "</Main>\n\n");

    return 0;
}

int
CCmdShowConf::Help(CommandInfo_T & stCmdInfo)
{
    trpc_debug_log("Into CCmdShowConf::Help\n");

    AppendCmdInfo(stCmdInfo, "Usage: show conf\n\n");

    return 0;
}

int
CCmdShowConf::Process(CommandInfo_T & stCmdInfo)
{
    trpc_debug_log("Into CCmdShowConf::Process\n");

    // show service [server_no]
    vector < string > vCmdArray;
    SplitString(stCmdInfo.idata, " ", 8, vCmdArray);

    if (vCmdArray.size() >= 3 && strcmp(vCmdArray[2].c_str(), "-h") == 0) {
        Help(stCmdInfo);
    }
    else {
        ShowConf(vCmdArray, stCmdInfo);
    }

    return 0;
}
