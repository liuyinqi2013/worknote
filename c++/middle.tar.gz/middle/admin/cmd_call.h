#ifndef __C_CMD_CALL_H
#define __C_CMD_CALL_H

#include "command.h"

class CCmdCall: public CCommand
{
    DECLARE_DYNCREATE(CCmdCall);

public:
    CCmdCall();
    virtual ~CCmdCall();

    virtual int Process(CommandInfo_T& stCmdInfo);

private:
    int Call(const vector<string>& vCmdArray,
            CommandInfo_T& stCmdInfo);


    int Help(CommandInfo_T& stCmdInfo);
};

#endif
