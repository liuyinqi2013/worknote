#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <assert.h>

#include "cmd_show_service.h"

IMPLEMENT_DYNCREATE(CCmdShowService, CCommand);

CCmdShowService::CCmdShowService()
:  CCommand()
{

}

CCmdShowService::~CCmdShowService()
{

}

int
CCmdShowService::ShowService(const vector < string > &vCmdArray,
                             CommandInfo_T & stCmdInfo)
{
    trpc_debug_log("Into CCmdShowService::ShowService\n");

    bool bShowByServerNo;
    unsigned uServerNo = 0;
    if (vCmdArray.size() >= 3) {
        bShowByServerNo = true;
        ServerConf_T *p = GetServerPtr(vCmdArray[2].c_str());
        if (p == NULL){
            AppendCmdInfo(stCmdInfo, "Server [%s] not found\n", vCmdArray[2].c_str());
            return -1;
        }
        uServerNo = p->uServerNo;
    }
    else {
        bShowByServerNo = false;
    }

    CShmServiceConf *pServiceConf = _pShmConfObjs->GetServiceConf();
    unsigned uRows = pServiceConf->GetShmRows();

    AppendCmdInfo(stCmdInfo,
                  "%-32s%-25s%-12s%-16s\n",
                  "ServiceName", "ServerName", "ServerNo", "SoFile");

    for (unsigned i = 0; i < uRows; ++i) {
        const ServiceInfo_T *p = pServiceConf->GetRecord(i);
        if (p == NULL || (p != NULL && !p->iIsValid)) {
            continue;
        }

        if (bShowByServerNo && uServerNo != p->uServerNo) {
            continue;
        }

        AppendCmdInfo(stCmdInfo,
                      "%-32s%-25s%-12d%-16s\n",
                      p->sServiceName,
                      p->sServerName, p->uServerNo, p->sSoFile);
    }

    AppendCmdInfo(stCmdInfo, "\n");

    return 0;
}

int
CCmdShowService::Help(CommandInfo_T & stCmdInfo)
{
    trpc_debug_log("Into CCmdShowService::Help\n");

    AppendCmdInfo(stCmdInfo, "Usage: show service [server_no]\n\n");

    return 0;
}

int
CCmdShowService::Process(CommandInfo_T & stCmdInfo)
{
    trpc_debug_log("Into CCmdShowService::Process\n");

    // show service [server_no]
    vector < string > vCmdArray;
    SplitString(stCmdInfo.idata, " ", 8, vCmdArray);

    if (vCmdArray.size() >= 3 && strcmp(vCmdArray[2].c_str(), "-h") == 0) {
        Help(stCmdInfo);
    }
    else {
        ShowService(vCmdArray, stCmdInfo);
    }

    return 0;
}
