#ifndef __C_CMD_STOP_H
#define __C_CMD_STOP_H

#include "command.h"

class CCmdStop: public CCommand
{
    DECLARE_DYNCREATE(CCmdStop);

public:
    CCmdStop();
    virtual ~CCmdStop();

    virtual int Process(CommandInfo_T& stCmdInfo);

private:
    int Stop(const vector<string>& vCmdArray,
            CommandInfo_T& stCmdInfo);


    int Help(CommandInfo_T& stCmdInfo);
};

#endif
