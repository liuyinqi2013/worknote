#ifndef __C_CMD_SHOW_CONF_H
#define __C_CMD_SHOW_CONF_H

#include "command.h"

class CCmdShowConf: public CCommand
{
    DECLARE_DYNCREATE(CCmdShowConf);

public:
    CCmdShowConf();
    virtual ~CCmdShowConf();

    virtual int Process(CommandInfo_T& stCmdInfo);

private:
    int ShowConf(const vector<string>& vCmdArray,
            CommandInfo_T& stCmdInfo);

    int Help(CommandInfo_T& stCmdInfo);
};

#endif
