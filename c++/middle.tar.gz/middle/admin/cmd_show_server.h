#ifndef __C_CMD_SHOW_SERVER_H
#define __C_CMD_SHOW_SERVER_H

#include "command.h"

class CCmdShowServer: public CCommand
{
    DECLARE_DYNCREATE(CCmdShowServer);

public:
    CCmdShowServer();
    virtual ~CCmdShowServer();

    virtual int Process(CommandInfo_T& stCmdInfo);

private:
    int ShowAllServer(const vector<string>& vCmdArray,
            CommandInfo_T& stCmdInfo);
    
    int ShowServer(const vector<string>& vCmdArray,
            CommandInfo_T& stCmdInfo);

    int Help(CommandInfo_T& stCmdInfo);
};

#endif
