#ifndef __C_ADMIN_H
#define __C_ADMIN_H

/*
����: 
       1.  ���ص�ʵ��

Created by Song, 2003-02,03
Change list:
    1 ���뱨������ --changed by verminniu 2007-9
*/


#include <string>
#include <vector>
using namespace std;

#include "trpc_server.h"
#include "admin_socket.h"
#include "trpc_queue.h"
#include "shm_conf_objs.h"
#include "command.h"
#include "conf_cmd_route.h"
#include "monitor.h"


#include "trpc_warning.h"
#include "trpc_stat.h"


class CAdminServer
{
public:
    CAdminServer(const char * sServerName, const char * sTrpcHome);
    ~CAdminServer();

    int Init();
    int Run();
    
    const char * get_error_text() const { return _error_text; }

private:
    int ReadConfig(const char * sConfigFile);
    int InitLog();
    int InitShmConfig(const char * sConfigFile);
    int InitTrpcQueue();
    int InitCmdRoute();
    int InitSocket();
    int InitClient();
    
private:
    int CheckClientTimeOut();
    bool IsAllowIP(const char * sIP);

    int Monitor();
    int RunOnce();
    int AcceptConnect();

    int ProcessRecv(int iSockNo);
    int ProcessCmd(int iSockNo, CommandInfo_T& stCmd);
    
    static int Max(int a, int b){return (a > b ? a:b);}

    //begin added by verminniu 2007-9-25
    //admin����
    int Warning(char ErrorId[], char Content[]);
    int SendStat(int iStatId, int iValue);
    //end added by verminniu 2007-9-25

private:
    struct CONFIG_T
    {
        int iListenPort;
        int iMaxClient;
        int iClientTimeOut;

        int iMaxLogSize;
        int iMaxLogNum;
        char sBindAddress[32];
        char sAllowIP[4096];
    };

private:
    static const int MAX_CMD_ROUTE_ROWS = 1024;
    
    string _strTrpcHome;
    string _strServerName;
    string _strTrpcConfPath;
    string _strConfPath;
    string _strLogPath;
    
    Socket _ListenSock;
    AdminSocket * _pSockArray;
    AdminSocket * _pSockEnd;

    CAdminConfObjs * _pAdminConfObjs;

    // ��������������Ҫ�ŵ�_pAdminConfObjs����
    CTrpcQueue * _pQueue;
    CShmConfObjs * _pShmConfObjs;
    CNameValueConf * _pMainConf;

    CMonitor * _pMonitor;

    key_t _iConfIpcKey;
    key_t _iQueueIpcKey;
    int _iMaxMqNum;
    char _sBindAddress[32];

    char _sWarningIp[32];
    int  _iWarningPort;

    char _sStatIp[32];
    int  _iStatPort;

    CTrpcWarning * _pWarningHandle;
    CTrpcStat    * _pStatHandle;

    CONFIG_T _stConfig;
    CConfCmdRoute * _pCmdRoute;
    vector<string> _vAllowIP;

    char _error_text[256];
};

#endif
