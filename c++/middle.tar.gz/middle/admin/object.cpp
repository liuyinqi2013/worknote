// This source file implements the methods of some basic classes 
// like CRuntimeClass, CObject, etc.
// Copyright(C) 2003, Tencent.com
// Developed by Hongzhe Shi
//
// Emulate MFC's implementation
//
// classes:
// CRuntimeClass
// CObject
//      First draft only implements Object Dynamic Creation

#include <assert.h>
#include "object.h"

//CRuntimeClass's implementation
CObject *
CRuntimeClass::CreateObject(void)
{
    if (m_pfnCreateObject)
        return m_pfnCreateObject();
    else
        return NULL;
}


//CObject's implementations
CObject::CObject()
{
}

CObject::~CObject()
{
}

CRuntimeClass
    CObject::classCObject = {
    "CObject",
        sizeof(CObject),
        NULL,
        NULL,
    NULL
};

const CRuntimeClass *
CObject::GetRuntimeClass(void) const
{
    return RUNTIME_CLASS(CObject);
}

//CRuntimeClass link list's header
static CRuntimeClass *__pFirstClass = RUNTIME_CLASS(CObject);


CRuntimeClass *
GetClassListHeader(void)
{
    return __pFirstClass;
}

void
InitClass(CRuntimeClass * pNewClass)
{
    assert(pNewClass);

    pNewClass->m_pNextClass = __pFirstClass;
    __pFirstClass = pNewClass;
}

CLASSLIST::CLASSLIST(CRuntimeClass * pNewClass)
{
    InitClass(pNewClass);
}

CObject *
TCreateObject(const char *class_name)
{
    CRuntimeClass *pHead = GetClassListHeader();

    while (pHead) {
        if (!strcmp(pHead->m_szClassName, class_name))
            return pHead->CreateObject();
        pHead = pHead->m_pNextClass;
    }
    return NULL;
}

IMPLEMENT_DYNAMIC(CException, CObject)
#ifdef _DEBUG
     void PrintClassList(void)
{
    CRuntimeClass *pHead = GetClassListHeader();

    while (pHead) {
        if (pHead->m_szClassName) {
            CRuntimeClass *pBaseClass = NULL;
            cout << "class " << pHead->m_szClassName
                << " create object=" << (void *) pHead->m_pfnCreateObject;


            pBaseClass = pHead->m_pBaseClass;
            if (pBaseClass)
                cout << " baseclass " << pBaseClass->m_szClassName << endl;
            else
                cout << " baseclass is NULL" << endl;
        }
        pHead = pHead->m_pNextClass;
    }
}

#endif
