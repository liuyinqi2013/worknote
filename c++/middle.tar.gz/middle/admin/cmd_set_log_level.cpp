#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <assert.h>

#include "cmd_set_log_level.h"

IMPLEMENT_DYNCREATE(CCmdSetLogLevel, CCommand);

CCmdSetLogLevel::CCmdSetLogLevel()
:  CCommand()
{

}

CCmdSetLogLevel::~CCmdSetLogLevel()
{

}

int
CCmdSetLogLevel::Help(CommandInfo_T & stCmdInfo)
{
    AppendCmdInfo(stCmdInfo, "Usage: setlog server_name[all] <no|error|normal|debug>\n\n");

//    AppendCmdInfo(stCmdInfo,
//                  "log_level no: no log\n    error: error log\n    normal: normal\n    debug: debug log\n\n");

    return 0;
}

int
CCmdSetLogLevel::Set(const vector < string > &vCmdArray,
                     CommandInfo_T & stCmdInfo)
{
    const char *sServerName = vCmdArray[1].c_str();
    const char * psLogLevelName = vCmdArray[2].c_str();
    int iLogLevel;

    if (strcasecmp(psLogLevelName, "no") == 0){
        iLogLevel = CLog::NO_LOG;
    }
    else if (strcasecmp(psLogLevelName, "error") == 0){
        iLogLevel = CLog::ERROR_LOG;
    }
    else if (strcasecmp(psLogLevelName, "normal") == 0){
        iLogLevel = CLog::NORMAL_LOG;
    }
    else if (strcasecmp(psLogLevelName, "debug") == 0){
        iLogLevel = CLog::DEBUG_LOG;
    }
    else{
        Help(stCmdInfo);
        return -1;
    }

    // �����Ϊall
    if (strncmp(sServerName, "all", sizeof("all")) != 0)
    {
        CShmServerConf *pServerConf = _pShmConfObjs->GetServerConf();
        if (pServerConf->Lock() != 0) {
            AppendCmdInfo(stCmdInfo, "pServerConf->Lock: %s\n",
                          pServerConf->get_error_text());
            return -1;
        }
        
        ServerConf_T *p = GetServerPtrByName(sServerName);
        
        if (p == NULL)
        {
            AppendCmdInfo(stCmdInfo, "Server Not Found: %s\n",
                  sServerName);
            
            pServerConf->UnLock();
            return -1;
        }
        
        p->iLogLevel = iLogLevel;
        pServerConf->UnLock();
    }
    else
    {
        CShmServerConf *pServerConf = _pShmConfObjs->GetServerConf();
        
        // ����
        if (pServerConf->Lock() != 0) {
            AppendCmdInfo(stCmdInfo, "pServerConf->Lock: %s\n",
                          pServerConf->get_error_text());
            return -1;
        }
        
        unsigned int iServerNum = pServerConf->GetShmRows();
        
        // �������з���,��������
        for (unsigned i = 0; i < iServerNum; ++i)
        {
            ServerConf_T *p = pServerConf->GetServerInfoPtr(i);
            if (p == NULL)
            {
                continue;
            }
                 
            p->iLogLevel = iLogLevel;
        }

        pServerConf->UnLock();
    }

    AppendCmdInfo(stCmdInfo, "OK\n\n");

    return 0;
}

int
CCmdSetLogLevel::Process(CommandInfo_T & stCmdInfo)
{
    // setloglevel server_no level
    vector < string > vCmdArray;
    SplitString(stCmdInfo.idata, " ", 8, vCmdArray);

    if (vCmdArray.size() < 3) {
        Help(stCmdInfo);
    }
    else {
        Set(vCmdArray, stCmdInfo);
    }

    return 0;
}
