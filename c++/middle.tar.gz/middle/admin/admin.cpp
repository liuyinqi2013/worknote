/*
����: 
       1.  ���ص�ʵ��

Created by Song, 2003-02,03
Change list:

edit by richardzhao, change array->128

*/

#include <cstdio>
#include <cstring>
#include <ctype.h>
#include <assert.h>
#include <errno.h>

#include "admin.h"

//begin added by verminniu 2007-9-24
//�����������ݿ��IP�Ͷ˿�
char    sHOST[16];
unsigned    sPORT;
//end added by verminniu 2007-9-24


CAdminServer::CAdminServer(const char *sTrpcHome, const char *sServerName)
    :
_strTrpcHome(sTrpcHome),
_strServerName(sServerName),
_ListenSock(),
_pSockArray(NULL),
_pSockEnd(NULL),
_pAdminConfObjs(NULL),
_pQueue(NULL),
_pShmConfObjs(NULL),
_pMainConf(NULL),
_pMonitor(NULL),
_iConfIpcKey((key_t) - 1),
_iQueueIpcKey((key_t) - 1),
_iMaxMqNum(0),
_pWarningHandle(NULL),
_pStatHandle(NULL),
_pCmdRoute(NULL)
{
    char sTrpcConfPath[256];
    char sConfigPath[256];
    char sLogPath[256];
    size_t nLen = strlen(sTrpcHome);
    if (nLen == 0 || sTrpcHome[nLen - 1] != '/') {
        _strTrpcHome += "/";
    }

    snprintf(sTrpcConfPath, sizeof(sTrpcConfPath), "%sconf/trpc.conf",
             _strTrpcHome.c_str());
    snprintf(sConfigPath, sizeof(sConfigPath), "%sconf/%s.conf",
             _strTrpcHome.c_str(), sServerName);
    snprintf(sLogPath, sizeof(sLogPath), "%slog/%s/%s",
             _strTrpcHome.c_str(), sServerName, sServerName);

    _strTrpcConfPath = sTrpcConfPath;
    _strConfPath = sConfigPath;
    _strLogPath = sLogPath;

    _error_text[0] = '\0';
}

CAdminServer::~CAdminServer()
{
    delete _pAdminConfObjs;

    if (_pQueue != NULL) {
        _pQueue->Close();
    }
    delete _pQueue;

    if (_pShmConfObjs != NULL) {
        _pShmConfObjs->Close();
    }

    delete _pWarningHandle;
    delete _pStatHandle;
    
    delete _pShmConfObjs;
    delete _pMainConf;

    delete[]_pSockArray;

    delete _pCmdRoute;

    delete _pMonitor;
}

int
CAdminServer::Init()
{
    //begin changed by verminniu 2007-9-25
    //����InitLog��ReadConfig,��ReadConfig�п���Ҫ�õ�trpc_debug_log��
    if (InitLog() != 0) {
        return -1;
    }

    if (ReadConfig(_strConfPath.c_str()) != 0) {
        return -1;
    }
    //end changed by verminniu 2007-9-25

    if (InitShmConfig(_strTrpcConfPath.c_str()) != 0) {
        trpc_error_log("Init: %s\n", _error_text);
        return -1;
    }

    if (InitTrpcQueue() != 0) {
        trpc_error_log("Init: %s\n", _error_text);
        return -1;
    }

    if (InitCmdRoute() != 0) {
        trpc_error_log("Init: %s\n", _error_text);
        return -1;
    }

    if (InitSocket() != 0) {
        trpc_error_log("Init: %s\n", _error_text);
        return -1;
    }

    // ��ʼ��ͳ�ƺͱ���
    if (InitClient() != 0) {
        trpc_error_log("Init: %s\n", _error_text);
        return -1;
    }

    // ��ʼ��Monitor����
    _pMonitor = new CMonitor();
    _pMonitor->Init(_pAdminConfObjs);

    trpc_write_log("Init finnished\n\n");
    fprintf(stdout, "Init finnished\n");

    DaemonInit(1, 0);

    return 0;
}

int
CAdminServer::ReadConfig(const char *sConfigFile)
{
    int iRetVal;

    // ��ȡ�����ļ���Main
    _pMainConf = new CNameValueConf(sConfigFile, MAX_MAIN_CONF_ROWS, "Main");

    iRetVal = _pMainConf->ReadFromFile();
    if (iRetVal != 0) {
        sprintf(_error_text, "ReadConfig: %s", _pMainConf->get_error_text());
        return -1;
    }

    const int NAME_ARRAY_SIZE = 6;
/*
    char *sNameArr[NAME_ARRAY_SIZE] = {
        {"ListentPort"},
        {"MaxClient"},
        {"ClientTimeOut"},
        {"MaxLogSize"},
        {"MaxLogNum"},
        {"AllowIP"}
    };
*/

    char sNameArr[NAME_ARRAY_SIZE][128] = {
        {"ListentPort"},
        {"MaxClient"},
        {"ClientTimeOut"},
        {"MaxLogSize"},
        {"MaxLogNum"},
        {"AllowIP"}
    };

    memset(&_stConfig, 0, sizeof(_stConfig));
    CONFIG_T *p = &_stConfig;

    int iRetArr[NAME_ARRAY_SIZE];
    iRetArr[0] = _pMainConf->GetNameValue(sNameArr[0], p->iListenPort);
    iRetArr[1] = _pMainConf->GetNameValue(sNameArr[1], p->iMaxClient);
    iRetArr[2] = _pMainConf->GetNameValue(sNameArr[2], p->iClientTimeOut);
    iRetArr[3] = _pMainConf->GetNameValue(sNameArr[3], p->iMaxLogSize);
    iRetArr[4] = _pMainConf->GetNameValue(sNameArr[4], p->iMaxLogNum);
    iRetArr[5] = _pMainConf->GetNameValue(sNameArr[5], p->sAllowIP,
                                          sizeof(p->sAllowIP));

    for (int i = 0; i < NAME_ARRAY_SIZE; ++i) {
        if (iRetArr[i] != 0) {
            sprintf(_error_text, "ReadConfig: MainConf not found: [%s]",
                    sNameArr[i]);
            return -1;
        }
    }
    _pMainConf->GetNameValue("BindAddress",
    		_stConfig.sBindAddress,
    		sizeof(_stConfig.sBindAddress),
    		"0");


    SplitString(p->sAllowIP, ",", 1024, _vAllowIP);

    return 0;
}

int
CAdminServer::InitLog()
{
    g_pLog = new CLog(_strLogPath.c_str(), _stConfig.iMaxLogSize,
                      _stConfig.iMaxLogNum);
    if (g_pLog->open() != 0) {
        sprintf(_error_text, "CLog::open: %s\n", g_pLog->get_error());
        delete g_pLog;
        return -1;
    }
    return 0;
}

int
CAdminServer::InitShmConfig(const char *sConfigFile)
{
    int iRetVal;

    // ��ȡ�����ļ���Const
    CNameValueConf *pConf = new CNameValueConf(sConfigFile,
                                               MAX_CONST_CONF_ROWS,
                                               SECTION_NAME_CONST_CONF);
/*
    iRetVal = pConf->ReadFromFile();
    if (iRetVal != 0) {
        sprintf(_error_text, "InitShmConfig: %s", pConf->get_error_text());
        delete pConf;
        return -1;
    }
    */
    
    iRetVal = pConf->ReadFromFile();
    if (iRetVal != 0) {
        sprintf(_error_text, "InitShmConfig: %s", pConf->get_error_text());
        delete pConf;
        return -1;
    }

    const int NAME_ARRAY_SIZE = 3;
/*
    char *sNameArr[NAME_ARRAY_SIZE] = {
        {"ConfIpcKey"},
        {"QueueIpcKey"},
        {"MaxMqNum"},
    };
*/

    char sNameArr[NAME_ARRAY_SIZE][128]= {
        {"ConfIpcKey"},
        {"QueueIpcKey"},
        {"MaxMqNum"}
    };

    int iRetArr[NAME_ARRAY_SIZE];
    iRetArr[0] = pConf->GetNameValue(sNameArr[0], _iConfIpcKey);
    iRetArr[1] = pConf->GetNameValue(sNameArr[1], _iQueueIpcKey);
    iRetArr[2] = pConf->GetNameValue(sNameArr[2], _iMaxMqNum);

    for (int i = 0; i < NAME_ARRAY_SIZE; ++i) {
        if (iRetArr[i] != 0) {
            sprintf(_error_text, "InitShmConfig: ConstConf not found: [%s]",
                    sNameArr[i]);

            delete pConf;
            return -1;
        }
    }
    
    // ��ShmConfObjs
    _pShmConfObjs = new CShmConfObjs(sConfigFile,
                                     _iConfIpcKey,
                                     MAX_TRPC_SERVER_NO,
                                     MAX_CONF_CUSHION_SIZE);

    iRetVal = _pShmConfObjs->Create();
    if (iRetVal < 0) {
        sprintf(_error_text, "CShmConfObjs::Create: %s",
                _pShmConfObjs->get_error_text());
        return -1;
    }

    iRetVal = _pShmConfObjs->Open();
    if (iRetVal < 0) {
        sprintf(_error_text, "CShmConfObjs::Open: %s",
                _pShmConfObjs->get_error_text());
        return -1;
    }

    iRetVal = _pShmConfObjs->ReadFromFile();
    if (iRetVal < 0) {
        sprintf(_error_text, "CShmConfObjs::ReadFromFile: %s",
                _pShmConfObjs->get_error_text());
        return -1;
    }

    iRetVal = _pShmConfObjs->WriteToShm();
    if (iRetVal < 0) {
        sprintf(_error_text, "CShmConfObjs::WriteToShm: %s",
                _pShmConfObjs->get_error_text());
        return -1;
    }

    // ��ȡ���� -- �Ƿ��ͳ�ƺͱ�����Ϣ
    CShmNameValueConf *pMainConf = _pShmConfObjs->GetMainConf();
    
    const int TMP_NAME_ARRAY_SIZE = 2;
    
    char sTmpNameArr[TMP_NAME_ARRAY_SIZE][128]= {
        {"StatEnable"},
        {"WarningEnable"}
    };

    int iConfArr[TMP_NAME_ARRAY_SIZE];

    // warning
    pMainConf->GetNameValue(sTmpNameArr[0], iConfArr[0]);
    pMainConf->GetNameValue(sTmpNameArr[1], iConfArr[1]);
    
    // ��ʼ��middled /////////////////////
    CShmServerConf *pServerConf = _pShmConfObjs->GetServerConf();
    ServerConf_T *pServerInfo = pServerConf->GetServerInfoPtr(MIDDLED_SERVER_NO);
    if (pServerInfo == NULL) {
        sprintf(_error_text, "CShmServerConf::GetServerInfoPtr: %s",
                pServerConf->get_error_text());
        return -1;
    }

    trpc_debug_log("WarningEnable: %d, StatEnable: %d\n", iConfArr[1], iConfArr[0]);
        
    strcpy(pServerInfo->sServerName, "middled");
    // ����server���
    pServerInfo->uServerNo = MIDDLED_SERVER_NO;
    // Ĭ�϶�����ͳ�ƺͱ�����Ϣ,������Ҫ�޸��ڷ����Լ������޸�
    pServerInfo->uWarning = (unsigned char)iConfArr[1];
    pServerInfo->uStat = (unsigned char)iConfArr[0];

    // ��ʼ��asyn /////////////////////
    pServerInfo = pServerConf->GetServerInfoPtr(ASYN_SERVER_NO);
    if (pServerInfo == NULL) {
        sprintf(_error_text, "CShmServerConf::GetServerInfoPtr: %s",
                pServerConf->get_error_text());
        return -1;
    }
    strcpy(pServerInfo->sServerName, "asyn");
    // ����������Ϊ1
    pServerInfo->uProcessNum = 1;
    // ����server���
    pServerInfo->uServerNo = ASYN_SERVER_NO;
    // Ĭ�϶�����ͳ�ƺͱ�����Ϣ,������Ҫ�޸��ڷ����Լ������޸�
    pServerInfo->uWarning = 1;
    pServerInfo->uStat = 1;

    // ��ʼ��error /////////////////////
    pServerInfo = pServerConf->GetServerInfoPtr(ERR_SERVER_NO);
    if (pServerInfo == NULL) {
        sprintf(_error_text, "CShmServerConf::GetServerInfoPtr: %s",
                pServerConf->get_error_text());
        return -1;
    }
    strcpy(pServerInfo->sServerName, "err");
    // ����������Ϊ1
    pServerInfo->uProcessNum = 1;
    // ����server���
    pServerInfo->uServerNo = ERR_SERVER_NO;
    // Ĭ�϶�����ͳ�ƺͱ�����Ϣ,������Ҫ�޸��ڷ����Լ������޸�
    pServerInfo->uWarning = 1;
    pServerInfo->uStat = 1;

    return 0;
}

int
CAdminServer::InitTrpcQueue()
{
    int iRetVal;
    
    CShmNameValueConf *pConstConf = _pShmConfObjs->GetConstConf();
    assert(pConstConf != NULL);

    unsigned uMaxRowsPerServer;
    iRetVal = pConstConf->GetNameValue("MaxRowsPerServer", uMaxRowsPerServer);
    if (iRetVal != 0) {
        uMaxRowsPerServer = DEFAULT_MAX_ROWS_PER_SERVER;
    }

    int iQueueValidTime;
    iRetVal = pConstConf->GetNameValue("QueueValidTime", iQueueValidTime);
    if (iRetVal != 0) {
        iQueueValidTime = DEFAULT_QUEUE_VALID_TIME;
    }

    int iRecyleTime;
    iRetVal = pConstConf->GetNameValue("QueueRecyleTime", iRecyleTime);
    if (iRetVal != 0) {
        iRecyleTime = DEFAULT_RECYLE_TIME;
    }
        
    int iSendRetryTimes;
    iRetVal = pConstConf->GetNameValue("MQSendRetryTimes", iSendRetryTimes);
    if (iRetVal != 0) {
        iSendRetryTimes = DEFAULT_SEND_RETRY_TIMES;
    }

    int iSendSleepTime;
    iRetVal = pConstConf->GetNameValue("MQSendSleepTime", iSendSleepTime);
    if (iRetVal != 0) {
        iSendSleepTime = DEFAULT_SEND_SLEEP_TIME;
    }
    
    _pQueue = new CTrpcQueue(_iQueueIpcKey,
                             MAX_TRPC_SERVER_NO,
                             MAX_TRPC_PROCESS_NO,
                             uMaxRowsPerServer,
                             _iMaxMqNum, 
                             iQueueValidTime, 
                             iRecyleTime,
                             iSendRetryTimes,
                             iSendSleepTime,
                             5);

    iRetVal = _pQueue->Create();
    if (iRetVal < 0) {
        sprintf(_error_text, "CTrpcQueue::Create: %s",
                _pQueue->get_error_text());
        return -1;
    }

    iRetVal = _pQueue->Open();
    if (iRetVal < 0) {
        sprintf(_error_text, "CTrpcQueue::Open: %s",
                _pQueue->get_error_text());
        return -1;
    }

    //added by verminniu 2007-8-23
    //��ʼ����Ϣ�洢��
    iRetVal = _pQueue->InitFreeList();
    if (iRetVal < 0){
        sprintf(_error_text, "CTrpcQueue:InitFreeList: %s",
                _pQueue->get_error_text());
        return -1;
    }
    //end added by verminniu 2007-8-23
    
    return 0;
}

int
CAdminServer::InitCmdRoute()
{
    _pAdminConfObjs = new CAdminConfObjs(_strTrpcHome.c_str(),
                                         _pShmConfObjs, _pQueue, _pMainConf);

    _pCmdRoute = new CConfCmdRoute(_strConfPath.c_str(),
                                   MAX_CMD_ROUTE_ROWS, _pAdminConfObjs);

    // ��ȡָ��·�ɱ�
    if (_pCmdRoute->ReadFromFile() != 0) {
        sprintf(_error_text, "CConfCmdRoute::ReadFromFile: %s",
                _pCmdRoute->get_error_text());
        return -1;
    }

    return 0;
}

int
CAdminServer::InitClient()
{
    CShmNameValueConf *pConstConf = _pShmConfObjs->GetConstConf();
    
    const int NAME_ARRAY_SIZE = 4;
    
    char sNameArr[NAME_ARRAY_SIZE][128]= {
        {"WarningHost"},
        {"WarningPort"},
        {"StatHost"},
        {"StatPort"}
    };

    int iRetArr[NAME_ARRAY_SIZE];
    // warning
    iRetArr[0] = pConstConf->GetNameValue(sNameArr[0], _sWarningIp, sizeof(_sWarningIp));
    iRetArr[1] = pConstConf->GetNameValue(sNameArr[1], _iWarningPort);

    // stat
    iRetArr[2] = pConstConf->GetNameValue(sNameArr[2], _sStatIp, sizeof(_sStatIp));
    iRetArr[3] = pConstConf->GetNameValue(sNameArr[3], _iStatPort);

    if (_sStatIp[0] != 0 && _iWarningPort != 0)
    {
        _pWarningHandle = new CTrpcWarning(_sWarningIp, _iWarningPort);
    }
    else
    {
        _pWarningHandle = NULL;
    }

    if (_sStatIp[0] != 0 && _iStatPort != 0)
    {
        _pStatHandle = new CTrpcStat(_sStatIp, _iStatPort);
    }
    else
    {
        _pStatHandle = NULL;
    }

    return 0;
}


int
CAdminServer::InitSocket()
{
    _pSockArray = new AdminSocket[_stConfig.iMaxClient];
    _pSockEnd = _pSockArray + _stConfig.iMaxClient;

    try {
        // ����socket
        _ListenSock.create();
        _ListenSock.set_nonblock();

        int reuse_addr;
        _ListenSock.set_sock_opt(SO_REUSEADDR,
                                 (void *) (&(reuse_addr)),
                                 sizeof(reuse_addr), SOL_SOCKET);

        _ListenSock.bind(_stConfig.iListenPort, _stConfig.sBindAddress);
        _ListenSock.listen();
        trpc_write_log("Listen port: %d\n", _stConfig.iListenPort);
        trpc_write_log("Bind Address: %s\n", _stConfig.sBindAddress);
    }
    catch(SocketException & e) {
        sprintf(_error_text, "SocketException: %s", e.what());
        return -1;
    }

    return 0;
}

int
CAdminServer::Monitor()
{
//trpc_debug_log("Into CAdminServer::Monitor\n");

    // ���
    CommandInfo_T stCmdInfo;
    _pMonitor->Process(stCmdInfo);
    return 0;
}

int
CAdminServer::Run()
{
    int iCount=0;
    
    for (;;) {
        try {
            ++iCount;
            CheckClientTimeOut();
            Monitor();
            RunOnce();
            //ÿ����5������ɨ������Ϣ���
            if(iCount > 5)
            {
                int iRet = _pQueue->RecyleNodeByTime();

                //����л��յ��ڵ㣬����
                if( iRet != 0 )
                {
                    char Content[128];

                    snprintf(Content, sizeof(Content), "Admin Recyle %d Node!", iRet);
                    
                    Warning(ERR_MIDDLE_ROCYLE_NODE, Content);
                }
                
                iCount = 0;
             }
            //������
            //_pQueue->RecyleAllNode();
        }
        catch(SocketException & e) {
            trpc_error_log("SocketException: %s\n", e.what());
        }
    }

    return 0;
}

int
CAdminServer::RunOnce()
{
    fd_set read_set;
    int max_fds;

    max_fds = _ListenSock.fd();
    FD_ZERO(&read_set);
    FD_SET(max_fds, &read_set);

    for (AdminSocket * pSock = _pSockArray; pSock < _pSockEnd; ++pSock) {
        if (pSock->socket_is_ok()) {
            FD_SET(pSock->fd(), &read_set);
            max_fds = Max(pSock->fd(), max_fds);
        }
    }

    timeval timeout;
    timeout.tv_sec = 0;
    timeout.tv_usec = 500000;   //  500ms

    int ret = select(max_fds + 1, &read_set,
                     (fd_set *) 0, (fd_set *) 0, &timeout);

    if (ret > 0) {
        // client socket �Ƿ�׼����
        for (AdminSocket * pSock = _pSockArray; pSock < _pSockEnd; ++pSock) {
            if (!pSock->socket_is_ok())
                continue;

            if (FD_ISSET(pSock->fd(), &read_set)) {
                ProcessRecv(pSock - _pSockArray);
            }
        }

        // listen socket ׼����
        if (FD_ISSET(_ListenSock.fd(), &read_set)) {
            AcceptConnect();
        }
    }

    return 0;
}

int
CAdminServer::ProcessRecv(int iSockNo)
{
    AdminSocket *pSock = _pSockArray + iSockNo;
    pSock->SetLastAccessTime(time(NULL));

    try {
        int iRet = pSock->RecvRequest();
        switch (iRet) {
            case AdminSocket::RECV_CLOSE:
                // �Է��Ͽ�����
                trpc_write_log("RECV_CLOSE Connection close (%s:%d)\n",
                               pSock->GetIP(), pSock->GetPort());
                pSock->close();
                return 0;
                break;

            case AdminSocket::RECV_OK:
                break;

            case AdminSocket::RECV_HAVE_MORE:
                // �յ����Ĳ�������
                trpc_debug_log("have more data (%s:%d)\n",
                               pSock->GetIP(), pSock->GetPort());
                return 0;
                break;

            case AdminSocket::RECV_FMT_ERROR:
            default:
                // ����
                trpc_error_log("ReceiveMessage error(%s:%d): %s\n",
                               pSock->GetIP(),
                               pSock->GetPort(), pSock->get_last_error());
                pSock->close();
                return -1;
        }
    }
    catch(SocketException & e) {
        trpc_error_log("SocketException(%s:%d): %s\n",
                       pSock->GetIP(), pSock->GetPort(), e.what());

        pSock->close();
        return -1;
    }

    // ����
    CommandInfo_T stCmd;
    int iRetVal = ProcessCmd(iSockNo, stCmd);
    if (iRetVal < 0) {
        trpc_error_log("ProcessCmd: %s\n", _error_text);
        return -1;
    }
    else if (iRetVal > 0) {
        // �Ҳ������������
        stCmd.olen = snprintf(stCmd.odata,
                              sizeof(stCmd.odata), "error cmd\n");
    }

    // ���ؽ��
    char sHead[1024];
    int iHeadLen = snprintf(sHead, sizeof(sHead), "LENGTH: %d\n", stCmd.olen);
    try {
        pSock->SendMessage(sHead, iHeadLen, 0);
        pSock->SendMessage(stCmd.odata, stCmd.olen, 0);
    }
    catch(SocketException & e) {
        trpc_error_log("%s\n", e.what());
        return -1;
    }


    return 0;
}

int
CAdminServer::ProcessCmd(int iSockNo, CommandInfo_T & stCmd)
{
    AdminSocket *pSock = _pSockArray + iSockNo;

    if (pSock->GetDataLen() <= 0) {
        sprintf(_error_text, "DataLen < %d\n", pSock->GetDataLen());
        return -1;
    }

    // ����Ƿ�Ϊquit����,�����,ֱ�ӹر�
    if (strcmp(pSock->GetData(), "quit") == 0) {
        sprintf(_error_text, "quit");
        pSock->close();
        return -1;
    }

    // ���� 
    memcpy(stCmd.idata, pSock->GetData(), pSock->GetDataLen());
    stCmd.ilen = pSock->GetDataLen();

    trpc_write_log("Process [%s]\n", stCmd.idata);

    CCommand::ResetCmdInfo(stCmd);
    CCommand *pCmdObj = _pCmdRoute->SearchCmdObj(stCmd.idata);
    if (pCmdObj == NULL) {
        trpc_error_log("SearchCmdObj Cmd[%s]: not found\n", stCmd.idata);
        return 1;
    }


    pCmdObj->Process(stCmd);

    return 0;
}

int
CAdminServer::AcceptConnect()
{
    for (AdminSocket * pSock = _pSockArray; pSock < _pSockEnd; ++pSock) {
        if (!pSock->socket_is_ok()) {
            _ListenSock.accept(*pSock);

            pSock->set_nonblock();

            pSock->SetIPAndPort();
            if (!IsAllowIP(pSock->GetIP())) {
                trpc_error_log("Not Allow IP: %s\n", pSock->GetIP());
                pSock->close();
                return 0;
            }
            pSock->SetLastAccessTime(time(NULL));

            trpc_write_log("Accept New Connection (%s:%d)\n",
                           pSock->GetIP(), pSock->GetPort());
            return 0;
        }
    }

    // û�п���_sock_array
    AdminSocket sock;
    _ListenSock.accept(sock);
    sock.SetIPAndPort();

    trpc_error_log("Too Many Connection: MaxClient== %d\n",
                   _stConfig.iMaxClient);
    trpc_error_log("Close Connection(%s:%d)\n", sock.GetIP(), sock.GetPort());

    sock.close();

    return -1;
}

int
CAdminServer::CheckClientTimeOut()
{
    static time_t tLastCheckTime = 0;
    static const int CHECK_INTERVAL = 2;        // 2 ����һ��


    time_t tNow = time(NULL);
    if (tNow - tLastCheckTime < CHECK_INTERVAL) {
        return 0;
    }
    tLastCheckTime = tNow;

    for (AdminSocket * pSock = _pSockArray; pSock < _pSockEnd; ++pSock) {
        if (!pSock->socket_is_ok()) {
            continue;
        }

        if (tNow - pSock->GetLastAccessTime() > _stConfig.iClientTimeOut) {
            trpc_write_log("Client TimeOut(%d), Close Connection(%s:%d)\n",
                           _stConfig.iClientTimeOut, pSock->GetIP(),
                           pSock->GetPort());

            pSock->close();
        }
    }

    return 0;
}

bool CAdminServer::IsAllowIP(const char *sIP)
{
    for (vector < string >::const_iterator iter = _vAllowIP.begin();
         iter != _vAllowIP.end(); ++iter) {
        if (strcmp(iter->c_str(), sIP) == 0) {
            return true;
        }
    }

    return false;
}


//begin added by verminniu 2007-9-25
/******
*   ��������
*   ����:
*       ErrorId �����Ĵ������
*       Content ������Ϣ
*   ����:
*       0  �ɹ�
*       -1 ʧ��    
*******/
int
CAdminServer::Warning(char ErrorId[], char Content[])
{
    if (_pWarningHandle == NULL)
    {
        return 0;
    }

    return _pWarningHandle->warning(ErrorId, Content);
}

int
CAdminServer::SendStat(int iStatId, int iValue)
{
    if (_pStatHandle == NULL)
    {
        return 0;
    }

    return _pStatHandle->Send(iStatId, iValue);
}

//end added by verminniu 2007-9-25


