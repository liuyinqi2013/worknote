#include <stdio.h>
#include <string.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

#include <errno.h>
#include <assert.h>

#include "cmd_call.h"

IMPLEMENT_DYNCREATE(CCmdCall, CCommand);

CCmdCall::CCmdCall()
:  CCommand()
{

}

CCmdCall::~CCmdCall()
{

}

int
CCmdCall::Call(const vector < string > &vCmdArray, CommandInfo_T & stCmdInfo)
{
    trpc_debug_log("Into CCmdCall::Call\n");

    const char *pServerName = vCmdArray[2].c_str();

    // �Ҹ�Server ����Ϣ
    ServerConf_T stServerInfo;
    int iRetVal = GetServerInfo(pServerName, stServerInfo);
    if (iRetVal < 0) {
        AppendCmdInfo(stCmdInfo, "ERROR: %s\n\n", _error_text);
        return -1;
    }
    else if (iRetVal > 0) {
        AppendCmdInfo(stCmdInfo,
                      "ERROR: ServerName not found: %s\n\n", pServerName);
        return 1;
    }

    // ����Server �Ĺ����ڴ淢stop ����
    CServerShmCmd *pShmCmd = _pShmConfObjs->GetServerCmd();
    if (pShmCmd->Lock() != 0) {
        sprintf(_error_text, "CServerShmCmd::Lock: %s",
                pShmCmd->get_error_text());
        trpc_error_log("%s\n", _error_text);
        AppendCmdInfo(stCmdInfo, "ERROR: %s\n\n", _error_text);
        return -1;
    }

    if (pShmCmd->Insert(stServerInfo.uServerNo, vCmdArray[1].c_str()) != 0) {
        sprintf(_error_text, "CServerShmCmd::Insert: %s",
                pShmCmd->get_error_text());
        trpc_error_log("%s\n", _error_text);
        AppendCmdInfo(stCmdInfo, "ERROR: %s\n\n", _error_text);

        pShmCmd->UnLock();
        return -1;
    }
    pShmCmd->UnLock();

    AppendCmdInfo(stCmdInfo, "OK\n\n", _error_text);

    return 0;
}

int
CCmdCall::Help(CommandInfo_T & stCmdInfo)
{
    trpc_debug_log("Into CCmdCall::Help\n");

    AppendCmdInfo(stCmdInfo, "Usage:\n\
  call %s server_name\n\
  call %s server_name\n\
  call %s server_name\n\n", TRPC_SHM_CMD_INIT, TRPC_SHM_CMD_LOADCONF, TRPC_SHM_CMD_LOADSO);

    return 0;
}

int
CCmdCall::Process(CommandInfo_T & stCmdInfo)
{
    trpc_debug_log("Into CCmdCall::Process\n");

    // stop ServerName
    vector < string > vCmdArray;
    SplitString(stCmdInfo.idata, " ", 8, vCmdArray);

    if (vCmdArray.size() >= 3) {
        if (strcasecmp(vCmdArray[1].c_str(), TRPC_SHM_CMD_INIT) == 0
            || strcasecmp(vCmdArray[1].c_str(), TRPC_SHM_CMD_LOADCONF) == 0
            || strcasecmp(vCmdArray[1].c_str(), TRPC_SHM_CMD_LOADSO) == 0) {
            Call(vCmdArray, stCmdInfo);
            return 0;
        }
    }

    Help(stCmdInfo);

    return 0;
}
