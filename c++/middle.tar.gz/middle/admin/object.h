// This header file defines some basic object models.
// Copyright(C) 2003, Tencent.com
// Developed by Hongzhe Shi
//
// Emulate MFC's implementation
//
// classes:
// CRuntimeClass
// CObject
//  First draft only implement Object Dynamic Creation

#ifndef _OBJECT_H_
#define _OBJECT_H_

#ifndef __cplusplus
    #error  Need c++ compiler
#endif

#include <string.h>
#include <iostream>
using namespace std;

class CObject;
struct CRuntimeClass;
struct CLASSLIST;

// class CRuntimeClass implements functions 
// like Dynamic Create, RTTI, etc.
struct CRuntimeClass
{
    const char *m_szClassName;
    int m_iObjectSize;
    CRuntimeClass *m_pBaseClass;
    CObject *( *m_pfnCreateObject)(void);
    // CRuntimeClass objects linked together in simple list
    CRuntimeClass* m_pNextClass;       // linked list of registered classes

    //operations
    CObject *CreateObject();
};

struct CLASSLIST
{
    CLASSLIST(CRuntimeClass *pRuntimeClass);
};

//basic object
//Derive from CObject if want get the Dynamic Create Function or RTTI
class CObject
{
public:
    virtual ~CObject();
    virtual const CRuntimeClass *GetRuntimeClass(void)const;

    //
//protected:
    CObject();

    //Implementation
    static CRuntimeClass classCObject;

};


// Some macros 
#define RUNTIME_CLASS(class_name)   (CRuntimeClass *)(&class_name::class##class_name)

#define DECLARE_DYNAMIC(class_name) \
public: \
    static CRuntimeClass class##class_name; \
    virtual const CRuntimeClass* GetRuntimeClass(void) const; 


#define DECLARE_DYNCREATE(class_name)   \
    DECLARE_DYNAMIC(class_name) \
    static CObject* CreateObject();

#define IMPLEMENT_RUNTIMECLASS(class_name, base_class_name, pfnNew) \
    CRuntimeClass class_name::class##class_name = { \
        #class_name, sizeof(class class_name),  \
            RUNTIME_CLASS(base_class_name), pfnNew, NULL }; \
    CLASSLIST __initclass_##class_name(RUNTIME_CLASS(class_name)); \
    const CRuntimeClass* class_name::GetRuntimeClass(void) const \
        { return RUNTIME_CLASS(class_name); } \


#define IMPLEMENT_DYNAMIC(class_name, base_class_name) \
    IMPLEMENT_RUNTIMECLASS(class_name, base_class_name, NULL)   \

#define IMPLEMENT_DYNCREATE(class_name, base_class_name) \
    CObject * class_name::CreateObject(void) \
    { return new class_name; }  \
    IMPLEMENT_RUNTIMECLASS(class_name, base_class_name, class_name::CreateObject)   \
    

class CException : public CObject
{
    DECLARE_DYNAMIC(CException)
public:
    CException()
    {
        err_msg = new char[1024];
        memset(err_msg, 0, sizeof(err_msg));
    }
    
    CException(const char *error)
    { 
        err_msg = new char[1024];
        if (err_msg == NULL) throw;

        cout << "cexception" << endl;
        strncpy(err_msg, error, 1024);
        err_msg[1023] = 0;
    }

    virtual ~CException() 
    {
//      if (err_msg)
//          delete err_msg;
    }

    const char* GetErrorMessage(void) 
    {
        return err_msg;
    }

private:
    char *err_msg;
};


CRuntimeClass *GetClassListHeader(void);
CObject *TCreateObject(const char *class_name);

#ifdef _DEBUG
void PrintClassList(void);
#endif //_DEBUG

#endif //_OBJECT_H_
