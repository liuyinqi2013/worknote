#include <stdio.h>
#include <string.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

#include <errno.h>
#include <assert.h>

#include "cmd_stop.h"

IMPLEMENT_DYNCREATE(CCmdStop, CCommand);

CCmdStop::CCmdStop()
:  CCommand()
{

}

CCmdStop::~CCmdStop()
{

}

int
CCmdStop::Stop(const vector < string > &vCmdArray, CommandInfo_T & stCmdInfo)
{
    trpc_debug_log("Into CCmdStop::Stop\n");

    const char *pServerName = vCmdArray[1].c_str();

    // �����Ϊall
    if (strncmp(pServerName, "all", sizeof("all")) != 0)
    {
        // �Ҹ�Server ����Ϣ
        ServerConf_T stServerInfo;
        int iRetVal = GetServerInfo(pServerName, stServerInfo);
        if (iRetVal < 0) {
            AppendCmdInfo(stCmdInfo, "ERROR: %s\n\n", _error_text);
            return -1;
        }
        else if (iRetVal > 0) {
            AppendCmdInfo(stCmdInfo,
                          "ERROR: ServerName not found: %s\n\n", pServerName);
            return 1;
        }

        // ����Server �Ĺ����ڴ淢stop ����
        CServerShmCmd *pShmCmd = _pShmConfObjs->GetServerCmd();
        if (pShmCmd->Lock() != 0) {
            sprintf(_error_text, "CServerShmCmd::Lock: %s",
                    pShmCmd->get_error_text());
            trpc_error_log("%s\n", _error_text);
            AppendCmdInfo(stCmdInfo, "ERROR: %s\n\n", _error_text);
            return -1;
        }

        if (pShmCmd->Insert(stServerInfo.uServerNo, "stop") != 0) {
            sprintf(_error_text, "CServerShmCmd::Insert: %s",
                    pShmCmd->get_error_text());
            trpc_error_log("%s\n", _error_text);
            AppendCmdInfo(stCmdInfo, "ERROR: %s\n\n", _error_text);

            pShmCmd->UnLock();
            return -1;
        }
        pShmCmd->UnLock();
    }
    else
    {
        CShmServerConf *pServerConf = _pShmConfObjs->GetServerConf();
        
        unsigned int iServerNum = pServerConf->GetShmRows();
        
        // �������з���,��������
        for (unsigned i = 0; i < iServerNum; ++i)
        {
            // ����Server �Ĺ����ڴ淢stop ����
            CServerShmCmd *pShmCmd = _pShmConfObjs->GetServerCmd();
            if (pShmCmd->Lock() != 0) {
                sprintf(_error_text, "CServerShmCmd::Lock: %s",
                        pShmCmd->get_error_text());
                trpc_error_log("%s\n", _error_text);
                AppendCmdInfo(stCmdInfo, "ERROR: %s\n\n", _error_text);
                return -1;
            }

            if (pShmCmd->Insert(i, "stop") != 0) {
                sprintf(_error_text, "CServerShmCmd::Insert: %s",
                        pShmCmd->get_error_text());
                trpc_error_log("%s\n", _error_text);
                AppendCmdInfo(stCmdInfo, "ERROR: %s\n\n", _error_text);

                pShmCmd->UnLock();
                return -1;
            }
            pShmCmd->UnLock();  
        }
    }
    
    AppendCmdInfo(stCmdInfo, "OK\n\n", _error_text);

    return 0;
}

int
CCmdStop::Help(CommandInfo_T & stCmdInfo)
{
    trpc_debug_log("Into CCmdStop::Help\n");

    AppendCmdInfo(stCmdInfo, "Usage: stop ServerName[all]\n\n");

    return 0;
}

int
CCmdStop::Process(CommandInfo_T & stCmdInfo)
{
    trpc_debug_log("Into CCmdStop::Process\n");

    // stop ServerName
    vector < string > vCmdArray;
    SplitString(stCmdInfo.idata, " ", 8, vCmdArray);

    if (vCmdArray.size() == 1
        || (vCmdArray.size() > 1 &&
            strcmp(vCmdArray[1].c_str(), "-h") == 0)) {
        Help(stCmdInfo);
    }
    else {
        Stop(vCmdArray, stCmdInfo);
    }

    return 0;
}
