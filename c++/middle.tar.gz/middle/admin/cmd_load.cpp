#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <assert.h>

#include "cmd_load.h"

IMPLEMENT_DYNCREATE(CCmdLoad, CCommand);

CCmdLoad::CCmdLoad()
:  CCommand()
{

}

CCmdLoad::~CCmdLoad()
{

}

int
CCmdLoad::Load(CShmConfig * pShmConfig,
               const char *sConfigName, CommandInfo_T & stCmdInfo)
{
    trpc_debug_log("Into CCmdLoad::Load(%s)\n", sConfigName);

    if (pShmConfig->Lock() != 0) {
        sprintf(_error_text, "%s->Lock: %s",
                sConfigName, pShmConfig->get_error_text());
        goto _error;
    }

    // ������
    if (pShmConfig->ReadFromFile() != 0) {
        sprintf(_error_text, "%s->ReadFromFile: %s",
                sConfigName, pShmConfig->get_error_text());
        goto _error;
    }

    // д���õ��ڴ�
    if (pShmConfig->WriteToShm() != 0) {
        sprintf(_error_text, "%s->WriteToShm: %s",
                sConfigName, pShmConfig->get_error_text());
        goto _error;
    }

    pShmConfig->UnLock();

    AppendCmdInfo(stCmdInfo, "load %s OK\n\n", sConfigName);

    return 0;

  _error:
    AppendCmdInfo(stCmdInfo, "ERROR: %s\n\n", _error_text);
    pShmConfig->UnLock();
    return -1;
}

int
CCmdLoad::LoadAll(const vector < string > &vCmdArray,
                  CommandInfo_T & stCmdInfo)
{
    trpc_debug_log("Into CCmdLoad::LoadAll\n");

    static const int CONF_NUM = 3;
    CShmConfig *pShmConfArray[CONF_NUM] = {
        _pShmConfObjs->GetMainConf(),
        _pShmConfObjs->GetAccessControl(),
        _pShmConfObjs->GetServerConf()
    };

    char *sConfNameArray[CONF_NUM] = {
        "MainConf",
        "AccessControl",
        "ServerConf"
    };

    for (int i = 0; i < CONF_NUM; ++i) {
        if (Load(pShmConfArray[i], sConfNameArray[i], stCmdInfo) != 0) {
            return -1;
        }
    }

    AppendCmdInfo(stCmdInfo, "load all OK\n\n");

    return 0;
}

int
CCmdLoad::LoadMain(const vector < string > &vCmdArray,
                   CommandInfo_T & stCmdInfo)
{
    trpc_debug_log("Into CCmdLoad::LoadMain\n");

    return Load(_pShmConfObjs->GetMainConf(), "MainConf", stCmdInfo);
}

int
CCmdLoad::LoadAccessControl(const vector < string > &vCmdArray,
                            CommandInfo_T & stCmdInfo)
{
    trpc_debug_log("Into CCmdLoad::LoadAccessControl\n");

    return Load(_pShmConfObjs->GetAccessControl(),
                "AccessControl", stCmdInfo);
}

int
CCmdLoad::LoadServerConf(const vector < string > &vCmdArray,
                         CommandInfo_T & stCmdInfo)
{
    trpc_debug_log("Into CCmdLoad::LoadServerConf\n");

    return Load(_pShmConfObjs->GetServerConf(), "ServerConf", stCmdInfo);
}

int
CCmdLoad::Help(const vector < string > &vCmdArray, CommandInfo_T & stCmdInfo)
{
    trpc_debug_log("Into CCmdLoad::ShowHelp\n");

    AppendCmdInfo(stCmdInfo, "Usage:\n\
  load all  	-- �����������õ������ڴ�\n\
  load main 	-- ����main������\n\
  load server 	-- ����server������\n\
  load acl 	-- ����Ȩ�޿���������\n");

    AppendCmdInfo(stCmdInfo, "\n");

    return 0;
}

int
CCmdLoad::Process(CommandInfo_T & stCmdInfo)
{
    trpc_debug_log("Into CCmdLoad::Process\n");

    // load all|main|server|acl
    vector < string > vCmdArray;
    SplitString(stCmdInfo.idata, " ", 8, vCmdArray);

    if (vCmdArray.size() >= 2) {
        if (strcasecmp(vCmdArray[1].c_str(), "all") == 0) {
            LoadAll(vCmdArray, stCmdInfo);
            return 0;
        }
        else if (strcasecmp(vCmdArray[1].c_str(), "main") == 0) {
            LoadMain(vCmdArray, stCmdInfo);
            return 0;
        }
        else if (strcasecmp(vCmdArray[1].c_str(), "server") == 0) {
            LoadServerConf(vCmdArray, stCmdInfo);
            return 0;
        }
        else if (strcasecmp(vCmdArray[1].c_str(), "acl") == 0) {
            LoadAccessControl(vCmdArray, stCmdInfo);
            return 0;
        }
    }

    Help(vCmdArray, stCmdInfo);

    return 0;
}
