#ifndef __C_CMD_START_H
#define __C_CMD_START_H

#include "command.h"

class CCmdStart: public CCommand
{
    DECLARE_DYNCREATE(CCmdStart);

public:
    CCmdStart();
    virtual ~CCmdStart();

    virtual int Process(CommandInfo_T& stCmdInfo);

private:
    int Start(const vector<string>& vCmdArray,
            CommandInfo_T& stCmdInfo);

    int Help(CommandInfo_T& stCmdInfo);
};

#endif
