#!/bin/sh

ulimit -c 10000
killall -9 admin
./admin

