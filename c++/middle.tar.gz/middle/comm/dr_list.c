/*
����:
       1. data representation list��ͨ�õ���������ģ��


Created by Song, 2003.01-03
Change list:

*/

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <errno.h>
#include <netinet/in.h>
#include <assert.h>

#include "dr_list.h"



#define EE(p) p->error_text
#define EESIZE(p) (int)sizeof(p->error_text)
// �����ֶ���
static size_t
GetNameListColNum(const char *sColNameList)
{
    const char *p = sColNameList;
    size_t nColNum;

    while (*p && isspace(*p)) {
        ++p;
    }

    if (*p == '\0') {
        return 0;
    }

    for (nColNum = 1; *p; ++p) {
        if (*p == ',') {
            ++nColNum;
        }
    }

    return nColNum;
}

static char *
StrcpyColName(char *sColName, const char *sStr, size_t nLen, size_t nMaxLen)
{
    const char *p = sStr;
    const char *endp = sStr + nLen - 1;

    sColName[0] = '\0';

    // ȥ��ǰ��Ŀո�
    while (*p && isspace(*p)) {
        ++p;
    }

    // ȥ������Ŀո�
    while (endp >= p && isspace(*endp)) {
        --endp;
    }

    if (endp < p) {
        // ȫ���ǿո�
        return sColName;
    }

    nLen = endp - p + 1;
    if (nLen > nMaxLen) {
        nLen = nMaxLen;
    }

    strncpy(sColName, p, nLen);
    if (nLen <= nMaxLen - 1) {
        sColName[nLen] = '\0';
    }
    else if (nMaxLen > 0) {
        sColName[nMaxLen - 1] = '\0';
    }
    return sColName;
}

// �����ֶ���
static int
GetNameListColName(const char *sColNameList, DRListCol * pHeadArray,
                   size_t nColNum)
{
    const char *p = sColNameList;
    const char *lastp;
    size_t nLen = 0;
    size_t nCols = 0;

    // ȥ��ǰ��Ŀո�
    while (*p && isspace(*p)) {
        ++p;
    }


    for (lastp = p; *p != '\0'; ++p) {
        if (*p == ',') {
            StrcpyColName(pHeadArray[nCols].sColName, lastp,
                          nLen, DRLIST_MAX_COLS);
            if (strcmp(pHeadArray[nCols].sColName, "") != 0) {
                // ȥ���ո��ֶ�
                ++nCols;
            }
            nLen = 0;
            lastp = p + 1;
            if (nCols >= nColNum) {
                break;
            }
        }
        else {
            ++nLen;
        }
    }

    if (nLen > 0) {
        StrcpyColName(pHeadArray[nCols].sColName, lastp,
                      nLen, DRLIST_MAX_COLS);
        // ȥ���ո��ֶ�
        if (strcmp(pHeadArray[nCols].sColName, "") != 0) {
            ++nCols;
        }
    }

    return nCols;
}

/**
 * Funciton: ����һ��DRList �������malloc �����ڴ�
  ����:
  nBufferSize:  ������ݵ�buf ��С
  iCols:  ����ֶ���
  sErrMsg:  ������Ϣ
  
 return value NULL: ʧ��
 		!= NULL: DRList ָ��
**/
DRList *
CreateDRList(size_t nBufferSize, size_t nMaxCols, char *sErrMsg)
{
    char *pBuf;
    DRList *pDRList;
    size_t nHeadSize;

    // ���������ֶ���
    if (nMaxCols > DRLIST_MAX_COLS) {
        sprintf(sErrMsg, "too many cols : %d > %d",
                nMaxCols, DRLIST_MAX_COLS);
        return NULL;
    }

    // �����ڴ�
    nHeadSize = nMaxCols * sizeof(DRListCol);
    pBuf = malloc(sizeof(DRList) + nHeadSize + nBufferSize);
    if (pBuf == NULL) {
        sprintf(sErrMsg, "malloc : %s", strerror(errno));
        return NULL;
    }

    pDRList = (DRList *) pBuf;
    pDRList->pHeadArray = (DRListCol *) (pBuf + sizeof(DRList));
    pDRList->pBuffer = (char *) pDRList->pHeadArray + nHeadSize;

    pDRList->iBufferSize = nBufferSize;
    pDRList->bMaxCols = nMaxCols;
    pDRList->pFreeBuf = pDRList->pBuffer;
    pDRList->iLeftBufSize = nBufferSize;
    pDRList->iError = 0;

    memset(pDRList->pHeadArray, 0, nHeadSize);

    pDRList->bColumns = 0;

    return pDRList;
}

/**
 * Funciton: ����DRList ���
  ����:
  pDRList:  DRList ���
  
 return value 
 
**/
void
DestoryDRList(DRList * pDRList)
{
    free(pDRList);
}

const char *
DRList_GetError(DRList * pDRList)
{
    return EE(pDRList);
}

const char *
DRList_ColName(DRList * pDRList, size_t nCol)
{
    return pDRList->pHeadArray[nCol].sColName;
}

const DRListCol *
DRList_GetCol(DRList * pDRList, size_t nCol)
{
    return pDRList->pHeadArray + nCol;
}

/**
 * Funciton: ���������������
  ����:
  pDRList:  DRList ���
  
 return value 
 
**/
void
DRList_Reset(DRList * pDRList)
{
    DRListCol *pHead;
    int i;

    assert(pDRList != NULL);

    pDRList->iError = 0;

    pDRList->pFreeBuf = pDRList->pBuffer;
    pDRList->iLeftBufSize = pDRList->iBufferSize;
    pDRList->iError = 0;

    pHead = pDRList->pHeadArray;
    pDRList->bColumns = 0;
    for (i = 0; i < pDRList->bMaxCols; ++i, ++pHead) {
        pHead->bDataIsSet = FALSE;
        pHead->bColIsSet = FALSE;
    }
}

static int
DRList_PrintCol(const DRListCol * pHead,
                int (*pfnPrintf) (const char *fmt, ...))
{
    switch (pHead->bDataType) {
        case DRL_DT_INT32:
            pfnPrintf("DRL_DT_INT32: %d\n", *(int32_t *) pHead->pData);
            break;
        case DRL_DT_INT16:
            pfnPrintf("DRL_DT_INT16: %d\n", *(int16_t *) pHead->pData);
            break;
        case DRL_DT_CHAR:
            pfnPrintf("DRL_DT_CHAR: %c\n", *(char *) pHead->pData);
            break;
        case DRL_DT_STR:
            pfnPrintf("DRL_DT_STR: [%.*s]\n",
                      pHead->iDataSize, (char *) pHead->pData);
            break;
        case DRL_DT_BINARY:{
            char *p = pHead->pData;
            int i;
            pfnPrintf("DRL_DT_BINARY:\n");
            for (i = 0; i < pHead->iDataSize; ++i, ++p) {
                pfnPrintf(" %02x", *p);
                if (i > 0 && i % 40 == 0) {
                    pfnPrintf("\n");
                }
            }
            pfnPrintf("\n");

            break;
        }
        case DRL_DT_INT32_ARRAY:{
            int32_t *p = pHead->pData;
            int i;
            pfnPrintf("DRL_DT_INT32_ARRAY: ");
            for (i = 0; i < pHead->iArrayElms; ++i, ++p) {
                pfnPrintf(" %d,", *p);
            }
            pfnPrintf("\n");
            break;
        }
        case DRL_DT_INT16_ARRAY:{
            int16_t *p = pHead->pData;
            int i;
            pfnPrintf("DRL_DT_INT16_ARRAY: ");
            for (i = 0; i < pHead->iArrayElms; ++i, ++p) {
                pfnPrintf(" %d,", *p);
            }
            pfnPrintf("\n");
            break;
        }
        default:
            pfnPrintf("unknown data type: %d\n", pHead->bDataType);
    }

    return 0;
}

int
DRList_Print(const DRList * pDRList, int (*pfnPrintf) (const char *fmt, ...))
{
    DRListCol *pHead;
    int i;

    assert(pDRList != NULL);

    pfnPrintf("bColumns==%d\n", pDRList->bColumns);
    pfnPrintf("iBufferSize==%d\n", pDRList->iBufferSize);
    pfnPrintf("iError==%d\n", pDRList->iError);

    pHead = pDRList->pHeadArray;
    for (i = 0; i < pDRList->bColumns; ++i, ++pHead) {
        if (pHead->bColIsSet && pHead->bDataIsSet) {
            pfnPrintf("%d: %s: ", i, pHead->sColName);
            DRList_PrintCol(pHead, pfnPrintf);
        }
        /*
           else{
           pfnPrintf("col%d:  bColIsSet==%d, bDataIsSet==%d\n",
           i,
           pHead->bColIsSet,
           pHead->bDataIsSet);
           }
         */
    }

    return 0;
}

// �����ֶ��������ֶ��±�
size_t
GetColNoByName(DRList * pDRList, const char *sColName)
{
    DRListCol *pHead = pDRList->pHeadArray;
    size_t i;

    for (i = 0; i < pDRList->bColumns; ++i, ++pHead) {
        if (strcasecmp(pHead->sColName, sColName) == 0) {
            return i;
        }
    }

    // �Ҳ���
    return DRLIST_MAX_COLS;
}

/**
 * Funciton: �����ֶε�����
  ����:
  pDRList:  DRList ���
  bDataType:  ��������
  iArrayElms:  ����������������ʱ�����Ԫ�ظ���
  			���������͵��ֶβ�������
  
 return value 0: �ɹ�
 		!= 0: ʧ��
**/
int
DRList_SetColType(DRList * pDRList,
                  const char *sColName, char bDataType, size_t nDataSize)
{
    DRListCol *pHead;
    int iAlignSize = 0;
    size_t nCol;

    assert(pDRList != NULL);

    nCol = GetColNoByName(pDRList, sColName);
    if (nCol < DRLIST_MAX_COLS) {
        snprintf(EE(pDRList), EESIZE(pDRList), "Col(%s) already set",
                 sColName);
        return DRL_ERR_COLUMN;
    }

    if (pDRList->bColumns >= pDRList->bMaxCols) {
        snprintf(EE(pDRList), EESIZE(pDRList), "Too many cols(MaxCols==%d)",
                 pDRList->bMaxCols);
        return DRL_ERR_COLUMN;
    }

    pHead = pDRList->pHeadArray + pDRList->bColumns;
    pHead->bDataType = bDataType;
    pHead->bColIsSet = TRUE;
    strncpy(pHead->sColName, sColName, sizeof(pHead->sColName));
    pHead->sColName[sizeof(pHead->sColName) - 1] = '\0';

    switch (bDataType) {
        case DRL_DT_INT32:
            pHead->iDataSize = sizeof(int32_t);
            iAlignSize = 4;
            break;
        case DRL_DT_INT16:
            pHead->iDataSize = sizeof(int16_t);
            pHead->iArrayElms = 1;
            iAlignSize = 2;
            break;
        case DRL_DT_CHAR:
            pHead->iDataSize = sizeof(char);
            pHead->iArrayElms = 1;
            break;
        case DRL_DT_STR:
            pHead->iDataSize = nDataSize;
            pHead->iArrayElms = nDataSize;
            break;
        case DRL_DT_BINARY:
            pHead->iDataSize = nDataSize;
            pHead->iArrayElms = nDataSize;
            break;
        case DRL_DT_INT32_ARRAY:
            pHead->iDataSize = nDataSize;
            pHead->iArrayElms = nDataSize / sizeof(int32_t);
            iAlignSize = 4;
            break;
        case DRL_DT_INT16_ARRAY:
            pHead->iDataSize = nDataSize;
            pHead->iArrayElms = nDataSize / sizeof(int16_t);
            iAlignSize = 2;
            break;

        default:
            pHead->bColIsSet = FALSE;
            pDRList->iError = DRL_ERR_DATA_TYPE;
            snprintf(EE(pDRList), EESIZE(pDRList),
                     "Unkown DataType: %d", bDataType);
            return DRL_ERR_DATA_TYPE;
    }

    if (iAlignSize > 1) {
        /* ���� */
        size_t nMod = (size_t) pDRList->pFreeBuf % (size_t) iAlignSize;
        if (nMod != 0) {
            pDRList->pFreeBuf += nMod;
            pDRList->iLeftBufSize -= nMod;
        }
    }
    if (pDRList->iLeftBufSize < pHead->iDataSize) {
        pDRList->iError = DRL_ERR_NO_ENOUGH_BUF;
        snprintf(EE(pDRList), EESIZE(pDRList),
                 "Buffer size %d too small(Col==%s, Size==%d)",
                 pDRList->iBufferSize, sColName, nDataSize);
        return DRL_ERR_NO_ENOUGH_BUF;
    }
    pHead->pData = pDRList->pFreeBuf;
    pDRList->pFreeBuf += pHead->iDataSize;
    pDRList->iLeftBufSize -= pHead->iDataSize;
    ++pDRList->bColumns;

    return 0;
}

/**
 * Funciton: ��ѯ�ֶε�����
  ����:
  pDRList:  DRList ���
  iCol:  �ֶα��
  bDataType:  ��������
  iElmSize:  ��������
  iArrayElms:  ����������������ʱ�����Ԫ�ظ���
  			���������͵��ֶβ�������
  
 return value 0: �ɹ�
 		!= 0: ʧ��
**/
int
DRList_GetColType(DRList * pDRList,
                  const char *sColName, char *bDataType, size_t * nDataSize)
{
    DRListCol *pHead;
    size_t nCol;

    assert(pDRList != NULL);

    nCol = GetColNoByName(pDRList, sColName);
    if (nCol >= DRLIST_MAX_COLS) {
        snprintf(EE(pDRList), EESIZE(pDRList), "Invalid col: %d", nCol);
        return DRL_ERR_COLUMN;
    }

    pHead = pDRList->pHeadArray + nCol;
    if (pHead->bColIsSet) {
        pDRList->iError = DRL_ERR_COL_IS_SET;
        snprintf(EE(pDRList), EESIZE(pDRList), "Col %d not set", nCol);
        return DRL_ERR_COL_IS_SET;
    }

    *bDataType = pHead->bDataType;
    *nDataSize = pHead->iDataSize;

    return 0;
}

#define CHECK_DR_LIST(pDRList, pHead, sColName, bDataType, nCol) \
do{\
	nCol = GetColNoByName(pDRList, sColName);\
	if (nCol >= DRLIST_MAX_COLS){\
		snprintf(EE(pDRList), EESIZE(pDRList), "Invalid col: %s", sColName);\
		return DRL_ERR_COLUMN;\
	}\
	pHead = pDRList->pHeadArray + nCol;\
	if (!pHead->bColIsSet){\
		snprintf(EE(pDRList), EESIZE(pDRList), "Col %s not set", sColName);\
		return DRL_ERR_COL_ISNOT_SET;\
	}\
	if (pHead->bDataType != bDataType){\
		snprintf(EE(pDRList), EESIZE(pDRList), "Invalid DataType(col==%s): %d -- %d",\
			sColName, pHead->bDataType, bDataType);\
		return DRL_ERR_DATA_TYPE;\
	}\
}while(0)

/**
 * Funciton: �����ֶε�����
  ����:
  pDRList:  DRList ���
  iCol:  �ֶα��
  iValue:  ����
  
 return value 0: �ɹ�
 		!= 0: ʧ��
**/
int
DRList_SetInt32(DRList * pDRList, const char *sColName, int32_t iValue)
{
    DRListCol *pHead;
    char bDataType = DRL_DT_INT32;
    size_t nCol;

    CHECK_DR_LIST(pDRList, pHead, sColName, bDataType, nCol);
    *((int32_t *) pHead->pData) = iValue;
    pHead->bDataIsSet = TRUE;

    return 0;
}

int
DRList_SetInt16(DRList * pDRList, const char *sColName, int16_t iValue)
{
    DRListCol *pHead;
    char bDataType = DRL_DT_INT16;
    size_t nCol;

    CHECK_DR_LIST(pDRList, pHead, sColName, bDataType, nCol);
    *((int16_t *) pHead->pData) = iValue;
    pHead->bDataIsSet = TRUE;

    return 0;
}

int
DRList_SetChar(DRList * pDRList, const char *sColName, char cValue)
{
    DRListCol *pHead;
    char bDataType = DRL_DT_CHAR;
    size_t nCol;

    CHECK_DR_LIST(pDRList, pHead, sColName, bDataType, nCol);
    *((char *) pHead->pData) = cValue;
    pHead->bDataIsSet = TRUE;

    return 0;
}

int
DRList_SetStr(DRList * pDRList, const char *sColName, const char *sStr)
{
    DRListCol *pHead;
    char bDataType = DRL_DT_STR;
    size_t nCol;

    CHECK_DR_LIST(pDRList, pHead, sColName, bDataType, nCol);
    strncpy(pHead->pData, sStr, pHead->iDataSize);
    ((char *) pHead->pData)[pHead->iDataSize - 1] = '\0';
    pHead->bDataIsSet = TRUE;

    return 0;
}

int
DRList_SetBinary(DRList * pDRList, const char *sColName, const void *vBufer)
{
    DRListCol *pHead;
    char bDataType = DRL_DT_BINARY;
    size_t nCol;

    CHECK_DR_LIST(pDRList, pHead, sColName, bDataType, nCol);
    memcpy(pHead->pData, vBufer, pHead->iDataSize);
    pHead->bDataIsSet = TRUE;

    return 0;
}

int
DRList_SetInt32Array(DRList * pDRList, const char *sColName,
                     const int32_t * pArray)
{
    DRListCol *pHead;
    char bDataType = DRL_DT_INT32_ARRAY;
    size_t nCol;

    CHECK_DR_LIST(pDRList, pHead, sColName, bDataType, nCol);
    memcpy(pHead->pData, pArray, pHead->iDataSize);
    pHead->bDataIsSet = TRUE;

    return 0;
}

int
DRList_SetInt16Array(DRList * pDRList, const char *sColName,
                     const int16_t * pArray)
{
    DRListCol *pHead;
    char bDataType = DRL_DT_INT16_ARRAY;
    size_t nCol;

    CHECK_DR_LIST(pDRList, pHead, sColName, bDataType, nCol);
    memcpy(pHead->pData, pArray, pHead->iDataSize);
    pHead->bDataIsSet = TRUE;

    return 0;
}

/**
 * Funciton: ��ȡ �ֶε�����
  ����:
  pDRList:  DRList ���
  iCol:  �ֶα��
  piValue:  ����ָ��
  
 return value 0: �ɹ�
 		!= 0: ʧ��
**/
int
DRList_GetInt32(DRList * pDRList, const char *sColName, int32_t * piValue)
{
    DRListCol *pHead;
    char bDataType = DRL_DT_INT32;
    size_t nCol;

    CHECK_DR_LIST(pDRList, pHead, sColName, bDataType, nCol);
    *piValue = *(int32_t *) pHead->pData;

    return 0;
}

int
DRList_GetInt16(DRList * pDRList, const char *sColName, int16_t * piValue)
{
    DRListCol *pHead;
    char bDataType = DRL_DT_INT16;
    size_t nCol;

    CHECK_DR_LIST(pDRList, pHead, sColName, bDataType, nCol);
    *piValue = *(int16_t *) pHead->pData;

    return 0;
}

int
DRList_GetChar(DRList * pDRList, const char *sColName, char *pcValue)
{
    DRListCol *pHead;
    char bDataType = DRL_DT_CHAR;
    size_t nCol;

    CHECK_DR_LIST(pDRList, pHead, sColName, bDataType, nCol);
    *pcValue = *(char *) pHead->pData;

    return 0;
}

int
DRList_GetStr(DRList * pDRList, const char *sColName,
              char *sStr, size_t nSize)
{
    DRListCol *pHead;
    char bDataType = DRL_DT_STR;
    size_t nCol;

    CHECK_DR_LIST(pDRList, pHead, sColName, bDataType, nCol);
    if (nSize > (size_t) pHead->iDataSize) {
        nSize = pHead->iDataSize;
    }
    strncpy(sStr, pHead->pData, nSize);
    sStr[nSize - 1] = '\0';

    return 0;
}

int
DRList_GetBinary(DRList * pDRList, const char *sColName, void *vBufer)
{
    DRListCol *pHead;
    char bDataType = DRL_DT_BINARY;
    size_t nCol;

    CHECK_DR_LIST(pDRList, pHead, sColName, bDataType, nCol);
    memcpy(vBufer, pHead->pData, pHead->iDataSize);

    return 0;
}

int
DRList_GetInt32Array(DRList * pDRList, const char *sColName, int32_t * pArray)
{
    DRListCol *pHead;
    char bDataType = DRL_DT_INT32_ARRAY;
    size_t nCol;

    CHECK_DR_LIST(pDRList, pHead, sColName, bDataType, nCol);
    memcpy(pArray, pHead->pData, pHead->iDataSize);

    return 0;
}

int
DRList_GetInt16Array(DRList * pDRList, const char *sColName, int16_t * pArray)
{
    DRListCol *pHead;
    char bDataType = DRL_DT_INT16_ARRAY;
    size_t nCol;

    CHECK_DR_LIST(pDRList, pHead, sColName, bDataType, nCol);
    memcpy(pArray, pHead->pData, pHead->iDataSize);

    return 0;
}

static int DRL_VERSION = 1;

typedef struct _PACKAGE_HEAD PACKAGE_HEAD;
struct _PACKAGE_HEAD
{
    char sLen[4];
    char sVersion[4];
    unsigned char bColNum;
    char sColNameListLen[4];
    char sNameList[1];          /* not actualy 1 bytes */
};

typedef struct _PACKAGE_BODY PACKAGE_BODY;
struct _PACKAGE_BODY
{
    char bDataType;
    char sDataLen[4];
    char sData[1];              /* not actualy 1 bytes */
};

#define DR_PUT_INT32(dest, src, tmp32) \
*tmp32 = htonl(*(int32_t *)src); memcpy(dest, tmp32, sizeof(int32_t));

#define DR_PUT_INT16(dest, src, tmp16) \
*tmp16 = htons(*(int16_t *)src); memcpy(dest, tmp16, sizeof(int16_t));

/**
 * Funciton: ��DRList �����ݱ���������ֽڷ�ʽ�İ�
  ����:
  pDRList:  DRList ���
  sBuffer:  ���������İ�
  iMaxBufSize:  ��������ֽ���
  piBufSize:  �����ֽ���
  
 return value 0: �ɹ�
 		!= 0: ʧ��
**/
int
DRList_Encode(DRList * pDRList, void *sBuffer,
              size_t iMaxBufSize, size_t * piBufSize)
{
    size_t iLeftBufSize = iMaxBufSize;
    char *p = (char *) sBuffer;
    PACKAGE_HEAD *h = (PACKAGE_HEAD *) p;
    PACKAGE_BODY *pBody;
    DRListCol *pHead;
    int32_t tmp32;
    int16_t tmp16;
    int iPackLen;
    unsigned char bColNum;
    int iNameListLen;
    size_t i;

    if (iLeftBufSize < sizeof(PACKAGE_HEAD)) {
        /* ���ݲ����� */
        snprintf(EE(pDRList), EESIZE(pDRList),
                 "Buffer size %d too small", pDRList->iBufferSize);
        return DRL_ERR_NO_ENOUGH_BUF;
    }

    // ����head
    iLeftBufSize -= sizeof(PACKAGE_HEAD) - 1;
    h->bColNum = pDRList->bColumns;
    DR_PUT_INT32(h->sVersion, &DRL_VERSION, &tmp32);
    iLeftBufSize -= sizeof(PACKAGE_HEAD);

    iNameListLen = 0;
    h->sNameList[0] = '\0';
    for (i = 0; i < pDRList->bColumns; ++i) {
        int iLen;
        DRListCol *pCol = &pDRList->pHeadArray[i];
        if (i == 0) {
            iLen = snprintf(h->sNameList + iNameListLen,
                            iLeftBufSize, "%s", pCol->sColName);
        }
        else {
            iLen = snprintf(h->sNameList + iNameListLen,
                            iLeftBufSize, ",%s", pCol->sColName);
        }
        iNameListLen += iLen;
        iLeftBufSize -= iLen;
    }
    ++iNameListLen;             // ĩβ��0
    DR_PUT_INT32(h->sColNameListLen, &iNameListLen, &tmp32);

    // ����body
    pBody =
        (PACKAGE_BODY *) ((char *) sBuffer + sizeof(PACKAGE_HEAD) - 1 +
                          iNameListLen);
    for (bColNum = 0; bColNum < pDRList->bColumns;
         ++bColNum, pBody =
         (PACKAGE_BODY *) (pBody->sData + pHead->iDataSize)) {
        pHead = pDRList->pHeadArray + bColNum;
        if (pHead->bColIsSet && pHead->bDataIsSet) {
            iLeftBufSize -= sizeof(PACKAGE_BODY) + pHead->iDataSize - 1;
            if (iLeftBufSize < 0) {
                /* ���ݲ����� */
                snprintf(EE(pDRList), EESIZE(pDRList),
                         "Buffer size %d too small", pDRList->iBufferSize);
                return DRL_ERR_NO_ENOUGH_BUF;
            }

            pBody->bDataType = pHead->bDataType;
            DR_PUT_INT32(pBody->sDataLen, &pHead->iDataSize, &tmp32);

            switch (pHead->bDataType) {
                case DRL_DT_INT32:
                    DR_PUT_INT32(pBody->sData, pHead->pData, &tmp32);
                    break;
                case DRL_DT_INT16:
                    DR_PUT_INT16(pBody->sData, pHead->pData, &tmp16);
                    break;
                case DRL_DT_CHAR:
                    *(char *) pBody->sData = *(char *) pHead->pData;
                    break;
                case DRL_DT_STR:
                    strncpy(pBody->sData, pHead->pData, pHead->iDataSize);
                    break;
                case DRL_DT_BINARY:
                    memcpy(pBody->sData, pHead->pData, pHead->iDataSize);
                    break;
                case DRL_DT_INT32_ARRAY:{
                    int32_t *pSrc = (int32_t *) pHead->pData;
                    int32_t *pDest = (int32_t *) pBody->sData;
                    int i;
                    for (i = 0; i < pHead->iArrayElms; ++i, ++pSrc, ++pDest) {
                        DR_PUT_INT32(pDest, pSrc, &tmp32);
                    }
                    break;
                }
                case DRL_DT_INT16_ARRAY:{
                    int16_t *pSrc = (int16_t *) pHead->pData;
                    int16_t *pDest = (int16_t *) pBody->sData;
                    int i;
                    for (i = 0; i < pHead->iArrayElms; ++i, ++pSrc, ++pDest) {
                        DR_PUT_INT16(pDest, pSrc, &tmp16);
                    }
                    break;
                }
                default:
                    pDRList->iError = DRL_ERR_DATA_TYPE;
                    snprintf(EE(pDRList), EESIZE(pDRList),
                             "Invalid DataType: %d", pHead->bDataType);
                    return DRL_ERR_DATA_TYPE;
            }

        }
    }

    iPackLen = iMaxBufSize - iLeftBufSize;
    DR_PUT_INT32(h->sLen, &iPackLen, &tmp32);
    *piBufSize = iPackLen;

    return 0;
}

#define DR_GET_INT32(dest, src) \
memcpy(dest, src, sizeof(int32_t));\
*(int32_t *)(dest) = ntohl(*(int32_t *)(dest));

#define DR_GET_INT16(dest, src) \
memcpy(dest, src, sizeof(int16_t));\
*(int16_t *)(dest) = ntohs(*(int16_t *)(dest));

int
DRList_Decode(DRList * pDRList, const void *sBuffer, int iBufSize)
{
    const char *p = (const char *) sBuffer;
    const PACKAGE_HEAD *h = (const PACKAGE_HEAD *) p;
    const PACKAGE_BODY *pBody;
    const char *pBufEnd = (const char *) sBuffer + iBufSize;

    DRListCol *pHead;
    int32_t iDataLen;
    int iColCount;
    int32_t iNameListLen;
    int i;

    if (iBufSize < sizeof(PACKAGE_HEAD)) {
        snprintf(EE(pDRList), EESIZE(pDRList),
                 "BufSize(%d) too small", iBufSize);
        return -1;
    }

    DRList_Reset(pDRList);

    // ��װhead
    if (h->bColNum > DRLIST_MAX_COLS || h->bColNum > pDRList->bMaxCols) {
        snprintf(EE(pDRList), EESIZE(pDRList),
                 "too many cols: %d", h->bColNum);
        return -1;
    }

    // �����ֶ���
    iColCount = GetNameListColNum(h->sNameList);
    iColCount = GetNameListColName(h->sNameList,
                                   pDRList->pHeadArray, iColCount);
    pDRList->bColumns = 0;


    // ���ø����ֶε�ֵ
    DR_GET_INT32(&iNameListLen, h->sColNameListLen);
    pBody =
        (const PACKAGE_BODY *) ((const char *) sBuffer +
                                sizeof(PACKAGE_HEAD) + iNameListLen - 1);
    for (i = 0, pHead = pDRList->pHeadArray; i < iColCount;
         ++i, ++pHead, pBody = (PACKAGE_BODY *) (pBody->sData + iDataLen)) {
        if ((char *) pBody >= pBufEnd) {
            break;
        }

        if (pBufEnd - (char *) pBody < sizeof(PACKAGE_BODY)) {
            snprintf(EE(pDRList), EESIZE(pDRList),
                     "package is too smal(%d)", pBufEnd - (char *) pBody);
            return -1;
        }

        DR_GET_INT32(&iDataLen, pBody->sDataLen);
        if (pBufEnd - pBody->sData < iDataLen) {
            /* ���ݳ��Ȳ��� */
            snprintf(EE(pDRList), EESIZE(pDRList),
                     "DataLen of col %s wrong: %d", pHead->sColName,
                     iDataLen);
            return -1;
        }

        if (DRList_SetColType(pDRList, pHead->sColName,
                              pBody->bDataType, iDataLen) != 0) {
            return -1;
        }
        switch (pBody->bDataType) {
            case DRL_DT_INT32:
                DR_GET_INT32(pHead->pData, pBody->sData);
                break;
            case DRL_DT_INT16:
                DR_GET_INT16(pHead->pData, pBody->sData);
                break;
            case DRL_DT_CHAR:
                *(char *) pHead->pData = *(char *) pBody->sData;
                break;
            case DRL_DT_STR:
                strncpy(pHead->pData, pBody->sData, iDataLen);
                break;
            case DRL_DT_BINARY:
                memcpy(pHead->pData, pBody->sData, iDataLen);
                break;
            case DRL_DT_INT32_ARRAY:{
                int32_t *pSrc = (int32_t *) pBody->sData;
                int32_t *pDest = (int32_t *) pHead->pData;
                int i;
                for (i = 0; i < pHead->iArrayElms; ++i, ++pSrc, ++pDest) {
                    DR_GET_INT32(pDest, pSrc);
                }
                break;
            }
            case DRL_DT_INT16_ARRAY:{
                int16_t *pSrc = (int16_t *) pBody->sData;
                int16_t *pDest = (int16_t *) pHead->pData;
                int i;
                for (i = 0; i < pHead->iArrayElms; ++i, ++pSrc, ++pDest) {
                    DR_GET_INT16(pDest, pSrc);
                }
                break;
            }
            default:
                pDRList->iError = DRL_ERR_DATA_TYPE;
                snprintf(EE(pDRList), EESIZE(pDRList),
                         "Invalid DataType: %d", pBody->bDataType);
                return DRL_ERR_DATA_TYPE;
        }
        pHead->bDataIsSet = TRUE;
    }

    return 0;
}
