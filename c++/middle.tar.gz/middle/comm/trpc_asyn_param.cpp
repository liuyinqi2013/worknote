/*
    ����
        1   �������첽���յ�ʱ��Ĳ���
            ��¼����ȥ�Ĳ����ͷ��صĽ��
            
Created by verminniu, 2007-9
Change list:

*/


#include "trpc_asyn_param.h"

TrpcAsynRecvParam::~TrpcAsynRecvParam()
{
    Clear();
}

void 
TrpcAsynRecvParam::Clear()
{    
    for(iterator it = Begin();it != End(); ++it)
    {
        Erase(it);
    }
    _AsynRecvParamMap.clear();
}


int 
TrpcAsynRecvParam::CheckSocketIsOk(TrpcRealInfo_T * pHnd)
{
    
    if( pHnd == NULL ){
        return -1;
    }

    if( pHnd->pSock == NULL ){
        return -2;
    }

    if( !pHnd->pSock->socket_is_ok() ){
        return -3;
    }

    return 0;
}

int 
TrpcAsynRecvParam::InitData(iterator it)
{
    (it->second).pData = new char [MAX_TRPC_DATA_LEN];

    (it->second).bIsInitData = true;
    
    return 0;
}


char * 
TrpcAsynRecvParam::getData(iterator it)
{  
    if(IsInitData(it)){
        return (it->second).pData;
    }

    InitData(it);
    
    return (it->second).pData;
}

char * 
TrpcAsynRecvParam::getData(TRPC_INFO * pHnd)
{
    iterator it=Find(pHnd);
    
    return getData(it);
}


int 
TrpcAsynRecvParam::InsertTrpcInfo(TRPC_INFO * pHnd)
{
    TrpcRealInfo_T * pTmpHnd = (TrpcRealInfo_T *)pHnd;
    int iRet = 0;

    // ����Ѿ������ɼ�����handle�������Ŀ
    if( _AsynRecvParamMap.size() >= (unsigned)_iMaxHandles ){
        sprintf(_error_text, "Too many Handles");
        return -1;
    }

    //socket is not ok
    if((iRet = CheckSocketIsOk(pTmpHnd)) != 0){
        sprintf(_error_text, "Socket is Not OK: ret = %d ", iRet);
        return -1;
    }

    //exist
    if( _AsynRecvParamMap.count(pTmpHnd)){
		Erase(pHnd);
    }
	

    AsynRecvParam& pAsynParam = _AsynRecvParamMap[pTmpHnd];
    
    pAsynParam.pHnd = pTmpHnd;
    pAsynParam.pData = (char *)NULL;
    pAsynParam.iLen = MAX_TRPC_DATA_LEN;
    pAsynParam.iStat = APS_FREE;
    pAsynParam.bIsInitData = false;
	//pAsynParam.tInTime = time(NULL);

    return 0;
}

int 
TrpcAsynRecvParam::DeleteTrpcInfo(TRPC_INFO * pHnd)
{
    return Erase(pHnd);
}

int 
TrpcAsynRecvParam::Erase(TRPC_INFO * pHnd)
{
    TrpcRealInfo_T * pTmpHnd = (TrpcRealInfo_T *)pHnd;

    //not exist
    if(_AsynRecvParamMap.count(pTmpHnd) == 0){
        sprintf(_error_text, "TRPC_INFO handle is not exist ");
        return -1;
    }

    iterator tTmpit = Find(pHnd);
    
    Erase(tTmpit);

    return 0;
}

void 
TrpcAsynRecvParam::Erase(iterator it)
{
    if(IsInitData(it))
    {
        delete (it->second).pData;
        (it->second).pData = NULL;
    }
	
    _AsynRecvParamMap.erase(it);
}

/*
int 
TrpcAsynRecvParam::CheckParamTime(iterator it)
{
	time_t tNow = time(NULL);
	
	if((it->second).tInTime - tNow > _iParamTimeOut)
		return 0;

	return 1;
}


int 
TrpcAsynRecvParam::getTimeOutVec(vector<TRPC_INFO *>& vecTimeOutParam)
{
	for(iterator it = Begin(); it != End(); ++it)
	{
		if(CheckParamTime(it) != 0)
			continue;

		vecTimeOutParam.push_back(getHandle(it));
	}

	return vecTimeOutParam.size();
}
*/
