/*
����:
       1. trpcԶ�̹��̵��ð��Ķ�ӦSocket��


Created by Song, 2003.01-02
Change list:

*/

#include <cstdio>
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>
#include <signal.h>
#include <errno.h>

#include "trpc_client_socket.h"


TrpcClientSocket::TrpcClientSocket()
:  _strIP(),
_iPort(0),
_strUserName(),
_iStatus(STAT_TO_RECV),
_uWaterFlow(0),
_iGetSocketID(0),
_iInDataLen(0),
_iInLeftLen(0),
_bInDataIsNew(true),
_bIsLogin(false),
_bCanAccessAll(false), _iCanAccessAllCount(0), _tLastAccessTime(0)
{
    pthread_mutex_init(&_mutex, NULL);
    _error_text[0] = '\0';

    signal(SIGPIPE, SIG_IGN);
}

TrpcClientSocket::~TrpcClientSocket()
{

}

void
TrpcClientSocket::close()
{
    _bInDataIsNew = true;
    _bIsLogin = false;
    _bCanAccessAll = false;
    Socket::close();
}

/**
 * Funciton:  ��ȡtrpc�İ���buf
  ����:
  
 return value:  0 ���ӹر�
                 1 �������ض���
                 2 ����û����
                 3 ����ʽ����
                 < 0 have error(s)
**/
int
TrpcClientSocket::ReceiveMessage()
{
    int iBytes;

    if (_bInDataIsNew) {
        // һ�δ�5��bytes��������Ļ�������Ҳ̫����
        try {
            iBytes = receive(_sInData, 5);
            if (iBytes == 0) {
                return RECV_CLOSE;
            }
            else if (iBytes != 5) {
                sprintf(_error_text, "iBytes(%d) != 5", iBytes);
                return RECV_FMT_ERROR;
            }
        }
        catch(SocketException & e) {
            if (errno == EWOULDBLOCK || errno == EAGAIN) {
                return RECV_HAVE_MORE;
            }
            else {
                throw e;
            }
        }


        if (_sInData[0] != CTrpcPackage::PACK_STX) {
            sprintf(_error_text, "_sInData[0] == 0x%02x", _sInData[0]);
            return RECV_FMT_ERROR;
        }

        int iLen;
        TRPC_GET_INT32(iLen, _sInData + 1);
        if (iLen < CTrpcPackage::MinPackSize()) {
            sprintf(_error_text, "Len too short: %d < %d",
                    iLen, CTrpcPackage::MinPackSize());
            return RECV_FMT_ERROR;
        }
        else if (iLen > MAX_TRPC_PACKAGE_SIZE) {
            sprintf(_error_text, "Len too large: %d", iLen);
            return RECV_FMT_ERROR;
        }

        _iInDataLen = iBytes;
        _iInLeftLen = iLen - iBytes;
        _bInDataIsNew = false;

    }

    try {
        iBytes = receive(_sInData + _iInDataLen, _iInLeftLen);
        if (iBytes == 0) {
            return RECV_CLOSE;
        }
    }
    catch(SocketException & e) {
        if (errno == EWOULDBLOCK || errno == EAGAIN) {
            return RECV_HAVE_MORE;
        }
        else {
            throw e;
        }
    }

    _iInDataLen += iBytes;
    _iInLeftLen -= iBytes;

    if (_iInLeftLen > 0) {
        return RECV_HAVE_MORE;
    }


    // �յ�һ�������İ�
    _bInDataIsNew = true;
    return RECV_OK;
}

int
TrpcClientSocket::SendMessage(const void *msg, size_t len, int timeout)
{
    const char *buf = (const char *) msg;
    size_t bytes_sent = 0;
    int this_send;

    if (fd() == INVALID_SOCKET){
        sprintf(_error_text, "Invalid Socket fd");
        throw SocketException(_error_text);
    }

    while (bytes_sent < len) {
        do {
            if (timeout > 0) {
                // �ж��Ƿ�ʱ
                fd_set write_fds;
                FD_ZERO(&write_fds);
                FD_SET(fd(), &write_fds);

                timeval stTimeOut;
                stTimeOut.tv_sec = timeout;
                stTimeOut.tv_usec = 0;
                int iRet = select(fd() + 1, (fd_set *) 0, &write_fds,
                                  (fd_set *) 0, &stTimeOut);
                if (iRet == 0) {
                    sprintf(_error_text, "send time out(timeout==%d)",
                            timeout);
                    throw SocketException(_error_text);
                }
                else if (iRet < 0) {
                    sprintf(_error_text, "select: %s", strerror(errno));
                    throw SocketException(_error_text);
                }
            }

            // ����
            this_send = send(buf, len - bytes_sent);
        }
        while ((this_send < 0) && (errno == EINTR));

        if (this_send <= 0) {
            return this_send;
        }
        bytes_sent += this_send;
        buf += this_send;
    }

    return len;
}

int
TrpcClientSocket::Lock()
{
    if (pthread_mutex_lock(&_mutex) != 0) {
        sprintf(_error_text, "pthread_mutex_lock: %s", strerror(errno));
        throw SocketException(_error_text);
    }
    return 0;
}

int
TrpcClientSocket::UnLock()
{
    if (pthread_mutex_unlock(&_mutex) != 0) {
        sprintf(_error_text, "pthread_mutex_unlock: %s", strerror(errno));
        throw SocketException(_error_text);
    }
    return 0;
}

void
TrpcClientSocket::GenerateSocketID()
{
    struct timeval tval;
    gettimeofday(&tval, NULL);
    srand(tval.tv_sec * tval.tv_usec * getpid());

    _iGetSocketID = rand() * 1861;      // �����һ������
    _iGetSocketID *= rand();
}
