#include <stdio.h>
#include <string.h>

#include "trpc_error.h"

const char *g_sTrpcErrors[TRPC_ERROR_NUM] = {
    "",                         // 0
    "System error",             // 1
    "Invalid package head",     // 2
    "Invalid package body",     // 3
    "Invalid package",          // 4
    "Call service before login",// 5
    "Invalid msgtype",          // 6
    "Access denied for user",   // 7
    "Unfound Service",          // 8
    "No Service in Server",     // 9
    "Access denied for servicve",       // 10
    "Recursive calling",        // 11
    "Too many nest ipc_call",   // 12
    "Invalid olen",             // 13
    "Calling timeout",           // 14
    "System busy",				// 15
    "Server stoped",            // 16
    "Packet too old",            // 17
    "Asyn call error",            // 18
    "Error call error"            // 19
};

// ������Ϣ��������
const int g_sTrpcErrorsLen[TRPC_ERROR_NUM] = {
    sizeof(""),                         // 0
    sizeof("System error"),             // 1
    sizeof("Invalid package head"),     // 2
    sizeof("Invalid package body"),     // 3
    sizeof("Invalid package"),          // 4
    sizeof("Call service before login"),        // 5
    sizeof("Invalid msgtype"),          // 6
    sizeof("Access denied for user"),   // 7
    sizeof("Unfound Service"),          // 8
    sizeof("No Service in Server"),          // 9
    sizeof("Access denied for servicve"),       // 10
    sizeof("Recursive calling"),        // 11
    sizeof("Too many nest ipc_call"),   // 12
    sizeof("Invalid olen"),             // 13
    sizeof("Calling timeout"),           // 14
    sizeof("System busy"),				// 15
    sizeof("Server stoped"),            // 16
    sizeof("Packet too old"),           // 17
    sizeof("Asyn call error"),           // 18
    sizeof("Error call error")            // 19  
};

TRPC_EXPORT const char *
trpc_strerror(int errnum)
{
    static char error_text[256];
    if (errnum < 0 || errnum >= TRPC_ERROR_NUM) {
        snprintf(error_text, sizeof(error_text), "unkown errornum==%d", errnum);
        return error_text;
    }

    return g_sTrpcErrors[errnum];
}

TRPC_EXPORT const int
trpc_strerror_len(int errnum)
{
    if (errnum < 0 || errnum >= TRPC_ERROR_NUM)
        return 0;

    return g_sTrpcErrorsLen[errnum];
}

